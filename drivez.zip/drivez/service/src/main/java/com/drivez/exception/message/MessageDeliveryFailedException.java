package com.drivez.exception.message;

public class MessageDeliveryFailedException extends MessageException {
	private static final long serialVersionUID = -8229196452907180213L;

	public MessageDeliveryFailedException(String message, Throwable cause) {
		super(message, cause);
	}

	public MessageDeliveryFailedException(String message) {
		super(message);
	}

	public MessageDeliveryFailedException(Throwable cause) {
		super(cause);
	}

}
