package com.drivez.exception.security;

import com.drivez.exception.DriveZGenericException;

public class SystemUserNotFoundException extends DriveZGenericException {
	private static final long serialVersionUID = -2717040416903952852L;

	public SystemUserNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public SystemUserNotFoundException(String message) {
		super(message);
	}

	public SystemUserNotFoundException(Throwable cause) {
		super(cause);
	}

}
