package com.drivez.service.ride;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.drivez.bo.ride.ImageBo;
import com.drivez.bo.ride.OffersBo;
import com.drivez.bo.ride.ServiceAreaBo;
import com.drivez.bo.ride.VehicleModelInfoBo;
import com.drivez.bo.ride.VehicleTypeBo;
import com.drivez.dao.ride.RideDao;
import com.drivez.dto.ride.ImageDto;
import com.drivez.dto.ride.OffersDto;
import com.drivez.dto.ride.RiderHomeDto;
import com.drivez.dto.ride.ServiceAreaDto;
import com.drivez.dto.ride.VehicleModelInfoDto;
import com.drivez.dto.ride.VehicleTypeDto;
import com.drivez.mapper.ride.RideMapper;
import com.drivez.mapper.system.SystemMapper;
import com.drivez.util.DriveZConstants;

@Service
public class RideServiceImpl implements RideService {
	@Autowired
	private RideDao rideDao;

	@Override
	public RiderHomeDto getRiderHome(int cityId) {
		RiderHomeDto riderHomeDto = null;
		List<OffersBo> offersBos = null;
		List<OffersDto> offersDtos = null;
		List<ServiceAreaBo> serviceAreaBos = null;
		List<ServiceAreaDto> serviceAreaDtos = null;
		List<VehicleModelInfoBo> vehicleModelInfoBos = null;
		List<VehicleModelInfoDto> vehicleModelInfoDtos = null;

		riderHomeDto = new RiderHomeDto();
		offersBos = rideDao.getOffers();
		offersDtos = RideMapper.mapOffersBoListToOffersDtoList(offersBos);

		serviceAreaBos = rideDao.getServiceAreasByCity(cityId, DriveZConstants.STATUS_ACTIVE);
		serviceAreaDtos = RideMapper.mapServiceAreaBoListToServiceAreaDtoList(serviceAreaBos);

		vehicleModelInfoBos = rideDao.getMostRentedVehicleModels(cityId, DriveZConstants.STATUS_ACTIVE);
		vehicleModelInfoDtos = RideMapper.mapVehichelModelInfoBoToVehichelModelInfoDto(vehicleModelInfoBos);

		riderHomeDto.setOffersDtos(offersDtos);
		riderHomeDto.setServiceAreaDtos(serviceAreaDtos);
		riderHomeDto.setVehicleModelInfoDtos(vehicleModelInfoDtos);
		
		return riderHomeDto;
	}

	@Override
	public ImageDto getOfferImage(int offerId) {
		ImageBo imageBo = null;
		ImageDto imageDto = null;

		imageBo = rideDao.getOfferImage(offerId);
		imageDto = SystemMapper.mapImageBoToImageDto(imageBo);

		return imageDto;
	}

	@Override
	public ImageDto getVehicleModelImage(int vehicleModelId) {
		ImageBo imageBo = null;
		ImageDto imageDto = null;

		imageBo = rideDao.getVehicleModelImage(vehicleModelId);
		imageDto = SystemMapper.mapImageBoToImageDto(imageBo);

		return imageDto;
	}

	@Override
	public List<VehicleTypeDto> getVehicleTypes() {
		List<VehicleTypeBo> vehicleTypeBos = null;
		
		vehicleTypeBos = rideDao.getVehicleTypes();
		
		return RideMapper.mapVehicleTypeBosToVehicleTypeDtos(vehicleTypeBos);
		
	}
	
	

}
