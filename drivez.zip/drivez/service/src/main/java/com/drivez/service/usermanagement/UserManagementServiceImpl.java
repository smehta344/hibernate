package com.drivez.service.usermanagement;

import static com.drivez.mapper.usermanagement.UserManagementMapper.mapAddressDtoToAddressBo;
import static com.drivez.mapper.usermanagement.UserManagementMapper.mapIdentificationTypeBosToIdentificationTypeDtos;
import static com.drivez.mapper.usermanagement.UserManagementMapper.mapUserDtoToSystemUserBo;
import static com.drivez.util.DriveZConstants.IDENTIFICATION_TYPE_DRIVING_LICENSE;
import static com.drivez.util.DriveZConstants.NOTIFICATION_EMAIL_VERIFICATION_TEMPLATE;
import static com.drivez.util.DriveZConstants.NOTIFICATION_TEXT_VERIFICATION_TEMPLATE;
import static com.drivez.util.DriveZConstants.ROLE_USER_RIDER;
import static com.drivez.util.DriveZConstants.STATUS_USER_IDENTIFICATION_PENDING;
import static com.drivez.util.DriveZConstants.SYSTEM_NOREPLY_EMAIL_ADDRESS;
import static com.drivez.util.DriveZConstants.SYSTEM_USER;
import static com.drivez.util.RandomGenerator.generateOtp;
import static com.drivez.util.RandomGenerator.generateVerificationCode;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.drivez.bo.usermanagement.AddressBo;
import com.drivez.bo.usermanagement.IdentificationTypeBo;
import com.drivez.bo.usermanagement.SystemUserBo;
import com.drivez.bo.usermanagement.SystemUserDetailsBo;
import com.drivez.bo.usermanagement.UserIdentificationBo;
import com.drivez.bo.usermanagement.UserRoleBo;
import com.drivez.dao.usermanagement.UserManagementDao;
import com.drivez.dto.ride.UserDetailsDto;
import com.drivez.dto.usermanagement.AddressDto;
import com.drivez.dto.usermanagement.IdentificationTypeDto;
import com.drivez.dto.usermanagement.UserDto;
import com.drivez.dto.usermanagement.UserIdentificationDetailsDto;
import com.drivez.dto.usermanagement.UserRoleDto;
import com.drivez.exception.usermanagement.AccountAlreadyActivatedException;
import com.drivez.exception.usermanagement.AccountLockedOrDisabledException;
import com.drivez.exception.usermanagement.AccountVerificationFailedException;
import com.drivez.exception.usermanagement.AccountVerificationFailedException.Cause;
import com.drivez.exception.usermanagement.AccountVerificationFailedException.VerificationType;
import com.drivez.logging.DriveZLogger;
import com.drivez.mapper.usermanagement.UserManagementMapper;
import com.drivez.notification.beans.Notification;
import com.drivez.notification.beans.NotificationAttachment;
import com.drivez.notification.beans.NotificationTemplate;
import com.drivez.notification.beans.RichTextNotification;
import com.drivez.notification.facade.NotificationFacade;
import com.drivez.resource.reader.ResourceReader;
import com.drivez.util.DriveZConstants;

@Service
public class UserManagementServiceImpl implements UserManagementService {
	private final static DriveZLogger dLogger = DriveZLogger.getLogger(UserManagementServiceImpl.class);
	@Autowired
	private Environment env;

	@Autowired
	private UserManagementDao userManagementDao;

	@Autowired
	private ResourceReader webAppResourceReader;

	@Autowired
	@Qualifier("richTextNotificationFacade")
	private NotificationFacade richTextNotificationFacade;

	@Autowired
	@Qualifier("textNotificationFacade")
	private NotificationFacade textNotificationFacade;

	@Override
	@Transactional(readOnly = false)
	public int registerRider(UserDto userDto, AddressDto addressDto,
			UserIdentificationDetailsDto userIdentificationDetailsDto) {
		int addressId = 0;
		String otp = null;
		int systemUserId = 0;
		AddressBo addressBo = null;
		UserRoleBo userRoleBo = null;
		String verificationCode = null;
		SystemUserBo systemUserBo = null;
		int drivingLicenseIdentificationTypeId = 0;
		IdentificationTypeBo identificationTypeBo = null;
		UserIdentificationBo userIdentificationBo = null;

		Map<String, Object> bindingData = null;
		NotificationTemplate notificationTemplate = null;
		RichTextNotification richTextNotification = null;
		NotificationAttachment notificationAttachment = null;
		Map<String, List<NotificationAttachment>> notificationAttachments = null;

		Map<String, Object> textBindingData = null;
		NotificationTemplate textNotificationTemplate = null;
		Notification textNotification = null;

		addressBo = mapAddressDtoToAddressBo(addressDto);
		addressBo.setCreatedBy(SYSTEM_USER);
		addressBo.setCreatedDt(new Date());
		addressBo.setLastModifiedBy(SYSTEM_USER);
		addressBo.setLastModifiedDt(new Date());

		addressId = userManagementDao.saveAddress(addressBo);
		dLogger.info("in registerRider() saveAddress() finished with generated addressId {}", addressId);

		systemUserBo = mapUserDtoToSystemUserBo(userDto);
		otp = generateOtp(4);
		verificationCode = generateVerificationCode(12);

		systemUserBo.setMobileOtpNumber(otp);
		systemUserBo.setEmailAddressVerificationCode(verificationCode);
		systemUserBo.setMobileOtpNumberLastGeneratedTimeStamp(new Date());
		systemUserBo.setSystemUserAddressId(addressId);

		userRoleBo = userManagementDao.getUserRole(ROLE_USER_RIDER);
		systemUserBo.setUserRoleId(userRoleBo.getUserRoleId());
		systemUserBo.setStatus(DriveZConstants.STATUS_SYSTEM_USER_REGISTERED);
		systemUserBo.setCreatedBy(SYSTEM_USER);
		systemUserBo.setCreatedDt(new Date());
		systemUserBo.setLastModifiedBy(SYSTEM_USER);
		systemUserBo.setLastModifiedDt(new Date());

		systemUserId = userManagementDao.saveSystemUser(systemUserBo);
		dLogger.info("saved system user with systemUserId {} ", systemUserId);

		// store driving license of the user as 1 st identity
		identificationTypeBo = userManagementDao.getIdentificationType(IDENTIFICATION_TYPE_DRIVING_LICENSE);
		drivingLicenseIdentificationTypeId = identificationTypeBo.getIdentificationTypeId();
		userIdentificationBo = newUserIdentificationBo(systemUserId, drivingLicenseIdentificationTypeId,
				userIdentificationDetailsDto.getDrivingLicenseNo(),
				userIdentificationDetailsDto.getDrivingLicenseIssuedAuthority(), STATUS_USER_IDENTIFICATION_PENDING);
		userManagementDao.saveUserIdentification(userIdentificationBo);
		dLogger.debug("saved drivingLicense Identification details");

		// save 2nd identity of the user
		userIdentificationBo = newUserIdentificationBo(systemUserId,
				userIdentificationDetailsDto.getIdentificationTypeId(),
				userIdentificationDetailsDto.getIdentificationValue(),
				userIdentificationDetailsDto.getIdentificationIssuedAuthority(), STATUS_USER_IDENTIFICATION_PENDING);
		userManagementDao.saveUserIdentification(userIdentificationBo);
		dLogger.debug("saved 2nd Identity details");

		notificationAttachment = new NotificationAttachment();
		notificationAttachment.setContentId("logo");
		notificationAttachment.setData(webAppResourceReader.getResource("/WEB-INF/images/icons/logo.png"));
		notificationAttachment.setDataType("image/png");
		notificationAttachments = new HashMap<>();
		notificationAttachments.put("logo", Arrays.asList(new NotificationAttachment[] { notificationAttachment }));

		bindingData = new HashMap<String, Object>();
		bindingData.put("user", userDto.getDisplayName());
		bindingData.put("userId", systemUserId);
		bindingData.put("verificationCode", verificationCode);
		bindingData.put("RIDER_WEB_URI", env.getProperty("RIDER_WEB_URI"));

		notificationTemplate = new NotificationTemplate();
		notificationTemplate.setBindingData(bindingData);
		notificationTemplate.setTemplateName(NOTIFICATION_EMAIL_VERIFICATION_TEMPLATE);

		richTextNotification = new RichTextNotification();
		richTextNotification.setFrom(SYSTEM_NOREPLY_EMAIL_ADDRESS);
		richTextNotification.setTo(new String[] { userDto.getEmailAddress() });
		richTextNotification.setSubject("rider email verification");
		richTextNotification.setAttachments(notificationAttachments);

		richTextNotificationFacade.notify(richTextNotification, notificationTemplate);
		dLogger.debug("rich text email verification message sent");

		textBindingData = new HashMap<>();
		textBindingData.put("otp", otp);
		textNotificationTemplate = new NotificationTemplate();
		textNotificationTemplate.setBindingData(textBindingData);
		textNotificationTemplate.setTemplateName(NOTIFICATION_TEXT_VERIFICATION_TEMPLATE);

		textNotification = new Notification();
		textNotification.setTo(new String[] { userDto.getMobileNumber() });

		textNotificationFacade.notify(textNotification, textNotificationTemplate);
		dLogger.debug("text notification has been sent");

		return systemUserId;
	}

	@Override
	@Transactional(readOnly = true)
	public boolean isUserExists(final String emailAddress) {
		return userManagementDao.isUserExistsWithEmailAddress(emailAddress);
	}

	@Override
	@Transactional(readOnly = true)
	public List<IdentificationTypeDto> getIdentificationTypes() {
		List<IdentificationTypeBo> identificationTypeBos = null;
		List<IdentificationTypeDto> identificationTypeDtos = null;

		identificationTypeBos = userManagementDao.getIdentificationTypes();
		if (identificationTypeBos != null && identificationTypeBos.size() > 0) {
			identificationTypeDtos = mapIdentificationTypeBosToIdentificationTypeDtos(identificationTypeBos);
		}

		return identificationTypeDtos;
	}

	@Override
	public void verifyUserEmailAddress(int systemUserId, String verificationCode) {
		SystemUserBo bo = null;

		bo = userManagementDao.getSystemUser(systemUserId);
		if (bo.getStatus().hashCode() == DriveZConstants.STATUS_SYSTEM_USER_ACTIVATED.hashCode()) {
			throw new AccountAlreadyActivatedException(systemUserId, "account already active");
		} else if (bo.getStatus().hashCode() == DriveZConstants.STATUS_SYSTEM_USER_LOCKED.hashCode()
				|| bo.getStatus().hashCode() == DriveZConstants.STATUS_SYSTEM_USER_DISABLED.hashCode()) {
			throw new AccountLockedOrDisabledException(systemUserId,
					"account locked or disabled, unable to activate the account");
		} else if (bo.getIsEmailVerified() == DriveZConstants.ACCOUNT_EMAIL_OR_OTP_VERIFIED_STATUS) {
			throw new AccountVerificationFailedException(systemUserId, "email address already verified",
					VerificationType.EMAIL_ADDRESS, Cause.ALREADY_VERIFIED);
		} else if (bo.getEmailAddressVerificationCode().equals(verificationCode) == false) {
			throw new AccountVerificationFailedException(systemUserId, "email address mis-match",
					VerificationType.EMAIL_ADDRESS, Cause.MISMATCH);
		}

		userManagementDao.updateEmailVerifiedStatus(systemUserId, DriveZConstants.ACCOUNT_EMAIL_OR_OTP_VERIFIED_STATUS);
		dLogger.debug("email verification status has been verified");

		if (bo.getIsMobileNumberVerified() == DriveZConstants.ACCOUNT_EMAIL_OR_OTP_VERIFIED_STATUS) {
			dLogger.debug("systemUser {} has been activated", systemUserId);
			userManagementDao.updateSystemUserStatus(systemUserId, DriveZConstants.STATUS_SYSTEM_USER_ACTIVATED);
		}
	}

	public void verifyMobileNumber(int systemUserId, String otp) {
		SystemUserBo bo = null;

		bo = userManagementDao.getSystemUser(systemUserId);
		if (bo.getStatus().hashCode() == DriveZConstants.STATUS_SYSTEM_USER_ACTIVATED.hashCode()) {
			throw new AccountAlreadyActivatedException(systemUserId, "account already active");
		} else if (bo.getStatus().hashCode() == DriveZConstants.STATUS_SYSTEM_USER_LOCKED.hashCode()
				|| bo.getStatus().hashCode() == DriveZConstants.STATUS_SYSTEM_USER_DISABLED.hashCode()) {
			throw new AccountLockedOrDisabledException(systemUserId,
					"account locked or disabled, unable to activate the account");
		} else if (bo.getIsMobileNumberVerified() == DriveZConstants.ACCOUNT_EMAIL_OR_OTP_VERIFIED_STATUS) {
			throw new AccountVerificationFailedException(systemUserId, "mobile number already verified",
					VerificationType.MOBILE, Cause.ALREADY_VERIFIED);
		} else if (bo.getMobileOtpNumber().equals(otp) == false) {
			throw new AccountVerificationFailedException(systemUserId, "mobile number otp mis-match",
					VerificationType.MOBILE, Cause.MISMATCH);
		}

		userManagementDao.updateMobileVerifiedStatus(systemUserId,
				DriveZConstants.ACCOUNT_EMAIL_OR_OTP_VERIFIED_STATUS);
		dLogger.debug("email verification status has been verified");

		if (bo.getIsEmailVerified() == DriveZConstants.ACCOUNT_EMAIL_OR_OTP_VERIFIED_STATUS) {
			dLogger.debug("systemUser {} has been activated", systemUserId);
			userManagementDao.updateSystemUserStatus(systemUserId, DriveZConstants.STATUS_SYSTEM_USER_ACTIVATED);
		}
	}

	@Override
	public UserDetailsDto getUserDetails(String emailAddress) {
		UserDetailsDto userDetailsDto = null;
		SystemUserDetailsBo systemUserDetailsBo = null;

		systemUserDetailsBo = userManagementDao.getSystemUserDetails(emailAddress);
		userDetailsDto = UserManagementMapper.mapSystemUserDetailsBoToUserDetailsDto(systemUserDetailsBo);

		return userDetailsDto;
	}

	private final UserIdentificationBo newUserIdentificationBo(int systemUserId, int identificationTypeId,
			String identificationValue, String issuedAuthority, String status) {
		UserIdentificationBo userIdentificationBo = null;

		userIdentificationBo = new UserIdentificationBo();
		userIdentificationBo.setSystemUserId(systemUserId);
		userIdentificationBo.setIdentificationTypeId(identificationTypeId);
		userIdentificationBo.setIdentificationNo(identificationValue);
		userIdentificationBo.setIssuedAuthority(issuedAuthority);
		userIdentificationBo.setStatus(STATUS_USER_IDENTIFICATION_PENDING);
		userIdentificationBo.setCreatedBy(SYSTEM_USER);
		userIdentificationBo.setCreatedDt(new Date());
		userIdentificationBo.setLastModifiedBy(SYSTEM_USER);
		userIdentificationBo.setLastModifiedDt(new Date());
		return userIdentificationBo;
	}
}
