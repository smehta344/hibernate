package com.drivez.exception.usermanagement;

public class AccountVerificationFailedException extends AccountException {
	private static final long serialVersionUID = 8790320299155439286L;
	protected VerificationType verificationType;
	protected Cause failureCause;

	public AccountVerificationFailedException(int systemUserId, String message, VerificationType verificationType,
			Cause failureCause) {
		super(systemUserId, message);
		this.verificationType = verificationType;
		this.failureCause = failureCause;
	}

	public AccountVerificationFailedException(int systemUserId, Throwable e, VerificationType verificationType,
			Cause failureCause) {
		super(systemUserId, e);
		this.verificationType = verificationType;
		this.failureCause = failureCause;
	}

	public enum Cause {
		MISMATCH, ALREADY_VERIFIED
	}

	public enum VerificationType {
		MOBILE, EMAIL_ADDRESS
	}

	public VerificationType getVerificationType() {
		return verificationType;
	}

	public void setVerificationType(VerificationType verificationType) {
		this.verificationType = verificationType;
	}

	public Cause getFailureCause() {
		return failureCause;
	}

	public void setFailureCause(Cause failureCause) {
		this.failureCause = failureCause;
	}

}
