package com.drivez.dto.ride;

import com.drivez.dto.usermanagement.AddressDto;
import com.drivez.dto.usermanagement.UserDto;
import com.drivez.dto.usermanagement.UserRoleDto;

public class UserDetailsDto extends UserDto {
	protected AddressDto addressDto;
	protected UserRoleDto userRoleDto;

	public AddressDto getAddressDto() {
		return addressDto;
	}

	public void setAddressDto(AddressDto addressDto) {
		this.addressDto = addressDto;
	}

	public UserRoleDto getUserRoleDto() {
		return userRoleDto;
	}

	public void setUserRoleDto(UserRoleDto userRoleDto) {
		this.userRoleDto = userRoleDto;
	}

}
