package com.drivez.service.javaconfig;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.transaction.jta.JtaTransactionManager;

@Configuration
@PropertySource("classpath:META-INF/global-service.properties")
@ComponentScan(basePackages = { "com.drivez.dao.*" })
@EnableTransactionManagement
public class PersistenceConfig {
	@Autowired
	protected Environment env;

	@Bean
	public DataSource dataSource() {
		DataSource dataSource = null;
		JndiDataSourceLookup jndiDataSourceLookup = null;

		jndiDataSourceLookup = new JndiDataSourceLookup();
		dataSource = jndiDataSourceLookup.getDataSource(env.getProperty("dataSourceJndiName"));
		System.out.println("database initialized..");

		return dataSource;
	}

	@Bean
	public JtaTransactionManager transactionManager() {
		return new JtaTransactionManager();
	}

	@Bean(autowire = Autowire.BY_TYPE)
	public JdbcTemplate jdbcTemplate() {
		return new JdbcTemplate();
	}
}
