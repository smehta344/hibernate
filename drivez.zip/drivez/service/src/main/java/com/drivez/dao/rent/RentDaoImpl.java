package com.drivez.dao.rent;

import java.sql.PreparedStatement;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.drivez.bo.rent.BookingInformationBo;
import com.drivez.bo.rent.PaymentTrackingBo;
import com.drivez.util.DateHelper;

@Repository
public class RentDaoImpl implements RentDao {
	// sql queries
	private final String SQL_INSERT_BOOKING_INFO = "insert into booking_information(hours, total_amount, booking_service_area_id, status, vehicle_model_id, city_id, customer_id, booking_date, booked_vehichel_id, created_by, created_dt, last_modified_by, last_modified_dt) values(?,?,?,?,?,?,?,?,?,?,?,?,?) ";
	private final String SQL_INSERT_PAYMENT_TRACKING = "insert into payment_tracking(booking_id, customer_id, gateway_nm, mid, status, created_by, created_dt, last_modified_by, last_modified_dt) values(?,?,?,?,?,?,?,?,?) ";
	private final String SQL_UPDATE_PAYMENT_TRACKING = "update payment_tracking set gateway_transaction_id = ?, bank_tx_id = ?, bank_nm = ?, bank_resp_cd = ?, bank_resp_msg = ?, payment_mode = ?, status = ? where payment_tracking_id = ? ";
	private final String SQL_UPDATE_BOOKING_INFO_STATUS_BY_BOOKING_INFO_ID = "update booking_information set status = ? where booking_information_id = ?";
	private final String SQL_GET_PAYMENT_TRACKING_ID_BY_BOOKING_ID_AND_STATUS = "select payment_tracking_id from payment_tracking where booking_id = ? and status = ?";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int saveBookingInfo(final BookingInformationBo bookingInformationBo) {
		int bookingInformationId = 0;
		KeyHolder kh = null;
		int records = 0;

		kh = new GeneratedKeyHolder();
		records = jdbcTemplate.update((connection) -> {
			PreparedStatement pstmt = null;
			pstmt = connection.prepareStatement(SQL_INSERT_BOOKING_INFO, new String[] { "booking_information_id" });
			pstmt.setInt(1, bookingInformationBo.getHours());
			pstmt.setDouble(2, bookingInformationBo.getTotalAmount());
			pstmt.setInt(3, bookingInformationBo.getBookingServiceAreaId());
			pstmt.setString(4, bookingInformationBo.getStatus());
			pstmt.setInt(5, bookingInformationBo.getVehichelModelId());
			pstmt.setInt(6, bookingInformationBo.getCityId());
			pstmt.setInt(7, bookingInformationBo.getCustomerId());
			pstmt.setDate(8, DateHelper.toSqlDate(bookingInformationBo.getBookingDate()));
			pstmt.setInt(9, bookingInformationBo.getBookedVehichelId());
			pstmt.setString(10, bookingInformationBo.getCreatedBy());
			pstmt.setDate(11, DateHelper.toSqlDate(bookingInformationBo.getCreatedDt()));
			pstmt.setString(12, bookingInformationBo.getLastModifiedBy());
			pstmt.setDate(13, DateHelper.toSqlDate(bookingInformationBo.getLastModifiedDt()));

			return pstmt;
		}, kh);

		if (records == 1) {
			bookingInformationId = kh.getKey().intValue();
		}

		return bookingInformationId;
	}

	public int savePaymentTracking(PaymentTrackingBo paymentTrackingBo) {
		int paymentTrackingId = 0;
		KeyHolder kh = null;
		int records = 0;

		kh = new GeneratedKeyHolder();
		records = jdbcTemplate.update((connection) -> {
			PreparedStatement pstmt = null;

			pstmt = connection.prepareStatement(SQL_INSERT_PAYMENT_TRACKING, new String[] { "payment_tracking_id" });
			pstmt.setInt(1, paymentTrackingBo.getBookingId());
			pstmt.setInt(2, paymentTrackingBo.getCustomerId());
			pstmt.setString(3, paymentTrackingBo.getGatewayName());
			pstmt.setString(4, paymentTrackingBo.getMid());
			pstmt.setString(5, paymentTrackingBo.getStatus());
			pstmt.setString(6, paymentTrackingBo.getCreatedBy());
			pstmt.setDate(7, DateHelper.toSqlDate(paymentTrackingBo.getCreatedDt()));
			pstmt.setString(8, paymentTrackingBo.getLastModifiedBy());
			pstmt.setDate(9, DateHelper.toSqlDate(paymentTrackingBo.getLastModifiedDt()));

			return pstmt;
		}, kh);

		if (records == 1) {
			paymentTrackingId = kh.getKey().intValue();
		}

		return paymentTrackingId;
	}

	public void updatePaymentTracking(PaymentTrackingBo paymentTrackingBo) {
		jdbcTemplate.update(SQL_UPDATE_PAYMENT_TRACKING, paymentTrackingBo.getGatewayTransactionId(),
				paymentTrackingBo.getBankTransactionId(), paymentTrackingBo.getBankName(),
				paymentTrackingBo.getBankResponseCode(), paymentTrackingBo.getBankResponseMessage(),
				paymentTrackingBo.getPaymentMode(), paymentTrackingBo.getStatus(),
				paymentTrackingBo.getPaymentTrackingId());
	}

	public void updateBookingInfoStatus(int bookingInformationId, String status) {
		jdbcTemplate.update(SQL_UPDATE_BOOKING_INFO_STATUS_BY_BOOKING_INFO_ID, status, bookingInformationId);
	}

	@Override
	public int getPaymentTrackingId(int bookingInformationId, String status) {
		return jdbcTemplate.queryForObject(SQL_GET_PAYMENT_TRACKING_ID_BY_BOOKING_ID_AND_STATUS, Integer.class,
				bookingInformationId, status);
	}

}
