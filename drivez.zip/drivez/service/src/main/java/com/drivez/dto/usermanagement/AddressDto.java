package com.drivez.dto.usermanagement;

import java.io.Serializable;

public class AddressDto implements Serializable {

	private static final long serialVersionUID = 1L;

	protected int addressId;
	protected String streetAddress;
	protected String areaOrLandMarkAddress;
	protected String cityName;
	protected String stateName;
	protected String countryName;
	protected int zip;

	public int getAddressId() {
		return addressId;
	}

	public void setAddressId(int addressId) {
		this.addressId = addressId;
	}

	public String getStreetAddress() {
		return streetAddress;
	}

	public void setStreetAddress(String streetAddress) {
		this.streetAddress = streetAddress;
	}

	public String getAreaOrLandMarkAddress() {
		return areaOrLandMarkAddress;
	}

	public void setAreaOrLandMarkAddress(String areaOrLandMarkAddress) {
		this.areaOrLandMarkAddress = areaOrLandMarkAddress;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

	public String getCountryName() {
		return countryName;
	}

	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public int getZip() {
		return zip;
	}

	public void setZip(int zip) {
		this.zip = zip;
	}

}
