package com.drivez.resource.listener;

import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.ContextLoaderListener;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import com.drivez.dto.system.CityDto;
import com.drivez.logging.DriveZLogger;
import com.drivez.resource.reader.WebAppResourceReader;
import com.drivez.service.ride.RideService;
import com.drivez.service.system.SystemService;

public class RiderWebApplicationContextListener extends ContextLoaderListener {
	private final static DriveZLogger dLogger = DriveZLogger.getLogger(RiderWebApplicationContextListener.class);
	public static final String SERVLET_CONTEXT_KEY = ServletContext.class.getName();

	public RiderWebApplicationContextListener(WebApplicationContext context) {
		super(context);
	}

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		WebAppResourceReader webAppResourceReader = null;
		ApplicationContext rootApplicationContext = null;
		ServletContext servletContext = null;
		List<CityDto> activeCities = null;
		SystemService systemService = null;

		super.contextInitialized(sce);

		servletContext = sce.getServletContext();

		rootApplicationContext = WebApplicationContextUtils.getWebApplicationContext(servletContext);

		webAppResourceReader = rootApplicationContext.getBean("webAppResourceReader", WebAppResourceReader.class);
		webAppResourceReader.setServletContext(servletContext);

		systemService = rootApplicationContext.getBean("systemServiceImpl", SystemService.class);
		activeCities = systemService.getActiveCities();
		servletContext.setAttribute("activeCities", activeCities);

		dLogger.info("webAppResourceReader initialized..");
	}

}
