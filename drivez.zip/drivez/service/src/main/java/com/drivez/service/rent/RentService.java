package com.drivez.service.rent;

import com.drivez.dto.rent.BookingInformationDto;
import com.drivez.dto.rent.PaymentTrackingDto;
import com.drivez.dto.rent.RentInfoDto;

public interface RentService {
	RentInfoDto createRentRequest(BookingInformationDto bookingInformationDto, PaymentTrackingDto paymentTrackingDto);

	void updateRentStatus(int bookingInformationId, PaymentTrackingDto paymentTrackingDto, String status);
}
