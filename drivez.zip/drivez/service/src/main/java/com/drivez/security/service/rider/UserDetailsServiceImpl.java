package com.drivez.security.service.rider;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.drivez.dto.ride.UserDetailsDto;
import com.drivez.security.bean.UserDetailsImpl;
import com.drivez.service.usermanagement.UserManagementService;

@Service
public class UserDetailsServiceImpl implements UserDetailsService {
	@Autowired
	private UserManagementService userManagementService;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		UserDetailsDto userDetailsDto = null;
		UserDetails userDetails = null;

		try {
			userDetailsDto = userManagementService.getUserDetails(username);
			userDetails = new UserDetailsImpl(userDetailsDto.getUserId(), userDetailsDto.getEmailAddress(),
					userDetailsDto.getPassword(), userDetailsDto.getUserRoleDto().getUserRoleCode(),
					userDetailsDto.getStatus());
		} catch (com.drivez.exception.security.SystemUserNotFoundException e) {
			throw new UsernameNotFoundException("username : " + username + " not available");
		}

		return userDetails;
	}

}
