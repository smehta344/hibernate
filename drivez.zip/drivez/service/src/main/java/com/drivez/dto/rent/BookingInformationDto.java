package com.drivez.dto.rent;

import java.io.Serializable;
import java.util.Date;

public class BookingInformationDto implements Serializable {
	private static final long serialVersionUID = 1L;
	protected int bookingInfoId;
	protected int hours;
	protected double totalAmount;
	protected int bookingServiceAreaId;
	protected String status;
	protected int vehichelModelId;
	protected int cityId;
	protected int customerId;
	protected Date bookingDate;
	protected int bookedVehichelId;
	protected Date createdDt;
	protected String createdBy;
	protected Date lastModifiedDt;
	protected String lastModifiedBy;

	public int getBookingInfoId() {
		return bookingInfoId;
	}

	public void setBookingInfoId(int bookingInfoId) {
		this.bookingInfoId = bookingInfoId;
	}

	public int getHours() {
		return hours;
	}

	public void setHours(int hours) {
		this.hours = hours;
	}

	public double getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}

	public int getBookingServiceAreaId() {
		return bookingServiceAreaId;
	}

	public void setBookingServiceAreaId(int bookingServiceAreaId) {
		this.bookingServiceAreaId = bookingServiceAreaId;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getVehichelModelId() {
		return vehichelModelId;
	}

	public void setVehichelModelId(int vehichelModelId) {
		this.vehichelModelId = vehichelModelId;
	}

	public int getCityId() {
		return cityId;
	}

	public void setCityId(int cityId) {
		this.cityId = cityId;
	}

	public int getCustomerId() {
		return customerId;
	}

	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}

	public Date getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(Date bookingDate) {
		this.bookingDate = bookingDate;
	}

	public int getBookedVehichelId() {
		return bookedVehichelId;
	}

	public void setBookedVehichelId(int bookedVehichelId) {
		this.bookedVehichelId = bookedVehichelId;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getLastModifiedDt() {
		return lastModifiedDt;
	}

	public void setLastModifiedDt(Date lastModifiedDt) {
		this.lastModifiedDt = lastModifiedDt;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

}
