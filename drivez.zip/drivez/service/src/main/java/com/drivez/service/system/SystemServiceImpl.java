package com.drivez.service.system;

import static com.drivez.mapper.system.SystemMapper.mapCityBosToCityDtos;
import static com.drivez.mapper.system.SystemMapper.mapCountryBosToCountryDtos;
import static com.drivez.mapper.system.SystemMapper.mapStateBosToStateDtos;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.drivez.bo.ride.ImageBo;
import com.drivez.bo.system.CityBo;
import com.drivez.bo.system.CountryBo;
import com.drivez.bo.system.StateBo;
import com.drivez.dao.system.SystemDao;
import com.drivez.dto.ride.ImageDto;
import com.drivez.dto.system.CityDto;
import com.drivez.dto.system.CountryDto;
import com.drivez.dto.system.StateDto;
import com.drivez.logging.DriveZLogger;
import com.drivez.mapper.system.SystemMapper;
import com.drivez.util.DriveZConstants;

@Service
public class SystemServiceImpl implements SystemService {

	private final static DriveZLogger dLogger = DriveZLogger.getLogger(SystemServiceImpl.class);

	@Autowired
	private SystemDao systemDao;

	@Override
	public List<CountryDto> getCountries() {
		List<CountryBo> countryBos = null;
		List<CountryDto> countryDtos = null;

		countryBos = systemDao.getCountries();
		if (countryBos != null && countryBos.size() > 0) {
			countryDtos = mapCountryBosToCountryDtos(countryBos);
			if (countryDtos != null) {
				dLogger.debug("mapped {} bos to {} dtos", countryBos.size(), countryDtos.size());
			}
		}

		return countryDtos;
	}

	@Override
	public List<StateDto> getStates(int countryId) {
		List<StateBo> stateBos = null;
		List<StateDto> stateDtos = null;

		stateBos = systemDao.getStates(countryId);
		if (stateBos != null && stateBos.size() > 0) {
			stateDtos = mapStateBosToStateDtos(stateBos);
			if (stateDtos != null) {
				dLogger.debug("mapped {} state bos to {} state dtos for country id {}", stateBos.size(),
						stateDtos.size(), countryId);
			}
		}
		return stateDtos;
	}

	@Override
	public List<CityDto> getCities(int stateId) {
		List<CityBo> cityBos = null;
		List<CityDto> cityDtos = null;

		cityBos = systemDao.getCities(stateId);
		if (cityBos != null && cityBos.size() > 0) {
			cityDtos = mapCityBosToCityDtos(cityBos);
			if (cityDtos != null) {
				dLogger.debug("mapped {} city bos to {} city dtos for state id {}", cityBos.size(), cityDtos.size(),
						stateId);
			}
		}
		return cityDtos;
	}

	@Override
	public ImageDto getCityImage(int cityId) {
		ImageBo imageBo = null;
		ImageDto imageDto = null;

		imageBo = systemDao.getCityImage(cityId);
		imageDto = SystemMapper.mapImageBoToImageDto(imageBo);

		return imageDto;
	}

	@Override
	public List<CityDto> getActiveCities() {
		List<CityBo> cityBos;
		List<CityDto> cityDtos;

		cityBos = systemDao.getCities(DriveZConstants.STATUS_ACTIVE);
		cityDtos = SystemMapper.mapCityBosToCityDtos(cityBos);

		return cityDtos;
	}

	@Override
	public CityDto getCityByCityName(String cityName) {
		CityBo cityBo = null;
		CityDto cityDto = null;

		cityBo = systemDao.getCityByCityName(cityName);
		cityDto = SystemMapper.mapCityBoToCityDto(cityBo);
		return cityDto;
	}

	@Override
	public CityDto getCityByCityId(int cityId) {
		CityBo cityBo = null;
		CityDto cityDto = null;

		cityBo = systemDao.getCityByCityId(cityId);
		cityDto = SystemMapper.mapCityBoToCityDto(cityBo);
		return cityDto;
	}

}
