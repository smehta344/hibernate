package com.drivez.mapper.ride;

import java.util.ArrayList;
import java.util.List;

import com.drivez.bo.ride.OffersBo;
import com.drivez.bo.ride.RiderHomeBo;
import com.drivez.bo.ride.ServiceAreaBo;
import com.drivez.bo.ride.VehicleModelInfoBo;
import com.drivez.bo.ride.VehicleTypeBo;
import com.drivez.dto.ride.OffersDto;
import com.drivez.dto.ride.RiderHomeDto;
import com.drivez.dto.ride.ServiceAreaDto;
import com.drivez.dto.ride.VehicleModelInfoDto;
import com.drivez.dto.ride.VehicleTypeDto;
import com.drivez.dto.system.CityDto;

public class RideMapper {
	public static RiderHomeDto mapRiderHomeBoToRiderHomeDto(RiderHomeBo riderHomeBo) {
		RiderHomeDto riderHomeDto = null;
		CityDto cityDto = null;
		ServiceAreaDto serviceAreaDto = null;
		VehicleModelInfoDto vehicleModelInfoDto = null;
		OffersDto offersDto = null;

		List<ServiceAreaDto> serviceAreaDtos = new ArrayList<>();
		for (ServiceAreaBo serviceAreaBo : riderHomeBo.getServiceAreaBos()) {
			serviceAreaDto = new ServiceAreaDto();
			serviceAreaDto.setCityId(serviceAreaBo.getCityId());
			serviceAreaDto.setServiceAreaId(serviceAreaBo.getServiceAreaId());
			serviceAreaDto.setServiceAreaName(serviceAreaBo.getServiceAreaName());
			serviceAreaDtos.add(serviceAreaDto);
		}

		List<VehicleModelInfoDto> vehicleModelInfoDtos = new ArrayList<>();
		for (VehicleModelInfoBo vehichelModelInfoBo : riderHomeBo.getVehichelModelInfoBos()) {
			vehicleModelInfoDto = new VehicleModelInfoDto();
			vehicleModelInfoDto.setModelName(vehichelModelInfoBo.getModelName());
			vehicleModelInfoDto.setVehicleModelId(vehichelModelInfoBo.getVehicleModelId());
			vehicleModelInfoDtos.add(vehicleModelInfoDto);
		}

		List<OffersDto> offersDtos = new ArrayList<>();
		for (OffersBo offersBo : riderHomeBo.getOffersBos()) {
			offersDto = new OffersDto();
			offersDto.setOfferId(offersBo.getOfferId());
			offersDtos.add(offersDto);
		}

		riderHomeDto = new RiderHomeDto();
		riderHomeDto.setOffersDtos(offersDtos);
		riderHomeDto.setServiceAreaDtos(serviceAreaDtos);
		riderHomeDto.setVehicleModelInfoDtos(vehicleModelInfoDtos);

		return riderHomeDto;

	}

	public static ServiceAreaDto mapServiceAreaBoToServiceAreaDto(ServiceAreaBo serviceAreaBo) {
		ServiceAreaDto serviceAreaDto = null;

		serviceAreaDto = new ServiceAreaDto();
		serviceAreaDto.setCityId(serviceAreaBo.getCityId());
		serviceAreaDto.setServiceAreaId(serviceAreaBo.getServiceAreaId());
		serviceAreaDto.setServiceAreaName(serviceAreaBo.getServiceAreaName());

		return serviceAreaDto;
	}

	public static OffersDto mapOffersBoToOffersDto(OffersBo offersBo) {
		OffersDto offersDto = null;

		offersDto = new OffersDto();
		offersDto.setOfferId(offersBo.getOfferId());

		return offersDto;
	}

	public static VehicleModelInfoDto mapVehichelModelInfoBoToVehichelModelInfoDto(
			VehicleModelInfoBo vehichelModelInfoBo) {
		VehicleModelInfoDto vehicleModelInfoDto = null;

		vehicleModelInfoDto = new VehicleModelInfoDto();
		vehicleModelInfoDto.setVehicleModelId(vehichelModelInfoBo.getVehicleModelId());
		vehicleModelInfoDto.setModelName(vehichelModelInfoBo.getModelName());

		return vehicleModelInfoDto;
	}
	
	public static List<ServiceAreaDto> mapServiceAreaBoListToServiceAreaDtoList(List<ServiceAreaBo> serviceAreaBos) {
		List<ServiceAreaDto> serviceAreaDtos = null;
		ServiceAreaDto serviceAreaDto = null;
		
		serviceAreaDtos = new ArrayList<>();
		for (ServiceAreaBo serviceAreaBo : serviceAreaBos) {
			serviceAreaDto = new ServiceAreaDto();
			serviceAreaDto.setCityId(serviceAreaBo.getCityId());
			serviceAreaDto.setServiceAreaId(serviceAreaBo.getServiceAreaId());
			serviceAreaDto.setServiceAreaName(serviceAreaBo.getServiceAreaName());
			serviceAreaDtos.add(serviceAreaDto);
		}

		return serviceAreaDtos;
	}

	public static List<OffersDto> mapOffersBoListToOffersDtoList(List<OffersBo> offersBos) {
		OffersDto offersDto = null;

		List<OffersDto> offersDtos = new ArrayList<>();
		for (OffersBo offersBo : offersBos) {
			offersDto = new OffersDto();
			offersDto.setOfferId(offersBo.getOfferId());
			offersDtos.add(offersDto);
		}

		return offersDtos;
	}

	public static List<VehicleModelInfoDto> mapVehichelModelInfoBoToVehichelModelInfoDto(List<VehicleModelInfoBo> vehichelModelInfoBos) {
		VehicleModelInfoDto vehicleModelInfoDto = null;
		
		List<VehicleModelInfoDto> vehicleModelInfoDtos = new ArrayList<>();
		for (VehicleModelInfoBo vehichelModelInfoBo : vehichelModelInfoBos) {
			vehicleModelInfoDto = new VehicleModelInfoDto();
			vehicleModelInfoDto.setModelName(vehichelModelInfoBo.getModelName());
			vehicleModelInfoDto.setVehicleModelId(vehichelModelInfoBo.getVehicleModelId());
			vehicleModelInfoDtos.add(vehicleModelInfoDto);
		}

		return vehicleModelInfoDtos;
	}
	
	public static List<VehicleTypeDto> mapVehicleTypeBosToVehicleTypeDtos(List<VehicleTypeBo> vehicleTypeBos){
		VehicleTypeDto vehicleTypeDto = null;
		
		List<VehicleTypeDto> vehicleTypeDtos = new ArrayList<>();
		for (VehicleTypeBo vehicleTypeBo: vehicleTypeBos) {
			vehicleTypeDto = new VehicleTypeDto();
			vehicleTypeDto.setVehicleTypeId(vehicleTypeBo.getVehicleTypeId());
			vehicleTypeDto.setVehicleTypeName(vehicleTypeBo.getVehicleTypeName());
			vehicleTypeDtos.add(vehicleTypeDto);
		}
		
		return vehicleTypeDtos;
	}

}
