package com.drivez.service.javaconfig;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.ui.velocity.VelocityEngineFactoryBean;

import com.drivez.message.formatter.VelocityMessageFormatter;

@Configuration
@ComponentScan(basePackageClasses = { VelocityMessageFormatter.class })
@PropertySource("classpath:META-INF/velocity.properties")
@SuppressWarnings("deprecation")
public class MessageFormatterConfig {
	@Autowired
	private Environment env;

	@Bean
	public VelocityEngineFactoryBean velocityEngine() {
		VelocityEngineFactoryBean velocityEngineFactoryBean = null;
		Properties velocityProperties = null;

		velocityEngineFactoryBean = new VelocityEngineFactoryBean();
		velocityProperties = new Properties();

		velocityProperties.put("resource.loader", env.getProperty("resource.loader"));
		velocityProperties.put("file.resource.loader.class", env.getProperty("file.resource.loader.class"));
		velocityProperties.put("file.resource.loader.path", env.getProperty("file.resource.loader.path"));
		velocityProperties.put("file.resource.loader.cache", env.getProperty("file.resource.loader.cache"));

		velocityEngineFactoryBean.setVelocityProperties(velocityProperties);

		return velocityEngineFactoryBean;
	}

}
