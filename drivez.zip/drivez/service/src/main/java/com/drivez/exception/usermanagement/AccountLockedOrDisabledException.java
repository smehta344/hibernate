package com.drivez.exception.usermanagement;

public class AccountLockedOrDisabledException extends AccountException {
	private static final long serialVersionUID = -7813488728211719418L;

	public AccountLockedOrDisabledException(int systemUserId, String message, Throwable cause) {
		super(systemUserId, message, cause);
	}

	public AccountLockedOrDisabledException(int systemUserId, String message) {
		super(systemUserId, message);
	}

	public AccountLockedOrDisabledException(int systemUserId, Throwable cause) {
		super(systemUserId, cause);
	}

}
