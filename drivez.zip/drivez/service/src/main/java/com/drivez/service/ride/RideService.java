package com.drivez.service.ride;

import java.util.List;

import com.drivez.dto.ride.ImageDto;
import com.drivez.dto.ride.RiderHomeDto;
import com.drivez.dto.ride.VehicleTypeDto;

public interface RideService {

	RiderHomeDto getRiderHome(int cityId);

	ImageDto getOfferImage(int offerId);

	ImageDto getVehicleModelImage(int vehicleModelId);
	
	List<VehicleTypeDto> getVehicleTypes();
}
