package com.drivez.dto.rent;

public class RentInfoDto {
	protected int bookingInformationId;
	protected int paymentTrackingId;

	public RentInfoDto(int bookingInformationId, int paymentTrackingId) {
		super();
		this.bookingInformationId = bookingInformationId;
		this.paymentTrackingId = paymentTrackingId;
	}

	public int getBookingInformationId() {
		return bookingInformationId;
	}

	public void setBookingInformationId(int bookingInformationId) {
		this.bookingInformationId = bookingInformationId;
	}

	public int getPaymentTrackingId() {
		return paymentTrackingId;
	}

	public void setPaymentTrackingId(int paymentTrackingId) {
		this.paymentTrackingId = paymentTrackingId;
	}

}
