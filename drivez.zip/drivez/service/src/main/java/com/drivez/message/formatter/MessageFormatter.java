package com.drivez.message.formatter;

import java.util.Map;

public interface MessageFormatter {
	String merge(String templateName, Map<String, Object> bindingData);
}
