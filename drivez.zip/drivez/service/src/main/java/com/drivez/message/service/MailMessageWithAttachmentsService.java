package com.drivez.message.service;

import javax.mail.internet.MimeMessage;
import javax.mail.util.ByteArrayDataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.MailException;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.mail.javamail.MimeMessagePreparator;
import org.springframework.stereotype.Component;

import com.drivez.exception.message.MessageDeliveryFailedException;
import com.drivez.message.beans.Attachment;
import com.drivez.message.beans.MailMessageWithAttachments;
import com.drivez.message.beans.Message;

@Component
public class MailMessageWithAttachmentsService implements MessageService {
	@Autowired
	private JavaMailSenderImpl javaMailSenderImpl;

	@Override
	public void message(Message message) {
		MailMessageWithAttachments messageWithAttachments = null;

		messageWithAttachments = (MailMessageWithAttachments) message;
		try {
			javaMailSenderImpl.send(new MessageWithAttachmentsPreparator(messageWithAttachments));
		} catch (MailException e) {
			throw new MessageDeliveryFailedException("failed to send email", e);
		}

	}

	private final class MessageWithAttachmentsPreparator implements MimeMessagePreparator {
		private MailMessageWithAttachments messageWithAttachments;

		public MessageWithAttachmentsPreparator(MailMessageWithAttachments messageWithAttachments) {
			this.messageWithAttachments = messageWithAttachments;
		}

		@Override
		public void prepare(MimeMessage mimeMessage) throws Exception {
			MimeMessageHelper mimeMessageHelper = null;

			mimeMessageHelper = new MimeMessageHelper(mimeMessage, true);
			mimeMessageHelper.setFrom(messageWithAttachments.getFrom());

			// either of them or all will be available check condition before setting
			if (messageWithAttachments.getTo() != null && messageWithAttachments.getTo().length > 0) {
				mimeMessageHelper.setTo(messageWithAttachments.getTo());
			}
			if (messageWithAttachments.getCc() != null && messageWithAttachments.getCc().length > 0) {
				mimeMessageHelper.setCc(messageWithAttachments.getCc());
			}
			if (messageWithAttachments.getBcc() != null && messageWithAttachments.getBcc().length > 0) {
				mimeMessageHelper.setBcc(messageWithAttachments.getBcc());
			}
			mimeMessageHelper.setSubject(messageWithAttachments.getSubject());
			mimeMessageHelper.setText(messageWithAttachments.getContent(), true);

			for (Attachment attachment : messageWithAttachments.getAttachments()) {
				mimeMessageHelper.addInline(attachment.getContentId(),
						new ByteArrayDataSource(attachment.getData(), attachment.getDataType()));
			}
		}
	}
}
