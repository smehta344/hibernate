package com.drivez.dto.usermanagement;

import java.io.Serializable;

public class IdentificationTypeDto implements Serializable {

	private static final long serialVersionUID = 1L;

	protected int identificationTypeId;
	protected String identificationTypeName;

	public int getIdentificationTypeId() {
		return identificationTypeId;
	}

	public void setIdentificationTypeId(int identificationTypeId) {
		this.identificationTypeId = identificationTypeId;
	}

	public String getIdentificationTypeName() {
		return identificationTypeName;
	}

	public void setIdentificationTypeName(String identificationTypeName) {
		this.identificationTypeName = identificationTypeName;
	}

}
