package com.drivez.service.usermanagement;

import java.util.List;

import com.drivez.dto.ride.UserDetailsDto;
import com.drivez.dto.usermanagement.AddressDto;
import com.drivez.dto.usermanagement.IdentificationTypeDto;
import com.drivez.dto.usermanagement.UserDto;
import com.drivez.dto.usermanagement.UserIdentificationDetailsDto;

public interface UserManagementService {
	int registerRider(UserDto userDto, AddressDto addressDto,
			UserIdentificationDetailsDto userIdentificationDetailsDto);

	boolean isUserExists(String emailAddress);

	List<IdentificationTypeDto> getIdentificationTypes();

	void verifyUserEmailAddress(int systemUserId, String verificationCode);

	void verifyMobileNumber(int systemUserId, String otp);

	UserDetailsDto getUserDetails(String emailAddress);
}
