package com.drivez.dao.rent;

import com.drivez.bo.rent.BookingInformationBo;
import com.drivez.bo.rent.PaymentTrackingBo;

public interface RentDao {
	int saveBookingInfo(BookingInformationBo bookingInformationBo);

	int savePaymentTracking(PaymentTrackingBo paymentTrackingBo);

	void updatePaymentTracking(PaymentTrackingBo paymentTrackingBo);

	void updateBookingInfoStatus(int bookingInformationId, String status);
	
	int getPaymentTrackingId(int bookingInformationId, String status);
}
