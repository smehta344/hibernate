package com.drivez.exception.resource.reader;

import com.drivez.exception.DriveZGenericException;

public class ResourceReaderException extends DriveZGenericException {
	private static final long serialVersionUID = 734792964717378260L;

	public ResourceReaderException(String message, Throwable cause) {
		super(message, cause);
	}

	public ResourceReaderException(String message) {
		super(message);
	}

	public ResourceReaderException(Throwable cause) {
		super(cause);
	}

}
