package com.drivez.mapper.rent;

import com.drivez.bo.rent.BookingInformationBo;
import com.drivez.bo.rent.PaymentTrackingBo;
import com.drivez.dto.rent.BookingInformationDto;
import com.drivez.dto.rent.PaymentTrackingDto;

public class RentMapper {
	public static PaymentTrackingBo mapPaymentTrackingDtotoPaymentTrackingBo(PaymentTrackingDto paymentTrackingDto) {
		PaymentTrackingBo paymentTrackingBo=null;
		
		paymentTrackingBo = new PaymentTrackingBo();
		paymentTrackingBo.setBookingId(paymentTrackingDto.getBookingId());
		paymentTrackingBo.setPaymentTrackingId(paymentTrackingDto.getPaymentTrackingId());
		paymentTrackingBo.setCustomerId(paymentTrackingDto.getCustomerId());
		paymentTrackingBo.setGatewayTransactionId(paymentTrackingDto.getGatewayTransactionId());
		paymentTrackingBo.setBankTransactionId(paymentTrackingDto.getBankTransactionId());
		paymentTrackingBo.setBankName(paymentTrackingDto.getBankName());
		paymentTrackingBo.setBankResponseCode(paymentTrackingDto.getBankResponseCode());
		paymentTrackingBo.setGatewayName(paymentTrackingDto.getGatewayName());
		paymentTrackingBo.setPaymentMode(paymentTrackingDto.getPaymentMode());
		paymentTrackingBo.setMid(paymentTrackingDto.getMid());
		paymentTrackingBo.setStatus(paymentTrackingDto.getStatus());
		paymentTrackingBo.setCreatedBy(paymentTrackingDto.getCreatedBy());
		paymentTrackingBo.setCreatedDt(paymentTrackingDto.getCreatedDt());
		paymentTrackingBo.setLastModifiedBy(paymentTrackingDto.getLastModifiedBy());
		paymentTrackingBo.setLastModifiedDt(paymentTrackingDto.getLastModifiedDt());
		
		return paymentTrackingBo;
		
	}
	
	public static BookingInformationBo mapBokinginformationDtotoBookingInformationBo(BookingInformationDto bookingInformationDto) {
		BookingInformationBo bookingInformationBo = null;
		
		bookingInformationBo = new BookingInformationBo();
		bookingInformationBo.setBookingInfoId(bookingInformationDto.getBookingInfoId());
		bookingInformationBo.setHours(bookingInformationDto.getHours());
		bookingInformationBo.setTotalAmount(bookingInformationDto.getTotalAmount());
		bookingInformationBo.setBookingServiceAreaId(bookingInformationDto.getBookingServiceAreaId());
		bookingInformationBo.setStatus(bookingInformationDto.getStatus());
		bookingInformationBo.setVehichelModelId(bookingInformationDto.getVehichelModelId());
		bookingInformationBo.setCityId(bookingInformationDto.getCityId());
		bookingInformationBo.setCustomerId(bookingInformationDto.getCustomerId());
		bookingInformationBo.setBookingDate(bookingInformationDto.getBookingDate());
		bookingInformationBo.setBookedVehichelId(bookingInformationDto.getBookedVehichelId());
		bookingInformationBo.setCreatedBy(bookingInformationDto.getCreatedBy());
		bookingInformationBo.setCreatedDt(bookingInformationDto.getCreatedDt());
		bookingInformationBo.setLastModifiedBy(bookingInformationDto.getLastModifiedBy());
		bookingInformationBo.setLastModifiedDt(bookingInformationDto.getLastModifiedDt());
		
		return bookingInformationBo;
	}
}
