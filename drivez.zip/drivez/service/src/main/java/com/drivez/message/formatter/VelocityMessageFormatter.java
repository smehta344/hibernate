package com.drivez.message.formatter;

import java.io.StringWriter;
import java.util.Map;

import org.apache.velocity.Template;
import org.apache.velocity.VelocityContext;
import org.apache.velocity.app.VelocityEngine;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class VelocityMessageFormatter implements MessageFormatter {
	@Autowired
	private VelocityEngine velocityEngine;

	@Override
	public String merge(String templateName, Map<String, Object> bindingData) {
		VelocityContext velocityContext = null;
		StringWriter writer = null;
		Template template = null;

		writer = new StringWriter();
		template = velocityEngine.getTemplate(templateName);
		velocityContext = new VelocityContext();
		for (String key : bindingData.keySet()) {
			velocityContext.put(key, bindingData.get(key));
		}
		template.merge(velocityContext, writer);

		return writer.toString();
	}
}
