package com.drivez.message.service;

import org.springframework.stereotype.Component;

import com.drivez.logging.DriveZLogger;
import com.drivez.message.beans.Message;

@Component
public class LogTextMessageService implements MessageService {
	private final static DriveZLogger dLogger = DriveZLogger.getLogger(LogTextMessageService.class);

	@Override
	public void message(Message message) {
		dLogger.info("message content : " + message.getContent());
	}

}
