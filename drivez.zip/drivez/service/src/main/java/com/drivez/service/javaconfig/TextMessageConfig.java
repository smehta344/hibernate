package com.drivez.service.javaconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.web.client.RestTemplate;

import com.drivez.message.service.TextLocalMessageService;
import com.drivez.notification.facade.TextNotificationFacade;

@Configuration
@PropertySource("classpath:META-INF/text-message-config.properties")
@ComponentScan(basePackageClasses = { TextLocalMessageService.class, TextNotificationFacade.class })
public class TextMessageConfig {

	@Bean
	public RestTemplate textMessageClient() {
		return new RestTemplate();
	}
}
