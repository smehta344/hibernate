package com.drivez.dto.ride;

public class OffersDto {
	protected int offerId;

	public int getOfferId() {
		return offerId;
	}

	public void setOfferId(int offerId) {
		this.offerId = offerId;
	}
}
