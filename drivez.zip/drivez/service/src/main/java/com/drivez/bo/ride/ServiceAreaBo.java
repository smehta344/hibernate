package com.drivez.bo.ride;

import java.io.Serializable;
import java.util.Date;

public class ServiceAreaBo implements Serializable {
	protected int serviceAreaId;
	protected String serviceAreaName;
	protected String description;
	protected String status;
	protected int cityId;
	protected int pickupLocation;
	protected int dropLocation;
	protected Date createdDt;
	protected String createdBy;
	protected Date lastModifiedDt;
	protected String lastModifiedBy;

	public int getServiceAreaId() {
		return serviceAreaId;
	}

	public void setServiceAreaId(int serviceAreaId) {
		this.serviceAreaId = serviceAreaId;
	}

	public String getServiceAreaName() {
		return serviceAreaName;
	}

	public void setServiceAreaName(String serviceAreaName) {
		this.serviceAreaName = serviceAreaName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getCityId() {
		return cityId;
	}

	public void setCityId(int cityId) {
		this.cityId = cityId;
	}

	public int getPickupLocation() {
		return pickupLocation;
	}

	public void setPickupLocation(int pickupLocation) {
		this.pickupLocation = pickupLocation;
	}

	public int getDropLocation() {
		return dropLocation;
	}

	public void setDropLocation(int dropLocation) {
		this.dropLocation = dropLocation;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getLastModifiedDt() {
		return lastModifiedDt;
	}

	public void setLastModifiedDt(Date lastModifiedDt) {
		this.lastModifiedDt = lastModifiedDt;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}
}
