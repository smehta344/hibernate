package com.drivez.dto.system;

import java.io.Serializable;

public class StateDto implements Serializable {

	private static final long serialVersionUID = 1L;

	protected int stateId;
	protected String stateName;

	public int getStateId() {
		return stateId;
	}

	public void setStateId(int stateId) {
		this.stateId = stateId;
	}

	public String getStateName() {
		return stateName;
	}

	public void setStateName(String stateName) {
		this.stateName = stateName;
	}

}
