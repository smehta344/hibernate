package com.drivez.util;

import java.util.Locale;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;

@Component
public class ValidationUtil {

	@Autowired
	private MessageSource messageSource;

	
	
	public boolean isEmpty(String s) {
		if (null == s || s.trim().length() == 0) {
			return true;
		}
		return false;
	}
	
	
}
