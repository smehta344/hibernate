package com.drivez.notification.facade;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.drivez.message.beans.Attachment;
import com.drivez.message.beans.MailMessageWithAttachments;
import com.drivez.message.formatter.MessageFormatter;
import com.drivez.message.service.MailMessageWithAttachmentsService;
import com.drivez.notification.beans.Notification;
import com.drivez.notification.beans.NotificationAttachment;
import com.drivez.notification.beans.NotificationTemplate;
import com.drivez.notification.beans.RichTextNotification;

@Component
public class RichTextNotificationFacade implements NotificationFacade {
	@Autowired
	private MessageFormatter messageFormatter;

	@Autowired
	private MailMessageWithAttachmentsService messageService;

	@Override
	public void notify(Notification notification, NotificationTemplate notificationTemplate) {
		MailMessageWithAttachments messageWithAttachments = null;
		RichTextNotification rtNotification = null;
		Map<String, Object> bindingData = null;
		List<Attachment> attachments = null;
		List<String> groupContentIds = null;
		String content = null;
		Map<String, List<NotificationAttachment>> notificationAttachments = null;

		rtNotification = (RichTextNotification) notification;
		bindingData = new HashMap<>(notificationTemplate.getBindingData());

		attachments = new ArrayList<>();
		notificationAttachments = rtNotification.getAttachments();

		for (String key : notificationAttachments.keySet()) {
			groupContentIds = new ArrayList<>();
			for (NotificationAttachment nAttachment : notificationAttachments.get(key)) {
				groupContentIds.add(nAttachment.getContentId());
				attachments.add(
						new Attachment(nAttachment.getContentId(), nAttachment.getData(), nAttachment.getDataType()));
			}
			if (groupContentIds != null && groupContentIds.size() == 1) {
				bindingData.put(key, groupContentIds.get(0));
			} else {
				bindingData.put(key, groupContentIds);
			}

		}

		content = messageFormatter.merge(notificationTemplate.getTemplateName(), bindingData);

		messageWithAttachments = new MailMessageWithAttachments();
		messageWithAttachments.setFrom(rtNotification.getFrom());
		messageWithAttachments.setTo(rtNotification.getTo());
		messageWithAttachments.setCc(rtNotification.getCc());
		messageWithAttachments.setBcc(rtNotification.getBcc());
		messageWithAttachments.setSubject(rtNotification.getSubject());
		messageWithAttachments.setContent(content);
		messageWithAttachments.setAttachments(attachments);
		messageService.message(messageWithAttachments);
	}

}
