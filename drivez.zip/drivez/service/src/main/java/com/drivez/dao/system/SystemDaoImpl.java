package com.drivez.dao.system;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import com.drivez.bo.ride.ImageBo;
import com.drivez.bo.system.CityBo;
import com.drivez.bo.system.CountryBo;
import com.drivez.bo.system.StateBo;
import com.drivez.logging.DriveZLogger;

@Repository
public class SystemDaoImpl implements SystemDao {
	private final String SQL_GET_COUNTRIES_ORDER_BY_COUNTRY_NM = "select country_id, country_nm, status, created_by, created_dt, last_modified_by, last_modified_dt from country order by country_nm asc";
	private final String SQL_GET_STATES_BY_COUNTRY_ID_ORDER_BY_STATE_NM = "select state_id, state_nm, country_id, status, created_by, created_dt ,last_modified_by, last_modified_dt  from state where country_id = ? order by state_nm asc";
	private final String SQL_GET_CITIES_BY_STATE_ID_ORDER_BY_CITY_NM = "select city_id, city_nm, state_id, status, created_by, created_dt, last_modified_by, last_modified_dt from city where state_id = ? order by city_nm";
	private final String SQL_GET_CITIES_By_STATUS_ORDER_BY_CITY_NM = "select city_id, city_nm, state_id, status, created_by, created_dt, last_modified_by, last_modified_dt from city where status = ? order by city_nm";
	private final String SQL_GET_CITY_IMAGE_BY_CITY_ID = "select city_nm, city_image_data, img_type from city where city_id = ?";
	private final String SQL_GET_CITY_BY_CITY_NM = "select city_id, city_nm, state_id, status, created_by, created_dt, last_modified_by, last_modified_dt from city where city_nm = ?";
	private final String SQL_GET_CITY_BY_CITY_ID = "select city_id, city_nm, state_id, status, created_by, created_dt, last_modified_by, last_modified_dt from city where city_id = ?";

	private final static DriveZLogger dLogger = DriveZLogger.getLogger(SystemDaoImpl.class);
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<CountryBo> getCountries() {
		List<CountryBo> countries = null;

		countries = jdbcTemplate.query(SQL_GET_COUNTRIES_ORDER_BY_COUNTRY_NM, (rs, rowNo) -> {
			CountryBo countryBo = null;

			countryBo = new CountryBo();
			countryBo.setCountryId(rs.getInt(1));
			countryBo.setCountryName(rs.getString(2));
			countryBo.setStatus(rs.getString(3));
			countryBo.setCreatedBy(rs.getString(4));
			countryBo.setCreatedDt(rs.getDate(5));
			countryBo.setLastModifiedBy(rs.getString(6));
			countryBo.setLastModifiedDt(rs.getDate(7));
			return countryBo;
		});
		if (countries != null && countries.size() > 0) {
			dLogger.debug("fetched {} countries from country table", countries.size());
		} else {
			dLogger.warn("no countries found in the country table");
		}

		return countries;
	}

	@Override
	public List<StateBo> getStates(final int countryId) {
		List<StateBo> states = null;

		states = jdbcTemplate.query(SQL_GET_STATES_BY_COUNTRY_ID_ORDER_BY_STATE_NM, (rs, rowNum) -> {
			StateBo stateBo = null;

			stateBo = new StateBo();
			stateBo.setStateId(rs.getInt(1));
			stateBo.setStateName(rs.getString(2));
			stateBo.setCountryId(rs.getInt(3));
			stateBo.setStatus(rs.getString(4));
			stateBo.setCreatedBy(rs.getString(5));
			stateBo.setCreatedDt(rs.getDate(6));
			stateBo.setLastModifiedBy(rs.getString(7));
			stateBo.setLastModifiedDt(rs.getDate(8));

			return stateBo;
		}, countryId);

		if (states != null && states.size() > 0) {
			dLogger.debug("fetched {} states from state table for country id {}", states.size(), countryId);
		} else {
			dLogger.warn("Zero states found for country id {}", countryId);
		}

		return states;
	}

	@Override
	public List<CityBo> getCities(final int stateId) {
		List<CityBo> cities = null;

		cities = jdbcTemplate.query(SQL_GET_CITIES_BY_STATE_ID_ORDER_BY_CITY_NM, new CityRowMapper(), stateId);

		if (cities != null && cities.size() > 0) {
			dLogger.debug("fetched {} cities from city table for stateId {}", cities.size(), stateId);
		} else {
			dLogger.warn("Zero cities found for stateId {}", stateId);
		}

		return cities;
	}

	@Override
	public List<CityBo> getCities(String status) {
		List<CityBo> cities = null;

		cities = jdbcTemplate.query(SQL_GET_CITIES_By_STATUS_ORDER_BY_CITY_NM, new CityRowMapper(), status);

		if (cities != null && cities.size() > 0) {
			dLogger.debug("fetched {} cities from city table for status {}", cities.size(), status);
		} else {
			dLogger.warn("Zero cities found for stateId {}", status);
		}

		return cities;
	}

	@Override
	public ImageBo getCityImage(int cityId) {
		return jdbcTemplate.queryForObject(SQL_GET_CITY_IMAGE_BY_CITY_ID, (rs, rowNum) -> {
			ImageBo image = null;
			image = new ImageBo();
			image.setImageName(rs.getString(1));
			image.setImageData(rs.getBytes(2));
			image.setImageType(rs.getString(3));

			return image;
		}, cityId);
	}

	@Override
	public CityBo getCityByCityName(String cityName) {
		return jdbcTemplate.queryForObject(SQL_GET_CITY_BY_CITY_NM, new CityRowMapper(), cityName);
	}

	@Override
	public CityBo getCityByCityId(int cityId) {
		return jdbcTemplate.queryForObject(SQL_GET_CITY_BY_CITY_ID, new CityRowMapper(), cityId);
	}

	private final class CityRowMapper implements RowMapper<CityBo> {
		@Override
		public CityBo mapRow(ResultSet rs, int rowNum) throws SQLException {
			CityBo cityBo = null;

			cityBo = new CityBo();
			cityBo.setCityId(rs.getInt(1));
			cityBo.setCityName(rs.getString(2));
			cityBo.setStateId(rs.getInt(3));
			cityBo.setStatus(rs.getString(4));
			cityBo.setCreatedBy(rs.getString(5));
			cityBo.setCreatedDt(rs.getDate(6));
			cityBo.setLastModifiedBy(rs.getString(7));
			cityBo.setLastModifiedDt(rs.getDate(8));

			return cityBo;
		}
	}

}
