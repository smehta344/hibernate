package com.drivez.message.service;

import com.drivez.message.beans.Message;

public interface MessageService {
	void message(Message message);
}
