package com.drivez.dao.usermanagement;

import static com.drivez.util.DateHelper.toSqlDate;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.drivez.bo.usermanagement.AddressBo;
import com.drivez.bo.usermanagement.IdentificationTypeBo;
import com.drivez.bo.usermanagement.SystemUserBo;
import com.drivez.bo.usermanagement.SystemUserDetailsBo;
import com.drivez.bo.usermanagement.UserIdentificationBo;
import com.drivez.bo.usermanagement.UserRoleBo;
import com.drivez.exception.security.SystemUserNotFoundException;
import com.drivez.logging.DriveZLogger;

@Repository
public class UserManagementDaoImpl implements UserManagementDao {
	// sql queries
	private final String SQL_SAVE_ADDRESS = "insert into address(address_line1, address_line2, city, state, zip,country, created_by, created_dt, last_modified_by, last_modified_dt) values(?,?,?,?,?,?,?,?,?,?)";
	private final String SQL_SAVE_SYSTEM_USER = "insert into system_user(display_nm, email_address, mobile_nbr, password,date_of_birth, gender, user_role, email_address_verification_code, mobile_otp_nbr, mobile_otp_nbr_last_generated_time, is_email_verified, is_mobile_nbr_verified, mobile_nbr_verified_dt, email_address_verified_dt, status, last_logged_in_date, system_user_address_id, created_by, created_dt, last_modified_by, last_modified_dt) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
	private final String SQL_SAVE_USER_IDENTIFICATION = "insert into user_identification(system_user_id, identity_type_id, status, identification_no, issued_authority,created_by, created_dt, last_modified_by, last_modified_dt ) values(?,?,?,?,?,?,?,?,?)";
	private final String SQL_GET_USER_ROLE = "select user_role_id, user_role_cd, description, created_by, created_dt,last_modified_by, last_modified_dt  from user_role where user_role_cd = ?";
	private final String SQL_GET_USER_ROLE_BY_ID = "select user_role_id, user_role_cd, description, created_by, created_dt,last_modified_by, last_modified_dt  from user_role where user_role_id = ?";
	private final String SQL_GET_IDENTIFICATION_TYPE = "select identity_type_id, identity_type_nm, description, created_by, created_dt, last_modified_by, last_modified_dt from identity_type where identity_type_nm = ?";
	private final String SQL_GET_COUNT_OF_SYSTEM_USER_BY_EMAIL_ADDRESS = "select count(1) from system_user where email_address = ?";
	private final String SQL_GET_IDENTIFICATION_TYPES = "select identity_type_id, identity_type_nm, description, created_by, created_dt, last_modified_by, last_modified_dt from identity_type order by identity_type_nm asc";
	private final String SQL_GET_SYSTEM_USER_BY_SYSTEM_USER_ID = "select system_user_id, display_nm, email_address, mobile_nbr, password, date_of_birth, gender, user_role, email_address_verification_code, mobile_otp_nbr, mobile_otp_nbr_last_generated_time, is_email_verified, is_mobile_nbr_verified, mobile_nbr_verified_dt, email_address_verified_dt, status, last_logged_in_date, system_user_address_id, created_by, created_dt, last_modified_by, last_modified_dt from system_user where system_user_id = ?";
	private final String SQL_UPD_EMAIL_VERIFIED_STATUS_BY_SYSTEM_USER_ID = "update system_user set is_email_verified = ? where system_user_id = ?";
	private final String SQL_UPD_MOBILE_NBR_VERIFIED_STATUS_BY_SYSTEM_USER_ID = "update system_user set is_mobile_nbr_verified = ? where system_user_id = ?";
	private final String SQL_UPD_SYSTEM_USER_STATUS_BY_SYSTEM_USER_ID = "update system_user set status = ? where system_user_id = ?";
	private final String SQL_GET_SYSTEM_USER_DETAILS_BY_EMAIL_ADDRESS = "SELECT su.system_user_id, su.display_nm, su.email_address, su.mobile_nbr, su.password,     su.date_of_birth,     su.gender,     su.user_role,     su.email_address_verification_code,     su.mobile_otp_nbr,     su.mobile_otp_nbr_last_generated_time,     su.is_email_verified,     su.is_mobile_nbr_verified,     su.mobile_nbr_verified_dt,     su.email_address_verified_dt,     su.status,     su.last_logged_in_date,     su.system_user_address_id,     su.created_by,     su.created_dt,     su.last_modified_by,     su.last_modified_dt, 	ur.user_role_id,     ur.user_role_cd,     ur.description,     ur.created_by,     ur.created_dt,     ur.last_modified_by,     ur.last_modified_dt, 	a.address_id,     a.address_line1,     a.address_line2,     a.city,     a.state,     a.zip,     a.country,     a.created_by,     a.created_dt,     a.last_modified_by,     a.last_modified_dt     FROM     system_user su         INNER JOIN     address a ON su.system_user_address_id = a.address_id INNER JOIN user_role ur ON su.user_role = ur.user_role_id WHERE su.email_address = ?";

	private static final DriveZLogger dLogger = DriveZLogger.getLogger(UserManagementDaoImpl.class);
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public int saveAddress(final AddressBo addressBo) {
		KeyHolder kh = null;
		int addressId = 0;
		int records = 0;

		kh = new GeneratedKeyHolder();
		records = jdbcTemplate.update((connection) -> {
			PreparedStatement pstmt = null;
			pstmt = connection.prepareStatement(SQL_SAVE_ADDRESS, new String[] { "address_id" });
			pstmt.setString(1, addressBo.getAddressLine1());
			pstmt.setString(2, addressBo.getAddressLine2());
			pstmt.setString(3, addressBo.getCity());
			pstmt.setString(4, addressBo.getState());
			pstmt.setInt(5, addressBo.getZip());
			pstmt.setString(6, addressBo.getCountry());
			pstmt.setString(7, addressBo.getCreatedBy());
			pstmt.setDate(8, new java.sql.Date(addressBo.getCreatedDt().getTime()));
			pstmt.setString(9, addressBo.getLastModifiedBy());
			pstmt.setDate(10, toSqlDate(addressBo.getLastModifiedDt()));
			return pstmt;
		}, kh);

		if (records == 1) { // safe check not to run into unwanted exceptions
			addressId = kh.getKey().intValue();
			dLogger.debug("address has been saved with generated id {} ", addressId);
		}

		return addressId;
	}

	@Override
	public int saveSystemUser(final SystemUserBo systemUserBo) {
		int systemUserId = 0;
		KeyHolder kh = null;
		int records = 0;

		kh = new GeneratedKeyHolder();

		records = jdbcTemplate.update((connection) -> {
			PreparedStatement pstmt = null;

			pstmt = connection.prepareStatement(SQL_SAVE_SYSTEM_USER, new String[] { "system_user_id" });
			pstmt.setString(1, systemUserBo.getDisplayName());
			pstmt.setString(2, systemUserBo.getEmailAddress());
			pstmt.setString(3, systemUserBo.getMobileNumber());
			pstmt.setString(4, systemUserBo.getPassword());
			pstmt.setDate(5, toSqlDate(systemUserBo.getDateOfBirth()));
			pstmt.setString(6, systemUserBo.getGender());
			pstmt.setInt(7, systemUserBo.getUserRoleId());
			pstmt.setString(8, systemUserBo.getEmailAddressVerificationCode());
			pstmt.setString(9, systemUserBo.getMobileOtpNumber());
			pstmt.setDate(10, toSqlDate(systemUserBo.getMobileOtpNumberLastGeneratedTimeStamp()));
			pstmt.setInt(11, systemUserBo.getIsEmailVerified());
			pstmt.setInt(12, systemUserBo.getIsMobileNumberVerified());
			pstmt.setDate(13, toSqlDate(systemUserBo.getMobileNumberVerifiedDate()));
			pstmt.setDate(14, toSqlDate(systemUserBo.getEmailAddressVerifiedDate()));
			pstmt.setString(15, systemUserBo.getStatus());
			pstmt.setDate(16, toSqlDate(systemUserBo.getLastLoggedInDate()));
			pstmt.setInt(17, systemUserBo.getSystemUserAddressId());
			pstmt.setString(18, systemUserBo.getCreatedBy());
			pstmt.setDate(19, toSqlDate(systemUserBo.getCreatedDt()));
			pstmt.setString(20, systemUserBo.getLastModifiedBy());
			pstmt.setDate(21, toSqlDate(systemUserBo.getLastModifiedDt()));

			return pstmt;
		}, kh);
		if (records == 1) {
			systemUserId = kh.getKey().intValue();
			dLogger.debug("systemUser saved with generated systemUserId {} ", systemUserId);
		}

		return systemUserId;
	}

	@Override
	public int saveUserIdentification(final UserIdentificationBo userIdentificationBo) {
		int userIdentificationId = 0;
		KeyHolder kh = null;
		int records = 0;

		kh = new GeneratedKeyHolder();
		records = jdbcTemplate.update((connection) -> {
			PreparedStatement pstmt = null;

			pstmt = connection.prepareStatement(SQL_SAVE_USER_IDENTIFICATION,
					new String[] { "user_identification_id" });
			pstmt.setInt(1, userIdentificationBo.getSystemUserId());
			pstmt.setInt(2, userIdentificationBo.getIdentificationTypeId());
			pstmt.setString(3, userIdentificationBo.getStatus());
			pstmt.setString(4, userIdentificationBo.getIdentificationNo());
			pstmt.setString(5, userIdentificationBo.getIssuedAuthority());
			pstmt.setString(6, userIdentificationBo.getCreatedBy());
			pstmt.setDate(7, toSqlDate(userIdentificationBo.getCreatedDt()));
			pstmt.setString(8, userIdentificationBo.getLastModifiedBy());
			pstmt.setDate(9, toSqlDate(userIdentificationBo.getLastModifiedDt()));

			return pstmt;
		}, kh);
		if (records == 1) {
			userIdentificationId = kh.getKey().intValue();
			dLogger.debug("UserIdentification saved with generated userIdentificationId {} ", userIdentificationId);
		}

		return userIdentificationId;
	}

	@Override
	public UserRoleBo getUserRole(String userRoleCode) {
		return jdbcTemplate.queryForObject(SQL_GET_USER_ROLE, (rs, rowNum) -> {
			UserRoleBo userRoleBo = null;

			userRoleBo = new UserRoleBo();
			userRoleBo.setUserRoleId(rs.getInt(1));
			userRoleBo.setUserRoleCode(rs.getString(2));
			userRoleBo.setDescription(rs.getString(3));
			userRoleBo.setCreatedBy(rs.getString(4));
			userRoleBo.setCreatedDt(rs.getDate(5));
			userRoleBo.setLastModifiedBy(rs.getString(6));
			userRoleBo.setLastModifiedDt(rs.getDate(7));
			return userRoleBo;
		}, userRoleCode);
	}

	@Override
	public UserRoleBo getUserRoleByUserRoleId(int userRoleId) {
		return jdbcTemplate.queryForObject(SQL_GET_USER_ROLE_BY_ID, (rs, rowNum) -> {
			UserRoleBo userRoleBo = null;

			userRoleBo = new UserRoleBo();
			userRoleBo.setUserRoleId(rs.getInt(1));
			userRoleBo.setUserRoleCode(rs.getString(2));
			userRoleBo.setDescription(rs.getString(3));
			userRoleBo.setCreatedBy(rs.getString(4));
			userRoleBo.setCreatedDt(rs.getDate(5));
			userRoleBo.setLastModifiedBy(rs.getString(6));
			userRoleBo.setLastModifiedDt(rs.getDate(7));
			return userRoleBo;
		}, userRoleId);
	}

	@Override
	public IdentificationTypeBo getIdentificationType(String identificationType) {
		return jdbcTemplate.queryForObject(SQL_GET_IDENTIFICATION_TYPE, new IdentificationTypeBoMapper(),
				identificationType);
	}

	@Override
	public boolean isUserExistsWithEmailAddress(final String emailAddress) {
		boolean exists = false;
		int count = 0;

		count = jdbcTemplate.queryForObject(SQL_GET_COUNT_OF_SYSTEM_USER_BY_EMAIL_ADDRESS, Integer.class, emailAddress);
		exists = count == 1 ? true : false;
		dLogger.debug("No of users found for emailAddress {} is {}", emailAddress, count);

		return exists;
	}

	@Override
	public List<IdentificationTypeBo> getIdentificationTypes() {
		return jdbcTemplate.query(SQL_GET_IDENTIFICATION_TYPES, new IdentificationTypeBoMapper());
	}

	@Override
	public SystemUserBo getSystemUser(int systemUserId) {
		return jdbcTemplate.queryForObject(SQL_GET_SYSTEM_USER_BY_SYSTEM_USER_ID, (rs, rowNum) -> {
			SystemUserBo bo = null;

			bo = new SystemUserBo();
			bo.setSystemUserId(rs.getInt(1));
			bo.setDisplayName(rs.getString(2));
			bo.setEmailAddress(rs.getString(3));
			bo.setMobileNumber(rs.getString(4));
			bo.setPassword(rs.getString(5));
			bo.setDateOfBirth(rs.getDate(6));
			bo.setGender(rs.getString(7));
			bo.setUserRoleId(rs.getInt(8));
			bo.setEmailAddressVerificationCode(rs.getString(9));
			bo.setMobileOtpNumber(rs.getString(10));
			bo.setMobileOtpNumberLastGeneratedTimeStamp(rs.getDate(11));
			bo.setIsEmailVerified(rs.getInt(12));
			bo.setIsMobileNumberVerified(rs.getInt(13));
			bo.setMobileNumberVerifiedDate(rs.getDate(14));
			bo.setEmailAddressVerifiedDate(rs.getDate(15));
			bo.setStatus(rs.getString(16));
			bo.setLastLoggedInDate(rs.getDate(17));
			bo.setSystemUserAddressId(rs.getInt(18));
			bo.setCreatedBy(rs.getString(19));
			bo.setCreatedDt(rs.getDate(20));
			bo.setLastModifiedBy(rs.getString(21));
			bo.setLastModifiedDt(rs.getDate(22));

			return bo;
		}, systemUserId);
	}

	@Override
	public void updateEmailVerifiedStatus(int systemUserId, int verifiedStatus) {
		jdbcTemplate.update(SQL_UPD_EMAIL_VERIFIED_STATUS_BY_SYSTEM_USER_ID, verifiedStatus, systemUserId);
	}

	@Override
	public void updateMobileVerifiedStatus(int systemUserId, int verifiedStatus) {
		jdbcTemplate.update(SQL_UPD_MOBILE_NBR_VERIFIED_STATUS_BY_SYSTEM_USER_ID, verifiedStatus, systemUserId);
	}

	@Override
	public void updateSystemUserStatus(int systemUserId, String status) {
		jdbcTemplate.update(SQL_UPD_SYSTEM_USER_STATUS_BY_SYSTEM_USER_ID, status, systemUserId);
	}

	@Override
	public AddressBo getSystemUserAddressByID(int addressId) {
		return jdbcTemplate.queryForObject(SQL_GET_USER_ROLE_BY_ID, (rs, rowNum) -> {
			AddressBo addressBo = null;

			addressBo = new AddressBo();
			addressBo.setAddressId(rs.getInt(1));
			addressBo.setAddressLine1(rs.getString(2));
			addressBo.setAddressLine2(rs.getString(3));
			addressBo.setCity(rs.getString(4));
			addressBo.setState(rs.getString(5));
			addressBo.setZip(rs.getInt(6));
			addressBo.setCountry(rs.getString(7));
			addressBo.setCreatedBy(rs.getString(8));
			addressBo.setCreatedDt(rs.getDate(9));
			addressBo.setLastModifiedBy(rs.getString(10));
			addressBo.setLastModifiedDt(rs.getDate(11));

			return addressBo;
		}, addressId);
	}

	@Override
	public SystemUserDetailsBo getSystemUserDetails(String emailAddress) {
		try {
			return jdbcTemplate.queryForObject(SQL_GET_SYSTEM_USER_DETAILS_BY_EMAIL_ADDRESS, (rs, rowNum) -> {
				SystemUserDetailsBo systemUserDetailsBo = null;
				UserRoleBo userRoleBo = null;
				AddressBo addressBo = null;

				systemUserDetailsBo = new SystemUserDetailsBo();

				systemUserDetailsBo.setSystemUserId(rs.getInt(1));
				systemUserDetailsBo.setDisplayName(rs.getString(2));
				systemUserDetailsBo.setEmailAddress(rs.getString(3));
				systemUserDetailsBo.setMobileNumber(rs.getString(4));
				systemUserDetailsBo.setPassword(rs.getString(5));
				systemUserDetailsBo.setDateOfBirth(rs.getDate(6));
				systemUserDetailsBo.setGender(rs.getString(7));
				systemUserDetailsBo.setUserRoleId(rs.getInt(8));
				systemUserDetailsBo.setEmailAddressVerificationCode(rs.getString(9));
				systemUserDetailsBo.setMobileOtpNumber(rs.getString(10));
				systemUserDetailsBo.setMobileOtpNumberLastGeneratedTimeStamp(rs.getDate(11));
				systemUserDetailsBo.setIsEmailVerified(rs.getInt(12));
				systemUserDetailsBo.setIsMobileNumberVerified(rs.getInt(13));
				systemUserDetailsBo.setMobileNumberVerifiedDate(rs.getDate(14));
				systemUserDetailsBo.setEmailAddressVerifiedDate(rs.getDate(15));
				systemUserDetailsBo.setStatus(rs.getString(16));
				systemUserDetailsBo.setLastLoggedInDate(rs.getDate(17));
				systemUserDetailsBo.setSystemUserAddressId(rs.getInt(18));
				systemUserDetailsBo.setCreatedBy(rs.getString(19));
				systemUserDetailsBo.setCreatedDt(rs.getDate(20));
				systemUserDetailsBo.setLastModifiedBy(rs.getString(21));
				systemUserDetailsBo.setLastModifiedDt(rs.getDate(22));

				userRoleBo = new UserRoleBo();
				userRoleBo.setUserRoleId(rs.getInt(23));
				userRoleBo.setUserRoleCode(rs.getString(24));
				userRoleBo.setDescription(rs.getString(25));
				userRoleBo.setCreatedBy(rs.getString(26));
				userRoleBo.setCreatedDt(rs.getDate(27));
				userRoleBo.setLastModifiedBy(rs.getString(28));
				userRoleBo.setLastModifiedDt(rs.getDate(29));

				systemUserDetailsBo.setUserRoleBo(userRoleBo);

				addressBo = new AddressBo();
				addressBo.setAddressId(rs.getInt(30));
				addressBo.setAddressLine1(rs.getString(31));
				addressBo.setAddressLine2(rs.getString(32));
				addressBo.setCity(rs.getString(33));
				addressBo.setState(rs.getString(34));
				addressBo.setZip(rs.getInt(35));
				addressBo.setCountry(rs.getString(36));
				addressBo.setCreatedBy(rs.getString(37));
				addressBo.setCreatedDt(rs.getDate(38));
				addressBo.setLastModifiedBy(rs.getString(39));
				addressBo.setLastModifiedDt(rs.getDate(40));

				systemUserDetailsBo.setAddressBo(addressBo);

				return systemUserDetailsBo;
			}, emailAddress);
		} catch (EmptyResultDataAccessException e) {
			throw new SystemUserNotFoundException("SystemUser with emailAddress " + emailAddress + " is not found", e);
		}
	}

	private final class IdentificationTypeBoMapper implements RowMapper<IdentificationTypeBo> {
		@Override
		public IdentificationTypeBo mapRow(ResultSet rs, int rowNum) throws SQLException {
			IdentificationTypeBo identificationTypeBo = null;

			identificationTypeBo = new IdentificationTypeBo();
			identificationTypeBo.setIdentificationTypeId(rs.getInt(1));
			identificationTypeBo.setIdentificationTypeName(rs.getString(2));
			identificationTypeBo.setDescription(rs.getString(3));
			identificationTypeBo.setCreatedBy(rs.getString(4));
			identificationTypeBo.setCreatedDt(rs.getDate(5));
			identificationTypeBo.setLastModifiedBy(rs.getString(6));
			identificationTypeBo.setLastModifiedDt(rs.getDate(7));

			return identificationTypeBo;
		}

	}

}
