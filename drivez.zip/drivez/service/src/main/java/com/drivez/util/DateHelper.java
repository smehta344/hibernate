package com.drivez.util;

public class DateHelper {
	public static java.sql.Date toSqlDate(java.util.Date uDate) {
		if (uDate != null) {
			return new java.sql.Date(uDate.getTime());
		}
		return null;
	}
}
