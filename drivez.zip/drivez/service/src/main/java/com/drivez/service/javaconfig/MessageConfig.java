package com.drivez.service.javaconfig;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;
import org.springframework.mail.javamail.JavaMailSenderImpl;

import com.drivez.message.service.MailMessageWithAttachmentsService;
import com.drivez.notification.facade.RichTextNotificationFacade;

@Configuration
@PropertySource("classpath:META-INF/message-config.properties")
@ComponentScan(basePackageClasses = { MailMessageWithAttachmentsService.class, RichTextNotificationFacade.class })
public class MessageConfig {
	@Autowired
	private Environment env;

	@Bean
	public JavaMailSenderImpl javaMailSenderImpl() {
		JavaMailSenderImpl javaMailSenderImpl = null;
		Properties javaMailProperties = null;

		javaMailProperties = new Properties();
		javaMailProperties.put("mail.smtp.host", env.getProperty("mail.smtp.host"));
		javaMailProperties.put("mail.smtp.port", env.getProperty("mail.smtp.port"));

		javaMailSenderImpl = new JavaMailSenderImpl();
		javaMailSenderImpl.setJavaMailProperties(javaMailProperties);
		javaMailSenderImpl.setUsername(env.getProperty("mail.smtp.username"));
		javaMailSenderImpl.setPassword(env.getProperty("mail.smtp.password"));

		return javaMailSenderImpl;
	}
}
