package com.drivez.service.system;

import java.util.List;

import com.drivez.dto.ride.ImageDto;
import com.drivez.dto.system.CityDto;
import com.drivez.dto.system.CountryDto;
import com.drivez.dto.system.StateDto;

public interface SystemService {
	List<CountryDto> getCountries();

	List<StateDto> getStates(int countryId);

	List<CityDto> getCities(int stateId);

	ImageDto getCityImage(int cityId);

	List<CityDto> getActiveCities();
	
	CityDto getCityByCityName(String cityName);
	
	CityDto getCityByCityId(int cityId);

}
