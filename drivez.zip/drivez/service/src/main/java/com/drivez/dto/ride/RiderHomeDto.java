package com.drivez.dto.ride;

import java.util.List;

public class RiderHomeDto {
	protected List<ServiceAreaDto> serviceAreaDtos;
	protected List<VehicleModelInfoDto> vehicleModelInfoDtos;
	protected List<OffersDto> offersDtos;

	public List<ServiceAreaDto> getServiceAreaDtos() {
		return serviceAreaDtos;
	}

	public void setServiceAreaDtos(List<ServiceAreaDto> serviceAreaDtos) {
		this.serviceAreaDtos = serviceAreaDtos;
	}

	public List<VehicleModelInfoDto> getVehicleModelInfoDtos() {
		return vehicleModelInfoDtos;
	}

	public void setVehicleModelInfoDtos(List<VehicleModelInfoDto> vehicleModelInfoDtos) {
		this.vehicleModelInfoDtos = vehicleModelInfoDtos;
	}

	public List<OffersDto> getOffersDtos() {
		return offersDtos;
	}

	public void setOffersDtos(List<OffersDto> offersDtos) {
		this.offersDtos = offersDtos;
	}

}
