package com.drivez.service.javaconfig;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@Import({ PersistenceConfig.class, MessageFormatterConfig.class, MessageConfig.class, TextMessageConfig.class })
@ComponentScan(basePackages = { "com.drivez.service.*", "com.drivez.util", "com.drivez.resource.reader" })
@EnableTransactionManagement
public class ServiceRootConfig {

}
