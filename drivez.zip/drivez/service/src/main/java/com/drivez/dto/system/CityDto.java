package com.drivez.dto.system;

import java.io.Serializable;

public class CityDto implements Serializable {

	protected int cityId;
	protected String cityName;

	public int getCityId() {
		return cityId;
	}

	public void setCityId(int cityId) {
		this.cityId = cityId;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

}
