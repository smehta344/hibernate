package com.drivez.mapper.system;

import java.util.ArrayList;
import java.util.List;

import com.drivez.bo.ride.ImageBo;
import com.drivez.bo.system.CityBo;
import com.drivez.bo.system.CountryBo;
import com.drivez.bo.system.StateBo;
import com.drivez.dto.ride.ImageDto;
import com.drivez.dto.system.CityDto;
import com.drivez.dto.system.CountryDto;
import com.drivez.dto.system.StateDto;

public class SystemMapper {
	private static CountryDto mapCountryBoToCountryDto(CountryBo countryBo) {
		CountryDto countryDto = null;

		countryDto = new CountryDto();
		countryDto.setCountryId(countryBo.getCountryId());
		countryDto.setCountryName(countryBo.getCountryName());

		return countryDto;
	}

	public static List<CountryDto> mapCountryBosToCountryDtos(List<CountryBo> countryBos) {
		List<CountryDto> countryDtos = null;

		countryDtos = new ArrayList<>();
		for (CountryBo bo : countryBos) {
			countryDtos.add(mapCountryBoToCountryDto(bo));
		}
		return countryDtos;
	}

	private static StateDto mapStateBoToStateDto(StateBo stateBo) {
		StateDto stateDto = null;

		stateDto = new StateDto();
		stateDto.setStateId(stateBo.getStateId());
		stateDto.setStateName(stateBo.getStateName());
		return stateDto;
	}

	public static List<StateDto> mapStateBosToStateDtos(List<StateBo> stateBos) {
		List<StateDto> stateDtos = null;

		stateDtos = new ArrayList<>();
		for (StateBo bo : stateBos) {
			stateDtos.add(mapStateBoToStateDto(bo));
		}
		return stateDtos;
	}

	public static CityDto mapCityBoToCityDto(CityBo cityBo) {
		CityDto cityDto = null;

		cityDto = new CityDto();
		cityDto.setCityId(cityBo.getCityId());
		cityDto.setCityName(cityBo.getCityName());

		return cityDto;
	}

	public static List<CityDto> mapCityBosToCityDtos(List<CityBo> cityBos) {
		List<CityDto> cityDtos = null;

		cityDtos = new ArrayList<>();
		for (CityBo bo : cityBos) {
			cityDtos.add(mapCityBoToCityDto(bo));
		}
		return cityDtos;
	}
	
	public static ImageDto mapImageBoToImageDto(ImageBo imageBo) {
		ImageDto imageDto = null;
		
		imageDto = new ImageDto();
		imageDto.setImageData(imageBo.getImageData());
		imageDto.setImageName(imageBo.getImageName());
		imageDto.setImageType(imageBo.getImageType());
		
		return imageDto;
		
	}
}
