package com.drivez.mapper.usermanagement;

import java.util.ArrayList;
import java.util.List;

import com.drivez.bo.usermanagement.AddressBo;
import com.drivez.bo.usermanagement.IdentificationTypeBo;
import com.drivez.bo.usermanagement.SystemUserBo;
import com.drivez.bo.usermanagement.SystemUserDetailsBo;
import com.drivez.dto.ride.UserDetailsDto;
import com.drivez.dto.usermanagement.AddressDto;
import com.drivez.dto.usermanagement.IdentificationTypeDto;
import com.drivez.dto.usermanagement.UserDto;
import com.drivez.dto.usermanagement.UserRoleDto;

public class UserManagementMapper {
	public static AddressBo mapAddressDtoToAddressBo(AddressDto addressDto) {
		AddressBo addressBo = null;

		addressBo = new AddressBo();
		addressBo.setAddressId(addressDto.getAddressId());
		addressBo.setAddressLine1(addressDto.getStreetAddress());
		addressBo.setAddressLine2(addressDto.getAreaOrLandMarkAddress());
		addressBo.setCity(addressDto.getCityName());
		addressBo.setState(addressDto.getStateName());
		addressBo.setZip(addressDto.getZip());
		addressBo.setCountry(addressDto.getCountryName());

		return addressBo;
	}

	public static SystemUserBo mapUserDtoToSystemUserBo(UserDto userDto) {
		SystemUserBo systemUserBo = null;

		systemUserBo = new SystemUserBo();
		systemUserBo.setSystemUserId(userDto.getUserId());
		systemUserBo.setDisplayName(userDto.getDisplayName());
		systemUserBo.setEmailAddress(userDto.getEmailAddress());
		systemUserBo.setMobileNumber(userDto.getMobileNumber());
		systemUserBo.setPassword(userDto.getPassword());
		systemUserBo.setDateOfBirth(userDto.getDateOfBirth());
		systemUserBo.setGender(userDto.getGender());

		return systemUserBo;
	}

	private static IdentificationTypeDto mapIdentificationTypeBoToIdentificationTypeDto(
			IdentificationTypeBo identificationTypeBo) {
		IdentificationTypeDto identificationTypeDto = null;

		identificationTypeDto = new IdentificationTypeDto();
		identificationTypeDto.setIdentificationTypeId(identificationTypeBo.getIdentificationTypeId());
		identificationTypeDto.setIdentificationTypeName(identificationTypeBo.getIdentificationTypeName());

		return identificationTypeDto;
	}

	public static List<IdentificationTypeDto> mapIdentificationTypeBosToIdentificationTypeDtos(
			List<IdentificationTypeBo> identificationTypeBos) {
		List<IdentificationTypeDto> identificationTypeDtos = null;

		identificationTypeDtos = new ArrayList<IdentificationTypeDto>();
		for (IdentificationTypeBo bo : identificationTypeBos) {
			identificationTypeDtos.add(mapIdentificationTypeBoToIdentificationTypeDto(bo));
		}
		return identificationTypeDtos;
	}

	public static UserDetailsDto mapSystemUserDetailsBoToUserDetailsDto(SystemUserDetailsBo systemUserDetailsBo) {
		UserDetailsDto userDetailsDto = null;
		AddressDto addressDto = null;
		UserRoleDto userRoleDto = null;

		userDetailsDto = new UserDetailsDto();
		userDetailsDto.setEmailAddress(systemUserDetailsBo.getEmailAddress());
		userDetailsDto.setDisplayName(systemUserDetailsBo.getDisplayName());
		userDetailsDto.setPassword(systemUserDetailsBo.getPassword());
		userDetailsDto.setGender(systemUserDetailsBo.getGender());
		userDetailsDto.setMobileNumber(systemUserDetailsBo.getMobileNumber());
		userDetailsDto.setUserId(systemUserDetailsBo.getSystemUserId());
		userDetailsDto.setDateOfBirth(systemUserDetailsBo.getDateOfBirth());
		userDetailsDto.setStatus(systemUserDetailsBo.getStatus());

		addressDto = new AddressDto();
		addressDto.setAddressId(systemUserDetailsBo.getAddressBo().getAddressId());
		addressDto.setStreetAddress(systemUserDetailsBo.getAddressBo().getAddressLine1());
		addressDto.setAreaOrLandMarkAddress(systemUserDetailsBo.getAddressBo().getAddressLine2());
		addressDto.setCityName(systemUserDetailsBo.getAddressBo().getCity());
		addressDto.setStateName(systemUserDetailsBo.getAddressBo().getState());
		addressDto.setCountryName(systemUserDetailsBo.getAddressBo().getCountry());
		addressDto.setZip(systemUserDetailsBo.getAddressBo().getZip());

		userDetailsDto.setAddressDto(addressDto);

		userRoleDto = new UserRoleDto();
		userRoleDto.setUserRoleCode(systemUserDetailsBo.getUserRoleBo().getUserRoleCode());
		userRoleDto.setUserRoleId(systemUserDetailsBo.getUserRoleBo().getUserRoleId());

		userDetailsDto.setUserRoleDto(userRoleDto);

		return userDetailsDto;
	}

}
