package com.drivez.bo.ride;

import java.io.Serializable;
import java.util.List;

import com.drivez.bo.system.CityBo;

public class RiderHomeBo implements Serializable {
	protected List<VehicleModelInfoBo> vehichelModelInfoBos;
	protected List<OffersBo> offersBos;
	protected List<ServiceAreaBo> serviceAreaBos;


	public List<VehicleModelInfoBo> getVehichelModelInfoBos() {
		return vehichelModelInfoBos;
	}

	public void setVehichelModelInfoBos(List<VehicleModelInfoBo> vehichelModelInfoBos) {
		this.vehichelModelInfoBos = vehichelModelInfoBos;
	}

	public List<OffersBo> getOffersBos() {
		return offersBos;
	}

	public void setOffersBos(List<OffersBo> offersBos) {
		this.offersBos = offersBos;
	}

	public List<ServiceAreaBo> getServiceAreaBos() {
		return serviceAreaBos;
	}

	public void setServiceAreaBos(List<ServiceAreaBo> serviceAreaBos) {
		this.serviceAreaBos = serviceAreaBos;
	}

}
