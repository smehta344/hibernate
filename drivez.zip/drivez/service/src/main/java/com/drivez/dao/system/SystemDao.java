package com.drivez.dao.system;

import java.util.List;

import com.drivez.bo.ride.ImageBo;
import com.drivez.bo.system.CityBo;
import com.drivez.bo.system.CountryBo;
import com.drivez.bo.system.StateBo;

public interface SystemDao {
	List<CountryBo> getCountries();

	List<StateBo> getStates(int countryId);

	List<CityBo> getCities(int stateId);

	List<CityBo> getCities(String status);
	
	ImageBo getCityImage(int cityId);
	
	CityBo getCityByCityName(String cityName);
	
	CityBo getCityByCityId(int cityId);
}
