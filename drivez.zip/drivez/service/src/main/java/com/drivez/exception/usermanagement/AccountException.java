package com.drivez.exception.usermanagement;

import com.drivez.exception.DriveZGenericException;

public class AccountException extends DriveZGenericException {
	private static final long serialVersionUID = 7019151499300016613L;
	protected int systemUserId;

	public AccountException(int systemUserId, String message, Throwable cause) {
		super(message, cause);
		this.systemUserId = systemUserId;
	}

	public AccountException(int systemUserId, String message) {
		super(message);
		this.systemUserId = systemUserId;
	}

	public AccountException(int systemUserId, Throwable cause) {
		super(cause);
		this.systemUserId = systemUserId;
	}

	public int getSystemUserId() {
		return systemUserId;
	}

	public void setSystemUserId(int systemUserId) {
		this.systemUserId = systemUserId;
	}

}
