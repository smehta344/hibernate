package com.drivez.bo.usermanagement;

import java.io.Serializable;
import java.util.Date;

public class SystemUserBo implements Serializable {
	private static final long serialVersionUID = 1L;

	protected int systemUserId;
	protected String displayName;
	protected String emailAddress;
	protected String mobileNumber;
	protected String password;
	protected Date dateOfBirth;
	protected String gender;
	protected int userRoleId;
	protected String emailAddressVerificationCode;
	protected String mobileOtpNumber;
	protected Date mobileOtpNumberLastGeneratedTimeStamp;
	protected int isEmailVerified;
	protected int isMobileNumberVerified;
	protected Date mobileNumberVerifiedDate;
	protected Date emailAddressVerifiedDate;
	protected String status;
	protected int systemUserAddressId;
	protected Date lastLoggedInDate;
	protected Date createdDt;
	protected String createdBy;
	protected Date lastModifiedDt;
	protected String lastModifiedBy;

	public int getSystemUserId() {
		return systemUserId;
	}

	public void setSystemUserId(int systemUserId) {
		this.systemUserId = systemUserId;
	}

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public int getUserRoleId() {
		return userRoleId;
	}

	public void setUserRoleId(int userRoleId) {
		this.userRoleId = userRoleId;
	}

	public String getEmailAddressVerificationCode() {
		return emailAddressVerificationCode;
	}

	public void setEmailAddressVerificationCode(String emailAddressVerificationCode) {
		this.emailAddressVerificationCode = emailAddressVerificationCode;
	}

	public String getMobileOtpNumber() {
		return mobileOtpNumber;
	}

	public void setMobileOtpNumber(String mobileOtpNumber) {
		this.mobileOtpNumber = mobileOtpNumber;
	}

	public Date getMobileOtpNumberLastGeneratedTimeStamp() {
		return mobileOtpNumberLastGeneratedTimeStamp;
	}

	public void setMobileOtpNumberLastGeneratedTimeStamp(Date mobileOtpNumberLastGeneratedTimeStamp) {
		this.mobileOtpNumberLastGeneratedTimeStamp = mobileOtpNumberLastGeneratedTimeStamp;
	}

	public int getIsEmailVerified() {
		return isEmailVerified;
	}

	public void setIsEmailVerified(int isEmailVerified) {
		this.isEmailVerified = isEmailVerified;
	}

	public int getIsMobileNumberVerified() {
		return isMobileNumberVerified;
	}

	public void setIsMobileNumberVerified(int isMobileNumberVerified) {
		this.isMobileNumberVerified = isMobileNumberVerified;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Date getMobileNumberVerifiedDate() {
		return mobileNumberVerifiedDate;
	}

	public void setMobileNumberVerifiedDate(Date mobileNumberVerifiedDate) {
		this.mobileNumberVerifiedDate = mobileNumberVerifiedDate;
	}

	public Date getEmailAddressVerifiedDate() {
		return emailAddressVerifiedDate;
	}

	public void setEmailAddressVerifiedDate(Date emailAddressVerifiedDate) {
		this.emailAddressVerifiedDate = emailAddressVerifiedDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getSystemUserAddressId() {
		return systemUserAddressId;
	}

	public void setSystemUserAddressId(int systemUserAddressId) {
		this.systemUserAddressId = systemUserAddressId;
	}

	public Date getLastLoggedInDate() {
		return lastLoggedInDate;
	}

	public void setLastLoggedInDate(Date lastLoggedInDate) {
		this.lastLoggedInDate = lastLoggedInDate;
	}

	public Date getCreatedDt() {
		return createdDt;
	}

	public void setCreatedDt(Date createdDt) {
		this.createdDt = createdDt;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getLastModifiedDt() {
		return lastModifiedDt;
	}

	public void setLastModifiedDt(Date lastModifiedDt) {
		this.lastModifiedDt = lastModifiedDt;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

}
