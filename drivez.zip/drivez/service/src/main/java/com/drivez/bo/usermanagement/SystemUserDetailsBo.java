package com.drivez.bo.usermanagement;

public class SystemUserDetailsBo extends SystemUserBo {
	private static final long serialVersionUID = 1L;
	protected UserRoleBo userRoleBo;
	protected AddressBo addressBo;

	public UserRoleBo getUserRoleBo() {
		return userRoleBo;
	}

	public void setUserRoleBo(UserRoleBo userRoleBo) {
		this.userRoleBo = userRoleBo;
	}

	public AddressBo getAddressBo() {
		return addressBo;
	}

	public void setAddressBo(AddressBo addressBo) {
		this.addressBo = addressBo;
	}

}
