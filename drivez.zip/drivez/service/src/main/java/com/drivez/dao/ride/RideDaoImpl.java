package com.drivez.dao.ride;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.drivez.bo.ride.ImageBo;
import com.drivez.bo.ride.OffersBo;
import com.drivez.bo.ride.ServiceAreaBo;
import com.drivez.bo.ride.VehicleModelInfoBo;
import com.drivez.bo.ride.VehicleTypeBo;

@Repository
public class RideDaoImpl implements RideDao {
	// sql queries
	private final String SQL_GET_RIDER_OFFERS = "select offer_id, status, percentage_discount, description, coupon_code, created_by, created_dt, last_modified_by, last_modified_dt from offers order by created_dt desc";
	private final String SQL_GET_MOST_RENTED_VEHICLE_MODELS_BY_CITY_ID = "select vehicle_model_id, vehicle_type_id, model_name, manufacturer_nm, fuel_type, with_ac_or_without_ac, seats, status, created_by, created_dt, last_modified_by, last_modified_dt from vehicle_model_info where vehicle_model_id in( select vmi.vehicle_model_id from vehicle_model_info vmi inner join booking_information bi on vmi.vehicle_model_id = bi.vehicle_model_id where bi.city_id = ? and vmi.status = ? group by vmi.vehicle_model_id  order by count(1) desc) limit 5;";
	private final String SQL_GET_SERVICE_AREAS_BY_CITY_AND_STATUS = "select service_area_id, service_area_nm, description, status, city_id, pickup_location, drop_location, created_by, created_dt, last_modified_by, last_modified_dt from service_area where city_id = ? and status = ? order by service_area_nm";
	private final String SQL_GET_VEHICLE_MODEL_IMAGE_BY_VEHICLE_MODEL_ID = "select model_name, vehicle_model_image, image_type from vehicle_model_info where vehicle_model_id = ?";
	private final String SQL_GET_OFFER_IMAGE_BY_OFFER_IMAGE_ID = "select offer_image_nm, offer_image, offer_image_type from offers where offer_id = ?";
	private final String SQL_GET_VEHICLE_TYPES = "SELECT vehicle_type_id, type_nm,    description, created_by,  created_dt,  last_modified_by, last_modified_dt from vehicle_type";
	
	@Autowired
	private JdbcTemplate jdbcTemplate;

	@Override
	public List<OffersBo> getOffers() {
		return jdbcTemplate.query(SQL_GET_RIDER_OFFERS, (rs, rowNum) -> {
			OffersBo bo = new OffersBo();
			bo.setOfferId(rs.getInt(1));
			bo.setStatus(rs.getString(2));
			bo.setPercentageDiscount(rs.getInt(3));
			bo.setDescription(rs.getString(4));
			bo.setCouponCode(rs.getString(5));
			bo.setCreatedBy(rs.getString(6));
			bo.setCreatedDt(rs.getDate(7));
			bo.setLastModifiedBy(rs.getString(8));
			bo.setLastModifiedDt(rs.getDate(9));
			return bo;
		});
	}

	@Override
	public List<VehicleModelInfoBo> getMostRentedVehicleModels(int cityId, String status) {
		return jdbcTemplate.query(SQL_GET_MOST_RENTED_VEHICLE_MODELS_BY_CITY_ID, (rs, rowNum) -> {
			VehicleModelInfoBo vehicleModelInfoBo = null;

			vehicleModelInfoBo = new VehicleModelInfoBo();
			vehicleModelInfoBo.setVehicleModelId(rs.getInt(1));
			vehicleModelInfoBo.setVehicleTypeId(rs.getInt(2));
			vehicleModelInfoBo.setModelName(rs.getString(3));
			vehicleModelInfoBo.setManufacturerName(rs.getString(4));
			vehicleModelInfoBo.setFuelType(rs.getString(5));
			vehicleModelInfoBo.setWithOrWithoutAC(rs.getString(6));
			vehicleModelInfoBo.setTotalSeats(rs.getInt(7));
			vehicleModelInfoBo.setStatus(rs.getString(8));
			vehicleModelInfoBo.setCreatedBy(rs.getString(9));
			vehicleModelInfoBo.setCreatedDt(rs.getDate(10));
			vehicleModelInfoBo.setLastModifiedBy(rs.getString(11));
			vehicleModelInfoBo.setLastModifiedDt(rs.getDate(12));

			return vehicleModelInfoBo;
		}, cityId, status);
	}

	@Override
	public List<ServiceAreaBo> getServiceAreasByCity(int cityId, String status) {
		return jdbcTemplate.query(SQL_GET_SERVICE_AREAS_BY_CITY_AND_STATUS, (rs, rowNum) -> {
			ServiceAreaBo serviceAreaBo = null;

			serviceAreaBo = new ServiceAreaBo();
			serviceAreaBo.setServiceAreaId(rs.getInt(1));
			serviceAreaBo.setServiceAreaName(rs.getString(2));
			serviceAreaBo.setDescription(rs.getString(3));
			serviceAreaBo.setStatus(rs.getString(4));
			serviceAreaBo.setCityId(rs.getInt(5));
			serviceAreaBo.setPickupLocation(rs.getInt(6));
			serviceAreaBo.setDropLocation(rs.getInt(7));
			serviceAreaBo.setCreatedBy(rs.getString(8));
			serviceAreaBo.setCreatedDt(rs.getDate(9));
			serviceAreaBo.setLastModifiedBy(rs.getString(10));
			serviceAreaBo.setLastModifiedDt(rs.getDate(11));

			return serviceAreaBo;
		}, cityId, status);
	}

	@Override
	public ImageBo getVehicleModelImage(int vehicleModelId) {
		return jdbcTemplate.queryForObject(SQL_GET_VEHICLE_MODEL_IMAGE_BY_VEHICLE_MODEL_ID, (rs, rowNum) -> {
			ImageBo image = null;

			image = new ImageBo();
			image.setImageName(rs.getString(1));
			image.setImageData(rs.getBytes(2));
			image.setImageType(rs.getString(3));
			return image;

		}, vehicleModelId);
	}

	@Override
	public ImageBo getOfferImage(int offerId) {
		return jdbcTemplate.queryForObject(SQL_GET_OFFER_IMAGE_BY_OFFER_IMAGE_ID, (rs, rowNum) -> {
			ImageBo image = null;

			image = new ImageBo();
			image.setImageName(rs.getString(1));
			image.setImageData(rs.getBytes(2));
			image.setImageType(rs.getString(3));
			return image;

		}, offerId);
	}

	@Override
	public List<VehicleTypeBo> getVehicleTypes() {
		return jdbcTemplate.query(SQL_GET_VEHICLE_TYPES, (rs, rowNum) -> {
			VehicleTypeBo bo = null;
			
			bo = new VehicleTypeBo();
			bo.setVehicleTypeId(rs.getInt(1));
			bo.setVehicleTypeName(rs.getString(2));
			bo.setDescription(rs.getString(3));
			bo.setCreatedBy(rs.getString(4));
			bo.setCreatedDt(rs.getDate(5));
			bo.setLastModifiedBy(rs.getString(6));
			bo.setLastModifiedDt(rs.getDate(7));
			
			return bo;
		});
	}
	
	
}
