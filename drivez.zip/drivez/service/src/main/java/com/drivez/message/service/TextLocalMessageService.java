package com.drivez.message.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.env.Environment;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import com.drivez.exception.message.MessageDeliveryFailedException;
import com.drivez.logging.DriveZLogger;
import com.drivez.message.beans.Message;

@Component
public class TextLocalMessageService implements MessageService {
	private final static DriveZLogger dLogger = DriveZLogger.getLogger(TextLocalMessageService.class);
	@Autowired
	private Environment env;

	@Autowired
	private RestTemplate textMessageClient;

	@Override
	public void message(Message message) {
		ResponseEntity<String> response = null;
		StringBuffer url = null;
		String numbers = null;

		numbers = StringUtils.arrayToCommaDelimitedString(message.getTo());

		url = new StringBuffer(env.getProperty("text.message.providerUrl"));
		url.append("apikey=").append(env.getProperty("text.message.apiKey")).append("&message=")
				.append(message.getContent()).append("&numbers=").append(numbers);

		dLogger.debug("sending text message to url {} ", url);
		response = textMessageClient.getForEntity(url.toString(), String.class);
		dLogger.debug("response after sending the text message {} ", response.getBody());

		if (response.getStatusCode() != HttpStatus.OK) {
			throw new MessageDeliveryFailedException("error while sending text message");
		}

	}

}
