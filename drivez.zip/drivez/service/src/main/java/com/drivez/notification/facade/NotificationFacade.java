package com.drivez.notification.facade;

import com.drivez.notification.beans.Notification;
import com.drivez.notification.beans.NotificationTemplate;

public interface NotificationFacade {
	void notify(Notification notification, NotificationTemplate notificationTemplate);
}
