package com.drivez.dto.ride;

public class ServiceAreaDto {
	protected int serviceAreaId;
	protected String serviceAreaName;
	protected int cityId;

	public int getServiceAreaId() {
		return serviceAreaId;
	}

	public void setServiceAreaId(int serviceAreaId) {
		this.serviceAreaId = serviceAreaId;
	}

	public String getServiceAreaName() {
		return serviceAreaName;
	}

	public void setServiceAreaName(String serviceAreaName) {
		this.serviceAreaName = serviceAreaName;
	}

	public int getCityId() {
		return cityId;
	}

	public void setCityId(int cityId) {
		this.cityId = cityId;
	}

}
