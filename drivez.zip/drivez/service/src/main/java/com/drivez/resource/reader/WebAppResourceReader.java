package com.drivez.resource.reader;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import javax.servlet.ServletContext;

import org.springframework.stereotype.Component;

import com.drivez.exception.resource.reader.ResourceReaderException;

@Component
public class WebAppResourceReader implements ResourceReader {
	private ServletContext servletContext;

	@Override
	public byte[] getResource(String criteria) {
		int i = 0;
		int b = -1;
		byte[] data = null;
		String basePath = null;
		String resourceLocation = null;
		InputStream in = null;

		if (servletContext == null) {
			throw new ResourceReaderException("ServletContext has not been set");
		}
		try {
			basePath = servletContext.getRealPath("/");
			resourceLocation = basePath + "/" + criteria;
			in = new FileInputStream(new File(resourceLocation));
			data = new byte[in.available()];

			while ((b = in.read()) != -1) {
				data[i++] = (byte) b;
			}
		} catch (IOException e) {
			throw new ResourceReaderException("failed to read file under : " + resourceLocation, e);
		} finally {
			if (in != null) {
				try {
					in.close();
				} catch (IOException e) {
					// eat the exception
				}
			}
		}

		return data;
	}

	public void setServletContext(ServletContext servletContext) {
		this.servletContext = servletContext;
	}

}
