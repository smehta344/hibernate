package com.drivez.service.rent;

import static com.drivez.mapper.rent.RentMapper.mapBokinginformationDtotoBookingInformationBo;
import static com.drivez.mapper.rent.RentMapper.mapPaymentTrackingDtotoPaymentTrackingBo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.drivez.bo.rent.BookingInformationBo;
import com.drivez.bo.rent.PaymentTrackingBo;
import com.drivez.dao.rent.RentDao;
import com.drivez.dto.rent.BookingInformationDto;
import com.drivez.dto.rent.PaymentTrackingDto;
import com.drivez.dto.rent.RentInfoDto;
import com.drivez.util.DriveZConstants;

@Service
public class RentServiceImpl implements RentService {
	@Autowired
	private RentDao rentDao;

	@Override
	@Transactional(readOnly = false)
	public RentInfoDto createRentRequest(BookingInformationDto bookingInformationDto,
			PaymentTrackingDto paymentTrackingDto) {
		BookingInformationBo bookingInformationBo = null;
		PaymentTrackingBo paymentTrackingBo = null;
		RentInfoDto rentInfoDto = null;
		int bookingInformationId = 0;
		int paymentTrackingId = 0;

		bookingInformationBo = mapBokinginformationDtotoBookingInformationBo(bookingInformationDto);
		bookingInformationId = rentDao.saveBookingInfo(bookingInformationBo);

		paymentTrackingDto.setBookingId(bookingInformationId);
		paymentTrackingBo = mapPaymentTrackingDtotoPaymentTrackingBo(paymentTrackingDto);
		paymentTrackingId = rentDao.savePaymentTracking(paymentTrackingBo);

		rentInfoDto = new RentInfoDto(bookingInformationId, paymentTrackingId);

		return rentInfoDto;
	}

	@Override
	@Transactional(readOnly = false)
	public void updateRentStatus(int bookingInformationId, PaymentTrackingDto paymentTrackingDto, String status) {
		PaymentTrackingBo paymentTrackingBo = null;
		int paymentTrackingId = 0;

		rentDao.updateBookingInfoStatus(bookingInformationId, status);
		paymentTrackingId = rentDao.getPaymentTrackingId(bookingInformationId,
				DriveZConstants.STATUS_RENT_PENDING_FOR_PAYMENT);

		paymentTrackingDto.setPaymentTrackingId(paymentTrackingId);
		paymentTrackingDto.setStatus(status);
		paymentTrackingBo = mapPaymentTrackingDtotoPaymentTrackingBo(paymentTrackingDto);
		rentDao.updatePaymentTracking(paymentTrackingBo);
	}

}
