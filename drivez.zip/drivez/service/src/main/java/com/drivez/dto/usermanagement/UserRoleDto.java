package com.drivez.dto.usermanagement;

public class UserRoleDto {
	protected int userRoleId;
	protected String userRoleCode;
	
	
	public int getUserRoleId() {
		return userRoleId;
	}
	public void setUserRoleId(int userRoleId) {
		this.userRoleId = userRoleId;
	}
	public String getUserRoleCode() {
		return userRoleCode;
	}
	public void setUserRoleCode(String userRoleCode) {
		this.userRoleCode = userRoleCode;
	}
		
	
}
