package com.drivez.resource.reader;

public interface ResourceReader {
	byte[] getResource(String criteria);
}
