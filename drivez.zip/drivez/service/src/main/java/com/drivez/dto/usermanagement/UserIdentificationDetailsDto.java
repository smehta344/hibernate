package com.drivez.dto.usermanagement;

import java.io.Serializable;

public class UserIdentificationDetailsDto implements Serializable {

	private static final long serialVersionUID = 1L;

	protected String drivingLicenseNo;
	protected String drivingLicenseIssuedAuthority;
	protected int identificationTypeId;
	protected String identificationValue;
	protected String identificationIssuedAuthority;

	public String getDrivingLicenseNo() {
		return drivingLicenseNo;
	}

	public void setDrivingLicenseNo(String drivingLicenseNo) {
		this.drivingLicenseNo = drivingLicenseNo;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getDrivingLicenseIssuedAuthority() {
		return drivingLicenseIssuedAuthority;
	}

	public void setDrivingLicenseIssuedAuthority(String drivingLicenseIssuedAuthority) {
		this.drivingLicenseIssuedAuthority = drivingLicenseIssuedAuthority;
	}

	public int getIdentificationTypeId() {
		return identificationTypeId;
	}

	public void setIdentificationTypeId(int identificationTypeId) {
		this.identificationTypeId = identificationTypeId;
	}

	public String getIdentificationValue() {
		return identificationValue;
	}

	public void setIdentificationValue(String identificationValue) {
		this.identificationValue = identificationValue;
	}

	public String getIdentificationIssuedAuthority() {
		return identificationIssuedAuthority;
	}

	public void setIdentificationIssuedAuthority(String identificationIssuedAuthority) {
		this.identificationIssuedAuthority = identificationIssuedAuthority;
	}

}
