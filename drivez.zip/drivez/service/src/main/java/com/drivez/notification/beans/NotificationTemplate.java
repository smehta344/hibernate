package com.drivez.notification.beans;

import java.util.Map;

public class NotificationTemplate {
	protected String templateName;
	protected Map<String, Object> bindingData;

	public String getTemplateName() {
		return templateName;
	}

	public void setTemplateName(String templateName) {
		this.templateName = templateName;
	}

	public Map<String, Object> getBindingData() {
		return bindingData;
	}

	public void setBindingData(Map<String, Object> bindingData) {
		this.bindingData = bindingData;
	}

}
