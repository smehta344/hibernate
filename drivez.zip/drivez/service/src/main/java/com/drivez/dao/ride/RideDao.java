package com.drivez.dao.ride;

import java.util.List;

import com.drivez.bo.ride.ImageBo;
import com.drivez.bo.ride.OffersBo;
import com.drivez.bo.ride.ServiceAreaBo;
import com.drivez.bo.ride.VehicleModelInfoBo;
import com.drivez.bo.ride.VehicleTypeBo;

public interface RideDao {
	List<OffersBo> getOffers();

	List<VehicleModelInfoBo> getMostRentedVehicleModels(int cityId, String status);

	List<ServiceAreaBo> getServiceAreasByCity(int cityId, String status);

	ImageBo getVehicleModelImage(int vehicleModelId);

	ImageBo getOfferImage(int offerId);
	
	List<VehicleTypeBo> getVehicleTypes();
}
