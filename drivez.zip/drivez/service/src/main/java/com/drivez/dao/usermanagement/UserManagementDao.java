package com.drivez.dao.usermanagement;

import java.util.List;

import com.drivez.bo.usermanagement.AddressBo;
import com.drivez.bo.usermanagement.IdentificationTypeBo;
import com.drivez.bo.usermanagement.SystemUserBo;
import com.drivez.bo.usermanagement.SystemUserDetailsBo;
import com.drivez.bo.usermanagement.UserIdentificationBo;
import com.drivez.bo.usermanagement.UserRoleBo;

public interface UserManagementDao {
	int saveAddress(AddressBo addressBo);

	int saveSystemUser(SystemUserBo systemUserBo);

	int saveUserIdentification(UserIdentificationBo userIdentificationBo);

	UserRoleBo getUserRole(String userRoleCode);

	public UserRoleBo getUserRoleByUserRoleId(int userRoleId);

	AddressBo getSystemUserAddressByID(int AddressId);

	IdentificationTypeBo getIdentificationType(String identificationType);

	boolean isUserExistsWithEmailAddress(String emailAddress);

	List<IdentificationTypeBo> getIdentificationTypes();

	SystemUserBo getSystemUser(int systemUserId);

	void updateEmailVerifiedStatus(int systemUserId, int verifiedStatus);

	void updateMobileVerifiedStatus(int systemUserId, int verifiedStatus);

	void updateSystemUserStatus(int systemUserId, String status);

	SystemUserDetailsBo getSystemUserDetails(String emailAddress);

}
