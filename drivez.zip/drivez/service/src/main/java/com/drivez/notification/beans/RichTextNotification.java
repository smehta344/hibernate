package com.drivez.notification.beans;

import java.util.List;
import java.util.Map;

public class RichTextNotification extends Notification {
	protected String[] cc;
	protected String[] bcc;
	protected String subject;
	protected Map<String, List<NotificationAttachment>> attachments;

	public String[] getCc() {
		return cc;
	}

	public void setCc(String[] cc) {
		this.cc = cc;
	}

	public String[] getBcc() {
		return bcc;
	}

	public void setBcc(String[] bcc) {
		this.bcc = bcc;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public Map<String, List<NotificationAttachment>> getAttachments() {
		return attachments;
	}

	public void setAttachments(Map<String, List<NotificationAttachment>> attachments) {
		this.attachments = attachments;
	}

}
