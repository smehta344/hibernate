package com.drivez.exception.usermanagement;

public class AccountAlreadyActivatedException extends AccountException {
	private static final long serialVersionUID = -7083919194804854596L;

	public AccountAlreadyActivatedException(int systemUserId, String message, Throwable cause) {
		super(systemUserId, message, cause);
	}

	public AccountAlreadyActivatedException(int systemUserId, String message) {
		super(systemUserId, message);
	}

	public AccountAlreadyActivatedException(int systemUserId, Throwable cause) {
		super(systemUserId, cause);
	}

}
