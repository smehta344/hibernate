package com.drivez.notification.facade;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.drivez.message.beans.Message;
import com.drivez.message.formatter.MessageFormatter;
import com.drivez.message.service.TextLocalMessageService;
import com.drivez.notification.beans.Notification;
import com.drivez.notification.beans.NotificationTemplate;

@Component
public class TextNotificationFacade implements NotificationFacade {
	@Autowired
	private MessageFormatter messageFormatter;

	@Autowired
	private TextLocalMessageService messageService;

	@Override
	public void notify(Notification notification, NotificationTemplate notificationTemplate) {
		String content = null;
		Message message = null;

		content = messageFormatter.merge(notificationTemplate.getTemplateName(), notificationTemplate.getBindingData());
		message = new Message();
		message.setContent(content);
		message.setFrom(notification.getFrom());
		message.setTo(notification.getTo());

		messageService.message(message);
	}

}
