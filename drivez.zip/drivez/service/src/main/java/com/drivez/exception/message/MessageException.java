package com.drivez.exception.message;

import com.drivez.exception.DriveZGenericException;

public class MessageException extends DriveZGenericException {
	private static final long serialVersionUID = 527283395639472149L;

	public MessageException(String message, Throwable cause) {
		super(message, cause);
	}

	public MessageException(String message) {
		super(message);
	}

	public MessageException(Throwable cause) {
		super(cause);
	}

}
