package com.drivez.message.beans;

public class Attachment {
	protected String contentId;
	protected byte[] data;
	protected String dataType;

	public Attachment() {
	}

	public Attachment(String contentId, byte[] data, String dataType) {
		this.contentId = contentId;
		this.data = data;
		this.dataType = dataType;
	}

	public String getContentId() {
		return contentId;
	}

	public void setContentId(String contentId) {
		this.contentId = contentId;
	}

	public byte[] getData() {
		return data;
	}

	public void setData(byte[] data) {
		this.data = data;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}

}
