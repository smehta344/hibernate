package com.drivez.exception;

public class DriveZGenericException extends RuntimeException {
	private static final long serialVersionUID = 452140029888769342L;

	public DriveZGenericException(String message, Throwable cause) {
		super(message, cause);
	}

	public DriveZGenericException(String message) {
		super(message);
	}

	public DriveZGenericException(Throwable cause) {
		super(cause);
	}

}
