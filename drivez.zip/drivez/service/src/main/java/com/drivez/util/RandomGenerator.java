package com.drivez.util;

import java.security.SecureRandom;

public class RandomGenerator {
	private final static String numberSequences = "0123456789";
	private final static String alphaNumericSequenceWithSpecialChars = "abc-$defghijk012345lmnopqrstuvwxyz6789";

	public static String generateOtp(int length) {
		SecureRandom secureRandom = null;
		char[] otpSequence = null;
		String otp = null;

		otpSequence = new char[length];
		secureRandom = new SecureRandom();

		for (int i = 0; i < length; i++) {
			otpSequence[i] = numberSequences.charAt(secureRandom.nextInt(10));
		}

		otp = new String(otpSequence);
		return otp;
	}

	public static String generateVerificationCode(int length) {
		SecureRandom secureRandom = null;
		char[] verificationCodeSequence = null;
		String verificationCode = null;

		verificationCodeSequence = new char[length];
		secureRandom = new SecureRandom();

		for (int i = 0; i < length; i++) {
			verificationCodeSequence[i] = alphaNumericSequenceWithSpecialChars.charAt(secureRandom.nextInt(39));
		}

		verificationCode = new String(verificationCodeSequence);
		return verificationCode;
	}

	public static void main(String[] args) {
		for(int i=0;i<1000;i++)
		System.out.println(generateVerificationCode(12));
	}
}
