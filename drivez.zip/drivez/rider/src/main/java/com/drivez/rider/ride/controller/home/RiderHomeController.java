package com.drivez.rider.ride.controller.home;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.web.bind.annotation.SessionAttributes;

import com.drivez.dto.ride.ImageDto;
import com.drivez.dto.ride.RiderHomeDto;
import com.drivez.dto.ride.VehicleTypeDto;
import com.drivez.dto.system.CityDto;
import com.drivez.logging.DriveZLogger;
import com.drivez.service.ride.RideService;
import com.drivez.service.system.SystemService;
import com.drivez.util.DriveZConstants;

@Controller
@RequestMapping("/home")
@SessionAttributes(names = { "choosen-city", "choosen-city-name" })
public class RiderHomeController {
	private final static DriveZLogger dLogger = DriveZLogger.getLogger(RiderHomeController.class);

	@Autowired
	private RideService rideService;

	@Autowired
	private SystemService systemService;

	@GetMapping("/rider.web")
	public String showRiderHomePage(@SessionAttribute(name = "choosen-city", required = false) Integer choosenCityId,
			@SessionAttribute(name = "choosen-city-name", required = false) String choosenCityName, Model model) {
		RiderHomeDto riderHomeDto = null;
		CityDto city = null;

		if (choosenCityId == null) {
			city = systemService.getCityByCityName(DriveZConstants.SYSTEM_DEFAULT_CITY);
			choosenCityId = city.getCityId();
			choosenCityName = city.getCityName();

			model.addAttribute("choosen-city", choosenCityId);
			model.addAttribute("choosen-city-name", choosenCityName);
		}

		riderHomeDto = rideService.getRiderHome(choosenCityId);
		model.addAttribute("riderHome", riderHomeDto);

		return "rider-home";
	}

	@GetMapping("/{cityId}/change-rider-city.web")
	public String changeRiderCity(@PathVariable("cityId") int cityId, Model model) {
		CityDto city = null;
		String choosenCityName = null;

		city = systemService.getCityByCityId(cityId);
		choosenCityName = city.getCityName();
		model.addAttribute("choosen-city-name", choosenCityName);
		model.addAttribute("choosen-city", cityId);
		return "redirect:/home/rider.web";
	}

	@ModelAttribute("vehicleTypes")
	public List<VehicleTypeDto> populateVehicleTypes() {
		return rideService.getVehicleTypes();
	}

	@GetMapping("/{cityId}/city-image.web")
	@ResponseBody
	public byte[] getCityImage(@PathVariable("cityId") int cityId) {
		ImageDto image = null;
		image = systemService.getCityImage(cityId);
		return image.getImageData();
	}

	@GetMapping("/{offerId}/offer-image.web")
	@ResponseBody
	public byte[] getOfferImage(@PathVariable("offerId") int offerId) {
		ImageDto image = null;
		image = rideService.getOfferImage(offerId);
		return image.getImageData();
	}

	@GetMapping("/{vehicleModelId}/vehicle-model-image.web")
	@ResponseBody
	public byte[] getVehicleModelImage(@PathVariable("vehicleModelId") int vehicleModelId) {
		ImageDto image = null;

		image = rideService.getVehicleModelImage(vehicleModelId);
		return image.getImageData();
	}
}
