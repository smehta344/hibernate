package com.drivez.rider.rent.controller.request;

import java.util.Date;
import java.util.TreeMap;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;

import com.drivez.dto.rent.BookingInformationDto;
import com.drivez.dto.rent.PaymentTrackingDto;
import com.drivez.dto.rent.RentInfoDto;
import com.drivez.rider.rent.form.request.CreateRentRequestForm;
import com.drivez.security.bean.UserDetailsImpl;
import com.drivez.service.rent.RentService;
import com.drivez.util.DriveZConstants;
import com.paytm.pg.merchant.CheckSumServiceHelper;

@Controller
@PropertySource("classpath:paytm-gateway.properties")
public class CreateRentRequestController {
	@Value("${MID}")
	protected String mid;
	@Value("${MERCHANT_KEY}")
	protected String merchantKey;
	@Value("${INDUSTRY_TYPE_ID}")
	protected String industryTypeId;
	@Value("${CHANNEL_ID}")
	protected String channelId;
	@Value("${WEBSITE}")
	protected String webSite;
	@Value("${PAYTM_URL}")
	protected String payTMUrl;
	@Value("${CALLBACK_URL}")
	protected String callbackUrl;

	@Autowired
	protected RentService rentService;

	@PostMapping("/create-rent.web")
	public String createRentRequest(@ModelAttribute CreateRentRequestForm form, Model model) {
		BookingInformationDto bookingInformationDto = null;
		PaymentTrackingDto paymentTrackingDto = null;
		UserDetailsImpl userDetails = null;
		RentInfoDto rentInfoDto = null;
		String systemUserName = null;
		Object principle = null;
		String checkSum = null;
		int systemUserId = 0;

		principle = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principle instanceof UserDetails) {
			userDetails = (UserDetailsImpl) principle;
			systemUserName = userDetails.getUsername();
			systemUserId = userDetails.getSystemUserId();
		}
		bookingInformationDto = new BookingInformationDto();
		bookingInformationDto.setBookingDate(new Date());
		bookingInformationDto.setBookedVehichelId(form.getVehicleId());
		bookingInformationDto.setBookingServiceAreaId(form.getRentalServiceAreaId());
		bookingInformationDto.setCityId(form.getRentalCityId());
		bookingInformationDto.setCustomerId(systemUserId);
		bookingInformationDto.setHours(form.getHours());
		bookingInformationDto.setStatus(DriveZConstants.STATUS_RENT_PENDING_FOR_PAYMENT);
		bookingInformationDto.setTotalAmount(form.getTransactionAmount());
		bookingInformationDto.setVehichelModelId(form.getVehicleModelId());
		bookingInformationDto.setCreatedBy(systemUserName);
		bookingInformationDto.setCreatedDt(new Date());
		bookingInformationDto.setLastModifiedBy(systemUserName);
		bookingInformationDto.setLastModifiedDt(new Date());

		paymentTrackingDto = new PaymentTrackingDto();
		paymentTrackingDto.setCustomerId(systemUserId);
		paymentTrackingDto.setGatewayName("PayTM");
		paymentTrackingDto.setMid(mid);
		paymentTrackingDto.setStatus(DriveZConstants.STATUS_RENT_PENDING_FOR_PAYMENT);
		paymentTrackingDto.setCreatedBy(systemUserName);
		paymentTrackingDto.setCreatedDt(new Date());
		paymentTrackingDto.setLastModifiedBy(systemUserName);
		paymentTrackingDto.setLastModifiedDt(new Date());

		rentInfoDto = rentService.createRentRequest(bookingInformationDto, paymentTrackingDto);
		checkSum = generateChecksum(rentInfoDto.getBookingInformationId(), systemUserId, form.getTransactionAmount());

		model.addAttribute("mid", mid);
		model.addAttribute("orderId", rentInfoDto.getBookingInformationId());
		model.addAttribute("customerId", systemUserId);
		model.addAttribute("industryTypeId", industryTypeId);
		model.addAttribute("channelId", channelId);
		model.addAttribute("transactionAmount", form.getTransactionAmount());
		model.addAttribute("website", webSite);
		model.addAttribute("callbackUrl", callbackUrl);
		model.addAttribute("payTMUrl", payTMUrl);
		model.addAttribute("paytmChecksum", checkSum);

		return "redirect-paytm";
	}

	private String generateChecksum(int orderId, int customerId, double amount) {
		TreeMap<String, String> parameters;
		String paytmChecksum = null;

		parameters = new TreeMap<String, String>();
		parameters.put("MID", mid);
		parameters.put("ORDER_ID", String.valueOf(orderId));
		parameters.put("CUST_ID", String.valueOf(customerId));
		parameters.put("INDUSTRY_TYPE_ID", industryTypeId);
		parameters.put("CHANNEL_ID", channelId);
		parameters.put("TXN_AMOUNT", String.valueOf(amount));
		parameters.put("WEBSITE", webSite);
		parameters.put("CALLBACK_URL", callbackUrl);

		try {
			paytmChecksum = CheckSumServiceHelper.getCheckSumServiceHelper().genrateCheckSum(merchantKey, parameters);
		} catch (Exception e) {
			e.printStackTrace();
		}

		return paytmChecksum;
	}
}
