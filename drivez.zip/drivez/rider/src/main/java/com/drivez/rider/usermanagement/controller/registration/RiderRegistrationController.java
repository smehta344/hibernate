package com.drivez.rider.usermanagement.controller.registration;

import static com.drivez.util.DriveZConstants.IDENTIFICATION_TYPE_DRIVING_LICENSE;

import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.WebDataBinder;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.InitBinder;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.bind.support.SessionStatus;

import com.drivez.dto.system.CityDto;
import com.drivez.dto.system.CountryDto;
import com.drivez.dto.system.StateDto;
import com.drivez.dto.usermanagement.AddressDto;
import com.drivez.dto.usermanagement.IdentificationTypeDto;
import com.drivez.dto.usermanagement.UserDto;
import com.drivez.dto.usermanagement.UserIdentificationDetailsDto;
import com.drivez.exception.usermanagement.AccountAlreadyActivatedException;
import com.drivez.exception.usermanagement.AccountException;
import com.drivez.exception.usermanagement.AccountLockedOrDisabledException;
import com.drivez.exception.usermanagement.AccountVerificationFailedException;
import com.drivez.exception.usermanagement.AccountVerificationFailedException.Cause;
import com.drivez.exception.usermanagement.AccountVerificationFailedException.VerificationType;
import com.drivez.logging.DriveZLogger;
import com.drivez.rider.usermanagement.form.registration.RiderRegistrationForm;
import com.drivez.service.system.SystemService;
import com.drivez.service.usermanagement.UserManagementService;
import com.drivez.usermanagement.validator.registration.RiderAddressValidator;
import com.drivez.usermanagement.validator.registration.RiderDemographicValidator;

@Controller
@SessionAttributes({ "riderRegistrationForm" })
public class RiderRegistrationController {
	private final static DriveZLogger dLogger = DriveZLogger.getLogger(RiderRegistrationController.class);
	@Autowired
	private MessageSource messageSource;
	@Autowired
	private UserManagementService userManagementService;
	@Autowired
	private SystemService systemService;
	@Autowired
	private RiderDemographicValidator riderDemographicValidator;

	@InitBinder
	public void init(WebDataBinder webDataBinder) {
		webDataBinder.addValidators(riderDemographicValidator);
	}

	@GetMapping(value = "/demographic-registration.web")
	public String showRiderDemographicRegistrationForm(HttpSession httpSession, Model model) {
		RiderRegistrationForm riderRegistrationForm = null;

		dLogger.debug("handling request for demographic registration of rider");

		if (httpSession.getAttribute("riderRegistrationForm") == null) {
			riderRegistrationForm = new RiderRegistrationForm();
			model.addAttribute("riderRegistrationForm", riderRegistrationForm);
		}

		return "rider-demographic-register";
	}

	@PostMapping(value = "/demographic-registration.web")
	public String validateAndShowAddressForm(@Validated({
			RiderDemographicValidator.RegistrationDemographicGroup.class }) @ModelAttribute("riderRegistrationForm") RiderRegistrationForm riderRegistrationForm,
			BindingResult errors, Model model) {

		if (errors.hasErrors()) {
			dLogger.debug("Errors occure in demographic registration");
			return "rider-demographic-register";

		} else {
			dLogger.debug("handling post request for demographic registration of rider");
			return "rider-address-register";
		}
	}

	@PostMapping(value = "/rider-registration.web")
	public String registerRider(
			@Validated(RiderAddressValidator.RegistrationAddressGroup.class) @ModelAttribute("riderRegistrationForm") RiderRegistrationForm form,
			BindingResult errors, Model model, SessionStatus sessionStatus) {
		int systemUserId = 0;
		UserDto userDto = null;
		AddressDto addressDto = null;
		UserIdentificationDetailsDto userIdentificationDetailsDto = null;

		if (errors.hasErrors()) {
			dLogger.debug("errors occurred during address registration");
			return "rider-address-register";
		}

		addressDto = new AddressDto();
		addressDto.setStreetAddress(form.getAddressLine1());
		addressDto.setAreaOrLandMarkAddress(form.getAddressLine2());
		addressDto.setCityName(form.getCity());
		addressDto.setStateName(form.getState());
		addressDto.setZip(form.getZip());
		addressDto.setCountryName(form.getCountry());

		userDto = new UserDto();
		userDto.setDisplayName(form.getDisplayName());
		userDto.setEmailAddress(form.getEmailAddress());
		userDto.setDateOfBirth(form.getDateOfBirth());
		userDto.setGender(form.getGender());
		userDto.setMobileNumber(form.getMobileNumber());
		userDto.setPassword(form.getPassword());

		userIdentificationDetailsDto = new UserIdentificationDetailsDto();
		userIdentificationDetailsDto.setDrivingLicenseNo(form.getDrivingLicenseNo());
		userIdentificationDetailsDto.setDrivingLicenseIssuedAuthority(form.getDrivingLicenseIssuedAuthority());
		userIdentificationDetailsDto.setIdentificationTypeId(form.getIdentificationTypeId());
		userIdentificationDetailsDto.setIdentificationValue(form.getIdentificationValue());
		userIdentificationDetailsDto.setIdentificationIssuedAuthority(form.getIdentificationIssuedAuthority());

		systemUserId = userManagementService.registerRider(userDto, addressDto, userIdentificationDetailsDto);
		if (systemUserId > 0) {
			dLogger.info("Rider registered successful with systemUserId {} " + systemUserId);
		}

		model.addAttribute("mobileNumber", form.getMobileNumber());
		model.addAttribute("systemUserId", systemUserId);
		sessionStatus.setComplete();

		return "verify-otp";
	}

	@ResponseBody
	@GetMapping(value = "/{countryId}/states.web", produces = "application/json")
	public List<StateDto> getStates(@PathVariable("countryId") int countryId) {
		List<StateDto> states = null;

		states = systemService.getStates(countryId);
		return states;
	}

	@ResponseBody
	@GetMapping(value = "/{stateId}/cities.web", produces = "application/json")
	public List<CityDto> getCities(@PathVariable("stateId") int stateId) {
		return systemService.getCities(stateId);
	}

	@GetMapping("/{systemUserId}/{verificationCode}/email-verify.web")
	public String verifyRiderEmailAddress(@PathVariable("systemUserId") int systemUserId,
			@PathVariable("verificationCode") String verificationCode) {

		userManagementService.verifyUserEmailAddress(systemUserId, verificationCode);
		return "redirect:/email-verified.web";
	}

	@PostMapping("/otp-verify.web")
	public String verifyRiderMobileNumber(@RequestParam("systemUserId") int systemUserId,
			@RequestParam("otp") String otp, @RequestParam("mobileNumber") String mobileNumber, Model model) {
		String message = null;

		try {
			if (otp == null || otp.trim().length() == 0) {
				model.addAttribute("systemUserId", systemUserId);
				model.addAttribute("mobileNumber", mobileNumber);
				model.addAttribute("error", messageSource.getMessage("otp.empty", null, Locale.getDefault()));
				return "verify-otp";
			}
			userManagementService.verifyMobileNumber(systemUserId, otp);
		} catch (AccountVerificationFailedException e) {
			if (e.getFailureCause() == Cause.MISMATCH) {
				model.addAttribute("systemUserId", systemUserId);
				model.addAttribute("mobileNumber", mobileNumber);
				model.addAttribute("error", messageSource.getMessage("otp.mismatch", null, Locale.getDefault()));
				return "verify-otp";
			} else if (e.getFailureCause() == Cause.ALREADY_VERIFIED) {
				message = messageSource.getMessage("account.mobileNumber.already.verified", null, Locale.getDefault());
				model.addAttribute("message", message);
				return "redirect:/account-verified-error.web";
			}
		}
		return "redirect:/otp-verified.web";
	}

	@ExceptionHandler(AccountException.class)
	public String handleAccountException(AccountException e, Model model) {
		String message = null;

		if (e instanceof AccountAlreadyActivatedException) {
			message = messageSource.getMessage("account.already.active", null, Locale.getDefault());
		} else if (e instanceof AccountLockedOrDisabledException) {
			message = messageSource.getMessage("account.lockedOrDisabled", null, Locale.getDefault());
		} else if (e instanceof AccountVerificationFailedException) {
			if (((AccountVerificationFailedException) e).getFailureCause() == Cause.ALREADY_VERIFIED) {
				if (((AccountVerificationFailedException) e).getVerificationType() == VerificationType.EMAIL_ADDRESS) {
					message = messageSource.getMessage("account.emailAddress.already.verified", null,
							Locale.getDefault());
				} else {
					message = messageSource.getMessage("account.mobileNumber.already.verified", null,
							Locale.getDefault());
				}
			} else if (((AccountVerificationFailedException) e).getFailureCause() == Cause.MISMATCH) {
				if (((AccountVerificationFailedException) e).getVerificationType() == VerificationType.EMAIL_ADDRESS) {
					message = messageSource.getMessage("account.emailAddress.verification.failed", null,
							Locale.getDefault());
				}
			}
		}
		model.addAttribute("message", message);
		return "redirect:/account-verified-error.web";
	}

	@ModelAttribute("identificationTypes")
	public List<IdentificationTypeDto> populateIdentificationTypes() {
		List<IdentificationTypeDto> identificationTypes = null;
		int index = -1;

		identificationTypes = userManagementService.getIdentificationTypes();
		for (int i = 0; i < identificationTypes.size(); i++) {
			if (identificationTypes.get(i).getIdentificationTypeName().equals(IDENTIFICATION_TYPE_DRIVING_LICENSE)) {
				index = i;
				break;
			}
		}
		if (index >= 0) {
			identificationTypes.remove(index);
		}

		return identificationTypes;
	}

	@ModelAttribute("countries")
	public List<CountryDto> populateCountries() {
		return systemService.getCountries();
	}
}
