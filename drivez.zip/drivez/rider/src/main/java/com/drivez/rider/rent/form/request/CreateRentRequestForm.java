package com.drivez.rider.rent.form.request;

import java.io.Serializable;

public class CreateRentRequestForm implements Serializable {
	private static final long serialVersionUID = -6364069627531037211L;
	protected int vehicleId;
	protected int vehicleModelId;
	protected int hours;
	protected int rentalCityId;
	protected int rentalServiceAreaId;
	protected double transactionAmount;

	public int getVehicleId() {
		return vehicleId;
	}

	public void setVehicleId(int vehicleId) {
		this.vehicleId = vehicleId;
	}

	public int getVehicleModelId() {
		return vehicleModelId;
	}

	public void setVehicleModelId(int vehicleModelId) {
		this.vehicleModelId = vehicleModelId;
	}

	public int getHours() {
		return hours;
	}

	public void setHours(int hours) {
		this.hours = hours;
	}

	public int getRentalCityId() {
		return rentalCityId;
	}

	public void setRentalCityId(int rentalCityId) {
		this.rentalCityId = rentalCityId;
	}

	public int getRentalServiceAreaId() {
		return rentalServiceAreaId;
	}

	public void setRentalServiceAreaId(int rentalServiceAreaId) {
		this.rentalServiceAreaId = rentalServiceAreaId;
	}

	public double getTransactionAmount() {
		return transactionAmount;
	}

	public void setTransactionAmount(double transactionAmount) {
		this.transactionAmount = transactionAmount;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
