package com.drivez.rider.javaconfig;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({ WebMvcConfig.class })
public class RiderWebRootConfig {

}
