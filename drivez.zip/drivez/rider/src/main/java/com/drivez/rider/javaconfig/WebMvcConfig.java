package com.drivez.rider.javaconfig;

import org.springframework.context.MessageSource;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.support.ResourceBundleMessageSource;
import org.springframework.validation.Validator;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.ViewControllerRegistry;
import org.springframework.web.servlet.config.annotation.ViewResolverRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurerAdapter;
import org.springframework.web.servlet.view.tiles3.TilesConfigurer;

import com.drivez.logging.DriveZLogger;

@Configuration
@EnableWebMvc
@ComponentScan(basePackages = { "com.drivez.rider.usermanagement.controller.*", "com.drivez.usermanagement.validator.*",
		"com.drivez.rider.ride.controller.*", "com.drivez.rider.rent.controller.*" })
public class WebMvcConfig extends WebMvcConfigurerAdapter {
	private final static DriveZLogger dLogger = DriveZLogger.getLogger(WebMvcConfig.class);

	@Override
	public void addViewControllers(ViewControllerRegistry registry) {
		registry.addViewController("/products.web").setViewName("products");
		registry.addViewController("/verify-otp.web").setViewName("verify-otp");
		registry.addViewController("/otp-verified.web").setViewName("otp-verified");
		registry.addViewController("/email-verified.web").setViewName("email-verified");
		registry.addViewController("/account-verified-error.web").setViewName("account-verified-error");
		registry.addViewController("/login.web").setViewName("login");
		registry.addViewController("/check-out.web").setViewName("check-out");
		registry.addViewController("/redirect-paytm.web").setViewName("redirect-paytm");
		registry.addViewController("/vehicle-booked.web").setViewName("vehicle-booked");
		dLogger.debug("view controllers registered");
	}

	@Override
	public void addResourceHandlers(ResourceHandlerRegistry registry) {
		registry.addResourceHandler("/css/*").addResourceLocations("/WEB-INF/css/");
		registry.addResourceHandler("/js/*").addResourceLocations("/WEB-INF/js/");
		registry.addResourceHandler("/images/**").addResourceLocations("/WEB-INF/images/");
		registry.addResourceHandler("/fonts/**").addResourceLocations("/WEB-INF/fonts/");
		dLogger.debug("resource handlers registered");
	}

	@Override
	public void configureViewResolvers(ViewResolverRegistry registry) {
		registry.tiles();
		dLogger.debug("tilesViewResolver configured");
	}

	@Override
	public Validator getValidator() {
		return super.getValidator();
	}

	@Bean
	public TilesConfigurer tilesConfigurer() {
		TilesConfigurer tilesConfigurer = null;

		tilesConfigurer = new TilesConfigurer();
		tilesConfigurer.setDefinitions("/WEB-INF/tiles-definitions.xml");
		return tilesConfigurer;
	}

	@Bean
	public MessageSource messageSource() {
		ResourceBundleMessageSource messageSource = null;
		messageSource = new ResourceBundleMessageSource();
		messageSource.setBasenames("errors", "messages");

		return messageSource;
	}

}
