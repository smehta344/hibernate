package com.drivez.rider.usermanagement.form.registration;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.Email;
import org.hibernate.validator.constraints.NotBlank;
import org.springframework.format.annotation.DateTimeFormat;

import com.drivez.usermanagement.validator.registration.RiderAddressValidator;
import com.drivez.usermanagement.validator.registration.RiderDemographicValidator;

public class RiderRegistrationForm implements Serializable {
	private static final long serialVersionUID = 737451477977641917L;

	// demographic fields
	@Size(max = 8, min = 5, groups = { RiderDemographicValidator.RegistrationDemographicGroup.class })
	protected String displayName;
	@NotBlank(groups = { RiderDemographicValidator.RegistrationDemographicGroup.class })
	@Email(groups = { RiderDemographicValidator.RegistrationDemographicGroup.class })
	protected String emailAddress;
	@Size(min = 8, max = 15, groups = { RiderDemographicValidator.RegistrationDemographicGroup.class })
	protected String password;
	@NotBlank(groups = { RiderDemographicValidator.RegistrationDemographicGroup.class })
	protected String reTypePassword;
	@Size(min = 12, max = 14, groups = { RiderDemographicValidator.RegistrationDemographicGroup.class })
	protected String mobileNumber;
	@NotBlank(groups = { RiderDemographicValidator.RegistrationDemographicGroup.class })
	protected String gender;
	@NotNull(groups = { RiderDemographicValidator.RegistrationDemographicGroup.class })
	@DateTimeFormat(pattern = "dd/mm/yyyy")
	protected Date dateOfBirth;

	@Size(min = 16, max = 16, groups = { RiderDemographicValidator.RegistrationDemographicGroup.class })
	protected String drivingLicenseNo;
	@NotBlank(groups = { RiderDemographicValidator.RegistrationDemographicGroup.class })
	protected String drivingLicenseIssuedAuthority;

	// address fields
	@NotNull(groups = { RiderAddressValidator.RegistrationAddressGroup.class })
	protected int identificationTypeId;
	@NotBlank(groups = { RiderAddressValidator.RegistrationAddressGroup.class })
	@Size(min = 5, max = 50, groups = { RiderAddressValidator.RegistrationAddressGroup.class })
	protected String identificationValue;
	@NotBlank(groups = { RiderAddressValidator.RegistrationAddressGroup.class })
	protected String identificationIssuedAuthority;
	@NotBlank(groups = { RiderAddressValidator.RegistrationAddressGroup.class })
	protected String addressLine1;
	protected String addressLine2;
	@NotBlank(groups = { RiderAddressValidator.RegistrationAddressGroup.class })
	protected String city;
	@NotBlank(groups = { RiderAddressValidator.RegistrationAddressGroup.class })
	protected String state;

	@Min(value = 1000, groups = { RiderAddressValidator.RegistrationAddressGroup.class })
	@Max(value = 999999, groups = { RiderAddressValidator.RegistrationAddressGroup.class })
	protected int zip;
	@NotBlank(groups = { RiderAddressValidator.RegistrationAddressGroup.class })
	protected String country;

	public String getDisplayName() {
		return displayName;
	}

	public void setDisplayName(String displayName) {
		this.displayName = displayName;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getReTypePassword() {
		return reTypePassword;
	}

	public void setReTypePassword(String reTypePassword) {
		this.reTypePassword = reTypePassword;
	}

	public String getMobileNumber() {
		return mobileNumber;
	}

	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(Date dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}

	public String getDrivingLicenseNo() {
		return drivingLicenseNo;
	}

	public void setDrivingLicenseNo(String drivingLicenseNo) {
		this.drivingLicenseNo = drivingLicenseNo;
	}

	public String getDrivingLicenseIssuedAuthority() {
		return drivingLicenseIssuedAuthority;
	}

	public void setDrivingLicenseIssuedAuthority(String drivingLicenseIssuedAuthority) {
		this.drivingLicenseIssuedAuthority = drivingLicenseIssuedAuthority;
	}

	public int getIdentificationTypeId() {
		return identificationTypeId;
	}

	public void setIdentificationTypeId(int identificationTypeId) {
		this.identificationTypeId = identificationTypeId;
	}

	public String getIdentificationValue() {
		return identificationValue;
	}

	public void setIdentificationValue(String identificationValue) {
		this.identificationValue = identificationValue;
	}

	public String getIdentificationIssuedAuthority() {
		return identificationIssuedAuthority;
	}

	public void setIdentificationIssuedAuthority(String identificationIssuedAuthority) {
		this.identificationIssuedAuthority = identificationIssuedAuthority;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getZip() {
		return zip;
	}

	public void setZip(int zip) {
		this.zip = zip;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

}
