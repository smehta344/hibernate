package com.drivez.usermanagement.validator.registration;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.drivez.rider.usermanagement.form.registration.RiderRegistrationForm;
import com.drivez.service.usermanagement.UserManagementService;
import com.drivez.util.ValidationUtil;

@Component
public class RiderDemographicValidator implements Validator {

	@Autowired
	UserManagementService userManagementService;

	@Autowired
	ValidationUtil validationUtil;

	@Override
	public boolean supports(Class<?> classType) {
		return classType.isAssignableFrom(RiderRegistrationForm.class);
	}

	@Override
	public void validate(Object obect, Errors errors) {

		RiderRegistrationForm riderRegistrationForm;
		riderRegistrationForm = (RiderRegistrationForm) obect;

		// Here we have to write logic for wheather user exist or not
		Boolean isEmailAddressExist;

		if (errors.hasFieldErrors("emailAddress") == false) {
			isEmailAddressExist = userManagementService.isUserExists(riderRegistrationForm.getEmailAddress());
			if (isEmailAddressExist) {
				errors.rejectValue("emailAddress", "emailAddress.Exist");
			}
		}

		if (errors.hasFieldErrors("password") == false && errors.hasFieldErrors("reTypePassword") == false) {
			if (riderRegistrationForm.getPassword().equals(riderRegistrationForm.getReTypePassword()) == false) {
				errors.rejectValue("reTypePassword", "reTypePassword.notMatched");
			}
		}

	}

	public interface RegistrationDemographicGroup {
	}

}
