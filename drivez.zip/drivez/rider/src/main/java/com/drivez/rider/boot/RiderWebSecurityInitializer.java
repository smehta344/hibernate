package com.drivez.rider.boot;

import org.springframework.security.web.context.AbstractSecurityWebApplicationInitializer;

public class RiderWebSecurityInitializer extends AbstractSecurityWebApplicationInitializer {

}
