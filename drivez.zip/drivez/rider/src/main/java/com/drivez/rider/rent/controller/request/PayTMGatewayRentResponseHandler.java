package com.drivez.rider.rent.controller.request;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.drivez.dto.rent.PaymentTrackingDto;
import com.drivez.paytm.bean.response.PaytmResponseBean;
import com.drivez.service.rent.RentService;
import com.drivez.util.DriveZConstants;

@Controller
public class PayTMGatewayRentResponseHandler {
	@Autowired
	private RentService rentService;

	@RequestMapping(value = "/paytm-gateway-response.web")
	public String handlePayTMResponse(@ModelAttribute PaytmResponseBean response, Model model) {
		PaymentTrackingDto paymentTrackingDto = null;
		int bookingInformationId = 0;
		String outcome = null;

		bookingInformationId = Integer.parseInt(response.getORDERID());
		paymentTrackingDto = new PaymentTrackingDto();
		paymentTrackingDto.setBookingId(bookingInformationId);
		paymentTrackingDto.setBankName(response.getBANKNAME());
		paymentTrackingDto.setBankResponseCode(response.getRESPCODE());
		paymentTrackingDto.setBankResponseMessage(response.getRESPMSG());
		paymentTrackingDto.setBankTransactionId(response.getBANKTXNID());
		paymentTrackingDto.setGatewayTransactionId(response.getTXNID());
		paymentTrackingDto.setPaymentMode(response.getPAYMENTMODE());
		paymentTrackingDto.setLastModifiedBy("system");
		paymentTrackingDto.setLastModifiedDt(new Date());

		if (response.getRESPCODE().equals("01")) {

			rentService.updateRentStatus(bookingInformationId, paymentTrackingDto,
					DriveZConstants.STATUS_RENT_PAYMENT_PROCESSED);
			model.addAttribute("txNo", bookingInformationId);
			outcome = "vehicle-booked";
		} else {
			rentService.updateRentStatus(bookingInformationId, paymentTrackingDto,
					DriveZConstants.STATUS_RENT_PAYEMNT_FAILED);
			model.addAttribute("error", response.getRESPMSG());
			outcome = "payment-error";
		}

		return outcome;
	}
}
