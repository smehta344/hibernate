package com.drivez.rider.javaconfig;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.authentication.ExceptionMappingAuthenticationFailureHandler;

@Configuration
@ComponentScan(basePackages = { "com.drivez.security.*" })
@EnableWebSecurity
public class RiderWebSecurityConfig extends WebSecurityConfigurerAdapter {
	@Autowired
	private UserDetailsService userDetailsService;
	@Autowired
	private AuthenticationFailureHandler authenticationFailureHandler;

	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf().disable();
		http.formLogin().loginPage("/login.web").loginProcessingUrl("/login-process.web").usernameParameter("username")
				.passwordParameter("password").failureHandler(authenticationFailureHandler)
				.defaultSuccessUrl("/home/rider.web");
		http.logout().logoutUrl("/logout.web").clearAuthentication(true).invalidateHttpSession(true)
				.logoutSuccessUrl("/home/rider.web");

		http.authorizeRequests()
				.antMatchers("/css/*", "/js/*", "/images/**", "/fonts/**", "/home/rider.web", "/login.web",
						"/logout.web", "/demographic-registration.web", "/rider-registration.web",
						"/email-verified.web", "/account-verified-error.web", "/otp-verified.web",
						"/**/change-rider-city.web", "/**/city-image.web", "/**/offer-image.web",
						"/**/vehicle-model-image.web", "/*/cities.web", "/*/states.web", "/countries.web")
				.permitAll().antMatchers("/check-out.web").access("hasAuthority('DRVZ_RIDER')");
	}

	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		auth.userDetailsService(userDetailsService);
	}

	@Bean
	public AuthenticationFailureHandler authenticationFailureHandler() {
		ExceptionMappingAuthenticationFailureHandler authenticationFailureHandler = null;
		Map<String, String> exceptionMappings = null;

		authenticationFailureHandler = new ExceptionMappingAuthenticationFailureHandler();
		exceptionMappings = new HashMap<String, String>();
		exceptionMappings.put(BadCredentialsException.class.getCanonicalName(), "/login.web?bad");
		exceptionMappings.put(LockedException.class.getCanonicalName(), "/login.web?locked");
		exceptionMappings.put(DisabledException.class.getCanonicalName(), "/login.web?notActive");
		authenticationFailureHandler.setExceptionMappings(exceptionMappings);

		return authenticationFailureHandler;
	}

}
