package com.drivez.rider.boot;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRegistration;

import org.springframework.web.WebApplicationInitializer;
import org.springframework.web.context.support.AnnotationConfigWebApplicationContext;
import org.springframework.web.servlet.DispatcherServlet;

import com.drivez.logging.DriveZLogger;
import com.drivez.resource.listener.RiderWebApplicationContextListener;
import com.drivez.rider.javaconfig.RiderWebRootConfig;
import com.drivez.rider.javaconfig.RiderWebSecurityConfig;
import com.drivez.service.javaconfig.ServiceRootConfig;

public class RiderWebDispatcherServletInitializer implements WebApplicationInitializer {
	private final static DriveZLogger dLogger = DriveZLogger.getLogger(RiderWebDispatcherServletInitializer.class);

	@Override
	public void onStartup(ServletContext servletContext) throws ServletException {
		DispatcherServlet dispatcher = null;
		RiderWebApplicationContextListener riderWebApplicationContextListener = null;
		AnnotationConfigWebApplicationContext rootAnnotationConfigApplicationContext = null;
		AnnotationConfigWebApplicationContext servletAnnotationConfigApplicationContext = null;

		rootAnnotationConfigApplicationContext = new AnnotationConfigWebApplicationContext();
		rootAnnotationConfigApplicationContext.register(ServiceRootConfig.class, RiderWebSecurityConfig.class);

		riderWebApplicationContextListener = new RiderWebApplicationContextListener(
				rootAnnotationConfigApplicationContext);
		servletContext.addListener(riderWebApplicationContextListener);

		servletAnnotationConfigApplicationContext = new AnnotationConfigWebApplicationContext();
		servletAnnotationConfigApplicationContext.register(RiderWebRootConfig.class);

		dispatcher = new DispatcherServlet(servletAnnotationConfigApplicationContext);
		ServletRegistration.Dynamic dynamic = servletContext.addServlet("dispatcher", dispatcher);
		dynamic.setLoadOnStartup(2);
		dynamic.addMapping("/");
	}

}
