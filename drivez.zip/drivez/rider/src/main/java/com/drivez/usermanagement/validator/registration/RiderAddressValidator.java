package com.drivez.usermanagement.validator.registration;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.drivez.rider.usermanagement.form.registration.RiderRegistrationForm;

@Component
public class RiderAddressValidator implements Validator {

	@Override
	public boolean supports(Class<?> classType) {

		return classType.isAssignableFrom(RiderRegistrationForm.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		
		
	}
	
	public interface RegistrationAddressGroup {
		
	}
	
}
