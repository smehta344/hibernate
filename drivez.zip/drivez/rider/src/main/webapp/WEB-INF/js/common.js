function toggleErrors() {
	$('p.error').each(function(index, obj, array) {
		if ($(obj).text().trim().length > 0) {
			$(obj).show();
		} else {
			$(obj).hide();
		}
	});
}

function populateSelectOptions(id, data, labelName, labelValue, selectedData) {
	var option = null;
	var opId = null;
	var opValue = null;
	var emptyOption = null;
	
	emptyOption = document.createElement("option");
	$("#"+id).empty();
	$("#"+id).append(emptyOption);
	
	$(data).each(function(index, obj, array){
		option = document.createElement("option");
		opId=$(obj).attr(labelValue);
		opValue=$(obj).attr(labelName);
		
		option.value=opId;
		option.innerText=opValue;
		if(selectedData != null && opId == selectedData) {
			option.selected=true;
		}
		$("#"+id).append(option);
	});
}









