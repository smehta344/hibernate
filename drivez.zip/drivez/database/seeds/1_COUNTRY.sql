INSERT INTO `drivezdb`.`country`
(`country_id`,
`country_nm`,
`status`,
`created_by`,
`created_dt`,
`last_modified_by`,
`last_modified_dt`)
VALUES
(1,'India','A','system',sysdate(),'system',sysdate());
