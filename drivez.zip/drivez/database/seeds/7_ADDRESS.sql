INSERT INTO `drivezdb`.`address`
(`address_id`,
`address_line1`,
`address_line2`,
`city`,
`state`,
`zip`,
`country`,
`created_by`,
`created_dt`,
`last_modified_by`,
`last_modified_dt`)
VALUES
(1,'Powai, JVLR Road, Opposite- Mirchi & Mime Restaurant','Lake Boulevard, Hiranandani Business Park, Powai','Mumbai','Maharashtra','400076','India','system',sysdate(),'system',sysdate()),
(2,'B.M.C Parking, Opp Runwal Chestnut Bldg. Village Road, Mulund Goregaon Link Road,',' Mulund West','Mumbai','Maharashtra','400078','India','system',sysdate(),'system',sysdate()),
(3,'70-C, Nehru Road','Chhatrapati Shivaji International Airport Area, Vile Parle','Mumbai','Maharashtra','','India','system',sysdate(),'system',sysdate()),
(4,'Opp to BPCL Juhu Versova Link Road,','jeevan Sapna Building, beside Banana Leaf Restaurant','Mumbai','Maharashtra','400053','India','system',sysdate(),'system',sysdate()),
(5,'2nd main, Somashekhar Reddy layout', 'near Horumau ring-road signal','Benguluru','Karnataka','','India','system',sysdate(),'system',sysdate()),

(6,'Behind Royal Enfield Service Center', 'Near Jeevika Hospital, Aswath Nagar,Marathahalli,','Benguluru','Karnataka','560037','India','system',sysdate(),'system',sysdate()),

(8,'#588, 20th Main Road, 1st Cross', '8th Block','Benguluru','Karnataka','','India','system',sysdate(),'system',sysdate()),

(9,'12th Cross, Govindaraja Nagar, 2nd stage', 'Malagala, Nagarbhavi','Benguluru','Karnataka','560072','India','system',sysdate(),'system',sysdate()),

(10,'Opp to Decathlon', ' Beside Chikkajala Police Station - Chikkajala','Benguluru','Karnataka','562157','India','system',sysdate(),'system',sysdate()),

(11,'P4 Parking, Kempegowda', 'International Airport Gangamuthanahalli','Benguluru','Karnataka','562300','India','system',sysdate(),'system',sysdate()),

(12,'Orchid Lakeview', 'Kariyammana Agrahara, Bellandur','Benguluru','Karnataka','560103','India','system',sysdate(),'system',sysdate()),

(13,'NO # 407, Ganesh Layout', 'Vidyaranayapura, MS Pallya','Benguluru','Karnataka','','India','system',sysdate(),'system',sysdate()),
(14,'19, Opp Karachi Bakery, Old Mumbai Highway', 'Vinayak Nagar, Indira Nagar, Gachibowli','Hyderabad','Telengana','500032','India','system',sysdate(),'system',sysdate()),

(15,'DMART Level 1 Parking, 283/A', 'Kavuri Hills Rd, CBI Colony, Jubilee Hills','Hyderabad','Telengana','500033','India','system',sysdate(),'system',sysdate()),

(16,'Kukatpally Metro Station Parking', 'Balaji Nagar, Kukatpally','Hyderabad','Telengana','500032','India','system',sysdate(),'system',sysdate()),

(17,'Ameerpet Metro Station Parking', 'Nagarjuna Nagar colony, Yella Reddy Guda','Hyderabad','Telengana','500073','India','system',sysdate(),'system',sysdate()),

(18,'Prakash Nagar, Ameerpet, Begumpet', 'Near Hanuman Temple','Hyderabad','Telengana','500016','India','system',sysdate(),'system',sysdate()),

(19,'IICT Campus, Inner Ring Rd, IICT & IICT Colony', 'IICT Colony, Tarnaka','Hyderabad','Telengana','500007','India','system',sysdate(),'system',sysdate()),

(20,'A, Near Cyber towers, 7, 2, Hitech City Rd', 'Jaihind Enclave, HITEC City','Hyderabad','Telengana','500081','India','system',sysdate(),'system',sysdate()),

(21,'Basement Brand Factory - BHEL Cross Road Ramachandrapuram', 'Gouthami Nagar Colony, Jawahar Colony, Serilingampally','Hyderabad','Telengana','500007','India','system',sysdate(),'system',sysdate()),
(22,'', 'Next To Kumar Theater, Kachiguda','Hyderabad','Telengana','500027','India','system',sysdate(),'system',sysdate()),
(23,'Near LB Nagar Metro Station', ' Pragati Nagar, 3-6-293/1, SBH Colony, LB Nagar','Hyderabad','Telengana','500074','India','system',sysdate(),'system',sysdate());
