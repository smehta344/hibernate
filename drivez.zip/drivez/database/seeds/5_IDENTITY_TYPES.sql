INSERT INTO `drivezdb`.`identity_type`
(`identity_type_id`,
`identity_type_nm`,
`description`,
`created_by`,
`created_dt`,
`last_modified_by`,
`last_modified_dt`
)
VALUES
(1,'Aadhar Card','It is one of the unique identification made up of biometric data of a person ','system',sysdate(),'system',sysdate()),
(2,'PAN','It refers to permanant account  issued by income tax for  easy retrieval of information and matching information relating to an assesseement','system',sysdate(),'system',sysdate()),
(3,'Voter Card','It primarily serves as an identity proof for Indian citizens while casting their ballot in the country  municipal, state, and national elections. ','system',sysdate(),'system',sysdate()),
(4,'Driving License ','It is an identity to certify the person eligibility to drive a vehicel ','system',sysdate(),'system',sysdate()),
(5,'Ration Card ','Document issued by state governments in India to households that are eligible to purchase subsidized food grain from the Public Distribution System (under the National Food Security Act).','system',sysdate(),'system',sysdate()),
(6,'Passport','It is issued by order of the President of India to Indian citizens for the purpose of international travel. It enables the bearer to travel internationally and serves as proof of Indian citizenship as per the Passports Act (1967).','system',sysdate(),'system',sysdate());

