INSERT INTO `drivezdb`.`vehichel_type`
(`vehichel_type_id`,
`type_nm`,
`description`,
`created_dt`,
`created_by`,
`last_modified_dt`,
`last_modified_by`)
VALUES
(1,"Bike","It can be any two wheeler automobile like scooty, bike",sysdate(),'system',sysdate(),'system'),
(2,"Car","It can be any four wheeler automobile like car, SUV  ",sysdate(),'system',sysdate(),'system');

