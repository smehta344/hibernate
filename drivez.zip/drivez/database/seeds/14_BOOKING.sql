INSERT INTO `drivezdb`.`booking_information`
(`booking_information_id`,
`hours`,
`total_amount`,
`booking_service_area_id`,
`status`,
`vehichel_model_id`,
`city_id`,
`customer_id`,
`transaction_id`,
`booking_date`,
`booked_vehichel_id`,
`created_by`,
`created_dt`,
`last_modified_by`,
`last_modified_dt`)
VALUES
(1,5,200,1,'C',21,1,1,1,sysdate(),1,'system',sysdate(),'system',sysdate()),
(2,3,200,1,'C',1,1,1,2,sysdate(),7,'system',sysdate(),'system',sysdate()),
(3,5,300,1,'C',2,1,1,3,sysdate(),8,'system',sysdate(),'system',sysdate()),
(4,8,600,1,'C',22,1,1,4,sysdate(),2,'system',sysdate(),'system',sysdate()),
(5,5,210,2,'C',36,1,1,5,sysdate(),15,'system',sysdate(),'system',sysdate()),
(6,5,200,2,'C',34,1,1,6,sysdate(),17,'system',sysdate(),'system',sysdate()),
(7,5,200,2,'C',21,1,1,7,sysdate(),19,'system',sysdate(),'system',sysdate()),
(8,5,290,22,'C',21,1,1,8,sysdate(),18,'system',sysdate(),'system',sysdate()),

(9,5,200,7,'C',21,2,1,9,sysdate(),54,'system',sysdate(),'system',sysdate()),
(10,3,200,7,'C',23,2,1,10,sysdate(),56,'system',sysdate(),'system',sysdate()),
(11,5,300,7,'C',7,2,1,11,sysdate(),59,'system',sysdate(),'system',sysdate()),
(12,8,600,8,'C',12,2,1,12,sysdate(),68,'system',sysdate(),'system',sysdate()),
(13,5,210,8,'C',11,2,1,13,sysdate(),67,'system',sysdate(),'system',sysdate()),
(14,5,200,8,'C',13,2,1,14,sysdate(),69,'system',sysdate(),'system',sysdate()),
(15,5,200,9,'C',19,2,1,15,sysdate(),79,'system',sysdate(),'system',sysdate()),
(16,5,290,10,'C',1,2,1,16,sysdate(),84,'system',sysdate(),'system',sysdate()),

(17,5,200,25,'C',12,3,1,17,sysdate(),139,'system',sysdate(),'system',sysdate()),
(18,3,200,25,'C',13,3,1,18,sysdate(),140,'system',sysdate(),'system',sysdate()),
(19,5,300,25,'C',21,3,1,19,sysdate(),146,'system',sysdate(),'system',sysdate()),

(20,8,600,24,'C',30,3,1,20,sysdate(),131,'system',sysdate(),'system',sysdate()),
(21,5,210,24,'C',31,3,1,21,sysdate(),132,'system',sysdate(),'system',sysdate()),
(22,5,200,24,'C',9,3,1,22,sysdate(),136,'system',sysdate(),'system',sysdate()),

(23,5,200,28,'C',34,3,1,23,sysdate(),173,'system',sysdate(),'system',sysdate()),
(24,5,290,28,'C',33,3,1,24,sysdate(),172,'system',sysdate(),'system',sysdate());



