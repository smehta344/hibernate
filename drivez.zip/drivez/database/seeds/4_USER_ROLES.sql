INSERT INTO `drivezdb`.`user_role`
(`user_role_id`,
`user_role_cd`,
`description`,
`created_dt`,
`created_by`,
`last_modified_dt`,
`last_modified_by`)
VALUES
(1,'DRVZ_ADM',"Administrator has all the system privileges",sysdate(),'system',sysdate(),'system'),
(2,'DRVZ_CSR',"Customer Service Representative  has system privileges of accessing the user account, approve cancellations, verification of identity and customer enquiry",sysdate(),'system',sysdate(),'system'),
(3,'DRVZ_RIDER',"Rider the system privileges of booking a ride ,selecting packages, registarting complaints  ",sysdate(),'system',sysdate(),'system');
