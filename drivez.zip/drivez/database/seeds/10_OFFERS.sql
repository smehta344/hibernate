INSERT INTO `drivezdb`.`offers`
(`offer_id`,
`offer_image_type`,
`offer_image_nm`,
`offer_image`,
`status`,
`percentage_discount`,
`description`,
`coupon_code`,
`created_by`,
`created_dt`,
`last_modified_by`,
`last_modified_dt`)
VALUES
(1,"img/png","img1","","A",10,"Flat 10 % off on your first booking","FIRST",'system',sysdate(),'system',sysdate()),
(2,"img/png","img2","","A",10,"Flat 10 % off for Delhi User","DELHI10",'system',sysdate(),'system',sysdate()),
(3,"img/png","img3","","A",10,"Flat 10 % off on all honda city booking","CITY10",'system',sysdate(),'system',sysdate()),
(4,"img/png","img4","","A",20,"Flat 20 % off on your second booking","REPEAT",'system',sysdate(),'system',sysdate()),
(5,"img/png","img5","","A",10,"Flat 10 % super cash when paid through MobiQuick","SUPER10",'system',sysdate(),'system',sysdate()),
(6,"img/png","img6","","A",50,"New paypal users  get 50 % off on your first booking","SAFE HAI",'system',sysdate(),'system',sysdate());
