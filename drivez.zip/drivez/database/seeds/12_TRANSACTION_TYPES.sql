INSERT INTO `drivezdb`.`transaction_type`
(`transaction_type_id`,
`transaction_type_nm`,
`description`,
`created_by`,
`created_dt`,
`last_modified_by`,
`last_modified_dt`)
VALUES
(1,"NEFT","National Electronic Fund Transfer (NEFT)",'system',sysdate(),'system',sysdate()),
(2,"RTGS","Real Time Gross Settlement",'system',sysdate(),'system',sysdate()),
(3,"ECS","Electronic Clearing System (ECS)",'system',sysdate(),'system',sysdate()),
(4,"IMPS","Immediate Payment Service (IMPS) ",'system',sysdate(),'system',sysdate());
