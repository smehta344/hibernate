CREATE DATABASE  IF NOT EXISTS `drivezdb` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `drivezdb`;
-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: 127.0.0.1    Database: drivezdb
-- ------------------------------------------------------
-- Server version	5.7.21-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `address` (
  `address_id` int(11) NOT NULL AUTO_INCREMENT,
  `address_line1` varchar(150) DEFAULT NULL,
  `address_line2` varchar(150) DEFAULT NULL,
  `city` varchar(45) DEFAULT NULL,
  `state` varchar(45) DEFAULT NULL,
  `zip` varchar(45) DEFAULT NULL,
  `country` varchar(45) DEFAULT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_modified_by` varchar(45) NOT NULL,
  `last_modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`address_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `booking_cancellation_or_refund`
--

DROP TABLE IF EXISTS `booking_cancellation_or_refund`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking_cancellation_or_refund` (
  `booking_cancellation_or_refund_id` int(11) NOT NULL AUTO_INCREMENT,
  `cancellation_or_refund_requested_dt` timestamp NULL DEFAULT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `cancelled_or_refund_customer_user_id` int(11) DEFAULT NULL,
  `reason_for_cancellation_or_refund` varchar(45) DEFAULT NULL,
  `cancellation_or_refund` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `status_changed_by_csr_id` int(11) DEFAULT NULL,
  `refund_or_cancellation_transaction_id` int(11) DEFAULT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_modified_by` varchar(45) NOT NULL,
  `last_modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`booking_cancellation_or_refund_id`),
  KEY `drivez.booked_user_id_idx` (`booking_id`),
  KEY `drivez.cancelled_or_refund_sys_user_idx` (`refund_or_cancellation_transaction_id`),
  KEY `drivez.status_changed_by_csr_id_idx` (`status_changed_by_csr_id`),
  CONSTRAINT `drivez.booked_user_id` FOREIGN KEY (`booking_id`) REFERENCES `booking_information` (`booking_information_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `drivez.cancelled_or_refund_sys_user` FOREIGN KEY (`refund_or_cancellation_transaction_id`) REFERENCES `system_user` (`system_user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `drivez.status_changed_by_csr_id` FOREIGN KEY (`status_changed_by_csr_id`) REFERENCES `system_user` (`system_user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `refund_or_cancellation_txn_id` FOREIGN KEY (`refund_or_cancellation_transaction_id`) REFERENCES `transaction` (`transaction_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `booking_information`
--

DROP TABLE IF EXISTS `booking_information`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `booking_information` (
  `booking_information_id` int(11) NOT NULL AUTO_INCREMENT,
  `hours` int(11) DEFAULT NULL,
  `total_amount` int(11) DEFAULT NULL,
  `booking_service_area_id` int(11) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `vehichel_model_id` int(11) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `transaction_id` int(11) DEFAULT NULL,
  `booking_date` timestamp NULL DEFAULT NULL,
  `booked_vehichel_id` int(11) DEFAULT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_dt` varchar(45) NOT NULL,
  `last_modified_by` varchar(45) NOT NULL,
  `last_modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`booking_information_id`),
  KEY `drivez.customer_id_idx` (`customer_id`),
  KEY `service_area_id_idx` (`booking_service_area_id`),
  KEY `drivez_booking_city_id_idx` (`city_id`),
  KEY `drivez_booked_vehichel_id_idx` (`vehichel_model_id`),
  KEY `drivez.booking_txn_id_idx` (`transaction_id`),
  KEY `booked_vehichel_id_idx` (`booked_vehichel_id`),
  CONSTRAINT `booked_vehichel_id` FOREIGN KEY (`booked_vehichel_id`) REFERENCES `vehichel` (`vehichel_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `drivez.booking_txn_id` FOREIGN KEY (`transaction_id`) REFERENCES `transaction` (`transaction_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `drivez.customer_id` FOREIGN KEY (`customer_id`) REFERENCES `system_user` (`system_user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `drivez.service_area_id` FOREIGN KEY (`booking_service_area_id`) REFERENCES `service_area` (`service_area_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `drivez_booked_vehichel_id` FOREIGN KEY (`vehichel_model_id`) REFERENCES `vehichel_model_info` (`vehichel_model_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `drivez_booking_city_id` FOREIGN KEY (`city_id`) REFERENCES `city` (`city_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `city`
--

DROP TABLE IF EXISTS `city`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `city` (
  `city_id` int(11) NOT NULL AUTO_INCREMENT,
  `city_nm` varchar(45) NOT NULL,
  `state_id` int(11) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_modified_by` varchar(45) NOT NULL,
  `last_modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`city_id`),
  KEY `state_id_idx` (`state_id`),
  CONSTRAINT `state_id` FOREIGN KEY (`state_id`) REFERENCES `state` (`state_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `complaint`
--

DROP TABLE IF EXISTS `complaint`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `complaint` (
  `complaint_id` int(11) NOT NULL AUTO_INCREMENT,
  ` title` varchar(45) DEFAULT NULL,
  `description` varchar(200) DEFAULT NULL,
  `compliant_raised_dt` timestamp NULL DEFAULT NULL,
  `customer_user_id` int(11) DEFAULT NULL,
  `booking_id` int(11) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_modified_by` varchar(45) NOT NULL,
  `last_modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`complaint_id`),
  KEY `complaint_customer_id_idx` (`customer_user_id`),
  CONSTRAINT `complaint_booking_id` FOREIGN KEY (`complaint_id`) REFERENCES `booking_information` (`booking_information_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `complaint_customer_id` FOREIGN KEY (`customer_user_id`) REFERENCES `system_user` (`system_user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `country`
--

DROP TABLE IF EXISTS `country`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `country` (
  `country_id` int(11) NOT NULL AUTO_INCREMENT,
  `country_nm` varchar(45) NOT NULL,
  `status` varchar(45) DEFAULT NULL,
  `created_by` varchar(45) DEFAULT NULL,
  `created_dt` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(45) DEFAULT NULL,
  `last_modified_dt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`country_id`),
  UNIQUE KEY `country_nm_UNIQUE` (`country_nm`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `customer_enquiry`
--

DROP TABLE IF EXISTS `customer_enquiry`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_enquiry` (
  `customer_enquiry_id` int(11) NOT NULL AUTO_INCREMENT,
  `contact_person_nm` varchar(45) DEFAULT NULL,
  `primary_contact_no` varchar(45) DEFAULT NULL,
  `secondary_contact_no` varchar(45) DEFAULT NULL,
  `primary_email_address` varchar(45) DEFAULT NULL,
  `secondary_email_address` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_modified_by` varchar(45) NOT NULL,
  `last_modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`customer_enquiry_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `identity_type`
--

DROP TABLE IF EXISTS `identity_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `identity_type` (
  `identity_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `identity_type_nm` varchar(45) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_modified_by` varchar(45) NOT NULL,
  `last_modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`identity_type_id`),
  UNIQUE KEY `identity_type_nm_UNIQUE` (`identity_type_nm`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `offers`
--

DROP TABLE IF EXISTS `offers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offers` (
  `offer_id` int(11) NOT NULL AUTO_INCREMENT,
  `offer_image_type` varchar(45) DEFAULT NULL,
  `offer_image_nm` varchar(150) DEFAULT NULL,
  `offer_image` blob,
  `status` varchar(45) DEFAULT NULL,
  `percentage_discount` int(11) DEFAULT NULL,
  `description` varchar(100) DEFAULT NULL,
  `coupon_code` varchar(45) DEFAULT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_modified_by` varchar(45) NOT NULL,
  `last_modified_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`offer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `packages`
--

DROP TABLE IF EXISTS `packages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `packages` (
  `package_id` int(11) NOT NULL,
  `package_nm` varchar(45) DEFAULT NULL,
  `vehichel_model_id` int(11) DEFAULT NULL,
  `base_rate_without_fuel` int(11) DEFAULT NULL,
  `excess_km_rate` int(11) DEFAULT NULL,
  `rate_per_hour_with_fuel` int(11) DEFAULT NULL,
  `created_by` varchar(45) DEFAULT NULL,
  `created_dt` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(45) DEFAULT NULL,
  `last_modified_dt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`package_id`),
  KEY `drivez_vehichel_id_idx` (`vehichel_model_id`),
  CONSTRAINT `drivez_vehichel_id` FOREIGN KEY (`vehichel_model_id`) REFERENCES `vehichel_model_info` (`vehichel_model_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `payment_info`
--

DROP TABLE IF EXISTS `payment_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_info` (
  `payment_info_id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) DEFAULT NULL,
  `partner_transaction_id` int(11) DEFAULT NULL,
  `bank_tx_id` varchar(45) DEFAULT NULL,
  `bank_name` varchar(45) DEFAULT NULL,
  `gateway_nm` varchar(45) DEFAULT NULL,
  `response_code` varchar(45) DEFAULT NULL,
  `response_msg` varchar(45) DEFAULT NULL,
  `payment_mode` varchar(45) DEFAULT NULL,
  `mid` varchar(45) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_modified_by` varchar(45) NOT NULL,
  `last_modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`payment_info_id`),
  KEY `tansaction_id1_idx` (`transaction_id`),
  CONSTRAINT `drivezdb.transaction_id` FOREIGN KEY (`transaction_id`) REFERENCES `transaction` (`transaction_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `service_area`
--

DROP TABLE IF EXISTS `service_area`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_area` (
  `service_area_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_area_nm` varchar(45) NOT NULL,
  `description` varchar(150) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `city_id` int(11) DEFAULT NULL,
  `pickup_location` int(11) DEFAULT NULL,
  `drop_location` int(11) DEFAULT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_modified_by` varchar(45) NOT NULL,
  `last_modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`service_area_id`),
  KEY `city_id_idx` (`city_id`),
  KEY `pickup_loc_idx` (`pickup_location`),
  KEY `drivez_drop_loc_idx` (`drop_location`),
  CONSTRAINT `city_id` FOREIGN KEY (`city_id`) REFERENCES `city` (`city_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `drivez_drop_loc` FOREIGN KEY (`drop_location`) REFERENCES `address` (`address_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `drivez_pick` FOREIGN KEY (`pickup_location`) REFERENCES `address` (`address_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `state`
--

DROP TABLE IF EXISTS `state`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `state` (
  `state_id` int(11) NOT NULL,
  `state_nm` varchar(45) DEFAULT NULL,
  `country_id` int(11) NOT NULL,
  `status` varchar(45) DEFAULT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_modified_by` varchar(45) NOT NULL,
  `last_modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`state_id`),
  KEY `coutry_id_idx` (`country_id`),
  CONSTRAINT `country_id` FOREIGN KEY (`country_id`) REFERENCES `country` (`country_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `system_user`
--

DROP TABLE IF EXISTS `system_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_user` (
  `system_user_id` int(11) NOT NULL AUTO_INCREMENT,
  `display_nm` varchar(45) NOT NULL,
  `email_address` varchar(45) DEFAULT NULL,
  `mobile_nbr` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `gender` varchar(1) DEFAULT NULL,
  `user_role` int(11) NOT NULL,
  `email_address_verification_code` varchar(45) DEFAULT NULL,
  `mobile_otp_nbr` varchar(45) DEFAULT NULL,
  `mobile_otp_nbr_last_generated_time` timestamp NULL DEFAULT NULL,
  `is_email_verified` tinyint(4) DEFAULT NULL,
  `is_mobile_nbr_verified` varchar(45) DEFAULT NULL,
  `mobile_nbr_verified_dt` timestamp NULL DEFAULT NULL,
  `email_address_verified_dt` timestamp NULL DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `last_logged_in_date` timestamp NULL DEFAULT NULL,
  `system_user_address_id` int(11) DEFAULT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_modified_by` varchar(45) NOT NULL,
  `last_modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`system_user_id`),
  KEY `user_role_idx` (`user_role`),
  KEY `system_user_address_id_idx` (`system_user_address_id`),
  CONSTRAINT `system_user_address_id` FOREIGN KEY (`system_user_address_id`) REFERENCES `address` (`address_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `user_role` FOREIGN KEY (`user_role`) REFERENCES `user_role` (`user_role_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `system_user_image`
--

DROP TABLE IF EXISTS `system_user_image`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_user_image` (
  `system_user_image_id` int(11) NOT NULL AUTO_INCREMENT,
  `system_user_id` int(11) DEFAULT NULL,
  `file_type` varchar(45) DEFAULT NULL,
  `file_nm` varchar(45) DEFAULT NULL,
  `image_file` longblob,
  `created_by` varchar(45) DEFAULT NULL,
  `created_dt` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(45) DEFAULT NULL,
  `last_modified_dt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`system_user_image_id`),
  CONSTRAINT `Drivez_SYS` FOREIGN KEY (`system_user_image_id`) REFERENCES `system_user` (`system_user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `transaction`
--

DROP TABLE IF EXISTS `transaction`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction` (
  `transaction_id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_dt` timestamp NULL DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `customer_id` int(11) DEFAULT NULL,
  `transaction_type_id` int(11) DEFAULT NULL,
  `created_by` varchar(45) DEFAULT NULL,
  `created_dt` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  `last_modified_by` varchar(45) DEFAULT NULL,
  `last_modified_dt` timestamp NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`transaction_id`),
  KEY `transaction_type_idx` (`transaction_type_id`),
  KEY `customer_id_idx` (`customer_id`),
  CONSTRAINT `customer_id` FOREIGN KEY (`customer_id`) REFERENCES `system_user` (`system_user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `transaction_type` FOREIGN KEY (`transaction_type_id`) REFERENCES `transaction_type` (`transaction_type_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `transaction_type`
--

DROP TABLE IF EXISTS `transaction_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_type` (
  `transaction_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `transaction_type_nm` varchar(45) DEFAULT NULL,
  `description` varchar(150) DEFAULT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_modified_by` varchar(45) NOT NULL,
  `last_modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`transaction_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_identification`
--

DROP TABLE IF EXISTS `user_identification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_identification` (
  `user_identification_id` int(11) NOT NULL AUTO_INCREMENT,
  `system_user_id` int(11) DEFAULT NULL,
  `identity_type_id` int(11) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `identification_no` varchar(100) DEFAULT NULL,
  `issued_authority` varchar(45) DEFAULT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_modified_by` varchar(45) NOT NULL,
  `last_modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`user_identification_id`),
  KEY `sys_use_idx` (`system_user_id`),
  KEY `ident_typ_idx` (`identity_type_id`),
  CONSTRAINT `drivez.identity_type` FOREIGN KEY (`identity_type_id`) REFERENCES `identity_type` (`identity_type_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `drivez.system_user` FOREIGN KEY (`system_user_id`) REFERENCES `system_user` (`system_user_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `user_role`
--

DROP TABLE IF EXISTS `user_role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_role` (
  `user_role_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_role_cd` varchar(45) NOT NULL,
  `description` varchar(500) DEFAULT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_modified_by` varchar(45) NOT NULL,
  `last_modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`user_role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vehichel`
--

DROP TABLE IF EXISTS `vehichel`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehichel` (
  `vehichel_id` int(11) NOT NULL AUTO_INCREMENT,
  `registration_no` varchar(45) NOT NULL,
  `registration_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `purchase_dt` timestamp NULL DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `vehichel_type_id` int(11) NOT NULL,
  `vehichel_model_type_id` int(11) DEFAULT NULL,
  `service_area_id` int(11) DEFAULT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  `last_modified_by` varchar(45) NOT NULL,
  `last_modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`vehichel_id`),
  UNIQUE KEY `registration_no_UNIQUE` (`registration_no`),
  KEY `vehicel_type_idx` (`vehichel_type_id`),
  KEY `vehichel_model_id_idx` (`vehichel_model_type_id`),
  KEY `service_area_ids_idx` (`service_area_id`),
  CONSTRAINT `service_area_id` FOREIGN KEY (`service_area_id`) REFERENCES `service_area` (`service_area_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `vehicel_type` FOREIGN KEY (`vehichel_type_id`) REFERENCES `vehichel_type` (`vehichel_type_id`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  CONSTRAINT `vehichel_model_id` FOREIGN KEY (`vehichel_model_type_id`) REFERENCES `vehichel_model_info` (`vehichel_model_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=201 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vehichel_model_info`
--

DROP TABLE IF EXISTS `vehichel_model_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehichel_model_info` (
  `vehichel_model_id` int(11) NOT NULL,
  `vehichel_type_id` int(11) DEFAULT NULL,
  `model_name` varchar(45) DEFAULT NULL,
  `image_type` varchar(45) DEFAULT NULL,
  `image_name` varchar(45) DEFAULT NULL,
  `vehichel_model_image` longblob,
  `manufacturer_nm` varchar(45) DEFAULT NULL,
  `fuel_type` varchar(50) DEFAULT NULL,
  `with_ac_or_without_ac` varchar(5) DEFAULT NULL,
  `seats` int(11) DEFAULT NULL,
  `status` varchar(45) DEFAULT NULL,
  `created_by` varchar(45) DEFAULT NULL,
  `created_dt` timestamp NULL DEFAULT NULL,
  `last_modified_by` varchar(45) DEFAULT NULL,
  `last_modified_dt` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`vehichel_model_id`),
  KEY `drivez_vehichel_type_idx` (`vehichel_type_id`),
  CONSTRAINT `drivez_vehichel_type` FOREIGN KEY (`vehichel_type_id`) REFERENCES `vehichel_type` (`vehichel_type_id`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Table structure for table `vehichel_type`
--

DROP TABLE IF EXISTS `vehichel_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vehichel_type` (
  `vehichel_type_id` int(11) NOT NULL AUTO_INCREMENT,
  `type_nm` varchar(45) DEFAULT NULL,
  `description` varchar(150) DEFAULT NULL,
  `created_by` varchar(45) NOT NULL,
  `created_dt` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `last_modified_by` varchar(45) NOT NULL,
  `last_modified_dt` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`vehichel_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping events for database 'drivezdb'
--

--
-- Dumping routines for database 'drivezdb'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-09 17:18:01
