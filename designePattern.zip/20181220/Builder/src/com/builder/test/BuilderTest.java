package com.builder.test;

import com.builder.core.AbstractTruck;
import com.builder.core.Truck;
import com.builder.core.tata.TataTruckBuilder;

public class BuilderTest {
	public static void main(String[] args) throws InstantiationException, IllegalAccessException {
		Truck truck = null;
		TataTruckBuilder builder = null;

		builder = (TataTruckBuilder) AbstractTruck.createTruckBuilder(TataTruckBuilder.class);
		builder.maxSpeed(200).steeringType("power steering").breakType("power break").color("red").engineType("Issuz")
				.fuelCapacity(100).fuelType("diesel").manufacturer("tata").mileage(5).weight(200).wheels(8);
		truck = builder.build();
		truck.specifications();

	}
}
