package com.builder.core.benz;

import com.builder.core.AbstractTruck;

public class BenzTruck extends AbstractTruck {
	protected long enginePower;
	protected String suspenstionType;

	public long getEnginePower() {
		return enginePower;
	}

	public void setEnginePower(long enginePower) {
		this.enginePower = enginePower;
	}

	public String getSuspenstionType() {
		return suspenstionType;
	}

	public void setSuspenstionType(String suspenstionType) {
		this.suspenstionType = suspenstionType;
	}

	@Override
	public void specifications() {
		System.out.println("BenzTruck [enginePower=" + enginePower + ", suspenstionType=" + suspenstionType
				+ ", fuelType=" + fuelType + ", fuelCapacity=" + fuelCapacity + ", manufacturer=" + manufacturer
				+ ", weight=" + weight + ", wheels=" + wheels + ", color=" + color + ", engineType=" + engineType
				+ ", breakType=" + breakType + ", mileage=" + mileage + "]");
	}

}
