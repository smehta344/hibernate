package com.builder.core.benz;

import com.builder.core.AbstractTruckBuilder;
import com.builder.core.Truck;

public class BenzTruckBuilder extends AbstractTruckBuilder {
	protected long enginePower;
	protected String suspenstionType;

	public long enginePower() {
		return enginePower;
	}

	public BenzTruckBuilder enginePower(long enginePower) {
		this.enginePower = enginePower;
		return this;
	}

	public String suspenstionType() {
		return suspenstionType;
	}

	public BenzTruckBuilder suspenstionType(String suspenstionType) {
		this.suspenstionType = suspenstionType;
		return this;
	}

	@Override
	public Truck build() {
		BenzTruck truck = null;

		truck = new BenzTruck();
		truck.setFuelType(fuelType());
		truck.setFuelCapacity(fuelCapacity());
		truck.setManufacturer(manufacturer());
		truck.setColor(color());
		truck.setBreakType(breakType());
		truck.setEnginePower(enginePower());
		truck.setEngineType(engineType());
		truck.setMileage(mileage());
		truck.setWheels(wheels());
		truck.setWeight(weight());
		truck.setSuspenstionType(suspenstionType());
		return truck;
	}

}
