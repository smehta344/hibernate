package com.builder.core;

public abstract class AbstractTruck implements Truck {
	protected String fuelType;
	protected int fuelCapacity;
	protected String manufacturer;
	protected float weight;
	protected int wheels;
	protected String color;
	protected String engineType;
	protected String breakType;
	protected float mileage;

	public String getFuelType() {
		return fuelType;
	}

	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}

	public int getFuelCapacity() {
		return fuelCapacity;
	}

	public void setFuelCapacity(int fuelCapacity) {
		this.fuelCapacity = fuelCapacity;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public float getWeight() {
		return weight;
	}

	public void setWeight(float weight) {
		this.weight = weight;
	}

	public int getWheels() {
		return wheels;
	}

	public void setWheels(int wheels) {
		this.wheels = wheels;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public String getEngineType() {
		return engineType;
	}

	public void setEngineType(String engineType) {
		this.engineType = engineType;
	}

	public String getBreakType() {
		return breakType;
	}

	public void setBreakType(String breakType) {
		this.breakType = breakType;
	}

	public float getMileage() {
		return mileage;
	}

	public void setMileage(float mileage) {
		this.mileage = mileage;
	}

	public static AbstractTruckBuilder createTruckBuilder(Class<?> builderClass)
			throws InstantiationException, IllegalAccessException {
		AbstractTruckBuilder builder = null;

		builder = (AbstractTruckBuilder) builderClass.newInstance();
		return builder;
	}

	@Override
	public String toString() {
		return "AbstractTruck [fuelType=" + fuelType + ", fuelCapacity=" + fuelCapacity + ", manufacturer="
				+ manufacturer + ", weight=" + weight + ", wheels=" + wheels + ", color=" + color + ", engineType="
				+ engineType + ", breakType=" + breakType + ", mileage=" + mileage + "]";
	}

}
