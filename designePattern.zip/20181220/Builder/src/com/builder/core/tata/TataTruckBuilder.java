package com.builder.core.tata;

import com.builder.core.AbstractTruckBuilder;
import com.builder.core.Truck;

public class TataTruckBuilder extends AbstractTruckBuilder {
	protected String steeringType;
	protected int maxSpeed;

	public String steeringType() {
		return steeringType;
	}

	public TataTruckBuilder steeringType(String steeringType) {
		this.steeringType = steeringType;
		return this;
	}

	public int maxSpeed() {
		return maxSpeed;
	}

	public TataTruckBuilder maxSpeed(int maxSpeed) {
		this.maxSpeed = maxSpeed;
		return this;
	}

	@Override
	public Truck build() {
		TataTruck truck = null;

		truck = new TataTruck();
		truck.setFuelType(fuelType());
		truck.setFuelCapacity(fuelCapacity());
		truck.setManufacturer(manufacturer());
		truck.setColor(color());
		truck.setBreakType(breakType());
		truck.setSteeringType(steeringType());
		truck.setEngineType(engineType());
		truck.setMaxSpeed(maxSpeed());
		truck.setMileage(mileage());
		truck.setWheels(wheels());
		truck.setWeight(weight());

		return truck;
	}

}
