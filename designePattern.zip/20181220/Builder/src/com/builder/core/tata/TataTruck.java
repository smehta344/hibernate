package com.builder.core.tata;

import com.builder.core.AbstractTruck;

public class TataTruck extends AbstractTruck {
	protected String steeringType;
	protected int maxSpeed;

	public String getSteeringType() {
		return steeringType;
	}

	public void setSteeringType(String steeringType) {
		this.steeringType = steeringType;
	}

	public int getMaxSpeed() {
		return maxSpeed;
	}

	public void setMaxSpeed(int maxSpeed) {
		this.maxSpeed = maxSpeed;
	}

	@Override
	public void specifications() {
		System.out.println("TataTruck [steeringType=" + steeringType + ", maxSpeed=" + maxSpeed + ", fuelType=" + fuelType
				+ ", fuelCapacity=" + fuelCapacity + ", manufacturer=" + manufacturer + ", weight=" + weight
				+ ", wheels=" + wheels + ", color=" + color + ", engineType=" + engineType + ", breakType=" + breakType
				+ ", mileage=" + mileage + "]");
	}

}
