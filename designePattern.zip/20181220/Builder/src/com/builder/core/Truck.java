package com.builder.core;

public interface Truck {
	void specifications();
}
