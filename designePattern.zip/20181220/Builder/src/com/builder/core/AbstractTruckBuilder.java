package com.builder.core;

public abstract class AbstractTruckBuilder {
	protected String fuelType;
	protected int fuelCapacity;
	protected String manufacturer;
	protected float weight;
	protected int wheels;
	protected String color;
	protected String engineType;
	protected String breakType;
	protected float mileage;

	public AbstractTruckBuilder fuelType(String fuelType) {
		this.fuelType = fuelType;
		return this;
	}

	public AbstractTruckBuilder fuelCapacity(int fuelCapacity) {
		this.fuelCapacity = fuelCapacity;
		return this;
	}

	public AbstractTruckBuilder manufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
		return this;
	}

	public AbstractTruckBuilder weight(float weight) {
		this.weight = weight;
		return this;
	}

	public AbstractTruckBuilder wheels(int wheels) {
		this.wheels = wheels;
		return this;
	}

	public AbstractTruckBuilder color(String color) {
		this.color = color;
		return this;
	}

	public AbstractTruckBuilder engineType(String engineType) {
		this.engineType = engineType;
		return this;
	}

	public AbstractTruckBuilder breakType(String breakType) {
		this.breakType = breakType;
		return this;
	}

	public AbstractTruckBuilder mileage(float mileage) {
		this.mileage = mileage;
		return this;
	}

	public String fuelType() {
		return fuelType;
	}

	public int fuelCapacity() {
		return fuelCapacity;
	}

	public String manufacturer() {
		return manufacturer;
	}

	public float weight() {
		return weight;
	}

	public int wheels() {
		return wheels;
	}

	public String color() {
		return color;
	}

	public String engineType() {
		return engineType;
	}

	public String breakType() {
		return breakType;
	}

	public float mileage() {
		return mileage;
	}

	protected abstract Truck build();
}
