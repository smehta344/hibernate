package com.uber2.command;

import org.web2faces.web.command.Web2FacesCommand;
import org.web2faces.web.context.MapContextObject;

public class NewAccountCommand implements Web2FacesCommand {

	@Override
	public String execute(MapContextObject contextObject) {
		String accountName = null;
		String emailAddress = null;
		String mobileNo = null;

		accountName = contextObject.getAttribute("accountName");
		emailAddress = contextObject.getAttribute("emailAddress");
		mobileNo = contextObject.getAttribute("mobileNo");
		System.out.println("email address  : " + emailAddress);

		contextObject.addAttribute("accountName", accountName);

		return "account-details";
	}

}
