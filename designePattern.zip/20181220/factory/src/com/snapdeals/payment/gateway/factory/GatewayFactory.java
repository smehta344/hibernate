package com.snapdeals.payment.gateway.factory;

import java.io.IOException;
import java.util.Properties;

import com.snapdeals.payment.gateway.AbstractPaymentGateway;
import com.snapdeals.payment.gateway.MasterPaymentGateway;
import com.snapdeals.payment.gateway.PaymentGateway;
import com.snapdeals.payment.gateway.VisaPaymentGateway;

public class GatewayFactory {
	private static Properties gatewayProps = new Properties();

	static {
		try {
			gatewayProps.load(GatewayFactory.class.getClassLoader().getResourceAsStream("payment-gateway.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static PaymentGateway createPaymentGateway(String paymentMode) {
		AbstractPaymentGateway paymentGateway = null;

		if (paymentMode != null) {
			if (paymentMode.equals("visa")) {
				paymentGateway = new VisaPaymentGateway();
			} else if (paymentMode.equals("master")) {
				paymentGateway = new MasterPaymentGateway();
			}
			paymentGateway.setApiKey(gatewayProps.getProperty(paymentMode + ".api.key"));
			paymentGateway.setApiSecret(gatewayProps.getProperty(paymentMode + ".secret"));
		}
		return paymentGateway;
	}
}
