package com.snapdeals.payment.gateway;

public interface PaymentGateway {
	String pay(String cardNo, String cvv, String expiry);
}
