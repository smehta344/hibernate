package com.snapdeals.payment.gateway;

import java.util.UUID;

public class MasterPaymentGateway extends AbstractPaymentGateway {

	@Override
	public String pay(String cardNo, String cvv, String expiry) {
		System.out.println(
				"processing master gateway payment with api.key : " + getApiKey() + " api.secret : " + getApiSecret());
		return "mst-" + UUID.randomUUID().toString();
	}

}
