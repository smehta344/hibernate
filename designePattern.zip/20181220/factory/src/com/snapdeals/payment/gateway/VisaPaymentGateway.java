package com.snapdeals.payment.gateway;

import java.util.UUID;

public class VisaPaymentGateway extends AbstractPaymentGateway {

	@Override
	public String pay(String cardNo, String cvv, String expiry) {
		System.out.println("reaching visa gateway with apiKey : " + getApiKey() + " secret : " + getApiSecret());

		return "v" + UUID.randomUUID().toString();
	}

}
