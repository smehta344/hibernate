package com.snapdeals.test;

import com.snapdeals.order.service.OrderService;

public class Test {
	public static void main(String[] args) {
		OrderService orderService = new OrderService();
		String refNo = orderService.processPayment("038303", "master", "39304384044", "393", "01/20");
		System.out.println("ref : " + refNo);
	}
}
