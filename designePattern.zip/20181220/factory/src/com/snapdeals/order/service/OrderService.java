package com.snapdeals.order.service;

import com.snapdeals.payment.gateway.PaymentGateway;
import com.snapdeals.payment.gateway.factory.GatewayFactory;

public class OrderService {
	private PaymentGateway paymentGateway;

	public String processPayment(String orderNo, String paymentMode, String cardNo, String cvv, String expiry) {
		float amount = 0.0f;
		String transactionReferenceNo = null;

		System.out.println("fetching the order information for orderNo : " + orderNo);
		amount = 933.4f;
		System.out.println("update the order with status as payment processing");
		System.out.println(
				"add transaction record into transaction table with orderNo and payment details with status as pending");

		paymentGateway = GatewayFactory.createPaymentGateway(paymentMode);
		transactionReferenceNo = paymentGateway.pay(cardNo, cvv, expiry);

		return transactionReferenceNo;
	}
}
