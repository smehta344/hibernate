package com.decorator.test;

import java.util.Date;

import com.decorator.bo.Application;
import com.decorator.bo.LoanStatus;

public class Test {
	public static void main(String[] args) {
		LoanAgent loanAgent = null;
		LoanStatus loanStatus = null;
		Application application = null;

		application = new Application();
		application.setApplicationNo(3939);
		application.setApplicantName("Mark");
		application.setAppliedDate(new Date());
		application.setPrinciple(339404);
		application.setTenure(36);
		application.setLoanType("personal");
		application.setOccupation("individual");

		loanAgent = new LoanAgent();
		loanStatus = loanAgent.process(application);
		System.out.println(loanStatus);

	}
}
