package com.decorator.test;

import com.decorator.bo.Application;
import com.decorator.bo.LoanStatus;
import com.decorator.loan.HomeLoan;
import com.decorator.loan.Loan;
import com.decorator.loan.PersonalLoan;
import com.decorator.pattern.CorporateLoan;

public class LoanAgent {

	public LoanStatus process(Application application) {
		Loan loan = null;
		LoanStatus loanStatus = null;

		if (application.getLoanType().equals("personal")) {
			loan = new PersonalLoan();
		} else if (application.getLoanType().equals("home")) {
			loan = new HomeLoan();
		}
		if (application.getOccupation().equals("salaried")) {
			loan = new CorporateLoan(loan);
		}
		loanStatus = loan.process(application);
		return loanStatus;
	}
}
