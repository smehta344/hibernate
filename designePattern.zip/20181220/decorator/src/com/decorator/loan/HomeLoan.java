package com.decorator.loan;

import com.decorator.bo.Application;
import com.decorator.bo.LoanStatus;

public class HomeLoan implements Loan {

	@Override
	public LoanStatus process(Application application) {
		LoanStatus loanStatus = null;

		loanStatus = new LoanStatus();
		loanStatus.setApplicationNo(application.getApplicationNo());
		loanStatus.setApplicantName(application.getApplicantName());
		loanStatus.setLoanType(application.getLoanType());
		loanStatus.setProcessingCharges((float) (application.getPrinciple() * 0.12));
		loanStatus.setDocumentationCharges(1500);
		loanStatus.setGrantedAmount(application.getPrinciple());
		loanStatus.setRi(10.23f);
		loanStatus.setStatus("approved");

		return loanStatus;

	}

}
