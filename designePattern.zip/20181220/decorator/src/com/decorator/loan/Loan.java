package com.decorator.loan;

import com.decorator.bo.Application;
import com.decorator.bo.LoanStatus;

public interface Loan {
	LoanStatus process(Application application);
}
