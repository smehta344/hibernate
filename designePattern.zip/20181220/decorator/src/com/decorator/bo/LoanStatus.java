package com.decorator.bo;

public class LoanStatus {
	private int applicationNo;
	private String applicantName;
	private String loanType;
	private float processingCharges;
	private float documentationCharges;
	private double grantedAmount;
	private float ri;
	private String status;
	private String comments;

	public int getApplicationNo() {
		return applicationNo;
	}

	public void setApplicationNo(int applicationNo) {
		this.applicationNo = applicationNo;
	}

	public String getApplicantName() {
		return applicantName;
	}

	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}

	public String getLoanType() {
		return loanType;
	}

	public void setLoanType(String loanType) {
		this.loanType = loanType;
	}

	public float getProcessingCharges() {
		return processingCharges;
	}

	public void setProcessingCharges(float processingCharges) {
		this.processingCharges = processingCharges;
	}

	public float getDocumentationCharges() {
		return documentationCharges;
	}

	public void setDocumentationCharges(float documentationCharges) {
		this.documentationCharges = documentationCharges;
	}

	public double getGrantedAmount() {
		return grantedAmount;
	}

	public void setGrantedAmount(double grantedAmount) {
		this.grantedAmount = grantedAmount;
	}

	public float getRi() {
		return ri;
	}

	public void setRi(float ri) {
		this.ri = ri;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	@Override
	public String toString() {
		return "LoanStatus [applicationNo=" + applicationNo + ", applicantName=" + applicantName + ", loanType="
				+ loanType + ", processingCharges=" + processingCharges + ", documentationCharges="
				+ documentationCharges + ", grantedAmount=" + grantedAmount + ", ri=" + ri + ", status=" + status
				+ ", comments=" + comments + "]";
	}

}
