package com.decorator.pattern;

import com.decorator.bo.Application;
import com.decorator.bo.LoanStatus;
import com.decorator.loan.Loan;

public abstract class ExclusiveLoan implements Loan {
	private Loan loan;

	public ExclusiveLoan(Loan loan) {
		this.loan = loan;
	}

	@Override
	public LoanStatus process(Application application) {
		return loan.process(application);
	}

}
