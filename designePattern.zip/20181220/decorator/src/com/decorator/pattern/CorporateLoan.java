package com.decorator.pattern;

import com.decorator.bo.Application;
import com.decorator.bo.LoanStatus;
import com.decorator.loan.Loan;

public class CorporateLoan extends ExclusiveLoan {

	public CorporateLoan(Loan loan) {
		super(loan);
	}

	@Override
	public LoanStatus process(Application application) {
		LoanStatus loanStatus = null;

		loanStatus = super.process(application);
		loanStatus.setDocumentationCharges(0);
		loanStatus.setProcessingCharges((float) (application.getPrinciple() * 0.05));
		loanStatus.setRi((float) (loanStatus.getRi() - 0.25));

		return loanStatus;
	}

}
