package com.mygate.queries.factory;

import com.mygate.queries.GetBlockByZoneSqlQuery;
import com.pa.core.SqlQuery;
import com.pa.core.factory.SqlQueryFactory;

public class MyGateQueriesFactory extends SqlQueryFactory {
	@Override
	protected SqlQuery createQuery(String qClass) {
		SqlQuery sqlQuery = null;

		if (qClass.equals("GetBlockByZone")) {
			sqlQuery = new GetBlockByZoneSqlQuery();
		}
		return sqlQuery;
	}

}
