package com.mygate.queries;

import java.sql.ResultSet;
import java.sql.SQLException;

import com.mygate.bo.Block;
import com.pa.core.SqlQuery;

public class GetBlockByZoneSqlQuery extends SqlQuery {

	@Override
	protected Object mapRow(ResultSet rs) throws SQLException {
		Block block = null;
		block = new Block();
		block.setBlockNo(rs.getInt(1));
		block.setBlockName(rs.getString(2));
		block.setCapacity(rs.getInt(3));
		block.setZone(rs.getString(4));
		return block;
	}

}
