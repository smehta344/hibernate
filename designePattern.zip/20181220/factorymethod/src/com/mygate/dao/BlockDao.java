package com.mygate.dao;

import java.sql.SQLException;
import java.util.List;

import com.mygate.queries.factory.MyGateQueriesFactory;
import com.pa.core.SqlQuery;
import com.pa.core.factory.SqlQueryFactory;

public class BlockDao {
	public List<?> getBlocksByZone(String zone) throws SQLException {
		List<?> blocks = null;
		SqlQuery sqlQuery = null;
		SqlQueryFactory sqlQueryFactory = null;

		sqlQueryFactory = new MyGateQueriesFactory();
		sqlQuery = sqlQueryFactory.newSqlQuery("GetBlockByZone");
		blocks = sqlQuery.execute("select block_no, block_nm, capacity, zone from blocks where zone like ?",
				new Object[] { "south" });

		return blocks;
	}
}












