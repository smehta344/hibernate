package com.pa.core.factory;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.pa.core.SqlQuery;

public abstract class SqlQueryFactory {
	protected String driverClassname;
	protected String url;
	protected String username;
	protected String password;

	public SqlQueryFactory() {
		Properties props = null;

		props = new Properties();
		try {
			props.load(this.getClass().getClassLoader().getResourceAsStream("pa.properties"));
			driverClassname = props.getProperty("jdbc.driverClassname");
			url = props.getProperty("jdbc.url");
			username = props.getProperty("jdbc.user");
			password = props.getProperty("jdbc.password");
			Class.forName(driverClassname);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public SqlQuery newSqlQuery(String qClass) throws SQLException {
		SqlQuery sqlQuery = null;
		Connection connection = null;

		connection = DriverManager.getConnection(url, username, password);
		sqlQuery = createQuery(qClass);
		sqlQuery.setConnection(connection);
		return sqlQuery;
	}

	protected abstract SqlQuery createQuery(String qClass);
}













