package com.pa.core;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public abstract class SqlQuery {
	protected Connection connection;

	public List<Object> execute(String sql, Object[] params) {
		PreparedStatement pstmt = null;
		List<Object> records = null;
		ResultSet rs = null;
		Object obj = null;

		try {
			pstmt = connection.prepareStatement(sql);
			for (int i = 0; i < params.length; i++) {
				if (params[i] instanceof Integer) {
					pstmt.setInt(i + 1, (Integer) params[i]);
				} else if (params[i] instanceof String) {
					pstmt.setString(i + 1, (String) params[i]);
				}
			}
			rs = pstmt.executeQuery();
			records = new ArrayList<>();
			while (rs.next()) {
				obj = mapRow(rs);
				records.add(obj);
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return records;
	}

	public void close() {
		if (connection != null) {
			try {
				connection.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}

	public void setConnection(Connection connection) {
		this.connection = connection;
	}

	protected abstract Object mapRow(ResultSet rs) throws SQLException;
}
