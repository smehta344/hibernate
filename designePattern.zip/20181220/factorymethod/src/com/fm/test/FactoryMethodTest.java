package com.fm.test;

import java.sql.SQLException;
import java.util.List;

import com.mygate.dao.BlockDao;

public class FactoryMethodTest {
	public static void main(String[] args) throws SQLException {
		BlockDao blockDao = new BlockDao();
		List<?> blocks = blockDao.getBlocksByZone("south");
		for(Object obj : blocks) {
			System.out.println(obj);
		}
	}
}
