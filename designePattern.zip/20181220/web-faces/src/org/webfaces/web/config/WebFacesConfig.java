package org.webfaces.web.config;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

import org.webfaces.web.exception.WebFacesCommandConfigException;
import org.webfaces.web.exception.WebFacesConfigException;
import org.webfaces.web.exception.WebFacesViewConfigException;

public class WebFacesConfig {
	private Properties commandMappings;
	private Properties views;

	public WebFacesConfig(String commandConfigLocation, String viewConfigLocation) {

		try {
			commandMappings = new Properties();
			commandMappings.load(new FileInputStream(new File(commandConfigLocation)));
		} catch (IOException e) {
			throw new WebFacesConfigException(
					"error while reading command configuration from location : " + commandConfigLocation, e);
		}

		try {
			views = new Properties();
			views.load(new FileInputStream(new File(viewConfigLocation)));
		} catch (IOException e) {
			throw new WebFacesConfigException(
					"error while reading view configuration from location : " + viewConfigLocation, e);
		}
	}

	public String getCommandClass(String requestUri) {
		String commandClass = null;

		if (commandMappings.containsKey(requestUri) == false) {
			throw new WebFacesCommandConfigException(
					"unable to find the command class for the request uri : " + requestUri);
		}

		commandClass = commandMappings.getProperty(requestUri);

		return commandClass;
	}

	public String getPage(String outcome) {
		String page = null;

		if (views.containsKey(outcome) == false) {
			throw new WebFacesViewConfigException("unable to find the page for the outcome : " + outcome);
		}
		page = views.getProperty(outcome);
		return page;
	}
}
