package org.webfaces.web.exception;

public class WebFacesException extends RuntimeException {
	private static final long serialVersionUID = -8949808164040815773L;

	public WebFacesException() {
		super();
	}

	public WebFacesException(String message, Throwable cause) {
		super(message, cause);
	}

	public WebFacesException(String message) {
		super(message);
	}

	public WebFacesException(Throwable cause) {
		super(cause);
	}

}
