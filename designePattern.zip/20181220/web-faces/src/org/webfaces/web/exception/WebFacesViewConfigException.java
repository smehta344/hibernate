package org.webfaces.web.exception;

public class WebFacesViewConfigException extends WebFacesException {

	public WebFacesViewConfigException(String message) {
		super(message);
	}

}
