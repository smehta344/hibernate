package org.webfaces.web.exception;

public class WebFacesConfigException extends WebFacesException {

	public WebFacesConfigException(String message, Throwable cause) {
		super(message, cause);
	}

}
