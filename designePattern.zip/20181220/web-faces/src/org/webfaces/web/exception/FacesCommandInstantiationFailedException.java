package org.webfaces.web.exception;

public class FacesCommandInstantiationFailedException extends WebFacesException {

	public FacesCommandInstantiationFailedException(String message, Throwable cause) {
		super(message, cause);
	}

}
