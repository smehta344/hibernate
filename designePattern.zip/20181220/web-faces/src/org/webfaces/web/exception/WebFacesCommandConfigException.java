package org.webfaces.web.exception;

public class WebFacesCommandConfigException extends WebFacesException {

	public WebFacesCommandConfigException(String message) {
		super(message);
	}

}
