package org.webfaces.web.exception;

public class DispatchViewException extends WebFacesException {

	public DispatchViewException(String message, Throwable cause) {
		super(message, cause);
	}

}
