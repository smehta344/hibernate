package org.webfaces.web.exception;

public class FacesCommandNotFoundException extends WebFacesException {

	public FacesCommandNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

}
