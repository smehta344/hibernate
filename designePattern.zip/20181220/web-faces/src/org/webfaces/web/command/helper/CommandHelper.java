package org.webfaces.web.command.helper;

import org.webfaces.web.command.FacesCommand;
import org.webfaces.web.config.WebFacesConfig;
import org.webfaces.web.exception.FacesCommandInstantiationFailedException;
import org.webfaces.web.exception.FacesCommandNotFoundException;

public class CommandHelper {

	public static FacesCommand getCommand(String requestUri, WebFacesConfig webFacesConfig) {
		String commandClassname = null;
		Class<FacesCommand> commandClass = null;
		FacesCommand facesCommand = null;

		try {
			commandClassname = webFacesConfig.getCommandClass(requestUri);
			commandClass = (Class<FacesCommand>) Class.forName(commandClassname);
			facesCommand = commandClass.newInstance();
		} catch (ClassNotFoundException e) {
			throw new FacesCommandNotFoundException(
					"commandClass not found under the class-path with name : " + commandClassname, e);
		} catch (InstantiationException | IllegalAccessException e) {
			throw new FacesCommandInstantiationFailedException(
					"error while creating the object of the commandClass : " + commandClassname, e);
		}
		return facesCommand;
	}
}
