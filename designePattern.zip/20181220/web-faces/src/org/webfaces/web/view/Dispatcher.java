package org.webfaces.web.view;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.webfaces.web.config.WebFacesConfig;
import org.webfaces.web.exception.DispatchViewException;

public class Dispatcher {
	public static void dispatch(HttpServletRequest request, HttpServletResponse response, String outcome,
			WebFacesConfig webFacesConfig) {
		String page = null;

		try {
			page = webFacesConfig.getPage(outcome);
			request.getRequestDispatcher(page).forward(request, response);
		} catch (ServletException | IOException e) {
			throw new DispatchViewException("error while rendering the page : " + page, e);
		}

	}
}
