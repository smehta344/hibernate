package org.webfaces.web.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.webfaces.web.command.FacesCommand;
import org.webfaces.web.command.helper.CommandHelper;
import org.webfaces.web.config.WebFacesConfig;
import org.webfaces.web.view.Dispatcher;

public class WebFacesServlet extends HttpServlet {
	private WebFacesConfig webFacesConfig;

	@Override
	public void init(ServletConfig config) throws ServletException {
		String appLocation = null;
		ServletContext servletContext = null;

		servletContext = config.getServletContext();
		appLocation = servletContext.getRealPath("/");
		System.out.println("app location : " + appLocation);
		webFacesConfig = new WebFacesConfig(appLocation + "/WEB-INF/command-mappings.properties",
				appLocation + "/WEB-INF/views.properties");
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String outcome = null;
		String requestUri = null;
		FacesCommand facesCommand = null;

		requestUri = request.getServletPath();
		System.out.println("requestUri : " + requestUri);

		facesCommand = CommandHelper.getCommand(requestUri, webFacesConfig);
		outcome = facesCommand.execute(request, response);
		Dispatcher.dispatch(request, response, outcome, webFacesConfig);
	}

}
