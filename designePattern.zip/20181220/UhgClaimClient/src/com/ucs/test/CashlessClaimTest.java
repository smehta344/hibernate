package com.ucs.test;

import java.util.Date;
import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.ucs.bo.DiagnosticReportBo;
import com.ucs.bo.PatientAdmissionBo;
import com.ucs.dto.ClaimForm;
import com.ucs.facade.CashlessClaimEjbRemote;

public class CashlessClaimTest {
	public static void main(String[] args) throws NamingException {
		ClaimForm claimForm = null;
		PatientAdmissionBo patientAdmission = null;
		DiagnosticReportBo report = null;

		patientAdmission = new PatientAdmissionBo();
		patientAdmission.setAdmissionNo(939);
		patientAdmission.setPatientName("Samuel");
		patientAdmission.setAdmissionDate(new Date());
		patientAdmission.setHospitalName("Apollo");
		patientAdmission.setCostPerDay(1000);
		patientAdmission.setRoomType("Shared");

		report = new DiagnosticReportBo();
		report.setReportName("blood report");

		claimForm = new ClaimForm();
		claimForm.setPolicyNo(939);
		claimForm.setPatientAdmission(patientAdmission);
		claimForm.setDiagnosticReport(report);
		claimForm.setTreatment("viral fever");

		Hashtable<String, Object> ht = new Hashtable<>();
		ht.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
		ht.put(Context.PROVIDER_URL, "t3://localhost:7001");
		ht.put(Context.SECURITY_PRINCIPAL, "weblogic");
		ht.put(Context.SECURITY_CREDENTIALS, "welcome1");

		InitialContext ic = new InitialContext(ht);
		CashlessClaimEjbRemote remote = (CashlessClaimEjbRemote) ic
				.lookup("cashlessClaim#com.ucs.facade.CashlessClaimEjbRemote");
		String claimNo = remote.applyForCashlessFacility(claimForm);
		System.out.println("claim : " +claimNo);
	}
}


















