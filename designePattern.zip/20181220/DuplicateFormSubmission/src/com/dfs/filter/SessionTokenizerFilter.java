package com.dfs.filter;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

public class SessionTokenizerFilter implements Filter {

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		String method = null;
		String token = null;
		String clientToken = null;
		String serverToken = null;
		HttpSession session = null;
		HttpServletRequest httpReq = null;
		HttpServletResponse httpResp = null;

		httpReq = (HttpServletRequest) request;
		httpResp = (HttpServletResponse) response;

		session = httpReq.getSession(false);

		// new user
		if (session == null) {
			session = httpReq.getSession();
		} else {
			method = httpReq.getMethod();
			
			if (method.equalsIgnoreCase("post")) {
				clientToken = httpReq.getParameter("client-token");
				serverToken = (String) session.getAttribute("server-token");
				if (clientToken.equals(serverToken) == false) {
					httpResp.sendRedirect("duplicate-request.jsp");
					return;
				}
			}

		}
		token = UUID.randomUUID().toString();
		session.setAttribute("server-token", token);
		httpReq.setAttribute("client-token", token);
		chain.doFilter(request, response);

	}

}










