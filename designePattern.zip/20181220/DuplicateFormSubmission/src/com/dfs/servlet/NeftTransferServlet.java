package com.dfs.servlet;

import java.io.IOException;
import java.util.UUID;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet(urlPatterns = { "/neftTransfer" })
public class NeftTransferServlet extends HttpServlet {
	public void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String fromAc = null;
		String toAc = null;
		float amount = 0.0f;
		//HttpSession session = null;

		//session = req.getSession();
		fromAc = req.getParameter("fromAc");
		toAc = req.getParameter("toAc");
		amount = Float.parseFloat(req.getParameter("amount"));

		System.out.println("recieved request with fromAc: " + fromAc + " toAc: " + toAc + " amount : " + amount);
		//session.setAttribute("referenceNo", UUID.randomUUID().toString());
		req.getRequestDispatcher("/transfer-details.jsp").forward(req, resp);
		//resp.sendRedirect("transfer-details.jsp?referenceNo="+UUID.randomUUID().toString());
	}
}














