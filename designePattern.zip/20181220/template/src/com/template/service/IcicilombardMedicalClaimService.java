package com.template.service;

import java.util.List;

import com.template.bo.Claim;
import com.template.bo.ClaimReport;
import com.template.bo.Drugs;
import com.template.bo.MedicalPolicy;
import com.template.bo.Treatment;

public class IcicilombardMedicalClaimService extends MedicalClaimService {

	@Override
	protected boolean checkMedicalPolicy(MedicalPolicy medicalPolicy) {
		if (medicalPolicy.getPolicyNo().startsWith("icici")) {
			return true;
		}
		return false;
	}

	@Override
	protected double computeSettlementAmount(MedicalPolicy medicalPolicy, Claim claim, List<Treatment> treatments,
			List<Drugs> drugs) {
		double totalTreatmentCost = 0.0;
		double totalDrugsCost = 0;
		double settlementAmount = 0;

		for (Treatment treatement : treatments) {
			totalTreatmentCost += treatement.getAmount();
		}
		for (Drugs drug : drugs) {
			totalDrugsCost += drug.getCost();
		}
		settlementAmount = (totalTreatmentCost - ((totalTreatmentCost * 30)) / 100)
				+ (totalDrugsCost - ((totalDrugsCost * 40) / 100));

		return settlementAmount;
	}

	@Override
	protected ClaimReport report(MedicalPolicy medicalPolicy, Claim claim, List<Treatment> treatments,
			List<Drugs> drugs, double settlementAmount) {
		ClaimReport report = null;

		report = newClaimReport(claim, medicalPolicy);
		report.setRemarks("approved");
		report.setSettlementAmount(settlementAmount);
		return report;
	}

}
