package com.template.service;

import java.util.ArrayList;
import java.util.List;

import com.template.bo.Claim;
import com.template.bo.ClaimReport;
import com.template.bo.Document;
import com.template.bo.Drugs;
import com.template.bo.MedicalPolicy;
import com.template.bo.Treatment;

public abstract class MedicalClaimService {
	public ClaimReport process(Claim claim, MedicalPolicy medicalPolicy) {
		ClaimReport claimReport = null;
		List<Treatment> treatments = null;
		List<Drugs> drugs = null;

		boolean checkMedicalPolicy = checkMedicalPolicy(medicalPolicy);
		if (checkMedicalPolicy == false) {
			claimReport = newClaimReport(claim, medicalPolicy);
			claimReport.setRemarks("Policy information is not matching");
			claimReport.setStatus("rejected");
			return claimReport;
		}

		boolean documentCheck = basicDocumentVerification(claim, medicalPolicy);
		if (documentCheck == false) {
			claimReport = newClaimReport(claim, medicalPolicy);
			claimReport.setRemarks("Documents mis-match, please verify and resubmit all documents");
			claimReport.setStatus("rejected");
			return claimReport;
		}
		treatments = treatmentAssesment(claim);
		drugs = drugAssesment(claim);
		double settlementAmount = computeSettlementAmount(medicalPolicy, claim, treatments, drugs);
		claimReport = report(medicalPolicy, claim, treatments, drugs, settlementAmount);

		return claimReport;
	}

	protected boolean basicDocumentVerification(Claim claim, MedicalPolicy medicalPolicy) {
		List<Document> documents = null;
		boolean flag = true;

		documents = claim.getDocuments();
		for (Document doc : documents) {
			if (doc.getPatientName().equals(medicalPolicy.getMemberName()) == false) {
				flag = false;
				break;
			}
			if (doc.getDocumentDate().compareTo(claim.getAdmissionDate()) < 0) {
				flag = false;
				break;
			}
		}

		return flag;
	}

	protected List<Treatment> treatmentAssesment(Claim claim) {
		List<Treatment> treatments = null;

		treatments = new ArrayList<>();
		treatments.add(new Treatment(1, "xray", 200, "xray"));
		treatments.add(new Treatment(2, "topup blood", 4000, "blood added"));

		return treatments;
	}

	protected List<Drugs> drugAssesment(Claim claim) {
		List<Drugs> drugs = null;

		drugs = new ArrayList<>();
		drugs.add(new Drugs(1, "dolo", 5, 20, "fever"));
		drugs.add(new Drugs(2, "dulcolex", 30, 20, "dulcolex"));

		return drugs;
	}

	abstract protected boolean checkMedicalPolicy(MedicalPolicy medicalPolicy);

	abstract protected double computeSettlementAmount(MedicalPolicy medicalPolicy, Claim claim,
			List<Treatment> treatments, List<Drugs> drugs);

	abstract protected ClaimReport report(MedicalPolicy medicalPolicy, Claim claim, List<Treatment> treatments,
			List<Drugs> drugs, double settlementAmount);

	protected ClaimReport newClaimReport(Claim claim, MedicalPolicy medicalPolicy) {
		ClaimReport report = null;

		report = new ClaimReport();
		report.setClaimNo(claim.getClaimNo());
		report.setClaimSubmittedDate(claim.getClaimSubmittedDate());
		report.setAdmissionDate(claim.getAdmissionDate());
		report.setHospitalName(claim.getHospitalName());
		report.setMemberName(medicalPolicy.getMemberName());
		report.setPlanName(medicalPolicy.getPlanName());
		report.setPolicyNo(medicalPolicy.getPolicyNo());

		return report;
	}
}
