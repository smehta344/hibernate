package com.template.test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.template.bo.Claim;
import com.template.bo.ClaimReport;
import com.template.bo.Document;
import com.template.bo.MedicalPolicy;
import com.template.service.MedicalClaimService;
import com.template.service.TataAigMedicalClaimService;

public class TemplateTest {
	public static void main(String[] args) {
		MedicalClaimService medicalClaimService = null;
		MedicalPolicy medicalPolicy = null;
		List<Document> documents = null;
		Claim claim = null;

		documents = new ArrayList<>();
		documents.add(
				new Document(1, "discharge summary", "Rayan", new Date(2019, 0, 02), "discharge summary", "verified"));
		documents.add(new Document(2, "lab reports", "Rayan", new Date(2019, 0, 03), "lab reports", "verified"));

		medicalPolicy = new MedicalPolicy("aig03903", "jeevan policy", "Rayan", new Date(2017, 02, 01),
				new Date(2019, 11, 31), 200000);

		claim = new Claim(234, new Date(2019, 0, 31), "in-patient claim", "330384", new Date(2019, 0, 01), "apollo",
				"Viral Fever", 120000, documents);

		medicalClaimService = new TataAigMedicalClaimService();
		ClaimReport report = medicalClaimService.process(claim, medicalPolicy);
		if (report.getStatus().equals("rejected") == false) {
			System.out.println("approved amount :  " + report.getSettlementAmount());
		} else {
			System.out.println(report.getRemarks());
		}
	}
}
