package com.template.bo;

import java.util.Date;

public class ClaimReport {
	protected int claimNo;
	protected String policyNo;
	protected String memberName;
	protected String planName;
	protected Date claimSubmittedDate;
	protected String hospitalName;
	protected Date admissionDate;
	protected String remarks;
	protected double settlementAmount;
	protected String status;

	public int getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(int claimNo) {
		this.claimNo = claimNo;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public Date getClaimSubmittedDate() {
		return claimSubmittedDate;
	}

	public void setClaimSubmittedDate(Date claimSubmittedDate) {
		this.claimSubmittedDate = claimSubmittedDate;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public Date getAdmissionDate() {
		return admissionDate;
	}

	public void setAdmissionDate(Date admissionDate) {
		this.admissionDate = admissionDate;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public double getSettlementAmount() {
		return settlementAmount;
	}

	public void setSettlementAmount(double settlementAmount) {
		this.settlementAmount = settlementAmount;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "ClaimReport [claimNo=" + claimNo + ", policyNo=" + policyNo + ", memberName=" + memberName
				+ ", planName=" + planName + ", claimSubmittedDate=" + claimSubmittedDate + ", hospitalName="
				+ hospitalName + ", admissionDate=" + admissionDate + ", remarks=" + remarks + ", settlementAmount="
				+ settlementAmount + ", status=" + status + "]";
	}

}
