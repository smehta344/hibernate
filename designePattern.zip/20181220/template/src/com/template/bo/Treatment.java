package com.template.bo;

public class Treatment {
	protected int treatmentNo;
	protected String treatmentName;
	protected double amount;
	protected String comments;

	public Treatment(int treatmentNo, String treatmentName, double amount, String comments) {
		this.treatmentNo = treatmentNo;
		this.treatmentName = treatmentName;
		this.amount = amount;
		this.comments = comments;
	}

	public int getTreatmentNo() {
		return treatmentNo;
	}

	public void setTreatmentNo(int treatmentNo) {
		this.treatmentNo = treatmentNo;
	}

	public String getTreatmentName() {
		return treatmentName;
	}

	public void setTreatmentName(String treatmentName) {
		this.treatmentName = treatmentName;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	@Override
	public String toString() {
		return "Treatment [treatmentNo=" + treatmentNo + ", treatmentName=" + treatmentName + ", amount=" + amount
				+ ", comments=" + comments + "]";
	}

}
