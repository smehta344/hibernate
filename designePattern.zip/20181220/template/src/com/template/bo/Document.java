package com.template.bo;

import java.util.Date;

public class Document {
	protected int documentNo;
	protected String documentType;
	protected String patientName;
	protected Date documentDate;
	protected String description;
	protected String status;

	public Document(int documentNo, String documentType, String patientName, Date documentDate, String description,
			String status) {
		this.documentNo = documentNo;
		this.documentType = documentType;
		this.patientName = patientName;
		this.documentDate = documentDate;
		this.description = description;
		this.status = status;
	}

	public int getDocumentNo() {
		return documentNo;
	}

	public void setDocumentNo(int documentNo) {
		this.documentNo = documentNo;
	}

	public String getDocumentType() {
		return documentType;
	}

	public void setDocumentType(String documentType) {
		this.documentType = documentType;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public Date getDocumentDate() {
		return documentDate;
	}

	public void setDocumentDate(Date documentDate) {
		this.documentDate = documentDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "Document [documentNo=" + documentNo + ", documentType=" + documentType + ", patientName=" + patientName
				+ ", documentDate=" + documentDate + ", description=" + description + ", status=" + status + "]";
	}

}
