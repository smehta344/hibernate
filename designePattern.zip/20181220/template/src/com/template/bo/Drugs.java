package com.template.bo;

public class Drugs {
	protected int drugNo;
	protected String drugName;
	protected int units;
	protected double cost;
	protected String comments;

	public Drugs(int drugNo, String drugName, int units, double cost, String comments) {
		super();
		this.drugNo = drugNo;
		this.drugName = drugName;
		this.units = units;
		this.cost = cost;
		this.comments = comments;
	}

	public int getDrugNo() {
		return drugNo;
	}

	public void setDrugNo(int drugNo) {
		this.drugNo = drugNo;
	}

	public String getDrugName() {
		return drugName;
	}

	public void setDrugName(String drugName) {
		this.drugName = drugName;
	}

	public int getUnits() {
		return units;
	}

	public void setUnits(int units) {
		this.units = units;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

	@Override
	public String toString() {
		return "Drugs [drugNo=" + drugNo + ", drugName=" + drugName + ", units=" + units + ", cost=" + cost
				+ ", comments=" + comments + "]";
	}

}
