package com.template.bo;

import java.util.Date;
import java.util.List;

public class Claim {
	protected int claimNo;
	protected Date claimSubmittedDate;
	protected String description;
	protected String admissionNo;
	protected Date admissionDate;
	protected String hospitalName;
	protected String problem;
	protected double treatmentCost;
	protected List<Document> documents;

	public Claim(int claimNo, Date claimSubmittedDate, String description, String admissionNo, Date admissionDate,
			String hospitalName, String problem, double treatmentCost, List<Document> documents) {
		this.claimNo = claimNo;
		this.claimSubmittedDate = claimSubmittedDate;
		this.description = description;
		this.admissionNo = admissionNo;
		this.admissionDate = admissionDate;
		this.hospitalName = hospitalName;
		this.problem = problem;
		this.treatmentCost = treatmentCost;
		this.documents = documents;
	}

	public int getClaimNo() {
		return claimNo;
	}

	public void setClaimNo(int claimNo) {
		this.claimNo = claimNo;
	}

	public Date getClaimSubmittedDate() {
		return claimSubmittedDate;
	}

	public void setClaimSubmittedDate(Date claimSubmittedDate) {
		this.claimSubmittedDate = claimSubmittedDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getAdmissionNo() {
		return admissionNo;
	}

	public void setAdmissionNo(String admissionNo) {
		this.admissionNo = admissionNo;
	}

	public Date getAdmissionDate() {
		return admissionDate;
	}

	public void setAdmissionDate(Date admissionDate) {
		this.admissionDate = admissionDate;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public String getProblem() {
		return problem;
	}

	public void setProblem(String problem) {
		this.problem = problem;
	}

	public double getTreatmentCost() {
		return treatmentCost;
	}

	public void setTreatmentCost(double treatmentCost) {
		this.treatmentCost = treatmentCost;
	}

	public List<Document> getDocuments() {
		return documents;
	}

	public void setDocuments(List<Document> documents) {
		this.documents = documents;
	}

	@Override
	public String toString() {
		return "Claim [claimNo=" + claimNo + ", claimSubmittedDate=" + claimSubmittedDate + ", description="
				+ description + ", admissionNo=" + admissionNo + ", admissionDate=" + admissionDate + ", hospitalName="
				+ hospitalName + ", problem=" + problem + ", treatmentCost=" + treatmentCost + ", documents="
				+ documents + "]";
	}

}
