package com.template.bo;

import java.util.Date;

public class MedicalPolicy {
	protected String policyNo;
	protected String planName;
	protected String memberName;
	protected Date effectiveDate;
	protected Date endDate;
	protected double sumInsurred;

	public MedicalPolicy(String policyNo, String planName, String memberName, Date effectiveDate, Date endDate,
			double sumInsurred) {
		this.policyNo = policyNo;
		this.planName = planName;
		this.memberName = memberName;
		this.effectiveDate = effectiveDate;
		this.endDate = endDate;
		this.sumInsurred = sumInsurred;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public double getSumInsurred() {
		return sumInsurred;
	}

	public void setSumInsurred(double sumInsurred) {
		this.sumInsurred = sumInsurred;
	}

	@Override
	public String toString() {
		return "MedicalPolicy [policyNo=" + policyNo + ", planName=" + planName + ", memberName=" + memberName
				+ ", effectiveDate=" + effectiveDate + ", endDate=" + endDate + ", sumInsurred=" + sumInsurred + "]";
	}

}
