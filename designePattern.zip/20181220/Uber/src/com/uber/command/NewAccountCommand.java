package com.uber.command;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.webfaces.web.command.FacesCommand;

public class NewAccountCommand implements FacesCommand {

	@Override
	public String execute(HttpServletRequest request, HttpServletResponse response) {
		String accountName = null;

		accountName = request.getParameter("accountName");
		request.setAttribute("accountName", accountName);
		return "account";
	}

}
