package com.ucs.dto;

import java.io.Serializable;

import com.ucs.bo.DiagnosticReportBo;
import com.ucs.bo.PatientAdmissionBo;

public class ClaimForm implements Serializable {
	protected int policyNo;
	protected PatientAdmissionBo patientAdmission;
	protected DiagnosticReportBo diagnosticReport;
	protected String treatment;

	public int getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(int policyNo) {
		this.policyNo = policyNo;
	}

	public PatientAdmissionBo getPatientAdmission() {
		return patientAdmission;
	}

	public void setPatientAdmission(PatientAdmissionBo patientAdmission) {
		this.patientAdmission = patientAdmission;
	}

	public DiagnosticReportBo getDiagnosticReport() {
		return diagnosticReport;
	}

	public void setDiagnosticReport(DiagnosticReportBo diagnosticReport) {
		this.diagnosticReport = diagnosticReport;
	}

	public String getTreatment() {
		return treatment;
	}

	public void setTreatment(String treatment) {
		this.treatment = treatment;
	}

}
