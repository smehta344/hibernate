package com.ucs.facade;

import javax.ejb.EJBException;
import javax.ejb.Remote;
import javax.ejb.Stateless;

import com.ucs.bo.PolicyBo;
import com.ucs.dto.ClaimForm;
import com.ucs.service.CashlessClaimService;
import com.ucs.service.PolicyService;

@Stateless(mappedName="cashlessClaim")
@Remote
public class CashlessClaimEjbRemoteImpl implements CashlessClaimEjbRemote {

	@Override
	public String applyForCashlessFacility(ClaimForm claimForm) {
		CashlessClaimService cashlessClaimService = null;
		PolicyService policyService = null;
		String claimNo = null;
		PolicyBo policy = null;

		policyService = new PolicyService();
		cashlessClaimService = new CashlessClaimService();

		policy = policyService.getPolicy(claimForm.getPolicyNo());
		claimNo = cashlessClaimService.logCashlessClaim(policy, claimForm.getPatientAdmission());
		boolean diagnostic = cashlessClaimService.diagnosisReport(claimNo, claimForm.getDiagnosticReport());
		if (diagnostic == false) {
			throw new EJBException("Diagnostic Report is invalid");
		}

		boolean treatement = cashlessClaimService.treatment(claimNo, claimForm.getTreatment());
		if (treatement == false) {
			throw new EJBException("treatement information is not approved");
		}

		return claimNo;
	}

}
