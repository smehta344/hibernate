package com.ucs.facade;

import javax.ejb.Remote;

import com.ucs.dto.ClaimForm;

@Remote
public interface CashlessClaimEjbRemote {
	String applyForCashlessFacility(ClaimForm claimForm);
}
