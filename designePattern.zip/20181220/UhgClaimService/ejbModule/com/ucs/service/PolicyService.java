package com.ucs.service;

import java.util.Date;

import com.ucs.bo.PolicyBo;

public class PolicyService {
	public PolicyBo getPolicy(int policyNo) {
		PolicyBo policy = null;

		policy = new PolicyBo(policyNo, "Samuel", "Jeeval Policy", new Date(2018, 07, 01), new Date(2019, 11, 31),
				987393);

		return policy;
	}
}
