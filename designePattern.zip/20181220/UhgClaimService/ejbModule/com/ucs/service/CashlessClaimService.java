package com.ucs.service;

import java.util.Random;

import com.ucs.bo.DiagnosticReportBo;
import com.ucs.bo.PatientAdmissionBo;
import com.ucs.bo.PolicyBo;

public class CashlessClaimService {
	public String logCashlessClaim(PolicyBo policy, PatientAdmissionBo patientAdmission) {
		String claimNo = null;

		if (policy.getPolicyHolderName().equals(patientAdmission.getPatientName()) == false) {
			throw new RuntimeException("data mismatch");
		}
		claimNo = "cugh" + new Random().nextInt();
		return claimNo;
	}

	public boolean diagnosisReport(String claimNo, DiagnosticReportBo report) {
		return true;
	}

	public boolean treatment(String claimNo, String description) {
		return true;
	}

}
