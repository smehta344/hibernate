package com.ucs.bo;

import java.io.Serializable;
import java.util.Map;

public class DiagnosticReportBo implements Serializable {
	protected String reportName;
	protected Map<String, String> testResults;

	public String getReportName() {
		return reportName;
	}

	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	public Map<String, String> getTestResults() {
		return testResults;
	}

	public void setTestResults(Map<String, String> testResults) {
		this.testResults = testResults;
	}

}
