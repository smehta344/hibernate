package com.ucs.bo;

import java.io.Serializable;
import java.util.Date;

public class PolicyBo implements Serializable {
	protected int policyNo;
	protected String policyHolderName;
	protected String planName;
	protected Date effectiveDate;
	protected Date endDate;
	protected double sumInsurred;

	public PolicyBo(int policyNo, String policyHolderName, String planName, Date effectiveDate, Date endDate,
			double sumInsurred) {
		super();
		this.policyNo = policyNo;
		this.policyHolderName = policyHolderName;
		this.planName = planName;
		this.effectiveDate = effectiveDate;
		this.endDate = endDate;
		this.sumInsurred = sumInsurred;
	}

	public int getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(int policyNo) {
		this.policyNo = policyNo;
	}

	public String getPolicyHolderName() {
		return policyHolderName;
	}

	public void setPolicyHolderName(String policyHolderName) {
		this.policyHolderName = policyHolderName;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public double getSumInsurred() {
		return sumInsurred;
	}

	public void setSumInsurred(double sumInsurred) {
		this.sumInsurred = sumInsurred;
	}

}
