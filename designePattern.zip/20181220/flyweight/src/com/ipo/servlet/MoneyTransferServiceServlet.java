package com.ipo.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ipo.service.MoneyTransferService;
import com.ipo.util.PostalServiceFactory;

public class MoneyTransferServiceServlet extends HttpServlet {

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String senderName = null;
		String receiverName = null;
		String fromPlace = null;
		String toPlace = null;
		String identityType = null;
		String identityNo = null;
		String transferType = null;
		double amount = 0;
		String referenceNo = null;
		MoneyTransferService moneyTransferService = null;

		senderName = req.getParameter("senderName");
		receiverName = req.getParameter("receiverName");
		fromPlace = req.getParameter("fromPlace");
		toPlace = req.getParameter("toPlace");
		identityType = req.getParameter("identityType");
		identityNo = req.getParameter("identityNo");
		amount = Double.parseDouble(req.getParameter("amount"));
		transferType = req.getParameter("transferType");

		try {
			moneyTransferService = (MoneyTransferService) PostalServiceFactory.createObject(transferType);
			referenceNo = moneyTransferService.transfer(senderName, receiverName, fromPlace, toPlace, identityNo,
					identityType, amount);

			req.setAttribute("referenceNo", referenceNo);
			req.getRequestDispatcher("/money-transfer-info.jsp").forward(req, resp);
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			throw new ServletException(e);
		}

	}

}
