package com.ipo.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ipo.service.ParcelService;
import com.ipo.util.PostalServiceFactory;

public class ParcelServiceServlet extends HttpServlet {
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		String source = null;
		String destination = null;
		String senderName = null;
		String receiverName = null;
		String description = null;
		String parcelType = null;
		double amount = 0;
		ParcelService parcelService = null;

		source = req.getParameter("source");
		destination = req.getParameter("destination");
		senderName = req.getParameter("senderName");
		receiverName = req.getParameter("receiverName");
		description = req.getParameter("description");
		parcelType = req.getParameter("parcelType");

		try {
			parcelService = (ParcelService) PostalServiceFactory.createObject(parcelType);
			amount = parcelService.bookParcel(source, destination, senderName, receiverName, description);
			req.setAttribute("amount", amount);

			req.getRequestDispatcher("/parcel-info.jsp").forward(req, resp);
		} catch (InstantiationException | IllegalAccessException | ClassNotFoundException e) {
			throw new ServletException(e);
		}

	}

}
