package com.ipo.service;

public class NormalMoneyTransferServiceImpl extends MoneyTransferService {

	public NormalMoneyTransferServiceImpl() {
		super("normalTransfer");
	}

	@Override
	public String transfer(String sender, String receiver, String fromPlace, String toPlace, String identityNo,
			String identityType, double amount) {
		return "normal:" + this.hashCode();
	}

}
