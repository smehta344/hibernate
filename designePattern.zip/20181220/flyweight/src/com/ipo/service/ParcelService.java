package com.ipo.service;

public abstract class ParcelService {
	protected String parcelType;

	public ParcelService(String parcelType) {
		this.parcelType = parcelType;
	}

	abstract public double bookParcel(String source, String destination, String senderName, String receiverName,
			String description);
}
