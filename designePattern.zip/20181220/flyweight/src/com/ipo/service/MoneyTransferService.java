package com.ipo.service;

public abstract class MoneyTransferService {
	protected String transferType;

	public MoneyTransferService(String transferType) {
		this.transferType = transferType;
	}

	abstract public String transfer(String sender, String receiver, String fromPlace, String toPlace,
			String identityNo, String identityType, double amount);
}
