package com.ipo.service;

public class InstaMoneyTransferServiceImpl extends MoneyTransferService {

	public InstaMoneyTransferServiceImpl() {
		super("instaTransfer");
	}

	@Override
	public String transfer(String sender, String receiver, String fromPlace, String toPlace, String identityNo,
			String identityType, double amount) {
		return "insta:" + this.hashCode();
	}

}
