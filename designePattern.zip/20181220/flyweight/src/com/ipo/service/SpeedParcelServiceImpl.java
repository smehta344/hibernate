package com.ipo.service;

public class SpeedParcelServiceImpl extends ParcelService {

	public SpeedParcelServiceImpl() {
		super("speedParcel");
	}

	@Override
	public double bookParcel(String source, String destination, String senderName, String receiverName,
			String description) {
		return this.hashCode();
	}

}
