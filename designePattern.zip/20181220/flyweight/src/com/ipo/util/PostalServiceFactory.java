package com.ipo.util;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

public class PostalServiceFactory {
	private static Map<String, Object> objectMap = new HashMap<>();
	private static Properties metadataProps;

	static {
		metadataProps = new Properties();
		try {
			metadataProps
					.load(PostalServiceFactory.class.getClassLoader().getResourceAsStream("app-classes.properties"));
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	public static Object createObject(String serviceType)
			throws InstantiationException, IllegalAccessException, ClassNotFoundException {
		Object obj = null;

		if (objectMap.containsKey(serviceType)) {
			obj = objectMap.get(serviceType);
		} else {
			String clazzName = metadataProps.getProperty(serviceType);
			obj = Class.forName(clazzName).newInstance();
			objectMap.put(serviceType, obj);
		}
		return obj;
	}
}
