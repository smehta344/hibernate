package com.ass.dao;

import com.ass.bo.ComplaintBo;
import com.ass.exception.AfterSalesSupportGenericException;
import com.ass.helper.ConnectionFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ComplaintDao {
	private final String SQL_GET_COMPLAINTS = "select complaint_no, complaint_title, description, reported_dt, estimated_completion_dt, estimated_cost, priority, status from complaint order by";
	private final String SQL_GET_NO_OF_COMPLAINTS = "select count(1) from complaint";

	public List<ComplaintBo> getComplaints(int pageNo, int pageSize, String sortColumn, String sortOrder) {
		List<ComplaintBo> complaints = null;
		PreparedStatement pstmt = null;
		ComplaintBo complaintBo = null;
		Connection con = null;
		ResultSet rs = null;
		int startIndex = 0;
		String sql = null;
		int endIndex = 0;
		int row = 1;

		// complete query
		sql = SQL_GET_COMPLAINTS + " " + sortColumn + " " + sortOrder;
		startIndex = ((pageNo - 1) * pageSize) + 1;
		endIndex = pageNo * pageSize;

		try {
			con = ConnectionFactory.createConnection();
			pstmt = con.prepareStatement(sql);
			rs = pstmt.executeQuery();
			complaints = new ArrayList<>();

			while (rs.next() && row <= endIndex) {
				if (row >= startIndex) {
					complaintBo = new ComplaintBo(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getDate(4),
							rs.getDate(5), rs.getInt(7), rs.getDouble(6), rs.getString(8));
					complaints.add(complaintBo);
				}
				row++;
			}
		} catch (Exception e) {
			throw new AfterSalesSupportGenericException("failed reading complaints", e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return complaints;
	}

	public int getNoOfComplaints() {
		int count = 0;
		ResultSet rs = null;
		Connection con = null;
		PreparedStatement pstmt = null;

		try {
			con = ConnectionFactory.createConnection();
			pstmt = con.prepareStatement(SQL_GET_NO_OF_COMPLAINTS);
			rs = pstmt.executeQuery();
			if (rs.next()) {
				count = rs.getInt(1);
			}
		} catch (Exception e) {
			throw new AfterSalesSupportGenericException("failed reading no of complaints", e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (pstmt != null) {
				try {
					pstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return count;

	}

	public static void main(String[] args) {
		ComplaintDao cdao = new ComplaintDao();
		List<ComplaintBo> cl = cdao.getComplaints(1, 10, "complaint_no", "asc");
		System.out.println("size : " + cl.size());
		int r = cdao.getNoOfComplaints();
		System.out.println("r : " +r);
	}
}
