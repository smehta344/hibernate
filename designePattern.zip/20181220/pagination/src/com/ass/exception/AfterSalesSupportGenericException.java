package com.ass.exception;

public class AfterSalesSupportGenericException extends RuntimeException {

	public AfterSalesSupportGenericException() {
		super();
	}

	public AfterSalesSupportGenericException(String message, Throwable cause) {
		super(message, cause);
	}

	public AfterSalesSupportGenericException(String message) {
		super(message);
	}

	public AfterSalesSupportGenericException(Throwable cause) {
		super(cause);
	}

}
