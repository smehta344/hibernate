package com.ass.helper;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.ass.exception.AfterSalesSupportGenericException;

public class ConnectionFactory {
	private static Properties dbProps;

	static {
		dbProps = new Properties();
		try {
			dbProps.load(ConnectionFactory.class.getClassLoader().getResourceAsStream("db.properties"));
			Class.forName(dbProps.getProperty("driverClassname"));
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
			throw new AfterSalesSupportGenericException("unable to read props", e);
		}
	}

	public static Connection createConnection() {
		Connection con = null;

		try {
			con = DriverManager.getConnection(dbProps.getProperty("url"), dbProps.getProperty("username"),
					dbProps.getProperty("password"));
			con.setAutoCommit(false);
		} catch (SQLException e) {
			e.printStackTrace();
			throw new AfterSalesSupportGenericException("unable to get connection", e);
		}

		return con;
	}
}
