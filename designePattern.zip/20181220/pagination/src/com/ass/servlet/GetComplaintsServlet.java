package com.ass.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.ass.delegate.ComplaintDelegate;
import com.ass.vo.ComplaintVo;

@WebServlet(urlPatterns = { "/complaints" })
public class GetComplaintsServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int pageNo = 0;
		int pageSize = 0;
		int totalPages = 0;
		float totalRecords = 0;
		String sPageNo = null;
		String sortColumn = null;
		String sortOrder = null;
		List<ComplaintVo> complaints = null;
		ComplaintDelegate complaintDelegate = null;

		sPageNo = req.getParameter("pageNo");

		// first request
		if (sPageNo == null) {
			pageNo = 1;
			pageSize = 5;
			sortColumn = "complaint_no";
			sortOrder = "asc";
		} else {
			pageNo = Integer.parseInt(sPageNo);
			sortColumn = req.getParameter("sortColumn");
			sortOrder = req.getParameter("sortOrder");
			pageSize = Integer.parseInt(req.getParameter("pageSize"));
		}

		complaintDelegate = new ComplaintDelegate();
		complaints = complaintDelegate.getComplaints(pageNo, pageSize, sortColumn, sortOrder);
		totalRecords = complaintDelegate.getNoOfComplaints();
		totalPages = (int) Math.ceil(totalRecords / pageSize);

		req.setAttribute("cPageNo", pageNo);
		req.setAttribute("totalPages", totalPages);
		req.setAttribute("complaints", complaints);
		req.setAttribute("sortColumn", sortColumn);
		req.setAttribute("sortOrder", sortOrder);
		req.setAttribute("sPageSize", pageSize);

		req.getRequestDispatcher("/complaints.jsp").forward(req, resp);
	}
}











