package com.ass.vo;

public class ComplaintVo {
	protected String complaintNo;
	protected String title;
	protected String reportedDate;
	protected String priority;
	protected String status;

	public ComplaintVo(String complaintNo, String title, String reportedDate, String priority, String status) {
		super();
		this.complaintNo = complaintNo;
		this.title = title;
		this.reportedDate = reportedDate;
		this.priority = priority;
		this.status = status;
	}

	public String getComplaintNo() {
		return complaintNo;
	}

	public void setComplaintNo(String complaintNo) {
		this.complaintNo = complaintNo;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getReportedDate() {
		return reportedDate;
	}

	public void setReportedDate(String reportedDate) {
		this.reportedDate = reportedDate;
	}

	public String getPriority() {
		return priority;
	}

	public void setPriority(String priority) {
		this.priority = priority;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
