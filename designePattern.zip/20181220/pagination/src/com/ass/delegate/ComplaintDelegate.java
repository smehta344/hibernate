package com.ass.delegate;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import com.ass.bo.ComplaintBo;
import com.ass.dao.ComplaintDao;
import com.ass.vo.ComplaintVo;

public class ComplaintDelegate {
	public List<ComplaintVo> getComplaints(int pageNo, int pageSize, String sortColumn, String sortOrder) {
		List<ComplaintBo> complaintBos = null;
		List<ComplaintVo> complaintVos = null;
		ComplaintDao complaintDao = null;
		ComplaintVo complaintVo = null;
		SimpleDateFormat sdf = null;

		sdf = new SimpleDateFormat("dd-MMM-yyyy");
		complaintDao = new ComplaintDao();
		complaintBos = complaintDao.getComplaints(pageNo, pageSize, sortColumn, sortOrder);
		complaintVos = new ArrayList<>();
		for (ComplaintBo complaintBo : complaintBos) {
			complaintVo = new ComplaintVo(String.valueOf(complaintBo.getComplaintNo()), complaintBo.getComplaintTitle(),
					sdf.format(complaintBo.getReportedDate()), String.valueOf(complaintBo.getPriority()),
					complaintBo.getStatus());
			complaintVos.add(complaintVo);
		}

		return complaintVos;
	}

	public int getNoOfComplaints() {
		return new ComplaintDao().getNoOfComplaints();
	}

	public static void main(String[] args) {
		ComplaintDelegate cd = new ComplaintDelegate();
		cd.getComplaints(1, 10, "complaint_no", "desc");
	}
}
