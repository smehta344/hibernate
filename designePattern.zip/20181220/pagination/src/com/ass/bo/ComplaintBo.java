package com.ass.bo;

import java.io.Serializable;
import java.util.Date;

public class ComplaintBo implements Serializable {
	protected int complaintNo;
	protected String complaintTitle;
	protected String description;
	protected Date reportedDate;
	protected Date estimatedCompletionDate;
	protected int priority;
	protected double estimatedCost;
	protected String status;

	public ComplaintBo(int complaintNo, String complaintTitle, String description, Date reportedDate,
			Date estimatedCompletionDate, int priority, double estimatedCost, String status) {
		this.complaintNo = complaintNo;
		this.complaintTitle = complaintTitle;
		this.description = description;
		this.reportedDate = reportedDate;
		this.estimatedCompletionDate = estimatedCompletionDate;
		this.priority = priority;
		this.estimatedCost = estimatedCost;
		this.status = status;
	}

	public int getComplaintNo() {
		return complaintNo;
	}

	public void setComplaintNo(int complaintNo) {
		this.complaintNo = complaintNo;
	}

	public String getComplaintTitle() {
		return complaintTitle;
	}

	public void setComplaintTitle(String complaintTitle) {
		this.complaintTitle = complaintTitle;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getReportedDate() {
		return reportedDate;
	}

	public void setReportedDate(Date reportedDate) {
		this.reportedDate = reportedDate;
	}

	public Date getEstimatedCompletionDate() {
		return estimatedCompletionDate;
	}

	public void setEstimatedCompletionDate(Date estimatedCompletionDate) {
		this.estimatedCompletionDate = estimatedCompletionDate;
	}

	public int getPriority() {
		return priority;
	}

	public void setPriority(int priority) {
		this.priority = priority;
	}

	public double getEstimatedCost() {
		return estimatedCost;
	}

	public void setEstimatedCost(double estimatedCost) {
		this.estimatedCost = estimatedCost;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
