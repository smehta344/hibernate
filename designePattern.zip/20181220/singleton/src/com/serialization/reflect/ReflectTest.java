package com.serialization.reflect;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;

public class ReflectTest {
	public static void main(String[] args)
			throws ClassNotFoundException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Class clazz = Class.forName("com.serialization.reflect.ReflectTimeZone");
		Constructor<?> constructor = clazz.getDeclaredConstructors()[0];
		constructor.setAccessible(true);
		
		
		Object obj = constructor.newInstance(null);
		System.out.println("obj1 : " + obj.hashCode());
		
		Object obj2 = constructor.newInstance(null);
		System.out.println("obj2 : " + obj2.hashCode());

	}
	
}
