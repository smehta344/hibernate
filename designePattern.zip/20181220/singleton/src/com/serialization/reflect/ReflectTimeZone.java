package com.serialization.reflect;

import java.io.Serializable;

public abstract class ReflectTimeZone implements Cloneable, Serializable {
	private static ReflectTimeZone instance;

	private ReflectTimeZone() {
	}

	public static ReflectTimeZone getInstance() {
		if (instance == null) {
			synchronized (ReflectTimeZone.class) {
				if (instance == null) {
					instance = new ReflectTimeZone() {};
				}
			}
		}
		return instance;
	}

	public Object readResolve() {
		return getInstance();
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}

}
