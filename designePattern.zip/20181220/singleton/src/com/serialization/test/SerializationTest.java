package com.serialization.test;

public class SerializationTest {
	public static void main(String[] args) {
		Product product1 = new Product();
		product1.setProductNo(1);
		product1.setProductName("Television");
		ObjectSerializer.serialize(product1, "d:\\product.ser");

		Product product2 = (Product) ObjectDeSerializer.deSerialize("d:\\product.ser");
		System.out.println("product1 == product2 ? : " + (product1 == product2));
	}
}
