package com.serialization.test;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class ObjectSerializer {
	public static void serialize(Object object, String loc) {
		try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(loc))) {
			oos.writeObject(object);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
