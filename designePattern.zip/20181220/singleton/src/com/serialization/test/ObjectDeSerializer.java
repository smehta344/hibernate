package com.serialization.test;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.ObjectInputStream;

public class ObjectDeSerializer {
	public static Object deSerialize(String loc) {
		try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(loc))) {
			return ois.readObject();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}
}
