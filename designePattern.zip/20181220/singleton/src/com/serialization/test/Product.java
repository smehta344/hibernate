package com.serialization.test;

import java.io.Serializable;

public class Product implements Serializable {
	private static final long serialVersionUID = 3196188991647919562L;
	protected int productNo;
	protected String productName;

	public int getProductNo() {
		return productNo;
	}

	public void setProductNo(int productNo) {
		this.productNo = productNo;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

}
