package com.singleton.staticblock;

public class Beta {
	public static void main(String[] args) {
		StaticBlockTimeZone tz1 = StaticBlockTimeZone.getInstance();
		StaticBlockTimeZone tz2 = StaticBlockTimeZone.getInstance();
		System.out.println("tz1 == tz2 ? : " + (tz1 == tz2));
	}
}
