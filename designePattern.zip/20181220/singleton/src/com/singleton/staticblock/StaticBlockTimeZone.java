package com.singleton.staticblock;

import java.util.Calendar;

public class StaticBlockTimeZone {
	private String defaultTimeZone;
	private static StaticBlockTimeZone instance;

	static {
		instance = new StaticBlockTimeZone();
		instance.defaultTimeZone = Calendar.getInstance().getTimeZone().getDisplayName();
	}

	private StaticBlockTimeZone() {
		// no op
	}

	public static StaticBlockTimeZone getInstance() {
		return instance;
	}

	public String getDefaultTimeZone() {
		return defaultTimeZone;
	}

}
