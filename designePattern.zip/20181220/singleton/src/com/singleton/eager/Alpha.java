package com.singleton.eager;

public class Alpha {
	public static void main(String[] args) throws ClassNotFoundException {
		// Class.forName("com.singleton.eager.EagerTimeZone");

		EagerTimeZone tz1 = EagerTimeZone.getInstance();
		EagerTimeZone tz2 = EagerTimeZone.getInstance();

		System.out.println("tz1 == tz2 ? : " + (tz1 == tz2));
	}
}
