package com.singleton.eager;

public class EagerTimeZone {
	// initializes only once at the time of loading the class
	private static EagerTimeZone instance = new EagerTimeZone();

	private EagerTimeZone() {
		// no-op
		System.out.println("EagerTimeZone Object instantiated");
	}

	public static EagerTimeZone getInstance() {
		return instance;
	}

}
