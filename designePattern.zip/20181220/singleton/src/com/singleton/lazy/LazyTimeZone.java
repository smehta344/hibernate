package com.singleton.lazy;

public class LazyTimeZone {
	private static LazyTimeZone instance;

	private LazyTimeZone() {
		// no-op
		System.out.println("LazyTimeZone Object instantiated");
	}

	public static LazyTimeZone getInstance() {
		if (instance == null) {
			instance = new LazyTimeZone();
		}
		return instance;
	}
}
