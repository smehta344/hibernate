package com.singleton.lazy;

public class Gamma {
	public static void main(String[] args) throws ClassNotFoundException {
		Class.forName("com.singleton.lazy.LazyTimeZone");
		LazyTimeZone ltz1 = LazyTimeZone.getInstance();
		LazyTimeZone ltz2 = LazyTimeZone.getInstance();

		System.out.println("Terminated ? : " + (ltz1 == ltz2));
	}
}
