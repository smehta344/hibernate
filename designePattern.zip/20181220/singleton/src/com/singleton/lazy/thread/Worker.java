package com.singleton.lazy.thread;

import java.util.concurrent.CountDownLatch;

public class Worker implements Runnable {
	private CountDownLatch countDownLatch;

	public Worker(CountDownLatch countDownLatch) {
		this.countDownLatch = countDownLatch;
	}

	@Override
	public void run() {
		ThreadedTimeZone ttz = null;
		ttz = ThreadedTimeZone.getInstance();
		System.out.println("hashCode :" + ttz.hashCode());
		countDownLatch.countDown();
	}
}
