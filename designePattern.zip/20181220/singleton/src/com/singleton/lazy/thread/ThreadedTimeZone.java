package com.singleton.lazy.thread;

public class ThreadedTimeZone {
	private static ThreadedTimeZone instance;

	private ThreadedTimeZone() {
	}

	public static ThreadedTimeZone getInstance() {
		if (instance == null) {
			System.out.println("locked");
			synchronized (ThreadedTimeZone.class) {
				if (instance == null) {
					instance = new ThreadedTimeZone();
				}
			}
			System.out.println("released");
		}
		return instance;
	}
}
