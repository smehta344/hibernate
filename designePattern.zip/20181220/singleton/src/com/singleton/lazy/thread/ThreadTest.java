package com.singleton.lazy.thread;

import java.util.Calendar;
import java.util.concurrent.CountDownLatch;

public class ThreadTest {
	public static void main(String[] args) throws InterruptedException {
		CountDownLatch cdl = new CountDownLatch(100);

		Worker worker = new Worker(cdl);
		long st = Calendar.getInstance().getTimeInMillis();
		for (int i = 0; i < 100; i++) {
			Thread t = new Thread(worker);
			t.start();
		}
		cdl.await();
		long et = Calendar.getInstance().getTimeInMillis();
		System.out.println("total execution ms : " + (et - st));
	}
}
