package com.singleton.clone;

public class CloneableTimeZone extends Stat implements Cloneable {
	private static CloneableTimeZone instance;

	private CloneableTimeZone() {
	}

	public static CloneableTimeZone getInstance() {
		if (instance == null) {
			synchronized (CloneableTimeZone.class) {
				if (instance == null) {
					instance = new CloneableTimeZone();
				}

			}
		}
		return instance;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException("Cloning is not supported");
	}

}
