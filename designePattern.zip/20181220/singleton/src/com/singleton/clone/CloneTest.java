package com.singleton.clone;

public class CloneTest {
	public static void main(String[] args) throws CloneNotSupportedException {
		CloneableTimeZone ctz1 = CloneableTimeZone.getInstance();
		CloneableTimeZone ctz2 = (CloneableTimeZone) ctz1.clone();

		System.out.println("ctz1 == ctz2 ? :  " + (ctz1 == ctz2));

	}
}
