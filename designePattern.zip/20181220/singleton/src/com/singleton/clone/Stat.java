package com.singleton.clone;

import java.util.Date;

public class Stat implements Cloneable {
	protected Date createdTime;

	public Stat() {
		createdTime = new Date();
	}

	public Date getCreatedTime() {
		return createdTime;
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		return super.clone();
	}

}
