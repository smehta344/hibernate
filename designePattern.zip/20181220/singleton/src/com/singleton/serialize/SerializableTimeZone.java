package com.singleton.serialize;

import java.io.Serializable;

public class SerializableTimeZone implements Cloneable, Serializable {
	private static SerializableTimeZone instance;

	private SerializableTimeZone() {

	}

	public static SerializableTimeZone getInstance() {
		if (instance == null) {
			synchronized (SerializableTimeZone.class) {
				if (instance == null) {
					instance = new SerializableTimeZone();
				}
			}
		}
		return instance;
	}
	
	public Object readResolve() {
		return getInstance();
	}

	@Override
	protected Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}

}










