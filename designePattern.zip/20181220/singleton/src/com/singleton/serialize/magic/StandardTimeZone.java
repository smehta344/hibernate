package com.singleton.serialize.magic;

import java.io.Serializable;

public class StandardTimeZone implements Serializable {
	private static final long serialVersionUID = -8498850960852085545L;
	protected int defaultTimeZone;
	
	public Object readResolve() {
		TimeZone tz = null;
		
		tz = new TimeZone();
		if(defaultTimeZone == 1) {
			tz.setDefaultTimeZone("Standard India Time");
		}
		return tz;
	}

	public int getDefaultTimeZone() {
		return defaultTimeZone;
	}

	public void setDefaultTimeZone(int defaultTimeZone) {
		this.defaultTimeZone = defaultTimeZone;
	}

}
