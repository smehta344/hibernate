package com.singleton.serialize.magic;

import com.serialization.test.ObjectDeSerializer;
import com.serialization.test.ObjectSerializer;

public class MagicTest {
	public static void main(String[] args) {
		/*TimeZone tz = new TimeZone();
		tz.setDefaultTimeZone("Standard India Time");
		ObjectSerializer.serialize(tz, "d:\\tz.ser");*/
		
		TimeZone stz = (TimeZone) ObjectDeSerializer.deSerialize("d:\\tz.ser");
		System.out.println(stz.defaultTimeZone);
		
	}
}
