package com.singleton.serialize.magic;

import java.io.Serializable;

public class TimeZone implements Serializable {
	private static final long serialVersionUID = 2098043658144257029L;
	protected String defaultTimeZone;

	public Object writeReplace() {
		StandardTimeZone stz = null;

		System.out.println("writeReplace()");
		stz = new StandardTimeZone();
		if (defaultTimeZone.equals("Standard India Time")) {
			stz.setDefaultTimeZone(1);
		}

		return stz;
	}

	public String getDefaultTimeZone() {
		return defaultTimeZone;
	}

	public void setDefaultTimeZone(String defaultTimeZone) {
		this.defaultTimeZone = defaultTimeZone;
	}

}
