package com.singleton.serialize;

import com.serialization.test.ObjectDeSerializer;
import com.serialization.test.ObjectSerializer;

public class SerializationTest {
	public static void main(String[] args) {
		SerializableTimeZone stz1 = SerializableTimeZone.getInstance();
		ObjectSerializer.serialize(stz1, "d:\\timezone.ser");
		SerializableTimeZone stz2 = (SerializableTimeZone) ObjectDeSerializer.deSerialize("d:\\timezone.ser");
		System.out.println("stz1 == stz2 ? : " + (stz1 == stz2));
	}
}
