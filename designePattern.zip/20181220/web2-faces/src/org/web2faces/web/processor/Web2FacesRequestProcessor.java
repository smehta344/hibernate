package org.web2faces.web.processor;

import javax.servlet.http.HttpServletResponse;

import org.web2faces.web.command.Web2FacesCommand;
import org.web2faces.web.command.helper.CommandHelper;
import org.web2faces.web.context.ContextObjectFactory;
import org.web2faces.web.context.MapContextObject;
import org.web2faces.web.metadata.Web2FacesMetadataContext;
import org.web2faces.web.view.Dispatcher;

import javax.servlet.http.HttpServletRequest;

/**
 * Application Controller
 * 
 * @author Sriman
 *
 */
public class Web2FacesRequestProcessor {

	public void handleRequest(HttpServletRequest request, HttpServletResponse response,
			Web2FacesMetadataContext metadataContext) {
		String outcome = null;
		String requestUri = null;
		MapContextObject mapContextObject = null;
		Web2FacesCommand web2FacesCommand = null;

		requestUri = request.getServletPath();
		mapContextObject = ContextObjectFactory.createContextObject(request, metadataContext.getTransport());
		web2FacesCommand = CommandHelper.getCommand(requestUri, metadataContext);
		outcome = web2FacesCommand.execute(mapContextObject);
		ContextObjectFactory.bindContextObject(request, metadataContext.getTransport(), mapContextObject);
		Dispatcher.dispatch(request, response, outcome, metadataContext);
	}
}
