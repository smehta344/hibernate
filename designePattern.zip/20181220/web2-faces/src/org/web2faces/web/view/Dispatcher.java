package org.web2faces.web.view;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.web2faces.web.exception.DispatcherViewException;
import org.web2faces.web.metadata.Web2FacesMetadataContext;

public class Dispatcher {
	public static void dispatch(HttpServletRequest request, HttpServletResponse response, String outcome,
			Web2FacesMetadataContext metadataContext) {
		String requestUri = null;
		String page = null;

		try {
			requestUri = request.getServletPath();
			page = metadataContext.getPage(requestUri, outcome);
			request.getRequestDispatcher(page).forward(request, response);
		} catch (ServletException | IOException e) {
			throw new DispatcherViewException("unable to forward to the page : " + page, e);
		}
	}
}
