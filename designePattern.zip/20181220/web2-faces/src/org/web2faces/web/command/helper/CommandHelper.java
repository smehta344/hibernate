package org.web2faces.web.command.helper;

import org.web2faces.web.command.Web2FacesCommand;
import org.web2faces.web.exception.CommandInstantiationFailedException;
import org.web2faces.web.exception.CommandNotFoundException;
import org.web2faces.web.metadata.Web2FacesMetadataContext;

public class CommandHelper {

	public static Web2FacesCommand getCommand(String requestUri, Web2FacesMetadataContext metadataContext) {
		String commandClass = null;
		Class<Web2FacesCommand> wClass = null;
		Web2FacesCommand web2FacesCommand = null;

		commandClass = metadataContext.getCommandClass(requestUri);
		try {
			wClass = (Class<Web2FacesCommand>) Class.forName(commandClass);
			web2FacesCommand = wClass.newInstance();
		} catch (ClassNotFoundException e) {
			throw new CommandNotFoundException("commandClass :" + commandClass + " is not found", e);
		} catch (InstantiationException | IllegalAccessException e) {
			throw new CommandInstantiationFailedException(
					"error while instantiating the commandClass : " + commandClass, e);
		}

		return web2FacesCommand;
	}
}
