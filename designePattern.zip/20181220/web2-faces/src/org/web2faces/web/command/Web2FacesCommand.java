package org.web2faces.web.command;

import org.web2faces.web.context.MapContextObject;

public interface Web2FacesCommand {
	String execute(MapContextObject contextObject);
}
