package org.web2faces.web.servlet;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.web2faces.web.config.reader.Web2FacesConfigReader;
import org.web2faces.web.config.reader.Web2FacesConfigReaderFactory;
import org.web2faces.web.metadata.Web2FacesMetadataContext;
import org.web2faces.web.processor.Web2FacesRequestProcessor;

public class Web2FacesServlet extends HttpServlet {
	private Web2FacesRequestProcessor web2FacesRequestProcessor;
	private Web2FacesMetadataContext metadataContext;

	@Override
	public void init(ServletConfig config) throws ServletException {
		Web2FacesConfigReader web2FacesConfigReader = null;
		ServletContext servletContext = null;
		String configLocation = null;
		String namespace = null;
		String type = null;

		servletContext = config.getServletContext();
		namespace = config.getInitParameter("namespace");
		type = namespace.substring(namespace.indexOf(".") + 1, namespace.length());
		System.out.println("type : " + type);
		web2FacesConfigReader = Web2FacesConfigReaderFactory.createWeb2FacesConfigReader(type);
		configLocation = servletContext.getRealPath("/WEB-INF/") + namespace;

		metadataContext = web2FacesConfigReader.readWeb2FacesConfig(configLocation);
		web2FacesRequestProcessor = new Web2FacesRequestProcessor();
		System.out.println("Web2FacesServlet initialized...");
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		web2FacesRequestProcessor.handleRequest(request, response, metadataContext);

	}

}
