
package org.web2faces.web.config.reader;

import org.web2faces.web.metadata.Web2FacesMetadataContext;

public interface Web2FacesConfigReader {
	Web2FacesMetadataContext readWeb2FacesConfig(String namespace);
}
