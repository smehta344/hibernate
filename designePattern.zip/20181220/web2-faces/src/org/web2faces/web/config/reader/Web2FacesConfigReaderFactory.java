package org.web2faces.web.config.reader;

public class Web2FacesConfigReaderFactory {
	public static Web2FacesConfigReader createWeb2FacesConfigReader(String type) {
		Web2FacesConfigReader reader = null;

		if (type.equals("xml")) {
			reader = new XmlWeb2FacesConfigReader();
		}

		return reader;
	}
}
