package org.web2faces.web.config.reader;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;

import org.web2faces.web.config.CommandMapping;
import org.web2faces.web.config.Forward;
import org.web2faces.web.config.Web2FacesConfig;
import org.web2faces.web.exception.ConfigReaderException;
import org.web2faces.web.metadata.CommandMappingMetadata;
import org.web2faces.web.metadata.ForwardMetadata;
import org.web2faces.web.metadata.Web2FacesMetadataContext;

public class XmlWeb2FacesConfigReader implements Web2FacesConfigReader {

	@Override
	public Web2FacesMetadataContext readWeb2FacesConfig(String namespace) {

		JAXBContext jContext = null;
		Unmarshaller unmarshaller = null;
		Web2FacesConfig web2FacesConfig = null;
		ForwardMetadata forwardMetadata = null;
		List<CommandMapping> commandMappings = null;
		List<ForwardMetadata> forwardMetadatas = null;
		JAXBElement<Web2FacesConfig> jElement = null;
		CommandMappingMetadata commandMappingMetadata = null;
		Web2FacesMetadataContext web2FacesMetadataContext = null;
		Map<String, CommandMappingMetadata> commandMappingsMap = null;

		try {
			jContext = JAXBContext.newInstance("org.web2faces.web.config");
			unmarshaller = jContext.createUnmarshaller();
			jElement = (JAXBElement<Web2FacesConfig>) unmarshaller.unmarshal(new File(namespace));
			web2FacesConfig = jElement.getValue();

			commandMappingsMap = new HashMap<>();
			commandMappings = web2FacesConfig.getCommandMappings().getCommandMapping();
			for (CommandMapping commandMapping : commandMappings) {
				forwardMetadatas = new ArrayList<>();
				commandMappingMetadata = new CommandMappingMetadata();
				commandMappingMetadata.setPath(commandMapping.getPath());
				commandMappingMetadata.setType(commandMapping.getType());

				for (Forward forward : commandMapping.getForward()) {
					forwardMetadata = new ForwardMetadata(forward.getName(), forward.getPage());
					forwardMetadatas.add(forwardMetadata);
				}
				commandMappingMetadata.setForwards(forwardMetadatas);
				commandMappingsMap.put(commandMapping.getPath(), commandMappingMetadata);
			}

			web2FacesMetadataContext = new Web2FacesMetadataContext(web2FacesConfig.getTransport(), commandMappingsMap);

		} catch (JAXBException e) {
			throw new ConfigReaderException("unable to read the configuration", e);
		}

		return web2FacesMetadataContext;
	}

}
