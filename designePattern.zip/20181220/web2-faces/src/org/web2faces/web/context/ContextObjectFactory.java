package org.web2faces.web.context;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.web2faces.web.mapper.Mapper;
import org.web2faces.web.mapper.MapperFactory;

public class ContextObjectFactory {
	public static MapContextObject createContextObject(HttpServletRequest request, String transport) {
		MapContextObject mapContextObject = null;
		Map<String, String[]> requestMap = null;
		Mapper mapper = null;

		mapper = MapperFactory.createMapper(transport);
		requestMap = mapper.extractData(request);
		mapContextObject = new MapContextObject(requestMap);
		return mapContextObject;
	}

	public static void bindContextObject(HttpServletRequest request, String transport,
			MapContextObject mapContextObject) {
		Mapper mapper = null;

		mapper = MapperFactory.createMapper(transport);
		mapper.bindData(mapContextObject.getResponseAttributes(), request);
	}

}
