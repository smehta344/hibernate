package org.web2faces.web.context;

import java.util.HashMap;
import java.util.Map;

public class MapContextObject {
	private Map<String, String[]> requestMap;
	private Map<String, Object> responseMap;

	public MapContextObject(Map<String, String[]> requestMap) {
		this.requestMap = requestMap;
		responseMap = new HashMap<>();
	}

	public String getAttribute(String attributeName) {
		String attributeValues[] = null;

		attributeValues = requestMap.get(attributeName);
		if (attributeValues.length > 0) {
			return attributeValues[0];
		}
		return null;
	}

	public String[] getAttributes(String attributeName) {
		String attributeValues[] = null;

		attributeValues = requestMap.get(attributeName);
		return attributeValues;
	}

	public void addAttribute(String attributeName, Object attribute) {
		responseMap.put(attributeName, attribute);
	}

	public Map<String, String[]> getRequestAttributes() {
		return requestMap;
	}

	public Map<String, Object> getResponseAttributes() {
		return responseMap;
	}
}








