package org.web2faces.web.mapper;

public class MapperFactory {
	public static Mapper createMapper(String transport) {
		Mapper mapper = null;

		if (transport.equals("http")) {
			mapper = new HttpMapper();
		}

		return mapper;
	}
}
