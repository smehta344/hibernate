package org.web2faces.web.mapper;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

public interface Mapper {
	Map<String, String[]> extractData(HttpServletRequest request);

	void bindData(Map<String, Object> response, HttpServletRequest request);
}
