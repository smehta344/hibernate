package org.web2faces.web.mapper;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

public class HttpMapper implements Mapper {

	@Override
	public Map<String, String[]> extractData(HttpServletRequest request) {
		return request.getParameterMap();
	}

	@Override
	public void bindData(Map<String, Object> response, HttpServletRequest request) {
		for (String attributeName : response.keySet()) {
			request.setAttribute(attributeName, response.get(attributeName));
		}
	}

}
