package org.web2faces.web.metadata;

import java.util.Map;

import org.web2faces.web.exception.CommandConfigNotFoundException;
import org.web2faces.web.exception.ForwardConfigNotFoundException;

public class Web2FacesMetadataContext {
	protected String transport;
	protected Map<String, CommandMappingMetadata> commandMappings;

	public Web2FacesMetadataContext(String transport, Map<String, CommandMappingMetadata> commandMappings) {
		this.transport = transport;
		this.commandMappings = commandMappings;
	}

	public String getTransport() {
		return transport;
	}

	public String getCommandClass(String requestUri) {
		String commandClass = null;
		CommandMappingMetadata commandMappingMetadata = null;

		if (commandMappings.containsKey(requestUri) == false) {
			throw new CommandConfigNotFoundException("command not found for request uri : " + requestUri);
		}
		commandMappingMetadata = commandMappings.get(requestUri);
		commandClass = commandMappingMetadata.getType();
		return commandClass;
	}

	public String getPage(String requestUri, String outcome) {
		String page = null;
		CommandMappingMetadata commandMappingMetadata = null;

		if (commandMappings.containsKey(requestUri) == false) {
			throw new CommandConfigNotFoundException("command not found for request uri : " + requestUri);
		}
		commandMappingMetadata = commandMappings.get(requestUri);
		for (ForwardMetadata forwardMetadata : commandMappingMetadata.getForwards()) {
			if (forwardMetadata.getName().equals(outcome)) {
				page = forwardMetadata.getPage();
				break;
			}
		}
		if (page == null) {
			throw new ForwardConfigNotFoundException(
					"forward not found for request uri : " + requestUri + " with outcome : " + outcome);
		}
		return page;
	}

}
