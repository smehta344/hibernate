package org.web2faces.web.metadata;

public class ForwardMetadata {
	protected String name;
	protected String page;

	public ForwardMetadata(String name, String page) {
		this.name = name;
		this.page = page;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPage() {
		return page;
	}

	public void setPage(String page) {
		this.page = page;
	}

}
