package org.web2faces.web.metadata;

import java.util.List;

public class CommandMappingMetadata {
	protected String path;
	protected String type;
	protected List<ForwardMetadata> forwards;

	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<ForwardMetadata> getForwards() {
		return forwards;
	}

	public void setForwards(List<ForwardMetadata> forwards) {
		this.forwards = forwards;
	}

}
