package org.web2faces.web.exception;

public class CommandNotFoundException extends Web2FacesException {

	public CommandNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

}
