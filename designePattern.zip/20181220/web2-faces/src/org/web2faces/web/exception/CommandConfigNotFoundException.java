package org.web2faces.web.exception;

public class CommandConfigNotFoundException extends Web2FacesException {

	public CommandConfigNotFoundException(String message) {
		super(message);
	}

}
