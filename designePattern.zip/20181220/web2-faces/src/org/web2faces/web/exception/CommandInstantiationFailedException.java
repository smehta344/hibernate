package org.web2faces.web.exception;

public class CommandInstantiationFailedException extends Web2FacesException {

	public CommandInstantiationFailedException(String message, Throwable cause) {
		super(message, cause);
	}

}
