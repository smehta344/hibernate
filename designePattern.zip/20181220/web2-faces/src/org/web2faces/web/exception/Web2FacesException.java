package org.web2faces.web.exception;

public class Web2FacesException extends RuntimeException {
	private static final long serialVersionUID = -1304147696993791918L;

	public Web2FacesException() {
		super();
	}

	public Web2FacesException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public Web2FacesException(String message, Throwable cause) {
		super(message, cause);
	}

	public Web2FacesException(String message) {
		super(message);
	}

	public Web2FacesException(Throwable cause) {
		super(cause);
	}

}
