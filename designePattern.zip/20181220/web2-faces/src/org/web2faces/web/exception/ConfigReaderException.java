package org.web2faces.web.exception;

public class ConfigReaderException extends Web2FacesException {

	public ConfigReaderException(String message, Throwable cause) {
		super(message, cause);
	}

}
