package org.web2faces.web.exception;

public class ForwardConfigNotFoundException extends Web2FacesException {

	public ForwardConfigNotFoundException(String message) {
		super(message);
	}

}
