package org.web2faces.web.exception;

public class DispatcherViewException extends Web2FacesException {

	public DispatcherViewException(String message, Throwable cause) {
		super(message, cause);
	}

}
