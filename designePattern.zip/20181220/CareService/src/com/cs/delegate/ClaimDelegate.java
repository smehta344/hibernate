package com.cs.delegate;

import java.text.ParseException;
import java.text.SimpleDateFormat;

import javax.naming.NamingException;

import com.cs.bo.ClaimBo;
import com.cs.remote.service.CashlessClaimService;
import com.cs.vo.CashlessClaimVO;

public class ClaimDelegate {

	public String applyCashlessClaim(CashlessClaimVO vo) throws ParseException, NamingException {
		String claimNo = null;
		ClaimBo bo = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/mm/yyyy");
		CashlessClaimService cashlessClaimService = null;

		bo = new ClaimBo();
		bo.setPolicyNo(Integer.parseInt(vo.getPolicyNo()));
		bo.setAdmissionNo(Integer.parseInt(vo.getAdmissionNo()));
		bo.setAdmissionDate(sdf.parse(vo.getAdmissionDate()));
		bo.setPatientName(vo.getPatientName());
		bo.setCostPerDay(Float.parseFloat(vo.getCostPerDay()));
		bo.setHospitalName(vo.getHospitalName());
		bo.setRoomType(vo.getRoomType());
		bo.setDiagnosticReportName(vo.getDiagnosticReportName());
		bo.setTreatmentName(vo.getTreatmentName());

		cashlessClaimService = new CashlessClaimService();
		claimNo = cashlessClaimService.applyCashlessClaim(bo);
		return claimNo;
	}
}
