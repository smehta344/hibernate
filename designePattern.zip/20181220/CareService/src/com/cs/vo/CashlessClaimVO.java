package com.cs.vo;

public class CashlessClaimVO {
	protected String policyNo;
	protected String admissionNo;
	protected String hospitalName;
	protected String patientName;
	protected String admissionDate;
	protected String roomType;
	protected String costPerDay;
	protected String diagnosticReportName;
	protected String treatmentName;

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getAdmissionNo() {
		return admissionNo;
	}

	public void setAdmissionNo(String admissionNo) {
		this.admissionNo = admissionNo;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public String getAdmissionDate() {
		return admissionDate;
	}

	public void setAdmissionDate(String admissionDate) {
		this.admissionDate = admissionDate;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public String getCostPerDay() {
		return costPerDay;
	}

	public void setCostPerDay(String costPerDay) {
		this.costPerDay = costPerDay;
	}

	public String getDiagnosticReportName() {
		return diagnosticReportName;
	}

	public void setDiagnosticReportName(String diagnosticReportName) {
		this.diagnosticReportName = diagnosticReportName;
	}

	public String getTreatmentName() {
		return treatmentName;
	}

	public void setTreatmentName(String treatmentName) {
		this.treatmentName = treatmentName;
	}

}
