package com.cs.remote.service;

import java.util.Date;

import javax.naming.NamingException;

import com.cs.bo.ClaimBo;
import com.cs.util.UhgClaimServiceLocator;
import com.ucs.bo.DiagnosticReportBo;
import com.ucs.bo.PatientAdmissionBo;
import com.ucs.dto.ClaimForm;
import com.ucs.facade.CashlessClaimEjbRemote;

public class CashlessClaimService {
	public String applyCashlessClaim(ClaimBo bo) throws NamingException {
		ClaimForm claimForm = null;
		PatientAdmissionBo patientAdmission = null;
		DiagnosticReportBo report = null;
		String claimNo = null;
		CashlessClaimEjbRemote remote = null;
		UhgClaimServiceLocator uhgClaimServiceLocator = null;

		patientAdmission = new PatientAdmissionBo();
		patientAdmission.setAdmissionNo(bo.getAdmissionNo());
		patientAdmission.setPatientName(bo.getPatientName());
		patientAdmission.setAdmissionDate(bo.getAdmissionDate());
		patientAdmission.setHospitalName(bo.getHospitalName());
		patientAdmission.setCostPerDay(bo.getCostPerDay());
		patientAdmission.setRoomType(bo.getRoomType());

		report = new DiagnosticReportBo();
		report.setReportName(bo.getDiagnosticReportName());

		claimForm = new ClaimForm();
		claimForm.setPolicyNo(bo.getPolicyNo());
		claimForm.setPatientAdmission(patientAdmission);
		claimForm.setDiagnosticReport(report);
		claimForm.setTreatment(bo.getTreatmentName());

		uhgClaimServiceLocator = new UhgClaimServiceLocator();
		remote = uhgClaimServiceLocator.lookupCashlessClaimEjb();
		claimNo = remote.applyForCashlessFacility(claimForm);

		return claimNo;
	}
}
