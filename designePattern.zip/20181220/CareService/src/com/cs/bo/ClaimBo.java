package com.cs.bo;

import java.util.Date;

public class ClaimBo {
	protected int policyNo;
	protected int admissionNo;
	protected String hospitalName;
	protected String patientName;
	protected Date admissionDate;
	protected String roomType;
	protected float costPerDay;
	protected String diagnosticReportName;
	protected String treatmentName;

	public int getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(int policyNo) {
		this.policyNo = policyNo;
	}

	public int getAdmissionNo() {
		return admissionNo;
	}

	public void setAdmissionNo(int admissionNo) {
		this.admissionNo = admissionNo;
	}

	public String getHospitalName() {
		return hospitalName;
	}

	public void setHospitalName(String hospitalName) {
		this.hospitalName = hospitalName;
	}

	public String getPatientName() {
		return patientName;
	}

	public void setPatientName(String patientName) {
		this.patientName = patientName;
	}

	public Date getAdmissionDate() {
		return admissionDate;
	}

	public void setAdmissionDate(Date admissionDate) {
		this.admissionDate = admissionDate;
	}

	public String getRoomType() {
		return roomType;
	}

	public void setRoomType(String roomType) {
		this.roomType = roomType;
	}

	public float getCostPerDay() {
		return costPerDay;
	}

	public void setCostPerDay(float costPerDay) {
		this.costPerDay = costPerDay;
	}

	public String getDiagnosticReportName() {
		return diagnosticReportName;
	}

	public void setDiagnosticReportName(String diagnosticReportName) {
		this.diagnosticReportName = diagnosticReportName;
	}

	public String getTreatmentName() {
		return treatmentName;
	}

	public void setTreatmentName(String treatmentName) {
		this.treatmentName = treatmentName;
	}

}
