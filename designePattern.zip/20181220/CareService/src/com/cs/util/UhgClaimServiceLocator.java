package com.cs.util;

import java.util.Hashtable;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import com.ucs.facade.CashlessClaimEjbRemote;

public class UhgClaimServiceLocator {
	public CashlessClaimEjbRemote lookupCashlessClaimEjb() throws NamingException {
		Hashtable<String, Object> ht = new Hashtable<>();
		ht.put(Context.INITIAL_CONTEXT_FACTORY, "weblogic.jndi.WLInitialContextFactory");
		ht.put(Context.PROVIDER_URL, "t3://localhost:7001");
		ht.put(Context.SECURITY_PRINCIPAL, "weblogic");
		ht.put(Context.SECURITY_CREDENTIALS, "welcome1");

		InitialContext ic = new InitialContext(ht);
		CashlessClaimEjbRemote remote = (CashlessClaimEjbRemote) ic
				.lookup("cashlessClaim#com.ucs.facade.CashlessClaimEjbRemote");
		return remote;
	}
}
