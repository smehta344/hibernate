package com.cs.servlet;

import java.io.IOException;
import java.text.ParseException;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cs.delegate.ClaimDelegate;
import com.cs.vo.CashlessClaimVO;

@WebServlet(urlPatterns= {"/applyCashlessClaim"})
public class ApplyCashlessClaimServlet extends HttpServlet {

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		CashlessClaimVO cashlessClaimVO = null;
		ClaimDelegate claimDelegate = null;

		cashlessClaimVO = new CashlessClaimVO();
		cashlessClaimVO.setPolicyNo(req.getParameter("policyNo"));
		cashlessClaimVO.setAdmissionNo(req.getParameter("admissionNo"));
		cashlessClaimVO.setHospitalName(req.getParameter("hospitalName"));
		cashlessClaimVO.setAdmissionDate(req.getParameter("admissionDate"));
		cashlessClaimVO.setPatientName(req.getParameter("patientName"));
		cashlessClaimVO.setRoomType(req.getParameter("roomType"));
		cashlessClaimVO.setCostPerDay(req.getParameter("costPerDay"));
		cashlessClaimVO.setDiagnosticReportName(req.getParameter("report"));
		cashlessClaimVO.setTreatmentName(req.getParameter("treatment"));

		claimDelegate = new ClaimDelegate();
		String claimNo;
		try {
			claimNo = claimDelegate.applyCashlessClaim(cashlessClaimVO);
		} catch (ParseException | NamingException e) {
			throw new ServletException(e);
		}
		req.setAttribute("claimNo", claimNo);
		req.getRequestDispatcher("/claim-info.jsp").forward(req, resp);
	}

}
