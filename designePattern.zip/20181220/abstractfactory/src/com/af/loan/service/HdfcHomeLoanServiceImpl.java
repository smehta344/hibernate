package com.af.loan.service;

public class HdfcHomeLoanServiceImpl implements HomeLoanService {

	@Override
	public void browse() {
		System.out.println("welcome to Hdfc home loans rate of interest starts from :9.25 per annum");
	}

}
