package com.af.loan.service;

public class SBIHomeLoanServiceImpl implements HomeLoanService {

	@Override
	public void browse() {
		System.out.println("welcome to SBI home loans rate of interest starts from :9.25 per annum");
	}

}
