package com.af.loan.service.factory;

import com.af.loan.service.HdfcHomeLoanServiceImpl;
import com.af.loan.service.HomeLoanService;

public class HdfcHomeLoanServiceFactoryImpl extends AbstractHomeLoanServiceFactory {

	@Override
	protected HomeLoanService createHomeLoanService() {
		return new HdfcHomeLoanServiceImpl();
	}

}
