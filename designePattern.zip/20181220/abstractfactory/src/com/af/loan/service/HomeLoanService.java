package com.af.loan.service;

public interface HomeLoanService {
	void browse();
}
