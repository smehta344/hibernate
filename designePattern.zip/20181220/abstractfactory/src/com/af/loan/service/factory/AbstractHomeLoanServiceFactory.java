package com.af.loan.service.factory;

import com.af.loan.service.HomeLoanService;

public abstract class AbstractHomeLoanServiceFactory {
	// abstract factory method
	public static AbstractHomeLoanServiceFactory newInstance(String bankName) {
		AbstractHomeLoanServiceFactory abstractHomeLoanServiceFactory = null;
		if (bankName.equals("sbi")) {
			abstractHomeLoanServiceFactory = new SBIHomeLoanServiceFactoryImpl();
		} else if (bankName.equals("hdfc")) {
			abstractHomeLoanServiceFactory = new HdfcHomeLoanServiceFactoryImpl();
		}
		return abstractHomeLoanServiceFactory;
	}

	public HomeLoanService newHomeLoanService() {
		HomeLoanService homeLoanService = null;

		homeLoanService = createHomeLoanService();
		// apply common instantiation process
		return homeLoanService;
	}

	protected abstract HomeLoanService createHomeLoanService();
}
