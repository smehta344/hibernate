package com.af.loan.service.factory;

import com.af.loan.service.HomeLoanService;
import com.af.loan.service.SBIHomeLoanServiceImpl;

public class SBIHomeLoanServiceFactoryImpl extends AbstractHomeLoanServiceFactory {

	@Override
	protected HomeLoanService createHomeLoanService() {
		return new SBIHomeLoanServiceImpl();
	}

}
