package com.af.client;

public class AFTest {
	public static void main(String[] args) {
		HomeLoans hl = new HomeLoans();
		hl.browse("hdfc");
	}
}
