package com.af.client;

import com.af.loan.service.HomeLoanService;
import com.af.loan.service.factory.AbstractHomeLoanServiceFactory;

public class HomeLoans {
	public void browse(String bankName) {
		AbstractHomeLoanServiceFactory abstractHomeLoanServiceFactory = AbstractHomeLoanServiceFactory
				.newInstance(bankName);
		HomeLoanService homeLoanService = abstractHomeLoanServiceFactory.newHomeLoanService();
		homeLoanService.browse();
	}
}
