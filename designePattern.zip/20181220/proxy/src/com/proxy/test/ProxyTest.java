package com.proxy.test;

import com.proxy.factory.LoanServiceFactory;
import com.proxy.manager.LoanService;
import com.proxy.vo.ApplicationForm;

public class ProxyTest {
	public static void main(String[] args) {
		LoanService loanService = null;
		ApplicationForm applicationForm = null;
		
		applicationForm = new ApplicationForm();
		applicationForm.setApplicationNo("35");
		applicationForm.setApplicantName("joseph");
		applicationForm.setGrossIncome(394035);
		applicationForm.setLoanAmount(200000);
		applicationForm.setLoanType("auto");
		applicationForm.setMobileNo("939893893");
		applicationForm.setOccupation("salaried");
		applicationForm.setTenure(35);
		applicationForm.setChannelNo("ag3930");
		
		loanService = LoanServiceFactory.createLoanService(false, "auto");
		String trackingNo = loanService.logLoanApplication(applicationForm);
		System.out.println("tracking no : " + trackingNo);
	}
}












