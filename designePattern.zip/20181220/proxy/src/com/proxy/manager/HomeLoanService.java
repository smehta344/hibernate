package com.proxy.manager;

import java.util.UUID;

import com.proxy.vo.ApplicationForm;

public class HomeLoanService implements LoanService {

	@Override
	public String logLoanApplication(ApplicationForm applicationForm) {
		System.out.println("received home loan application");
		return UUID.randomUUID().toString();
	}

}
