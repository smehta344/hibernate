package com.proxy.manager;

import com.proxy.vo.ApplicationForm;

public interface LoanService {
	String logLoanApplication(ApplicationForm applicationForm);
}
