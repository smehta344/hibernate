package com.proxy.manager;

import java.util.UUID;

import com.proxy.vo.ApplicationForm;

public class AutomobileLoanService implements LoanService {

	@Override
	public String logLoanApplication(ApplicationForm applicationForm) {
		System.out.println("your automobiles loan application has been received");
		return UUID.randomUUID().toString();
	}

}
