package com.proxy.manager;

import com.proxy.vo.ApplicationForm;

public class AgentLoanService implements LoanService {
	private LoanService loanService;

	public AgentLoanService(LoanService loanService) {
		this.loanService = loanService;
	}

	@Override
	public String logLoanApplication(ApplicationForm applicationForm) {
		String trackingNo = null;

		trackingNo = loanService.logLoanApplication(applicationForm);
		System.out.println("logging channel no : " + applicationForm.getChannelNo() + " with trackingNo : " + trackingNo
				+ "  in agent system");

		return trackingNo;
	}

}
