package com.proxy.factory;

import com.proxy.manager.AgentLoanService;
import com.proxy.manager.AutomobileLoanService;
import com.proxy.manager.HomeLoanService;
import com.proxy.manager.LoanService;

public class LoanServiceFactory {
	public static LoanService createLoanService(boolean agent, String loanType) {
		LoanService loanService = null;

		if (loanType.equals("auto")) {
			loanService = new AutomobileLoanService();
		} else {
			loanService = new HomeLoanService();
		}
		if (agent) {
			loanService = new AgentLoanService(loanService);
		}
		return loanService;
	}
}
