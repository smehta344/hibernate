package com.adpt.pattern;

import com.adpt.service.ComodityExchangeService;

public class Gold22ExchangeService {
	private ComodityExchangeService comodityExchangeService;

	public Gold22ExchangeService() {
		comodityExchangeService = new ComodityExchangeService();
	}

	public double getGoldPrice() {
		double goldPrice = 0.0;
		double gold22Price = 0.0;
		goldPrice = comodityExchangeService.getGoldPrice();

		gold22Price = (goldPrice / 24) * 22;
		return gold22Price;
	}

	public String placeOrder(int grams, double price) {
		String orderNo = null;
		int grams24 = 0;
		double price24 = 0;

		grams24 = (int) ((int) grams * 0.84);
		price24 = ((24f / 22) * 1) * price;

		orderNo = comodityExchangeService.buy(grams24, price24);

		return orderNo;
	}

}










