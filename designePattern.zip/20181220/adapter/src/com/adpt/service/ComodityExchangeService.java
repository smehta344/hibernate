package com.adpt.service;

import java.util.UUID;

public class ComodityExchangeService {
	public double getGoldPrice() {
		return 1023;
	}

	public String buy(int grams, double price) {
		System.out.println("received buy order for grams : " + grams + " price : " + price);
		return UUID.randomUUID().toString();
	}
}
