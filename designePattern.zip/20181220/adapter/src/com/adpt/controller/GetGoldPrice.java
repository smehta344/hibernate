package com.adpt.controller;

import com.adpt.pattern.Gold22ExchangeService;

public class GetGoldPrice {
	public void showGoldPrice() {
		Gold22ExchangeService gold22ExchangeService = null;
		double price = 0;

		gold22ExchangeService = new Gold22ExchangeService();
		price = gold22ExchangeService.getGoldPrice();
		System.out.println("22 carats 1 gram price : " + price);
	}
}
