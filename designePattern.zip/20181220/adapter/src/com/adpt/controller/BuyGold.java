package com.adpt.controller;

import com.adpt.pattern.Gold22ExchangeService;

public class BuyGold {
	public void placeOrder(int grams, double price) {
		Gold22ExchangeService gold22ExchangeService = null;
		String orderNo = null;

		gold22ExchangeService = new Gold22ExchangeService();
		orderNo = gold22ExchangeService.placeOrder(grams, price);
		System.out.println("order no : " + orderNo);
	}
}
