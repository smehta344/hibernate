package com.adpt.test;

import com.adpt.controller.BuyGold;

public class AdpTest {
	public static void main(String[] args) {
		/*GetGoldPrice ggp = new GetGoldPrice();
		ggp.showGoldPrice();*/
		
		BuyGold bg = new BuyGold();
		bg.placeOrder(10, 1023);
	}
}
