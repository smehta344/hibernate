package com.sec.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ServletViewController {
	@RequestMapping("/welcome-anno.htm")
	public String viewController() {
		return "welcome-anno";
	}
}
