package com.foodpanda.resource;

import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.Produces;

import com.foodpanda.dto.FoodItem;
import com.foodpanda.dto.FoodMenu;

@Path("/menu")
public class MenuResource {
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/{foodType}")
	public FoodMenu getFoodItemsByType(@PathParam("foodType") String foodType) {
		List<FoodItem> foodItems = null;
		FoodMenu foodMenu = null;

		foodItems = new ArrayList<>();
		foodItems.add(new FoodItem(1, "Spring rolls", "veg", 300));
		foodItems.add(new FoodItem(1, "Chicken Drum stick", "non-veg", 400));
		foodItems.add(new FoodItem(1, "Noodles", "veg", 200));
		foodItems.add(new FoodItem(1, "Biryani", "non-veg", 600));
		foodItems.add(new FoodItem(1, "Soup", "veg", 100));

		foodMenu = new FoodMenu(foodItems);

		return foodMenu;
	}

}
