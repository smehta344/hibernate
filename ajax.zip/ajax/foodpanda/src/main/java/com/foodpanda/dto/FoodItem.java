package com.foodpanda.dto;

public class FoodItem {
	protected int code;
	protected String itemName;
	protected String foodType;
	protected double price;

	public FoodItem(int code, String itemName, String foodType, double price) {
		super();
		this.code = code;
		this.itemName = itemName;
		this.foodType = foodType;
		this.price = price;
	}

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public String getFoodType() {
		return foodType;
	}

	public void setFoodType(String foodType) {
		this.foodType = foodType;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
