package com.foodpanda.dto;

import java.util.List;

import javax.json.bind.annotation.JsonbAnnotation;

@JsonbAnnotation
public class FoodMenu {
	List<FoodItem> foodItems;

	public FoodMenu(List<FoodItem> foodItems) {
		super();
		this.foodItems = foodItems;
	}

	public List<FoodItem> getFoodItems() {
		return foodItems;
	}

	public void setFoodItems(List<FoodItem> foodItems) {
		this.foodItems = foodItems;
	}

}
