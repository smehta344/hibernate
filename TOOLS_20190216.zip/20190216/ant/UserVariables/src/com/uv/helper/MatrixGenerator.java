package com.uv.helper;

import java.util.Random;

public class MatrixGenerator {

	public int[][] generate(int rows, int cols) {
		int[][] matrix = null;
		Random random = null;

		random = new Random(100);
		matrix = new int[rows][cols];
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				matrix[i][j] = random.nextInt(100);
			}
		}

		return matrix;
	}

}
