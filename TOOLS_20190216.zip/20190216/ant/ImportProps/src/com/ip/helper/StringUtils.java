package com.ip.helper;

public class StringUtils {

	public String reverse(String in) {
		StringBuffer ni = null;

		ni = new StringBuffer();
		for (int i = in.length() - 1; i >= 0; i--) {
			ni.append(in.charAt(i));
		}

		return ni.toString();
	}
}
