package com.ip.test;

import com.ip.helper.StringUtils;

public class IPTest {
	public static void main(String[] args) {
		StringUtils stringUtils = null;
		String ni = null;

		stringUtils = new StringUtils();
		ni = stringUtils.reverse("java");
		System.out.println(ni);
	}
}
