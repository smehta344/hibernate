package com.eel.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.eel.bo.Customer;
import com.eel.dao.CustomerDao;

public class EELTest {

	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/eel/common/application-context.xml");

		CustomerDao customerDao = context.getBean("customerDao", CustomerDao.class);
		List<Customer> customers = customerDao.getCustomers();
		for (Customer customer : customers) {
			System.out.println(customer);
		}
	}

}
