package com.eel.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.eel.bo.Customer;

public class CustomerDao {
	private final String SQL_GET_CUSTOMERS = "select customer_no, customer_nm from customer";
	private JdbcTemplate jdbcTemplate;

	public CustomerDao(JdbcTemplate jdbcTemplate) {
		super();
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<Customer> getCustomers() {
		return jdbcTemplate.query(SQL_GET_CUSTOMERS, new RowMapper<Customer>() {
			@Override
			public Customer mapRow(ResultSet rs, int rowNo) throws SQLException {
				return new Customer(rs.getInt(1), rs.getString(2));
			}
		});
	}

}
