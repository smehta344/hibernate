package com.ej.test;

import com.ej.helper.FibnocciSeries;

public class EJTest {
	public static void main(String[] args) {
		FibnocciSeries fibnocciSeries = null;

		fibnocciSeries = new FibnocciSeries();
		int series[] = fibnocciSeries.series(10);
		for (int i = 0; i < series.length; i++) {
			System.out.print(series[i] + " ");
		}
	}
}
