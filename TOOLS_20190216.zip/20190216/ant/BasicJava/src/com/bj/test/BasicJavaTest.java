package com.bj.test;

import com.bj.helper.ArrayHelper;

public class BasicJavaTest {
	public static void main(String[] args) {
		ArrayHelper arrayHelper = null;
		int[] inArray = null;
		int element = 0;
		
		inArray = new int[] {3,45,1,5,55,6,24,78,4};
		element = 6;
		arrayHelper = new ArrayHelper();
		int pos = arrayHelper.findElementPos(inArray, element);
		System.out.println("pos : " + pos);
	}
}
