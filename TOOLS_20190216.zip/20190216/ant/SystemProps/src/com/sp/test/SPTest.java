package com.sp.test;

import java.util.Properties;

public class SPTest {
	public static void main(String[] args) {
		Properties props = null;

		props = System.getProperties();
		for (Object key : props.keySet()) {
			System.out.println(key + " : " + props.getProperty((String) key));
		}
	}
}
