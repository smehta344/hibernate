package com.saw.servlet;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class TodayServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Date today = new Date();
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy HH:MM");
		String todays = sdf.format(today);
		req.setAttribute("day", todays);
		req.getRequestDispatcher("/today.jsp").forward(req, resp);
	}
}
