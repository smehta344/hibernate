package com.dt.helper;

public class StringUtils {
	public boolean isPalindrome(String in) {
		boolean flag = true;

		for (int i = 0; i < in.length() / 2; i++) {
			if (in.charAt(i) != in.charAt(in.length() - i - 1)) {
				flag = false;
				break;
			}
		}

		return flag;
	}
}
