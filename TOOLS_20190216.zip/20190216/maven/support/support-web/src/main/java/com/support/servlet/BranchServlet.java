package com.support.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bj.delegate.BranchDelegate;
import com.bj.dto.BranchDto;

public class BranchServlet extends HttpServlet {

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		BranchDelegate branchDelegate = null;
		List<BranchDto> branchDtos = null;

		branchDelegate = new BranchDelegate();
		branchDtos = branchDelegate.getBranches();
		req.setAttribute("branches", branchDtos);
		req.getRequestDispatcher("/branches.jsp").forward(req, resp);
	}

}
