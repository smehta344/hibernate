package com.bj.dto;

public class BranchDto {
	protected int branchNo;
	protected String branchName;

	public BranchDto(int branchNo, String branchName) {
		super();
		this.branchNo = branchNo;
		this.branchName = branchName;
	}

	public int getBranchNo() {
		return branchNo;
	}

	public void setBranchNo(int branchNo) {
		this.branchNo = branchNo;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

}
