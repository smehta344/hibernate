package com.bj.delegate;

import java.util.ArrayList;
import java.util.List;

import com.bj.bo.Branch;
import com.bj.dao.BranchDao;
import com.bj.dto.BranchDto;

public class BranchDelegate {
	public List<BranchDto> getBranches() {
		BranchDao branchDao = null;
		List<Branch> branches = null;
		List<BranchDto> branchDtos = null;

		branchDao = new BranchDao();
		branches = branchDao.getBranches();
		branchDtos = new ArrayList<>();
		for (Branch bo : branches) {
			branchDtos.add(new BranchDto(bo.getBranchNo(), bo.getBranchName()));
		}

		return branchDtos;
	}
}
