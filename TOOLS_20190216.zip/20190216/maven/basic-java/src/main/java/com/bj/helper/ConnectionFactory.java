package com.bj.helper;

import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;

public class ConnectionFactory {
	private static Properties dbProps;

	static {
		try {
			dbProps = new Properties();
			dbProps.load(ConnectionFactory.class.getClassLoader().getResourceAsStream("db.properties"));
			Class.forName(dbProps.getProperty("db.driverClassname"));
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}

	public static Connection getConnection() {
		Connection con = null;
		try {
			con = DriverManager.getConnection(dbProps.getProperty("db.url"), dbProps.getProperty("db.username"),
					dbProps.getProperty("db.password"));
			con.setAutoCommit(false);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return con;
	}
}
