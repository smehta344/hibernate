package com.bj.bo;

public class Branch {
	protected int branchNo;
	protected String branchName;

	public Branch(int branchNo, String branchName) {
		super();
		this.branchNo = branchNo;
		this.branchName = branchName;
	}

	public int getBranchNo() {
		return branchNo;
	}

	public void setBranchNo(int branchNo) {
		this.branchNo = branchNo;
	}

	public String getBranchName() {
		return branchName;
	}

	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}

	@Override
	public String toString() {
		return "Branch [branchNo=" + branchNo + ", branchName=" + branchName + "]";
	}

}
