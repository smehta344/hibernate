package com.bj.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.bj.bo.Branch;
import com.bj.helper.ConnectionFactory;

public class BranchDao {
	private final String SQL_GET_BRANCHES = "select branch_no, branch_nm from branch";

	public List<Branch> getBranches() {
		Connection con = null;
		Statement stmt = null;
		ResultSet rs = null;
		List<Branch> branches = null;

		try {
			con = ConnectionFactory.getConnection();
			stmt = con.createStatement();
			rs = stmt.executeQuery(SQL_GET_BRANCHES);
			branches = new ArrayList<>();
			while (rs.next()) {
				branches.add(new Branch(rs.getInt(1), rs.getString(2)));
			}

		} catch (Exception e) {
			throw new RuntimeException(e);
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (stmt != null) {
				try {
					stmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return branches;
	}
}
