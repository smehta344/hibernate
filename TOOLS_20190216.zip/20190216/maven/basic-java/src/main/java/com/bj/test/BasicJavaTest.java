package com.bj.test;

import java.util.List;

import com.bj.bo.Branch;
import com.bj.dao.BranchDao;

public class BasicJavaTest {
	public static void main(String[] args) {
		BranchDao branchDao = null;
		List<Branch> branches = null;

		branchDao = new BranchDao();
		branches = branchDao.getBranches();
		for (Branch b : branches) {
			System.out.println(b);
		}
	}
}
