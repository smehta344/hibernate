package tools;

public class PasswordManager {

}
