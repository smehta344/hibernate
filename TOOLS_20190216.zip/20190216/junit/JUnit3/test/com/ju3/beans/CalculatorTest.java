package com.ju3.beans;

import junit.framework.Assert;
import junit.framework.TestCase;

public class CalculatorTest extends TestCase {
	int a;
	int b;
	int expectedSum;
	int expectedSubstract;
	Calculator calculator;

	@Override
	protected void setUp() throws Exception {
		a = 10;
		b = 20;
		expectedSum = 30;
		expectedSubstract = 11;
		calculator = new Calculator();
	}

	public void testAdd() {
		int actualSum = 0;

		actualSum = calculator.add(a, b);
		Assert.assertEquals(expectedSum, actualSum);
	}

	public void testSubstract() {
		int actualSubstract = 0;
		actualSubstract = calculator.substract(a, b);
		Assert.assertEquals(expectedSubstract, actualSubstract);
	}

	@Override
	protected void tearDown() throws Exception {
		calculator = null;
	}

}
