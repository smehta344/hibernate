package com.ar.beans;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ArrayHelper {
	public int[] returnArrayRepeaters(int[] in) {
		Map<Integer, Integer> indexMap = null;
		List<Integer> repeaters = null;
		int[] oRepeaters = null;

		if (in != null && in.length >= 0) {
			indexMap = new HashMap<>();
			for (int n : in) {
				if (indexMap.containsKey(n)) {
					indexMap.put(n, indexMap.get(n) + 1);
				} else {
					indexMap.put(n, 1);
				}
			}
			repeaters = new ArrayList<>();
			for (int n : indexMap.keySet()) {
				if (indexMap.get(n) > 1) {
					repeaters.add(n);
				}
			}
			oRepeaters = new int[repeaters.size()];
			for (int i = 0; i < repeaters.size(); i++) {
				oRepeaters[i] = repeaters.get(i);
			}
		}
		return oRepeaters;
	}
}
