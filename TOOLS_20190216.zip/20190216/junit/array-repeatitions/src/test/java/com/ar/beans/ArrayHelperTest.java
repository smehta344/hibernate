package com.ar.beans;

import org.junit.After;
import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

public class ArrayHelperTest {
	int[] inArray;
	int[] inArrayEmpty;
	int[] inArrayOneElement;
	int[] inArraySameElement;
	int[] inArrayNegative;

	int[] expectedArray;
	int[] expectedArrayEmpty;
	int[] expectedArrayOneElement;
	int[] expectedArraySameElement;
	int[] expectedArrayNegative;
	ArrayHelper arrayHelper;

	@Before
	public void setUp() {
		inArray = new int[] { 10, 11, 13, 10, 32, 14, 11 };
		inArrayEmpty = new int[0];
		inArrayOneElement = new int[] { 10 };
		inArraySameElement = new int[] { 2, 2, 2, 2, 2, 2, 2, 2, 2 };
		inArrayNegative = new int[] { -1, -2, -1, -3, -5, -23, -98 };

		expectedArray = new int[0];
		expectedArrayEmpty = new int[0];
		expectedArray = new int[] { 10, 11 };
		expectedArrayOneElement = new int[0];
		expectedArraySameElement = new int[] { 2 };
		expectedArrayNegative = new int[] { -1 };

		arrayHelper = new ArrayHelper();
	}

	@Test
	public void testReturnArrayRepeaters() {
		int[] actualArray = null;

		actualArray = arrayHelper.returnArrayRepeaters(inArray);
		assertArrayEquals(expectedArray, actualArray);
	}

	@Test
	public void testReturnArrayRepeatersWithEmptyArray() {
		int[] actualArray = null;

		actualArray = arrayHelper.returnArrayRepeaters(inArrayEmpty);
		assertArrayEquals(expectedArrayEmpty, actualArray);
	}

	@Test
	public void testReturnArrayRepeatersWithNullArray() {
		int[] actualArray = null;
		actualArray = arrayHelper.returnArrayRepeaters(null);
		assertArrayEquals(null, actualArray);
	}

	@Test
	public void testReturnArrayRepeatersWithOneElementArray() {
		int[] actualArray = null;

		actualArray = arrayHelper.returnArrayRepeaters(inArrayOneElement);
		assertArrayEquals(expectedArrayOneElement, actualArray);
	}

	@Test
	public void testReturnArrayRepeaterWithSameElement() {
		int[] actualArray = null;

		actualArray = arrayHelper.returnArrayRepeaters(inArraySameElement);
		assertArrayEquals(expectedArraySameElement, actualArray);
	}
	
	@Test
	public void testReturnArrayRepeaterWithNegative() {
		int[] actualArray = null;
		
		actualArray = arrayHelper.returnArrayRepeaters(inArrayNegative);
		assertArrayEquals(expectedArrayNegative, actualArray);
	}

	@After
	public void tearDown() {
		arrayHelper = null;
	}
}
















