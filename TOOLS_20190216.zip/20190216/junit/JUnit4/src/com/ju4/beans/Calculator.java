package com.ju4.beans;

public class Calculator {
	public int add(int a, int b) {
		return a + b;
	}

	public int substract(int a, int b) {
		return b - a;
	}
}
