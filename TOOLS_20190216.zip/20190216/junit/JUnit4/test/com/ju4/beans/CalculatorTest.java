package com.ju4.beans;

import org.junit.After;
import org.junit.AfterClass;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

public class CalculatorTest {
	int a;
	int b;
	int expectedSum;
	int expectedSubstract;
	Calculator calculator;

	@BeforeClass
	public static void startup() {
		System.out.println("beforeClass()");
	}

	@Before
	public void fixture() {
		System.out.println("fixture()");
		a = 10;
		b = 20;
		expectedSum = 30;
		expectedSubstract = 10;
		calculator = new Calculator();
	}

	@Test
	public void testAdd() {
		int actualSum = 0;

		actualSum = calculator.add(a, b);
		assertEquals(expectedSum, actualSum);
	}

	@Test
	public void testSubstract() {
		int actualSubstract = 0;

		actualSubstract = calculator.substract(a, b);
		assertEquals(expectedSubstract, actualSubstract);
	}

	@After
	public void clean() {
		System.out.println("clean()");
	}

	@AfterClass
	public static void terminate() {
		System.out.println("afterClass()");
	}

}
