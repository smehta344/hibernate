package com.ju5.helper;

public interface Random {
	int nextInteger(int n);
}
