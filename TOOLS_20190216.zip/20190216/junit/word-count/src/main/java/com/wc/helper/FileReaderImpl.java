package com.wc.helper;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.ws.exception.WCFileNotFoundException;
import com.ws.exception.WCFileReaderException;

public class FileReaderImpl implements FileReader {
	public List<String> getWords(final String inFileName) {
		int c = 0;
		File inFile = null;
		String[] tokens = null;
		List<String> words = null;
		StringBuffer buffer = null;

		if (inFileName == null || inFileName.trim().length() == 0) {
			throw new WCFileNotFoundException("FileName is blank");
		}
		inFile = new File(inFileName);

		try (InputStream in = new FileInputStream(inFile)) {
			buffer = new StringBuffer();

			while ((c = in.read()) != -1) {
				buffer.append((char) c);
			}

		} catch (FileNotFoundException e) {
			throw new WCFileNotFoundException("File not found");
		} catch (IOException e) {
			throw new WCFileReaderException("error while reading the file", e);
		}
		tokens = buffer.toString().split(" ");
		if (tokens.length == 1) {
			if (tokens[0].trim().length() == 0) {
				words = new ArrayList<>();
			} else {
				words = Arrays.asList(tokens);
			}
		} else {
			words = Arrays.asList(tokens);
		}
		return words;
	}

}
