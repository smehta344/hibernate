package com.ws.exception;

public class WCException extends RuntimeException {

	public WCException() {
		super();
	}

	public WCException(String message, Throwable cause) {
		super(message, cause);
	}

	public WCException(String message) {
		super(message);
	}

	public WCException(Throwable cause) {
		super(cause);
	}

}
