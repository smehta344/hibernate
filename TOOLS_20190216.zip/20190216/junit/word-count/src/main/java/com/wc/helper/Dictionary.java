package com.wc.helper;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Dictionary {
	private FileReader fileReader;

	public Map<String, Integer> wordOccurrences(String inFileName) {
		List<String> words = null;
		Map<String, Integer> wordMap = null;

		words = fileReader.getWords(inFileName);
		wordMap = new HashMap<>();

		for (String word : words) {
			if (wordMap.containsKey(word) == false) {
				wordMap.put(word, 1);
			} else {
				int c = wordMap.get(word);
				c++;
				wordMap.put(word, c);
			}
		}

		return wordMap;
	}

	public void setFileReader(FileReader fileReader) {
		this.fileReader = fileReader;
	}

}
