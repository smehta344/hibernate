package com.wc.helper;

import java.util.List;

public interface FileReader {
	List<String> getWords(final String inFileName);
}
