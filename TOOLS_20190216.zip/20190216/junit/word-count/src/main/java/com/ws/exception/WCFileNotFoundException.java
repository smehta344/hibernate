package com.ws.exception;

public class WCFileNotFoundException extends WCException {

	public WCFileNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public WCFileNotFoundException(String message) {
		super(message);
	}

	public WCFileNotFoundException(Throwable cause) {
		super(cause);
	}

}
