package com.ws.exception;

public class WCFileReaderException extends WCException {

	public WCFileReaderException(String message, Throwable cause) {
		super(message, cause);
	}

	public WCFileReaderException(String message) {
		super(message);
	}

}
