package com.wc.helper;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.easymock.EasyMock;
import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class DictionaryTest {
	protected Dictionary dictionary;
	protected List<String> words;
	protected FileReader fileReader;
	protected Map<String, Integer> expectedWordOccurences;

	@Before
	public void setUp() {
		words = Arrays.asList(new String[] { "Lorem", "ipsum", "semper", "gravida", "fames", "tellus", "lacinia",
				"semper", "Lorem", "facilisis" });
		expectedWordOccurences = new HashMap<>();
		expectedWordOccurences.put("Lorem", 2);
		expectedWordOccurences.put("ipsum", 1);
		expectedWordOccurences.put("semper", 2);
		expectedWordOccurences.put("gravida", 1);
		expectedWordOccurences.put("fames", 1);
		expectedWordOccurences.put("tellus", 1);
		expectedWordOccurences.put("lacinia", 1);
		expectedWordOccurences.put("facilisis", 1);

		fileReader = EasyMock.createMock(FileReader.class);
		EasyMock.expect(fileReader.getWords("sample.txt")).andReturn(words);
		EasyMock.replay(fileReader);

		dictionary = new Dictionary();
		dictionary.setFileReader(fileReader);
	}

	@Test(timeout = 1)
	public void testWordOccurrenceWithData() throws InterruptedException {
		Map<String, Integer> actualData = null;
		int actualCount = 0;
		int expectedCount = 0;
		
		actualData = dictionary.wordOccurrences("sample.txt");
		for (String word : actualData.keySet()) {
			actualCount = actualData.get(word);
			expectedCount = expectedWordOccurences.get(word);
			Assert.assertEquals(expectedCount, actualCount);
		}
	}

	@After
	public void teardown() {
		fileReader = null;
		dictionary = null;
	}

}
