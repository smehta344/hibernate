package com.wc.helper;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Ignore;
import org.junit.Test;

import com.ws.exception.WCFileNotFoundException;

public class FileReaderTest {
	protected FileReaderImpl fileReader;
	protected String testWordData;
	protected String testOneWordData;
	protected String testNoData;

	protected String testWordDataFileName;
	protected String testOneWordDataFileName;
	protected String testNoDataFileName;
	protected String baseDirectory;

	protected List<String> expectedWordWithData;
	protected List<String> expectedOneWordData;
	protected List<String> expectedNoWordData;

	@Before
	public void setup() {
		testWordData = "Lorem ipsum semper gravida fames tellus lacinia quis porttitor facilisis";
		testOneWordData = "Lorem";
		testNoData = "";

		baseDirectory = "d:\\";
		testWordDataFileName = "word-file.txt";
		testOneWordDataFileName = "on-word.txt";
		testNoDataFileName = "no-data.txt";

		writeToFile(testWordDataFileName, baseDirectory, testWordData);
		writeToFile(testOneWordDataFileName, baseDirectory, testOneWordData);
		writeToFile(testNoDataFileName, baseDirectory, testNoData);

		expectedWordWithData = Arrays.asList(new String[] { "Lorem", "ipsum", "semper", "gravida", "fames", "tellus",
				"lacinia", "quis", "porttitor", "facilisis" });
		expectedOneWordData = Arrays.asList(new String[] { "Lorem" });
		expectedNoWordData = new ArrayList<>();

		fileReader = new FileReaderImpl();
	}

	@Test
	public void testGetWordsWithData() {
		List<String> actualWordData = null;

		actualWordData = fileReader.getWords(baseDirectory + testWordDataFileName);
		Assert.assertArrayEquals(expectedWordWithData.toArray(), actualWordData.toArray());
	}

	@Test
	@Ignore
	public void testGetWordsWithOneWord() {
		List<String> actualWordData = null;

		actualWordData = fileReader.getWords(baseDirectory + testOneWordDataFileName);
		Assert.assertArrayEquals(expectedOneWordData.toArray(), actualWordData.toArray());
	}

	@Test
	public void testGetWordsWithNoData() {
		List<String> actualWordData = null;

		actualWordData = fileReader.getWords(baseDirectory + testNoDataFileName);
		Assert.assertArrayEquals(expectedNoWordData.toArray(), actualWordData.toArray());
	}

	@Test(expected = WCFileNotFoundException.class)
	public void testGetWordsWithNoFileForException() {
		fileReader.getWords(baseDirectory + "nofile.txt");

		/*
		 * try { fileReader.getWords(baseDirectory + "nofile.txt");
		 * Assert.assertTrue(false); } catch (WCFileNotFoundException e) {
		 * Assert.assertTrue(true); }
		 */
	}

	@After
	public void teardown() {
		deleteFile(testWordDataFileName, baseDirectory);
		deleteFile(testOneWordDataFileName, baseDirectory);
		deleteFile(testNoDataFileName, baseDirectory);
	}

	private void writeToFile(String fileName, String path, String data) {
		File oFile = null;

		oFile = new File(path + fileName);
		try (FileOutputStream fos = new FileOutputStream(oFile)) {
			fos.write(data.getBytes());
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	private void deleteFile(String fileName, String path) {
		File file = null;

		file = new File(path + fileName);
		if (file.exists() == true) {
			file.delete();
		}
	}

}
