package com.wc.helper;

import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ FileReaderTest.class, DictionaryTest.class })
public class WordCountSuite {

}
