package com.wc.helper;

import java.util.Arrays;
import java.util.Collection;

import org.junit.After;
import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.junit.runners.Parameterized;
import org.junit.runners.Parameterized.Parameters;

@RunWith(Parameterized.class)
public class CalculatorTest {
	private int a;
	private int b;
	private int expectedSum;
	private Calculator calculator;

	public CalculatorTest(int a, int b, int expectedSum) {
		this.a = a;
		this.b = b;
		this.expectedSum = expectedSum;

	}

	@Parameters
	public static Collection<Integer[]> getParameters() {
		return Arrays.asList(new Integer[][] { { 10, 20, 30 }, { -10, -20, -30 }, { 10, -10, 0 } });
	}

	@Before
	public void setup() {
		calculator = new Calculator();
	}

	@Test
	public void testAdd() {
		int actualSum = 0;
		actualSum = calculator.add(a, b);
		Assert.assertEquals(expectedSum, actualSum);
	}

	@After
	public void teardown() {
		calculator = null;
	}
}
