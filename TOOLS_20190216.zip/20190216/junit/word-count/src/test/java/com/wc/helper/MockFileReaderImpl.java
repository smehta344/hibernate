package com.wc.helper;

import java.util.List;

public class MockFileReaderImpl implements FileReader {
	private List<String> words;

	public MockFileReaderImpl(List<String> words) {
		this.words = words;
	}

	@Override
	public List<String> getWords(String inFileName) {
		return words;
	}

}
