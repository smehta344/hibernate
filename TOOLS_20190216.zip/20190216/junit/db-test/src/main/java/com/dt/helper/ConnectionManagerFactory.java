package com.dt.helper;

public interface ConnectionManagerFactory {
	ConnectionManager getConnectionManager();
}