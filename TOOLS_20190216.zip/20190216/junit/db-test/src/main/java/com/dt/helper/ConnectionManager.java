package com.dt.helper;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import com.dt.exception.ConfigFileNotFoundException;
import com.dt.exception.DTException;
import com.dt.exception.DataAccessException;

public class ConnectionManager {
	private Properties dbProps;

	public ConnectionManager(String propsFile) {
		try {
			dbProps = new Properties();
			dbProps.load(ConnectionManager.class.getClassLoader().getResourceAsStream(propsFile));
			Class.forName(dbProps.getProperty("db.driverClassname"));
		} catch (IOException e) {
			throw new ConfigFileNotFoundException(propsFile + " not found", e);
		} catch (ClassNotFoundException e) {
			throw new DTException("driver Classname not found");
		}
	}

	public Connection getConnection() {
		Connection con = null;

		try {
			con = DriverManager.getConnection(dbProps.getProperty("db.url"), dbProps.getProperty("db.username"),
					dbProps.getProperty("db.password"));
			con.setAutoCommit(false);
		} catch (SQLException e) {
			throw new DataAccessException("unable to create connection", e);
		}

		return con;
	}
}
