package com.dt.exception;

public class ConfigFileNotFoundException extends DTException {

	public ConfigFileNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

}
