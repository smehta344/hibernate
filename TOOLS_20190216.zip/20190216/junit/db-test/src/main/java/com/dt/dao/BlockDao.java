package com.dt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.dt.bo.BlockBo;
import com.dt.exception.DataAccessException;
import com.dt.helper.ConnectionManager;
import com.dt.helper.ConnectionManagerFactory;

public class BlockDao {
	private final String SQL_GET_BLOCKS_BETWEEN_CAPACITY = "select block_no, block_nm, capacity, zone from blocks where capacity between ? and ?";
	private ConnectionManagerFactory connectionManagerFactory;

	public List<BlockBo> getBlocksBetweenCapacity(int minCapacity, int maxCapacity) {
		ConnectionManager connectionManager = null;
		PreparedStatement pstmt = null;
		List<BlockBo> blocks = null;
		Connection con = null;
		ResultSet rs = null;

		connectionManager = connectionManagerFactory.getConnectionManager();
		con = connectionManager.getConnection();
		try {
			pstmt = con.prepareStatement(SQL_GET_BLOCKS_BETWEEN_CAPACITY);
			pstmt.setInt(1, minCapacity);
			pstmt.setInt(2, maxCapacity);
			rs = pstmt.executeQuery();
			blocks = new ArrayList<>();
			while (rs.next()) {
				blocks.add(new BlockBo(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4)));
			}

		} catch (SQLException e) {
			throw new DataAccessException("unable to read block data");
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

		return blocks;
	}

	public void setConnectionManagerFactory(ConnectionManagerFactory connectionManagerFactory) {
		this.connectionManagerFactory = connectionManagerFactory;
	}

}
