package com.dt.exception;

public class DTException extends RuntimeException {

	public DTException(String message, Throwable cause) {
		super(message, cause);
	}

	public DTException(String message) {
		super(message);
	}

	public DTException(Throwable cause) {
		super(cause);
	}

}
