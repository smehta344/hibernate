package com.dt.bo;

public class BlockBo {
	protected int blockNo;
	protected String blockName;
	protected int capacity;
	protected String zone;

	public BlockBo(int blockNo, String blockName, int capacity, String zone) {
		super();
		this.blockNo = blockNo;
		this.blockName = blockName;
		this.capacity = capacity;
		this.zone = zone;
	}

	public int getBlockNo() {
		return blockNo;
	}

	public void setBlockNo(int blockNo) {
		this.blockNo = blockNo;
	}

	public String getBlockName() {
		return blockName;
	}

	public void setBlockName(String blockName) {
		this.blockName = blockName;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((blockName == null) ? 0 : blockName.hashCode());
		result = prime * result + blockNo;
		result = prime * result + capacity;
		result = prime * result + ((zone == null) ? 0 : zone.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		BlockBo other = (BlockBo) obj;
		if (blockName == null) {
			if (other.blockName != null)
				return false;
		} else if (!blockName.equals(other.blockName))
			return false;
		if (blockNo != other.blockNo)
			return false;
		if (capacity != other.capacity)
			return false;
		if (zone == null) {
			if (other.zone != null)
				return false;
		} else if (!zone.equals(other.zone))
			return false;
		return true;
	}

}
