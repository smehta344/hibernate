package com.dt.helper;

public class DefaultConnectionManagerFactory implements ConnectionManagerFactory {
	private String propsFile;
	private static ConnectionManager connectionManager;

	public DefaultConnectionManagerFactory(String propsFile) {
		this.propsFile = propsFile;
	}

	@Override
	public ConnectionManager getConnectionManager() {
		if (connectionManager == null) {
			connectionManager = new ConnectionManager(propsFile);
		}
		return connectionManager;
	}

}
