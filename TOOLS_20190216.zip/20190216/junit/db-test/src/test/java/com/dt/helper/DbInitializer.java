package com.dt.helper;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

public class DbInitializer {
	public static void execute(String schemaFile) {
		int c = 0;
		Properties props = null;
		Connection con = null;
		Statement stmt = null;
		String sql = null;
		StringBuffer buffer = null;

		try (InputStream in = DbInitializer.class.getClassLoader().getResourceAsStream(schemaFile)) {
			buffer = new StringBuffer();
			props = new Properties();

			while ((c = in.read()) != -1) {
				buffer.append((char) c);
			}
			sql = buffer.toString();

			props.load(DbInitializer.class.getClassLoader().getResourceAsStream("dbinit.properties"));
			Class.forName(props.getProperty("db.driverClassname"));
			con = DriverManager.getConnection(props.getProperty("db.url"), props.getProperty("db.username"),
					props.getProperty("db.password"));
			stmt = con.createStatement();

			stmt.execute(sql);

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}
}
