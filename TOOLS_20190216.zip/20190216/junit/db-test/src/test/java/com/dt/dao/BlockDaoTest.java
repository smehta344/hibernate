package com.dt.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.dt.bo.BlockBo;
import com.dt.helper.ConnectionManager;
import com.dt.helper.ConnectionManagerFactory;
import com.dt.helper.DbInitializer;
import com.dt.helper.DefaultConnectionManagerFactory;

public class BlockDaoTest {
	protected BlockDao blockDao;
	protected List<BlockBo> blocks;
	protected List<BlockBo> expectedBlocks;
	protected ConnectionManager connectionManager;
	protected ConnectionManagerFactory connectionManagerFactory;

	@BeforeClass
	public static void startup() {
		DbInitializer.execute("create-schema.sql");
	}

	@Before
	public void setup() throws SQLException {
		String sql = null;
		Connection con = null;
		PreparedStatement pstmt = null;

		blocks = new ArrayList<>();
		blocks.add(new BlockBo(1, "Marine", 200, "east"));
		blocks.add(new BlockBo(2, "Gold", 100, "east"));
		blocks.add(new BlockBo(3, "Tulip", 150, "west"));
		blocks.add(new BlockBo(4, "Rose", 90, "south"));
		blocks.add(new BlockBo(5, "Silver", 301, "east"));
		blocks.add(new BlockBo(6, "Diamond", 235, "north"));
		blocks.add(new BlockBo(7, "Platinum", 209, "west"));

		connectionManagerFactory = new DefaultConnectionManagerFactory("dbtest.properties");
		connectionManager = connectionManagerFactory.getConnectionManager();

		sql = "insert into blocks(block_no, block_nm, capacity, zone) values(?,?,?,?)";

		con = connectionManager.getConnection();
		pstmt = con.prepareStatement(sql);
		for (BlockBo bo : blocks) {
			pstmt.setInt(1, bo.getBlockNo());
			pstmt.setString(2, bo.getBlockName());
			pstmt.setInt(3, bo.getCapacity());
			pstmt.setString(4, bo.getZone());
			pstmt.executeUpdate();
		}
		con.commit();
		pstmt.close();
		con.close();
		
		blockDao = new BlockDao();
		blockDao.setConnectionManagerFactory(connectionManagerFactory);
		
		expectedBlocks = Arrays.asList(new BlockBo[] { new BlockBo(1, "Marine", 200, "east"),
				new BlockBo(2, "Gold", 100, "east"), new BlockBo(3, "Tulip", 150, "west") });
	}

	@Test
	public void testGetBlocksBetweenCapacity() {
		List<BlockBo> actualBlocks = null;

		actualBlocks = blockDao.getBlocksBetweenCapacity(100, 200);
		Assert.assertArrayEquals(expectedBlocks.toArray(), actualBlocks.toArray());
	}

	@After
	public void teardown() throws SQLException {
		String sql = null;
		Connection con = null;
		Statement stmt = null;

		connectionManagerFactory = new DefaultConnectionManagerFactory("dbtest.properties");
		connectionManager = connectionManagerFactory.getConnectionManager();

		con = connectionManager.getConnection();
		sql = "delete from blocks";
		stmt = con.createStatement();
		stmt.executeUpdate(sql);
		con.commit();
		con.close();
	}

	@AfterClass
	public static void shutdown() {
		DbInitializer.execute("drop-schema.sql");
	}

}
