USE `mygatetest`;
DROP TABLE IF EXISTS `blocks`;
DROP DATABASE IF EXISTS `mygatetest`;