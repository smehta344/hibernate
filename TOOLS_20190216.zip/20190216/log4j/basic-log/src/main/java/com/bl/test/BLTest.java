package com.bl.test;

import org.apache.log4j.BasicConfigurator;

import com.bl.helper.ArrayHelper;

public class BLTest {
	public static void main(String[] args) {
		// BasicConfigurator.configure();
		
		ArrayHelper arrayHelper = new ArrayHelper();
		int[] in = new int[] { 10, 3, 4, 6, 7 };
		int elem = 6;

		int index = arrayHelper.findElement(in, elem);
		System.out.println(index);

	}
}
