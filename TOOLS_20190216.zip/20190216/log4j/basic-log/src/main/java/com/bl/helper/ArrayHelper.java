package com.bl.helper;

import org.apache.log4j.Logger;

public class ArrayHelper {
	private static final Logger logger = Logger.getLogger(ArrayHelper.class);

	public int findElement(int[] in, int elem) {
		int index = -1;

		logger.debug("total elements in array : " + in.length);
		logger.debug("element to be found : " + elem);

		for (int i = 0; i < in.length; i++) {
			if (in[i] == elem) {
				index = i;
				logger.info("element found at index location : " + index);
				break;
			}
		}
		logger.debug("findElement method is returning index : " + index);
		return index;
	}
}
