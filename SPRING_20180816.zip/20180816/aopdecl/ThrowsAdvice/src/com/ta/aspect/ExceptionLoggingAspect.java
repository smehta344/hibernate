package com.ta.aspect;

import org.aspectj.lang.JoinPoint;

public class ExceptionLoggingAspect {
	public void logException(JoinPoint jp, IllegalArgumentException iae) {
		System.out.println("exception message : " + iae.getMessage());
	}
}
