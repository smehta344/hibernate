package com.ara.aspect;

import org.aspectj.lang.JoinPoint;

public class KeyValidatorAspect {
	public void validate(JoinPoint jp, Object ret) throws Throwable {
		if ((Integer) ret <= 0) {
			throw new Exception("weak key");
		}
	}
}
