package com.mba.aspect;

import org.aspectj.lang.JoinPoint;

import com.mba.security.helper.SecurityHelper;

public class SecurityAspect {
	private SecurityHelper securityHelper;

	public void audit(JoinPoint jp) {
		System.out.println(
				securityHelper.getLoggedInUser() + " is accessing the method : " + jp.getSignature().getName());
	}

	public void checkAuthentication(JoinPoint jp) throws Throwable {
		if (securityHelper.authenticate() == false) {
			throw new IllegalAccessException("invalid un/pwd");
		}
	}

	public void setSecurityHelper(SecurityHelper securityHelper) {
		this.securityHelper = securityHelper;
	}

}
