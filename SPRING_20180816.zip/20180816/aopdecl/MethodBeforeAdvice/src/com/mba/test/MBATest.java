package com.mba.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.mba.beans.LoanManager;
import com.mba.security.helper.SecurityHelper;

public class MBATest {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/mba/common/application-context.xml");
		SecurityHelper securityHelper = context.getBean("securityHelper", SecurityHelper.class);
		LoanManager lm = context.getBean("loanManager", LoanManager.class);
		
		securityHelper.login("john", "welcome1");
		
		boolean approved = lm.approveLoan(39);
		System.out.println("approved ? : " + approved);
		securityHelper.logout();
	}
}
