package com.mba.security.helper;

import com.mba.security.beans.User;

public class SecurityHelper {
	private static SecurityHelper instance = new SecurityHelper();
	private ThreadLocal<User> localUsers;

	private SecurityHelper() {
		localUsers = new ThreadLocal<>();
	}

	public static SecurityHelper getInstance() {
		return instance;
	}

	public void login(String un, String pwd) {
		User user = null;
		user = new User(un, pwd);
		localUsers.set(user);
	}

	public boolean authenticate() {
		User user = null;
		user = localUsers.get();
		if (user != null) {
			if (user.getUn().equals("john") && user.getPwd().equals("welcome1")) {
				return true;
			}
		}
		return false;
	}

	public void logout() {
		localUsers.set(null);
	}

	public String getLoggedInUser() {
		User user = null;
		user = localUsers.get();
		if (user != null) {
			return user.getUn();
		}
		return null;
	}
}
