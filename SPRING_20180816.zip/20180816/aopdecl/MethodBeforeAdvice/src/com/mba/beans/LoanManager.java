package com.mba.beans;

public class LoanManager {
	public boolean approveLoan(long loanNo) {
		System.out.println("in approveLoan()");
		return true;
	}
}
