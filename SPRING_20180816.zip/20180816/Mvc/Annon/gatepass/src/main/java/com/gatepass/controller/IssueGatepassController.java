package com.gatepass.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gatepass.dto.BlockDto;
import com.gatepass.dto.GatepassDto;
import com.gatepass.form.GatepassForm;
import com.gatepass.service.BlockService;
import com.gatepass.service.GatepassService;
import com.gatepass.validator.GatepassValidator;

@Controller
@RequestMapping("/issueGatepass.htm")
public class IssueGatepassController {
	@Autowired
	private BlockService blockService;

	@Autowired
	private GatepassService gatepassService;

	@Autowired
	private GatepassValidator gatepassValidator;

	@GetMapping
	public String showIssueGatepassForm(Model model) {
		GatepassForm gatepassForm = null;

		gatepassForm = new GatepassForm();
		model.addAttribute("gatepassForm", gatepassForm);

		return "issue-gatepass";
	}

	@SuppressWarnings("deprecation")
	@PostMapping
	public String createGatePass(@ModelAttribute("gatepassForm") GatepassForm gatepassForm, BindingResult errors,
			Model model) {
		int gatepassNo = 0;
		GatepassDto gatepassDto = null;
		Date estimatedEntryDate = null;

		if (gatepassValidator.supports(GatepassForm.class)) {
			gatepassValidator.validate(gatepassForm, errors);
			if (errors.hasErrors()) {
				return "issue-gatepass";
			}
		}

		estimatedEntryDate = new Date(gatepassForm.getEstimatedEntryDate().getMonth(),
				gatepassForm.getEstimatedEntryDate().getDay(), gatepassForm.getEstimatedEntryDate().getHours(),
				gatepassForm.getEstimatedHours(), gatepassForm.getEstimatedMinutes(), 0);

		gatepassDto = new GatepassDto(0, gatepassForm.getVisitorName(), gatepassForm.getMobileNo(),
				gatepassForm.getEmailAddress(), estimatedEntryDate, gatepassForm.getWhomToMeet(),
				gatepassForm.getPurpose(), gatepassForm.getFlatNo(), gatepassForm.getBlockNo(),
				gatepassForm.getStatus());
		gatepassNo = gatepassService.issueGatePass(gatepassDto);
		gatepassDto.setGatePassNo(gatepassNo);

		model.addAttribute("gatepass", gatepassDto);

		return "gatepass-details";
	}

	@ModelAttribute("blocks")
	public List<BlockDto> populateBlocks() {
		List<BlockDto> blocks = null;
		blocks = blockService.getBlocks();
		return blocks;
	}

}
