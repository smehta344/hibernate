package com.gatepass.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.stereotype.Service;

import com.gatepass.bo.GatepassBo;
import com.gatepass.bo.SearchGatepassBo;
import com.gatepass.dao.GatepassDao;
import com.gatepass.dto.GatepassDto;
import com.gatepass.dto.SearchGatepassDto;
import com.gatepass.exception.GatepassNotFoundException;

@Service
public class GatepassService {
	@Autowired
	private GatepassDao gatepassDao;

	public int issueGatePass(GatepassDto gatepassDto) {
		GatepassBo gatepassBo = null;
		int gatepassNo = 0;

		gatepassBo = new GatepassBo();
		gatepassBo.setVisitorName(gatepassDto.getVisitorName());
		gatepassBo.setEmailAddress(gatepassDto.getEmailAddress());
		gatepassBo.setMobileNo(gatepassDto.getMobileNo());
		gatepassBo.setEstimatedEntryTime(gatepassDto.getEstimatedEntityTime());
		gatepassBo.setPurpose(gatepassDto.getPurpose());
		gatepassBo.setWhomToMeet(gatepassDto.getWhomToMeet());
		gatepassBo.setFlatNo(gatepassDto.getFlatNo());
		gatepassBo.setBlockNo(gatepassDto.getBlockNo());
		gatepassBo.setStatus(gatepassDto.getStatus());

		gatepassNo = gatepassDao.saveGatepass(gatepassBo);
		return gatepassNo;
	}

	public GatepassDto getGatepass(int gatepassNo) {
		GatepassDto gatepassDto = null;
		GatepassBo gatepassBo = null;

		try {
			gatepassBo = gatepassDao.getGatePass(gatepassNo);
		} catch (EmptyResultDataAccessException e) {
			throw new GatepassNotFoundException("gatepass not found", e);
		}
		gatepassDto = mapGatepassBoToGatepassDto(gatepassBo);

		return gatepassDto;
	}

	public List<GatepassDto> searchGatepass(SearchGatepassDto searchGatepassDto) {
		List<GatepassDto> gatepassDtos = null;
		List<GatepassBo> gatepassBos = null;
		SearchGatepassBo searchGatepassBo = null;

		searchGatepassBo = new SearchGatepassBo();
		searchGatepassBo.setGatePassNo(searchGatepassDto.getGatepassNo());
		searchGatepassBo.setFlatNo(searchGatepassDto.getFlatNo());
		searchGatepassBo.setBlockNo(searchGatepassDto.getBlockNo());
		searchGatepassBo.setFromDate(searchGatepassDto.getFromDate());
		searchGatepassBo.setToEnd(searchGatepassDto.getToEndDate());
		searchGatepassBo.setStatus(searchGatepassDto.getStatus());

		gatepassBos = gatepassDao.searchGatePasses(searchGatepassBo);
		gatepassDtos = new ArrayList<>();
		for (GatepassBo bo : gatepassBos) {
			gatepassDtos.add(mapGatepassBoToGatepassDto(bo));
		}
		return gatepassDtos;
	}

	private GatepassDto mapGatepassBoToGatepassDto(GatepassBo gatepassBo) {
		GatepassDto gatepassDto = null;

		gatepassDto = new GatepassDto(gatepassBo.getGatePassNo(), gatepassBo.getVisitorName(), gatepassBo.getMobileNo(),
				gatepassBo.getEmailAddress(), gatepassBo.getEstimatedEntryTime(), gatepassBo.getWhomToMeet(),
				gatepassBo.getPurpose(), gatepassBo.getFlatNo(), gatepassBo.getBlockNo(), gatepassBo.getStatus());
		return gatepassDto;
	}
}
