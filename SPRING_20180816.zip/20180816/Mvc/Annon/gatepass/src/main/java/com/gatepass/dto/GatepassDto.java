package com.gatepass.dto;

import java.util.Date;

public class GatepassDto {
	protected int gatePassNo;
	protected String visitorName;
	protected String mobileNo;
	protected String emailAddress;
	protected Date estimatedEntityTime;
	protected String whomToMeet;
	protected String purpose;
	protected int flatNo;
	protected int blockNo;
	protected String status;

	public GatepassDto(int gatePassNo, String visitorName, String mobileNo, String emailAddress,
			Date estimatedEntityTime, String whomToMeet, String purpose, int flatNo, int blockNo, String status) {
		super();
		this.gatePassNo = gatePassNo;
		this.visitorName = visitorName;
		this.mobileNo = mobileNo;
		this.emailAddress = emailAddress;
		this.estimatedEntityTime = estimatedEntityTime;
		this.whomToMeet = whomToMeet;
		this.purpose = purpose;
		this.flatNo = flatNo;
		this.blockNo = blockNo;
		this.status = status;
	}

	public int getGatePassNo() {
		return gatePassNo;
	}

	public void setGatePassNo(int gatePassNo) {
		this.gatePassNo = gatePassNo;
	}

	public String getVisitorName() {
		return visitorName;
	}

	public void setVisitorName(String visitorName) {
		this.visitorName = visitorName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public Date getEstimatedEntityTime() {
		return estimatedEntityTime;
	}

	public void setEstimatedEntityTime(Date estimatedEntityTime) {
		this.estimatedEntityTime = estimatedEntityTime;
	}

	public String getWhomToMeet() {
		return whomToMeet;
	}

	public void setWhomToMeet(String whomToMeet) {
		this.whomToMeet = whomToMeet;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public int getFlatNo() {
		return flatNo;
	}

	public void setFlatNo(int flatNo) {
		this.flatNo = flatNo;
	}

	public int getBlockNo() {
		return blockNo;
	}

	public void setBlockNo(int blockNo) {
		this.blockNo = blockNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
