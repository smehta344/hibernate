package com.gatepass.bo;

import java.io.Serializable;
import java.util.Date;

public class SearchGatepassBo implements Serializable {
	protected int gatePassNo;
	protected int flatNo;
	protected int blockNo;
	protected Date fromDate;
	protected Date toEnd;
	protected String status;

	public int getGatePassNo() {
		return gatePassNo;
	}

	public void setGatePassNo(int gatePassNo) {
		this.gatePassNo = gatePassNo;
	}

	public int getFlatNo() {
		return flatNo;
	}

	public void setFlatNo(int flatNo) {
		this.flatNo = flatNo;
	}

	public int getBlockNo() {
		return blockNo;
	}

	public void setBlockNo(int blockNo) {
		this.blockNo = blockNo;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToEnd() {
		return toEnd;
	}

	public void setToEnd(Date toEnd) {
		this.toEnd = toEnd;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
