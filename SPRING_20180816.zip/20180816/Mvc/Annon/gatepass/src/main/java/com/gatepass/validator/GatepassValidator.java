package com.gatepass.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.gatepass.form.GatepassForm;

@Component
public class GatepassValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return clazz.isAssignableFrom(GatepassForm.class);
	}

	@Override
	public void validate(Object target, Errors errors) {
		GatepassForm form = null;

		form = (GatepassForm) target;
		if (isEmpty(form.getVisitorName()) == true) {
			errors.rejectValue("visitorName", "visitorName.blank");
		}

		if (isEmpty(form.getMobileNo()) == true) {
			errors.rejectValue("mobileNo", "mobileNo.blank");
		}

		if (isEmpty(form.getWhomToMeet()) == true) {
			errors.rejectValue("whomToMeet", "whomToMeet.blank");
		}
		if (isEmpty(form.getPurpose()) == true) {
			errors.rejectValue("purpose", "purpose.blank");
		}
		if (form.getFlatNo() <= 0) {
			errors.rejectValue("flatNo", "flatNo.invalid");
		}

	}

	private boolean isEmpty(String s) {
		if (s == null || s.trim().length() == 0) {
			return true;
		}
		return false;
	}

}
