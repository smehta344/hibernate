package com.gatepass.form;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class SearchGatepassForm {
	protected int gatepassNo;
	protected int flatNo;
	protected int blockNo;
	@DateTimeFormat(pattern = "dd-mm-yyyy")
	protected Date fromDate;
	@DateTimeFormat(pattern = "dd-mm-yyyy")
	protected Date toEndDate;
	protected String status;

	public int getGatepassNo() {
		return gatepassNo;
	}

	public void setGatepassNo(int gatepassNo) {
		this.gatepassNo = gatepassNo;
	}

	public int getFlatNo() {
		return flatNo;
	}

	public void setFlatNo(int flatNo) {
		this.flatNo = flatNo;
	}

	public int getBlockNo() {
		return blockNo;
	}

	public void setBlockNo(int blockNo) {
		this.blockNo = blockNo;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToEndDate() {
		return toEndDate;
	}

	public void setToEndDate(Date toEndDate) {
		this.toEndDate = toEndDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
