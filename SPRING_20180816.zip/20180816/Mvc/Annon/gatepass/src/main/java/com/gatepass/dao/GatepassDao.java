package com.gatepass.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.gatepass.bo.GatepassBo;
import com.gatepass.bo.SearchGatepassBo;

@Repository
public class GatepassDao {
	private final String SQL_INSERT_GATEPASS = "insert into gatepass(visitor_nm, mobile_no, email_address, expected_entry_time, purpose, whom_to_meet, flat_no, block_no, status) values(?,?,?,?,?,?,?,?,?)";
	private final String SQL_GET_GATEPASS = "select gatepass_no, visitor_nm, mobile_no, email_address, expected_entry_time, purpose, whom_to_meet, flat_no, block_no, status from gatepass where gatepass_no = ?";
	private final String SQL_SEARCH_GATEPASS = "select gatepass_no, visitor_nm, mobile_no, email_address, expected_entry_time, purpose, whom_to_meet, flat_no, block_no, status from gatepass where ";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public int saveGatepass(final GatepassBo gatePassBo) {
		int gatePassNo = 0;
		KeyHolder kh = null;

		kh = new GeneratedKeyHolder();
		jdbcTemplate.update(new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				PreparedStatement pstmt = null;

				pstmt = con.prepareStatement(SQL_INSERT_GATEPASS, new String[] { "gatepass_no" });
				pstmt.setString(1, gatePassBo.getVisitorName());
				pstmt.setString(2, gatePassBo.getMobileNo());
				pstmt.setString(3, gatePassBo.getEmailAddress());
				pstmt.setDate(4, new java.sql.Date(gatePassBo.getEstimatedEntryTime().getTime()));
				pstmt.setString(5, gatePassBo.getPurpose());
				pstmt.setString(6, gatePassBo.getWhomToMeet());
				pstmt.setInt(7, gatePassBo.getFlatNo());
				pstmt.setInt(8, gatePassBo.getBlockNo());
				pstmt.setString(9, gatePassBo.getStatus());

				return pstmt;
			}
		}, kh);

		gatePassNo = kh.getKey().intValue();

		return gatePassNo;
	}

	public GatepassBo getGatePass(int gatePassNo) {
		GatepassBo gatepassBo = null;

		gatepassBo = jdbcTemplate.queryForObject(SQL_GET_GATEPASS, new GatepassRowMapper(),
				new Object[] { gatePassNo });

		return gatepassBo;
	}

	public List<GatepassBo> searchGatePasses(final SearchGatepassBo searchGatepassBo) {
		List<GatepassBo> gatepassBos = null;

		final String sql = createQueryForSearchGatePass(searchGatepassBo);
		gatepassBos = jdbcTemplate.query(new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				PreparedStatement pstmt = null;
				int col = 1;

				pstmt = con.prepareStatement(sql);
				if (searchGatepassBo.getGatePassNo() > 0) {
					pstmt.setInt(col, searchGatepassBo.getGatePassNo());
					col++;
				}
				if (searchGatepassBo.getFlatNo() > 0) {
					pstmt.setInt(col, searchGatepassBo.getFlatNo());
					col++;
				}
				if (searchGatepassBo.getBlockNo() > 0) {
					pstmt.setInt(col, searchGatepassBo.getBlockNo());
					col++;
				}
				if (searchGatepassBo.getFromDate() != null && searchGatepassBo.getToEnd() != null) {
					pstmt.setDate(col, new java.sql.Date(searchGatepassBo.getFromDate().getTime()));
					col++;
					pstmt.setDate(col, new java.sql.Date(searchGatepassBo.getToEnd().getTime()));
					col++;
				}
				if (searchGatepassBo.getStatus() != null && searchGatepassBo.getStatus().trim().length() > 0) {
					pstmt.setString(col, searchGatepassBo.getStatus());
				}
				return pstmt;
			}
		}, new GatepassRowMapper());

		return gatepassBos;
	}

	private final class GatepassRowMapper implements RowMapper<GatepassBo> {
		@Override
		public GatepassBo mapRow(ResultSet rs, int rowNum) throws SQLException {
			return new GatepassBo(rs.getInt(1), rs.getString(2), rs.getString(3), rs.getString(4), rs.getDate(5),
					rs.getString(6), rs.getString(7), rs.getInt(8), rs.getInt(9), rs.getString(10));
		}

	}

	private String createQueryForSearchGatePass(SearchGatepassBo bo) {
		String sql = null;

		sql = SQL_SEARCH_GATEPASS;
		if (bo.getGatePassNo() > 0) {
			sql = buildWhereClause(sql, "gatepass_no = ?");
		}
		if (bo.getFlatNo() > 0) {
			sql = buildWhereClause(sql, "flat_no = ?");
		}
		if (bo.getBlockNo() > 0) {
			sql = buildWhereClause(sql, "block_no = ?");
		}
		if (bo.getFromDate() != null && bo.getToEnd() != null) {
			sql = buildWhereClause(sql, "expected_entry_time between ? and ?");
		}
		if (bo.getStatus() != null && bo.getStatus().trim().length() > 0) {
			sql = buildWhereClause(sql, "status = ?");
		}
		return sql;
	}

	private String buildWhereClause(String sql, String clause) {
		boolean whereClause = false;

		whereClause = sql.endsWith("where ");
		return whereClause == true ? sql + " " + clause : sql + " and " + clause;
	}

	public static void main(String[] args) {
		SearchGatepassBo bo = new SearchGatepassBo();
		bo.setBlockNo(323);
		bo.setFlatNo(32);
		bo.setStatus("new");

		String sql = new GatepassDao().createQueryForSearchGatePass(bo);
		System.out.println(sql);
	}
}
