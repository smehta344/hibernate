package com.gatepass.exception;

public class GatepassNotFoundException extends RuntimeException {

	public GatepassNotFoundException() {
		super();
	}

	public GatepassNotFoundException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public GatepassNotFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	public GatepassNotFoundException(String message) {
		super(message);
	}

	public GatepassNotFoundException(Throwable cause) {
		super(cause);
	}

}
