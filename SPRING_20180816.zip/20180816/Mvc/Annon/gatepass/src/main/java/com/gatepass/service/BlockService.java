package com.gatepass.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.gatepass.bo.BlockBo;
import com.gatepass.dao.BlockDao;
import com.gatepass.dto.BlockDto;

@Service
public class BlockService {
	@Autowired
	private BlockDao blockDao;

	public List<BlockDto> getBlocks() {
		List<BlockBo> blockBos = null;
		List<BlockDto> blockDtos = null;

		blockDtos = new ArrayList<>();
		blockBos = blockDao.getBlocks();
		for (BlockBo bo : blockBos) {
			blockDtos.add(new BlockDto(bo.getBlockNo(), bo.getBlockName()));
		}
		return blockDtos;
	}
}
