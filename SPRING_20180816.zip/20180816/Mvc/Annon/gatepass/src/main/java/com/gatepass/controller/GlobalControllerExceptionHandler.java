package com.gatepass.controller;

import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.gatepass.exception.GatepassNotFoundException;

//@ControllerAdvice
public class GlobalControllerExceptionHandler {

	@ExceptionHandler(GatepassNotFoundException.class)
	public String handleGatepassNotFoundException(GatepassNotFoundException e, Model model) {
		System.out.println("global handler");
		model.addAttribute("message", "Gatepass not found");
		return "resource-not-found";
	}

}
