package com.gatepass.form;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

public class GatepassForm {
	protected String visitorName;
	protected String mobileNo;
	protected String emailAddress;
	protected String whomToMeet;
	protected String purpose;
	@DateTimeFormat(pattern = "dd-mm-yyyy")
	protected Date estimatedEntryDate;
	protected int estimatedHours;
	protected int estimatedMinutes;
	protected int flatNo;
	protected int blockNo;
	protected String status;

	public String getVisitorName() {
		return visitorName;
	}

	public void setVisitorName(String visitorName) {
		this.visitorName = visitorName;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getWhomToMeet() {
		return whomToMeet;
	}

	public void setWhomToMeet(String whomToMeet) {
		this.whomToMeet = whomToMeet;
	}

	public String getPurpose() {
		return purpose;
	}

	public void setPurpose(String purpose) {
		this.purpose = purpose;
	}

	public Date getEstimatedEntryDate() {
		return estimatedEntryDate;
	}

	public void setEstimatedEntryDate(Date estimatedEntryDate) {
		this.estimatedEntryDate = estimatedEntryDate;
	}

	public int getEstimatedHours() {
		return estimatedHours;
	}

	public void setEstimatedHours(int estimatedHours) {
		this.estimatedHours = estimatedHours;
	}

	public int getEstimatedMinutes() {
		return estimatedMinutes;
	}

	public void setEstimatedMinutes(int estimatedMinutes) {
		this.estimatedMinutes = estimatedMinutes;
	}

	public int getFlatNo() {
		return flatNo;
	}

	public void setFlatNo(int flatNo) {
		this.flatNo = flatNo;
	}

	public int getBlockNo() {
		return blockNo;
	}

	public void setBlockNo(int blockNo) {
		this.blockNo = blockNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
