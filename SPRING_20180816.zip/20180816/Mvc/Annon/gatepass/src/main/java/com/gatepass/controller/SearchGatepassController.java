package com.gatepass.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gatepass.dto.BlockDto;
import com.gatepass.dto.GatepassDto;
import com.gatepass.dto.SearchGatepassDto;
import com.gatepass.form.SearchGatepassForm;
import com.gatepass.service.BlockService;
import com.gatepass.service.GatepassService;

@Controller
@RequestMapping("/search-gatepass.htm")
public class SearchGatepassController {
	@Autowired
	private BlockService blockService;
	@Autowired
	private GatepassService gatepassService;

	@GetMapping
	public String showSearchGatepassForm(Model model) {
		return "search-gatepass";
	}

	@PostMapping
	public String searchGatepass(@ModelAttribute("searchGatepassForm") SearchGatepassForm searchGatepassForm,
			BindingResult errors, Model model) {
		List<GatepassDto> gatepassDtos = null;
		SearchGatepassDto searchGatepassDto = null;

		searchGatepassDto = new SearchGatepassDto(searchGatepassForm.getGatepassNo(), searchGatepassForm.getFlatNo(),
				searchGatepassForm.getBlockNo(), searchGatepassForm.getFromDate(), searchGatepassForm.getToEndDate(),
				searchGatepassForm.getStatus());
		gatepassDtos = gatepassService.searchGatepass(searchGatepassDto);
		
		model.addAttribute("gatepasses", gatepassDtos);

		return "search-gatepass";
	}

	@ModelAttribute("blocks")
	public List<BlockDto> populateBlocks() {
		return blockService.getBlocks();
	}
}












