package com.gatepass.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.gatepass.bo.BlockBo;

@Repository
public class BlockDao {
	private final String GET_BLOCKS = "select block_no, block_nm from blocks order by block_nm";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<BlockBo> getBlocks() {
		return jdbcTemplate.query(GET_BLOCKS, (rs, rowNum) -> {
			BlockBo blockBo = null;
			blockBo = new BlockBo(rs.getInt(1), rs.getString(2));
			return blockBo;
		});
	}
}
