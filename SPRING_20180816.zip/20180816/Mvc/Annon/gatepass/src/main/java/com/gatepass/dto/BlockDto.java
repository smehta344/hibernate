package com.gatepass.dto;

public class BlockDto {
	protected int blockNo;
	protected String blockName;

	public BlockDto(int blockNo, String blockName) {
		this.blockNo = blockNo;
		this.blockName = blockName;
	}

	public int getBlockNo() {
		return blockNo;
	}

	public void setBlockNo(int blockNo) {
		this.blockNo = blockNo;
	}

	public String getBlockName() {
		return blockName;
	}

	public void setBlockName(String blockName) {
		this.blockName = blockName;
	}

}
