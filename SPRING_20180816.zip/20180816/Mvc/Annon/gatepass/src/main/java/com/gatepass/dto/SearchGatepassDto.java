package com.gatepass.dto;

import java.util.Date;

public class SearchGatepassDto {
	protected int gatepassNo;
	protected int flatNo;
	protected int blockNo;
	protected Date fromDate;
	protected Date toEndDate;
	protected String status;

	public SearchGatepassDto(int gatepassNo, int flatNo, int blockNo, Date fromDate, Date toEndDate, String status) {
		super();
		this.gatepassNo = gatepassNo;
		this.flatNo = flatNo;
		this.blockNo = blockNo;
		this.fromDate = fromDate;
		this.toEndDate = toEndDate;
		this.status = status;
	}

	public int getGatepassNo() {
		return gatepassNo;
	}

	public void setGatepassNo(int gatepassNo) {
		this.gatepassNo = gatepassNo;
	}

	public int getFlatNo() {
		return flatNo;
	}

	public void setFlatNo(int flatNo) {
		this.flatNo = flatNo;
	}

	public int getBlockNo() {
		return blockNo;
	}

	public void setBlockNo(int blockNo) {
		this.blockNo = blockNo;
	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public Date getToEndDate() {
		return toEndDate;
	}

	public void setToEndDate(Date toEndDate) {
		this.toEndDate = toEndDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
