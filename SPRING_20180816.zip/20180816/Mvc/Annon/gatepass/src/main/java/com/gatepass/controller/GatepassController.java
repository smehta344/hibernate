package com.gatepass.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.gatepass.dto.GatepassDto;
import com.gatepass.exception.GatepassNotFoundException;
import com.gatepass.service.GatepassService;

@Controller
public class GatepassController {
	@Autowired
	private GatepassService gatepassService;

	@RequestMapping("/{gatepassNo}/gatepass.htm")
	public String showGatepass(@PathVariable("gatepassNo") int gatepassNo, Model model) {
		GatepassDto gatepassDto = null;

		gatepassDto = gatepassService.getGatepass(gatepassNo);
		model.addAttribute("gatepass", gatepassDto);

		return "gatepass-details";
	}

	/*@ExceptionHandler(GatepassNotFoundException.class)
	public String handleGatepassNotFoundException(GatepassNotFoundException e, Model model) {
		model.addAttribute("message", "Sorry, we are unable to locate your gatepass");
		return "resource-not-found";
	}*/
}













