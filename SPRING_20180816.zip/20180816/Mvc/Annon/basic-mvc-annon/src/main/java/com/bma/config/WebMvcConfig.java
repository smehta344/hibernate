package com.bma.config;

import java.util.Properties;

import javax.sound.midi.ControllerEventListener;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.HandlerMapping;
import org.springframework.web.servlet.ViewResolver;
import org.springframework.web.servlet.handler.SimpleUrlHandlerMapping;
import org.springframework.web.servlet.mvc.Controller;
import org.springframework.web.servlet.mvc.ParameterizableViewController;
import org.springframework.web.servlet.view.InternalResourceViewResolver;

@Configuration
public class WebMvcConfig {
	@Bean
	public HandlerMapping urlHandlerMapping() {
		Properties mappings = null;
		SimpleUrlHandlerMapping handlerMapping = null;

		mappings = new Properties();
		mappings.put("/welcome-annon.htm", "viewWelcomeAnnon");
		handlerMapping = new SimpleUrlHandlerMapping();
		handlerMapping.setMappings(mappings);

		return handlerMapping;
	}

	@Bean
	public Controller viewWelcomeAnnon() {
		ParameterizableViewController viewWelcomeAnnonController = null;

		viewWelcomeAnnonController = new ParameterizableViewController();
		viewWelcomeAnnonController.setViewName("welcome-annon");

		return viewWelcomeAnnonController;
	}

	@Bean
	public ViewResolver jspViewResolver() {
		InternalResourceViewResolver internalResourceViewResolver = null;

		internalResourceViewResolver = new InternalResourceViewResolver();
		internalResourceViewResolver.setPrefix("/WEB-INF/jsp/");
		internalResourceViewResolver.setSuffix(".jsp");
		return internalResourceViewResolver;
	}
}
