package com.bma.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class RootConfig {

}
