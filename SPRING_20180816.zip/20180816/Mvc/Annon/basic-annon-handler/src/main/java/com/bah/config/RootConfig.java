package com.bah.config;

import org.springframework.context.annotation.Configuration;

@Configuration
public class RootConfig {

}
