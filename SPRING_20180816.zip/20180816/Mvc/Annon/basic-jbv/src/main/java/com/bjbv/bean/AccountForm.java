package com.bjbv.bean;

import javax.validation.constraints.Email;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

import org.hibernate.validator.constraints.Length;

import com.bjbv.groups.AccountTypeGroup;
import com.bjbv.groups.DemographicGroup;
import com.bjbv.payload.Error;

public class AccountForm {
	@NotEmpty(message = "firstName should not be blank", groups = { DemographicGroup.class })
	protected String firstName;
	@NotEmpty(message = "lastName should not be blank", groups = { DemographicGroup.class })
	protected String lastName;
	@Positive(message = "age should be non-zero positive integer", groups = {
			DemographicGroup.class }, payload = Error.Severe.class)
	@Max(value = 99, message = "age should not exceed 99", groups = {
			DemographicGroup.class }, payload = Error.Fatal.class)
	protected int age;
	@NotEmpty(message = "gender should not be blank", groups = { DemographicGroup.class })
	protected String gender;
	@Email(message = "email should be valid", groups = { DemographicGroup.class })
	protected String emailAddress;
	@Length(min = 10, max = 14, message = "mobileNo should be between 10 and 14 characters", groups = {
			DemographicGroup.class })
	protected String mobileNo;
	@NotEmpty(message = "accountType should not be blank", groups = { AccountTypeGroup.class })
	protected String accountType;
	@Min(value = 1000, message = "withdrawlLimit should be minimum 1000", groups = { AccountTypeGroup.class })
	protected double withdrawlLimit;
	@Min(value = 1, message = "depositeLimit should be minium 1", groups = { AccountTypeGroup.class })
	protected double depositeLimit;

	public AccountForm(String firstName, String lastName, int age, String gender, String emailAddress, String mobileNo,
			String accountType, double withdrawlLimit, double depositeLimit) {
		this.firstName = firstName;
		this.lastName = lastName;
		this.age = age;
		this.gender = gender;
		this.emailAddress = emailAddress;
		this.mobileNo = mobileNo;
		this.accountType = accountType;
		this.withdrawlLimit = withdrawlLimit;
		this.depositeLimit = depositeLimit;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public double getWithdrawlLimit() {
		return withdrawlLimit;
	}

	public void setWithdrawlLimit(double withdrawlLimit) {
		this.withdrawlLimit = withdrawlLimit;
	}

	public double getDepositeLimit() {
		return depositeLimit;
	}

	public void setDepositeLimit(double depositeLimit) {
		this.depositeLimit = depositeLimit;
	}

}
