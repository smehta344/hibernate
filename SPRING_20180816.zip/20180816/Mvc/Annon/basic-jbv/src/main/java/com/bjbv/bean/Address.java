package com.bjbv.bean;

import javax.validation.constraints.Max;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

import org.hibernate.validator.constraints.Length;

public class Address {
	@NotEmpty(message = "addressLine1 cannot be blank")
	@Length(min = 5, max = 50, message = "addressLine1 should be between 5 to 50 characters")
	protected String addressLine1;
	protected String addressLine2;
	@NotEmpty(message = "city should not be blank")
	protected String city;
	@NotEmpty(message = "state should not be blank")
	protected String state;
	@Positive(message = "zip should be non-zero positive integer")
	@Max(value = 99999, message = "zip cannot exceed 5 digits")
	protected int zip;
	@NotEmpty(message = "country should not be blank")
	protected String country;

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public int getZip() {
		return zip;
	}

	public void setZip(int zip) {
		this.zip = zip;
	}

	public String getCountry() {
		return country;
	}

	public void setCountry(String country) {
		this.country = country;
	}

}
