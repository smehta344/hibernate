package com.bjbv.test;

import javax.validation.ConstraintViolation;
import java.util.Set;

import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import com.bjbv.bean.Account;

public class IfscCodeTest {
	public static void main(String[] args) {
		ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
		Validator validator = validatorFactory.getValidator();

		Account account = new Account();
		account.setAccountHolderName("Mark");
		account.setAccountNo(1);
		account.setAmount(393);
		account.setAccountType("savings");
		account.setIfscCode("ICIC9393");
		
		Set<ConstraintViolation<Account>> constraintViolations = validator.validate(account);
		for(ConstraintViolation<Account> constraintViolation : constraintViolations) {
			System.out.println(constraintViolation.getMessage());
		}

	}
}
















