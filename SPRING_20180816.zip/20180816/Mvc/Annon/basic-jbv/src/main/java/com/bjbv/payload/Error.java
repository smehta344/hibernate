package com.bjbv.payload;

import javax.validation.Payload;

public class Error {
	public static interface Severe extends Payload {
	}

	public static interface Fatal extends Payload {
	}
}
