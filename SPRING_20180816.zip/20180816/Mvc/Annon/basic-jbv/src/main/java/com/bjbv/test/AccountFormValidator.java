package com.bjbv.test;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import com.bjbv.bean.AccountForm;
import com.bjbv.groups.AccountTypeGroup;
import com.bjbv.groups.DemographicGroup;

public class AccountFormValidator {
	public static void main(String[] args) {
		AccountForm accountForm = new AccountForm("Mathew", null, -1, "Male", "x", "3930", "savings", 0, 0);
		ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
		Validator validator = validatorFactory.getValidator();
		Set<ConstraintViolation<AccountForm>> constraintViolations = validator.validate(accountForm,
				DemographicGroup.class);

		for (ConstraintViolation<AccountForm> constraintViolation : constraintViolations) {
			System.out.println(constraintViolation.getConstraintDescriptor().getPayload());
			System.out.println(constraintViolation.getMessage());
		}

	}
}









