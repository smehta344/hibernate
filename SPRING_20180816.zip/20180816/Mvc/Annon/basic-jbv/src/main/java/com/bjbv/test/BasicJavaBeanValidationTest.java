package com.bjbv.test;

import java.util.Set;

import javax.validation.ConstraintViolation;
import javax.validation.Validation;
import javax.validation.Validator;
import javax.validation.ValidatorFactory;

import com.bjbv.bean.Address;

public class BasicJavaBeanValidationTest {
	public static void main(String[] args) {
		Address address = new Address();
		address.setAddressLine1("M");
		address.setCity("Hyderabad");
		address.setZip(-283);
		address.setCountry("India");

		ValidatorFactory validatorFactory = Validation.buildDefaultValidatorFactory();
		Validator validator = validatorFactory.getValidator();

		Set<ConstraintViolation<Address>> constraintViolations = validator.validate(address);
		for (ConstraintViolation<Address> constraintViolation : constraintViolations) {
			System.out.println(constraintViolation.getMessage());
		}

	}
}











