package com.bjbv.groups;

public interface AccountTypeGroup {

}
