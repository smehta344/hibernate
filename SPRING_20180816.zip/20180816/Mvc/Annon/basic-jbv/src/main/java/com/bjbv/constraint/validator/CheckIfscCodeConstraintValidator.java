package com.bjbv.constraint.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import com.bjbv.constraint.annotations.CheckIfscCode;

public class CheckIfscCodeConstraintValidator implements ConstraintValidator<CheckIfscCode, String> {
	protected String bankCode;

	@Override
	public void initialize(CheckIfscCode constraintAnnotation) {
		bankCode = constraintAnnotation.bankCode();
	}

	@Override
	public boolean isValid(String value, ConstraintValidatorContext context) {
		boolean flag = false;

		if (value.startsWith(bankCode) && value.length() == 8) {
			flag = true;
		}

		return flag;
	}

}
