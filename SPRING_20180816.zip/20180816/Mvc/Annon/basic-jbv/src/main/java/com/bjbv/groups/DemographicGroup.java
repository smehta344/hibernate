package com.bjbv.groups;

public interface DemographicGroup {

}
