package com.bjbv.constraint.annotations;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import javax.validation.Constraint;
import javax.validation.Payload;

import com.bjbv.constraint.validator.CheckIfscCodeConstraintValidator;

@Retention(RetentionPolicy.RUNTIME)
@Target({ ElementType.FIELD, ElementType.PARAMETER })
@Documented
@Constraint(validatedBy = CheckIfscCodeConstraintValidator.class)
public @interface CheckIfscCode {
	String bankCode();

	String message() default "IfscCode is not valid";

	Class<? extends Payload>[] payload() default {};

	Class<?>[] groups() default {};
}
