package com.bjbv.bean;

import javax.validation.constraints.Min;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Positive;

import com.bjbv.constraint.annotations.CheckIfscCode;

public class Account {
	@Min(value = 1, message = "accountNo should be non-zero positive")
	protected int accountNo;
	@NotEmpty(message = "accountHolderName cannot be blank")
	protected String accountHolderName;
	protected String accountType;
	@CheckIfscCode(bankCode = "ICIC")
	protected String ifscCode;
	@Positive(message = "amount should be zero or positive integer")
	protected double amount;

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

}
