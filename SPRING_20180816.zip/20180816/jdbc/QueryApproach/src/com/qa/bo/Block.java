package com.qa.bo;

import java.util.ArrayList;
import java.util.List;

public class Block {
	protected int blockNo;
	protected String blockName;
	protected int capacity;
	protected String zone;
	protected List<Flat> blockFlats;
	
	

	public Block() {
		blockFlats = new ArrayList<>();
	}

	public int getBlockNo() {
		return blockNo;
	}

	public void setBlockNo(int blockNo) {
		this.blockNo = blockNo;
	}

	public String getBlockName() {
		return blockName;
	}

	public void setBlockName(String blockName) {
		this.blockName = blockName;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	public List<Flat> getBlockFlats() {
		return blockFlats;
	}

	public void setBlockFlats(List<Flat> blockFlats) {
		this.blockFlats = blockFlats;
	}

	@Override
	public String toString() {
		return "Block [blockNo=" + blockNo + ", blockName=" + blockName + ", capacity=" + capacity + ", zone=" + zone
				+ ", blockFlats=" + blockFlats + "]";
	}

}
