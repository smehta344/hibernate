package com.qa.bo;

public class Flat {
	protected int flatNo;
	protected String flatType;
	protected int floor;
	protected String facing;
	protected int sqft;
	protected int blockNo;
	protected int ownerNo;

	public int getFlatNo() {
		return flatNo;
	}

	public void setFlatNo(int flatNo) {
		this.flatNo = flatNo;
	}

	public String getFlatType() {
		return flatType;
	}

	public void setFlatType(String flatType) {
		this.flatType = flatType;
	}

	public int getFloor() {
		return floor;
	}

	public void setFloor(int floor) {
		this.floor = floor;
	}

	public String getFacing() {
		return facing;
	}

	public void setFacing(String facing) {
		this.facing = facing;
	}

	public int getSqft() {
		return sqft;
	}

	public void setSqft(int sqft) {
		this.sqft = sqft;
	}

	public int getBlockNo() {
		return blockNo;
	}

	public void setBlockNo(int blockNo) {
		this.blockNo = blockNo;
	}

	public int getOwnerNo() {
		return ownerNo;
	}

	public void setOwnerNo(int ownerNo) {
		this.ownerNo = ownerNo;
	}

	@Override
	public String toString() {
		return "Flat [flatNo=" + flatNo + ", flatType=" + flatType + ", floor=" + floor + ", facing=" + facing
				+ ", sqft=" + sqft + ", blockNo=" + blockNo + ", ownerNo=" + ownerNo + "]";
	}

}
