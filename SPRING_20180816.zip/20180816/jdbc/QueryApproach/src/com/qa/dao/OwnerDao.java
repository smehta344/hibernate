package com.qa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCreator;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.qa.bo.Owner;

@Repository
public class OwnerDao {
	private final String SQL_CNT_OWNERS = "select count(1) from owner";
	private final String SQL_SELECT_MOBILE_NBR_OF_OWNER_BY_OWNER_NO = "select mobile_nbr from owner where owner_no = ?";
	private final String SQL_SELECT_OWNER_BY_OWNER_NO = "select owner_no, first_nm, last_nm, gender, dob, mobile_nbr, email_address from owner where owner_no = ?";
	private final String SQL_SELECT_OWNER_BY_FIRST_NM = "select owner_no, first_nm, last_nm, gender, dob, mobile_nbr, email_address from owner where first_nm like ?";
	private final String SQL_INSERT_OWNER = "insert into owner(owner_no, first_nm, last_nm, gender, dob, mobile_nbr, email_address) values(?,?,?,?,?,?,?)";
	private final String SQL_INSERT_OWNER_AUTO = "insert into owner(first_nm, last_nm, gender, dob, mobile_nbr, email_address) values(?,?,?,?,?,?)";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public int findNoOfOwners() {
		return jdbcTemplate.queryForObject(SQL_CNT_OWNERS, Integer.class);
	}

	public String findMobileNo(int ownerNo) {
		return jdbcTemplate.queryForObject(SQL_SELECT_MOBILE_NBR_OF_OWNER_BY_OWNER_NO, String.class,
				new Object[] { ownerNo });
	}

	public Owner findOwner(int ownerNo) {
		return jdbcTemplate.queryForObject(SQL_SELECT_OWNER_BY_OWNER_NO, new OwnerRowMapper(),
				new Object[] { ownerNo });
	}

	public List<Owner> queryOwner(String firstName) {
		return jdbcTemplate.query(SQL_SELECT_OWNER_BY_FIRST_NM, new OwnerRowMapper(),
				new Object[] { "%" + firstName + "%" });
	}

	public int saveOwner(Owner owner) {
		return jdbcTemplate.update(SQL_INSERT_OWNER, new Object[] { owner.getOwnerNo(), owner.getFirstName(),
				owner.getLastName(), owner.getGender(), owner.getDob(), owner.getMobileNo(), owner.getEmailAddress() });
	}

	public int saveOwnerAuto(final Owner owner) {
		KeyHolder kh = null;
		int records = 0;
		int ownerNo = 0;

		kh = new GeneratedKeyHolder();
		records = jdbcTemplate.update(new PreparedStatementCreator() {
			@Override
			public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
				PreparedStatement pstmt = null;
				pstmt = con.prepareStatement(SQL_INSERT_OWNER_AUTO, new String[] { "owner_no" });
				pstmt.setString(1, owner.getFirstName());
				pstmt.setString(2, owner.getLastName());
				pstmt.setString(3, owner.getGender());
				pstmt.setDate(4, new java.sql.Date(owner.getDob().getTime()));
				pstmt.setString(5, owner.getMobileNo());
				pstmt.setString(6, owner.getEmailAddress());

				return pstmt;
			}
		}, kh);

		if (records > 0) {
			ownerNo = kh.getKey().intValue();
		}
		return ownerNo;
	}

	private final class OwnerRowMapper implements RowMapper<Owner> {
		@Override
		public Owner mapRow(ResultSet rs, int rowNo) throws SQLException {
			Owner owner = null;
			owner = new Owner();
			owner.setOwnerNo(rs.getInt(1));
			owner.setFirstName(rs.getString(2));
			owner.setLastName(rs.getString(3));
			owner.setGender(rs.getString(4));
			owner.setDob(rs.getDate(5));
			owner.setMobileNo(rs.getString(6));
			owner.setEmailAddress(rs.getString(7));

			return owner;
		}
	}

}
