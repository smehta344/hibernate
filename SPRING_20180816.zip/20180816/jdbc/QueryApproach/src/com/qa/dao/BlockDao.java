package com.qa.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.qa.bo.Block;
import com.qa.bo.Flat;

@Repository
public class BlockDao {
	private final String SQL_SELECT_BLOCK_AND_FLATS = "select b.block_no, b.block_nm, b.capacity, b.zone, f.flat_no, f.flat_type, f.floor, f.facing, f.sq_ft, f.block_no, f.owner_no from blocks b inner join flat f on b.block_no = f.block_no";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<Block> getBlocksWithFlats() {
		return jdbcTemplate.query(SQL_SELECT_BLOCK_AND_FLATS, new BlockResultSetExtractor());
	}

	private final class BlockResultSetExtractor implements ResultSetExtractor<List<Block>> {
		@Override
		public List<Block> extractData(ResultSet rs) throws SQLException, DataAccessException {
			int blockNo = 0;
			Block block = null;
			Flat flat = null;
			Map<Integer, Block> blocksMap = null;
			List<Block> blocks = null;

			blocksMap = new HashMap<>();
			while (rs.next()) {
				blockNo = rs.getInt(1);
				if (blocksMap.containsKey(blockNo) == true) {
					block = (Block) blocksMap.get(blockNo);
				} else {
					block = new Block();
					block.setBlockNo(blockNo);
					block.setBlockName(rs.getString(2));
					block.setCapacity(rs.getInt(3));
					block.setZone(rs.getString(4));
					blocksMap.put(blockNo, block);
				}
				// read flat and add it to the block object
				flat = new Flat();
				flat.setFlatNo(rs.getInt(5));
				flat.setFlatType(rs.getString(6));
				flat.setFloor(rs.getInt(7));
				flat.setFacing(rs.getString(8));
				flat.setSqft(rs.getInt(9));
				flat.setBlockNo(rs.getInt(10));
				flat.setOwnerNo(rs.getInt(11));
				block.getBlockFlats().add(flat);
			}
			blocks = new ArrayList<>();
			if (blocksMap.size() > 0) {
				for (Block b : blocksMap.values()) {
					blocks.add(b);
				}
			}

			return blocks;
		}

	}

}
