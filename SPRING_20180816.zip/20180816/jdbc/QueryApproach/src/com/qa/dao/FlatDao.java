package com.qa.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;

import com.qa.bo.Flat;

@Repository
public class FlatDao {
	private final String SQL_SELECT_FLATS_ORDER_BY_FLAT_NO = "select flat_no, flat_type, floor, facing, sq_ft from flat order by flat_no";

	@Autowired
	private JdbcTemplate jdbcTemplate;

	public List<Flat> getFlatsByPagination(int pageSize, int pageNo) {
		return jdbcTemplate.query(SQL_SELECT_FLATS_ORDER_BY_FLAT_NO, new FlatResultSetExtractor(pageSize, pageNo));
	}

	private final class FlatResultSetExtractor implements ResultSetExtractor<List<Flat>> {
		private int pageSize;
		private int pageNo;

		public FlatResultSetExtractor(int pageSize, int pageNo) {
			super();
			this.pageSize = pageSize;
			this.pageNo = pageNo;
		}

		@Override
		public List<Flat> extractData(ResultSet rs) throws SQLException, DataAccessException {
			int startIndex = 0;
			int endIndex = 0;
			int row = 1;
			Flat flat = null;
			List<Flat> flats = null;

			startIndex = (pageSize * (pageNo - 1)) + 1;
			endIndex = (pageSize * (pageNo - 1)) + pageSize;
			flats = new ArrayList<>();
			while (rs.next() && row <= endIndex) {
				if (row >= startIndex) {
					flat = new Flat();
					flat.setFlatNo(rs.getInt(1));
					flat.setFlatType(rs.getString(2));
					flat.setFloor(rs.getInt(3));
					flat.setFacing(rs.getString(4));
					flat.setSqft(rs.getInt(5));
					flats.add(flat);
				}
				row++;
			}

			return flats;
		}

	}

}
