package com.qa.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.qa.bo.Flat;
import com.qa.config.AppConfig;
import com.qa.dao.FlatDao;

public class PaginationTest {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		FlatDao flatDao = context.getBean("flatDao", FlatDao.class);
		
		List<Flat> flats = flatDao.getFlatsByPagination(3, 3);
		System.out.println(flats);
	}
}
