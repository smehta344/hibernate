package com.qa.test;

import java.util.Date;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.qa.bo.Block;
import com.qa.bo.Owner;
import com.qa.config.AppConfig;
import com.qa.dao.BlockDao;
import com.qa.dao.OwnerDao;

public class QATest {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		
		OwnerDao ownerDao = context.getBean("ownerDao", OwnerDao.class);
		/*int noOfOwners = ownerDao.findNoOfOwners();
		System.out.println("owners : " +noOfOwners);*/
		
		/*String mobileNo = ownerDao.findMobileNo(1);
		System.out.println("mobile : " + mobileNo);*/
		
		/*Owner owner = ownerDao.findOwner(1);
		System.out.println(owner);*/
		
		Owner owner = new Owner();
		owner.setFirstName("Parul");
		owner.setLastName("j");
		owner.setGender("Female");
		owner.setDob(new Date());
		owner.setMobileNo("0399393");
		owner.setEmailAddress("parul@gmail.com");
		int ownerNo = ownerDao.saveOwnerAuto(owner);
		System.out.println("ownerNo : " + ownerNo);
		
		/*
		List<Owner> owners = ownerDao.queryOwner("u");
		for(Owner owner1 : owners) {
			System.out.println(owner1);
		}*/
		
		/*BlockDao blockDao = context.getBean("blockDao", BlockDao.class);
		List<Block> blocks = blockDao.getBlocksWithFlats();
		for(Block b :  blocks) {
			System.out.println(b);
		}*/
		
		
	}
}



















