package com.npjt.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.npjt.bo.Block;
import com.npjt.config.NPJTConfig;
import com.npjt.dao.BlockDao;
import com.npjt.dao.BlockInsertDao;

import java.util.List;

import org.springframework.context.ApplicationContext;

public class NPJTTest {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(NPJTConfig.class);

		BlockDao blockDao = context.getBean("blockDao", BlockDao.class);
		BlockInsertDao blockInsertDao = context.getBean("blockInsertDao", BlockInsertDao.class);
		/*
		 * int b = blockDao.findNoOfBlocksByZone("south");
		 * System.out.println("south zone blocks : " + b);
		 */
		/*
		 * List<Block> blocks = blockDao.getBlocksByCapacity(100);
		 * System.out.println(blocks);
		 */

		Block block = new Block();
		block.setBlockNo(5);
		block.setBlockName("Rose");
		block.setCapacity(90);
		block.setZone("east");
		int r = blockInsertDao.saveBlock(block);
		System.out.println("r : " + r);
		/*int records = blockDao.updateBlock(block);
		System.out.println("update : " + records);*/

	}
}
















