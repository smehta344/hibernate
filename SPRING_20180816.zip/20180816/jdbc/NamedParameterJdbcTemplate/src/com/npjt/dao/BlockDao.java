package com.npjt.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.stereotype.Repository;

import com.npjt.bo.Block;

@Repository
public class BlockDao {
	private final String SQL_FIND_NO_OF_BLOCKS_BY_ZONE = "select count(1) from blocks where zone = :p_zone";
	private final String SQL_SELECT_BLOCKS_BY_CAPACITY = "select block_no, block_nm, capacity, zone from blocks where capacity >= :p_capacity";
	private final String SQL_UPDATE_BLOCK = "update blocks set block_nm = :blockName, capacity=:capacity, zone=:zone where block_no=:blockNo";

	private NamedParameterJdbcTemplate npJdbcTemplate;
	private DataSource dataSource;

	@Autowired
	public BlockDao(DataSource dataSource) {
		this.dataSource = dataSource;
		npJdbcTemplate = new NamedParameterJdbcTemplate(this.dataSource);
	}

	public int findNoOfBlocksByZone(String zone) {
		Map<String, Object> paramMap = null;

		paramMap = new HashMap<>();
		paramMap.put("p_zone", zone);
		return npJdbcTemplate.queryForInt(SQL_FIND_NO_OF_BLOCKS_BY_ZONE, paramMap);
	}

	public List<Block> getBlocksByCapacity(int capacity) {
		MapSqlParameterSource paramSource = null;

		paramSource = new MapSqlParameterSource();
		paramSource.addValue("p_capacity", capacity);
		return npJdbcTemplate.query(SQL_SELECT_BLOCKS_BY_CAPACITY, paramSource, new BlockRowMapper());
	}
	
	public int updateBlock(Block block) {
		BeanPropertySqlParameterSource paramSource = null;
		
		paramSource= new BeanPropertySqlParameterSource(block);
		return npJdbcTemplate.update(SQL_UPDATE_BLOCK, paramSource);
	}

	private final class BlockRowMapper implements RowMapper<Block> {
		@Override
		public Block mapRow(ResultSet rs, int rowNum) throws SQLException {
			Block block = new Block();
			block.setBlockNo(rs.getInt(1));
			block.setBlockName(rs.getString(2));
			block.setCapacity(rs.getInt(3));
			block.setZone(rs.getString(4));
			return block;
		}

	}
}
