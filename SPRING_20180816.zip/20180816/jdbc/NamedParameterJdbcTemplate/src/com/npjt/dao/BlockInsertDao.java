package com.npjt.dao;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import com.npjt.bo.Block;

@Repository
public class BlockInsertDao {
	@Autowired
	private DataSource dataSource;
	
	public int saveBlock(Block block) {
		SimpleJdbcInsert simpleJdbcInsert = null;
		MapSqlParameterSource paramSource = null;
		
		simpleJdbcInsert = new SimpleJdbcInsert(dataSource);
		simpleJdbcInsert.setTableName("blocks");
		
		paramSource = new MapSqlParameterSource();
		paramSource.addValue("block_no", block.getBlockNo());
		paramSource.addValue("block_nm", block.getBlockName());
		paramSource.addValue("capacity", block.getCapacity());
		paramSource.addValue("zone", block.getZone());
		
		return simpleJdbcInsert.execute(paramSource);
	}
}

















