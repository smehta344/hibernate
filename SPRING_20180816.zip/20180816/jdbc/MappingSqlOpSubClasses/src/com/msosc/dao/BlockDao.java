package com.msosc.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.SqlParameter;
import org.springframework.jdbc.object.MappingSqlQuery;
import org.springframework.stereotype.Repository;

import com.msosc.bo.Block;

@Repository
public class BlockDao {
	private final String SQL_SELECT_BLOCK_BY_NO = "select block_no, block_nm, capacity, zone from blocks where block_no = ?";
	private DataSource dataSource;
	private GetBlockByBlockNo getBlockByBlockNo;
	
	
	@Autowired
	public BlockDao(DataSource dataSource) {
		this.dataSource = dataSource;
		getBlockByBlockNo = new GetBlockByBlockNo(this.dataSource);
	}

	public Block getBlockByNo(int blockNo) {
		Block block = null;
		
		block = getBlockByBlockNo.findObject(blockNo);
		
		return block;
	}

	private final class GetBlockByBlockNo extends MappingSqlQuery<Block> {

		public GetBlockByBlockNo(DataSource dataSource) {
			super(dataSource, SQL_SELECT_BLOCK_BY_NO);
			declareParameter(new SqlParameter(Types.INTEGER));
			compile();
		}

		@Override
		protected Block mapRow(ResultSet rs, int rowNum) throws SQLException {
			return new Block(rs.getInt(1), rs.getString(2), rs.getInt(3), rs.getString(4));
		}

	}
}
