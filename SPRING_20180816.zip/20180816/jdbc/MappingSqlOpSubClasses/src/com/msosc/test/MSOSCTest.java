package com.msosc.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.msosc.bo.Block;
import com.msosc.config.MSOSCConfig;
import com.msosc.dao.BlockDao;

public class MSOSCTest {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(MSOSCConfig.class);
		BlockDao blockDao = context.getBean("blockDao", BlockDao.class);
		
		Block block = blockDao.getBlockByNo(3);
		System.out.println(block);
	}
}
