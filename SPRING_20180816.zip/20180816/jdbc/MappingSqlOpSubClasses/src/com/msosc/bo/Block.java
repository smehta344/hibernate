package com.msosc.bo;

public class Block {
	protected int blockNo;
	protected String blockName;
	protected int capacity;
	protected String zone;

	public Block(int blockNo, String blockName, int capacity, String zone) {
		this.blockNo = blockNo;
		this.blockName = blockName;
		this.capacity = capacity;
		this.zone = zone;
	}

	public int getBlockNo() {
		return blockNo;
	}

	public void setBlockNo(int blockNo) {
		this.blockNo = blockNo;
	}

	public String getBlockName() {
		return blockName;
	}

	public void setBlockName(String blockName) {
		this.blockName = blockName;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	@Override
	public String toString() {
		return "Block [blockNo=" + blockNo + ", blockName=" + blockName + ", capacity=" + capacity + ", zone=" + zone
				+ "]";
	}

}
