package com.ca.test;

import java.util.Date;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.ca.bo.Block;
import com.ca.bo.Flat;
import com.ca.bo.Owner;
import com.ca.dao.BlockDao;
import com.ca.dao.FlatDao;

public class CATest {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/ca/common/application-context.xml");
		/*
		 * BlockDao blockDao = context.getBean("blockDao", BlockDao.class); List<Block>
		 * blocks = blockDao.getBlocksByZone("south"); for (Block block : blocks) {
		 * System.out.println(block); }
		 */

		FlatDao flatDao = context.getBean("flatDao", FlatDao.class);
		Owner owner = new Owner(3, "andrew", "k", "male", new Date(), "938494", "andrew@gmail.com");
		Flat flat = new Flat(1, 12, "2 bhk", "east", 1250);
		boolean flag = flatDao.joinFlat(owner, flat, "south");
		System.out.println("flag : " + flat);

	}
}
