package com.ca.bo;

public class Flat {
	private int flatNo;
	private int floor;
	private String flatType;
	private String facing;
	private int sqFt;
	private int blockNo;
	private int ownerNo;

	
	public Flat() {
		super();
	}

	public Flat(int flatNo, int floor, String flatType, String facing, int sqFt) {
		this.flatNo = flatNo;
		this.floor = floor;
		this.flatType = flatType;
		this.facing = facing;
		this.sqFt = sqFt;
	}

	public int getFlatNo() {
		return flatNo;
	}

	public void setFlatNo(int flatNo) {
		this.flatNo = flatNo;
	}

	public int getFloor() {
		return floor;
	}

	public void setFloor(int floor) {
		this.floor = floor;
	}

	public String getFlatType() {
		return flatType;
	}

	public void setFlatType(String flatType) {
		this.flatType = flatType;
	}

	public String getFacing() {
		return facing;
	}

	public void setFacing(String facing) {
		this.facing = facing;
	}

	public int getSqFt() {
		return sqFt;
	}

	public void setSqFt(int sqFt) {
		this.sqFt = sqFt;
	}

	public int getBlockNo() {
		return blockNo;
	}

	public void setBlockNo(int blockNo) {
		this.blockNo = blockNo;
	}

	public int getOwnerNo() {
		return ownerNo;
	}

	public void setOwnerNo(int ownerNo) {
		this.ownerNo = ownerNo;
	}

}
