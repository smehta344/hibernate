package com.ca.bo;

public class Block {
	private int blockNo;
	private String blockName;
	private int capacity;
	private String zone;

	public int getBlockNo() {
		return blockNo;
	}

	public void setBlockNo(int blockNo) {
		this.blockNo = blockNo;
	}

	public String getBlockName() {
		return blockName;
	}

	public void setBlockName(String blockName) {
		this.blockName = blockName;
	}

	public int getCapacity() {
		return capacity;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	public String getZone() {
		return zone;
	}

	public void setZone(String zone) {
		this.zone = zone;
	}

	@Override
	public String toString() {
		return "Block [blockNo=" + blockNo + ", blockName=" + blockName + ", capacity=" + capacity + ", zone=" + zone
				+ "]";
	}

}
