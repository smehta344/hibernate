package com.ca.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.PreparedStatementCallback;
import org.springframework.jdbc.core.PreparedStatementCreator;

import com.ca.bo.Block;

public class BlockDao {
	private JdbcTemplate jdbcTemplate;

	public BlockDao(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<Block> getBlocksByZone(String zone) {
		List<Block> blocks = null;
		GetBlockByZoneCreator getBlockByZoneCreator = null;
		GetBlockByZoneCallback getBlockByZoneCallback = null;

		getBlockByZoneCreator = new GetBlockByZoneCreator(zone);
		getBlockByZoneCallback = new GetBlockByZoneCallback();
		blocks = jdbcTemplate.execute(getBlockByZoneCreator, getBlockByZoneCallback);
		return blocks;
	}

	private final class GetBlockByZoneCreator implements PreparedStatementCreator {
		private String zone;

		public GetBlockByZoneCreator(String zone) {
			this.zone = zone;
		}

		@Override
		public PreparedStatement createPreparedStatement(Connection con) throws SQLException {
			PreparedStatement pstmt = null;

			pstmt = con.prepareStatement("select * from blocks where zone = ?");
			pstmt.setString(1, zone);
			return pstmt;
		}
	}

	private final class GetBlockByZoneCallback implements PreparedStatementCallback<List<Block>> {
		@Override
		public List<Block> doInPreparedStatement(PreparedStatement pstmt) throws SQLException, DataAccessException {
			List<Block> blocks = null;
			ResultSet rs = null;
			Block block = null;

			rs = pstmt.executeQuery();
			blocks = new ArrayList<>();
			while (rs.next()) {
				block = new Block();
				block.setBlockNo(rs.getInt("block_no"));
				block.setBlockName(rs.getString("block_nm"));
				block.setCapacity(rs.getInt("capacity"));
				block.setZone(rs.getString("zone"));
				blocks.add(block);
			}

			return blocks;
		}

	}
}
