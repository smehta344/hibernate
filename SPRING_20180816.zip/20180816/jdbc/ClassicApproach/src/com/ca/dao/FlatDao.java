package com.ca.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.ConnectionCallback;
import org.springframework.jdbc.core.JdbcTemplate;

import com.ca.bo.Flat;
import com.ca.bo.Owner;

public class FlatDao {
	private JdbcTemplate jdbcTemplate;

	public FlatDao(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public boolean joinFlat(Owner owner, Flat flat, String zone) {
		return jdbcTemplate.execute(new JoinFlatConnectionCallback(owner, flat, zone));
	}

	private final class JoinFlatConnectionCallback implements ConnectionCallback<Boolean> {
		private Owner owner;
		private Flat flat;
		private String zone;

		public JoinFlatConnectionCallback(Owner owner, Flat flat, String zone) {
			this.owner = owner;
			this.flat = flat;
			this.zone = zone;
		}

		@Override
		public Boolean doInConnection(Connection con) throws SQLException, DataAccessException {
			int blockNo = 0;
			ResultSet blockRs = null;
			PreparedStatement flatPstmt = null;
			PreparedStatement blockPstmt = null;
			PreparedStatement ownerPstmt = null;

			try {
				blockPstmt = con.prepareStatement("select block_no from blocks where zone = ?");
				blockPstmt.setString(1, zone);
				blockRs = blockPstmt.executeQuery();
				if (blockRs.next()) {
					blockNo = blockRs.getInt("block_no");
				}
				ownerPstmt = con.prepareStatement(
						"insert into owner(owner_no, first_nm, last_nm, dob, gender, mobile_nbr, email_address) values(?,?,?,?,?,?,?)");
				ownerPstmt.setInt(1, owner.getOwnerNo());
				ownerPstmt.setString(2, owner.getFirstName());
				ownerPstmt.setString(3, owner.getLastName());
				ownerPstmt.setDate(4, new java.sql.Date(owner.getDob().getTime()));
				ownerPstmt.setString(5, owner.getGender());
				ownerPstmt.setString(6, owner.getMobileNo());
				ownerPstmt.setString(7, owner.getEmailAddress());
				ownerPstmt.executeUpdate();

				flatPstmt = con.prepareStatement(
						"insert into flat(flat_no, flat_type, floor, facing, sq_ft, block_no, owner_no) values(?,?,?,?,?,?,?)");
				flatPstmt.setInt(1, flat.getFlatNo());
				flatPstmt.setString(2, flat.getFlatType());
				flatPstmt.setInt(3, flat.getFloor());
				flatPstmt.setString(4, flat.getFacing());
				flatPstmt.setInt(5, flat.getSqFt());
				flatPstmt.setInt(6, blockNo);
				flatPstmt.setInt(7, owner.getOwnerNo());
				flatPstmt.executeUpdate();

				return true;
			} finally {
				if (blockRs != null) {
					blockRs.close();
				}
				if (blockPstmt != null) {
					blockPstmt.close();
				}
				if (ownerPstmt != null) {
					ownerPstmt.close();
				}
				if (flatPstmt != null) {
					flatPstmt.close();
				}
			}

		}

	}

}
