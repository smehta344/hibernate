package com.mba.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.mba.beans.LoanManager;
import com.mba.security.helper.SecurityHelper;

public class MBATest {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext("com.mba.beans", "com.mba.aspect",
				"com.mba.security.helper");
		SecurityHelper helper = context.getBean("securityHelper", SecurityHelper.class);
		LoanManager lm = context.getBean("loanManager", LoanManager.class);
		helper.login("john", "welcome1");
		
		boolean approved = lm.approveLoan(1);
		System.out.println("approved : " + approved);
	}
}
