package com.aa.util;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class Cache {
	private static Cache instance = new Cache();
	private Map<String, Object> dataMap;

	private Cache() {
		dataMap = new ConcurrentHashMap<>();
	}

	public static Cache getInstance() {
		return instance;
	}

	public void put(String key, Object value) {
		dataMap.put(key, value);
	}

	public Object get(String key) {
		return dataMap.get(key);
	}

	public boolean containsKey(String key) {
		return dataMap.containsKey(key);
	}
}
