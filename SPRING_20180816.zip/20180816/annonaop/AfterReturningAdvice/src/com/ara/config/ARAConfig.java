package com.ara.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.EnableAspectJAutoProxy;

import com.ara.beans.KeyGenerator;

@Configuration
@ComponentScan(basePackages = { "com.ara.aspect" })
@EnableAspectJAutoProxy
public class ARAConfig {
	@Bean
	public KeyGenerator keyGenerator() {
		return new KeyGenerator();
	}
}
