package com.ara.aspect;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.AfterReturning;
import org.aspectj.lang.annotation.Aspect;
import org.springframework.stereotype.Component;

@Aspect
@Component
public class KeyValidatorAspect {
	@AfterReturning(value = "within(com.ara.beans.*)", returning = "ret")
	public void validate(JoinPoint jp, Object ret) throws Throwable {
		if ((Integer) ret <= 0) {
			throw new Exception("weak key");
		}
	}
}
