package com.boot.custom.config;

import java.util.Iterator;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.config.YamlPropertiesFactoryBean;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.support.PropertySourcesPlaceholderConfigurer;
import org.springframework.core.env.PropertySource;
import org.springframework.core.env.PropertySources;
import org.springframework.core.env.PropertySourcesPropertyResolver;
import org.springframework.core.io.ClassPathResource;

import com.boot.custom.config.beans.Bike;
import com.boot.custom.config.initializer.YamlConfigApplicationContextInitializer;

@SpringBootApplication
public class BootCustomConfigApplication {
	@Autowired
	private ApplicationContext applicationContext;

	public static void main(String[] args) {
		ApplicationContext context = null;
		SpringApplication springApplication = null;
		SpringApplicationBuilder springApplicationBuilder = null;

		springApplicationBuilder = new SpringApplicationBuilder(BootCustomConfigApplication.class)
				.initializers(new YamlConfigApplicationContextInitializer());
		springApplication = springApplicationBuilder.build();
		context = springApplication.run(args);
		Bike bike = context.getBean("bike", Bike.class);
		System.out.println(bike);

		System.exit(SpringApplication.exit(context));
	}

	@Bean
	public CommandLineRunner yamlConfigurationCommandLineRunner() {
		return args -> {
			YamlPropertiesFactoryBean yamlPropertiesFactoryBean = null;
			yamlPropertiesFactoryBean = new YamlPropertiesFactoryBean();
			yamlPropertiesFactoryBean.setResources(new ClassPathResource("bike.yaml"));

			Properties props = yamlPropertiesFactoryBean.getObject();
		};
	}

}
