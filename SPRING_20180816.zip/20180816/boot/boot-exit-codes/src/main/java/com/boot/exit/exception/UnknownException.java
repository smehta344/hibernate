package com.boot.exit.exception;

public class UnknownException extends RuntimeException {

	public UnknownException(String message) {
		super(message);
	}

}
