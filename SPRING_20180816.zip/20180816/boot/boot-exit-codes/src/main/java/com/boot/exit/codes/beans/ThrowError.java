package com.boot.exit.codes.beans;

import org.springframework.stereotype.Component;

import com.boot.exit.exception.UnknownException;

@Component
public class ThrowError {
	public void terminate() {
		throw new UnknownException("terminate");
	}
}
