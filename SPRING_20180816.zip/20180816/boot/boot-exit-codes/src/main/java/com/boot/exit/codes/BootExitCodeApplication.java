package com.boot.exit.codes;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.ExitCodeEvent;
import org.springframework.boot.ExitCodeExceptionMapper;
import org.springframework.boot.ExitCodeGenerator;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationListener;
import org.springframework.context.annotation.Bean;

import com.boot.exit.codes.beans.ThrowError;
import com.boot.exit.exception.UnknownException;

@SpringBootApplication
public class BootExitCodeApplication implements ExitCodeGenerator {
	@Bean
	public ExitCodeExceptionMapper exitCodeExceptionMapper() {
		System.out.println("exitCodeExceptionMapper()");
		return new BootExitCodeExceptionMapper();
	}

	// @Bean
	public CommandLineRunner initialize() {
		return args -> {
			throw new UnknownException("terminated");
		};
	}

	public static void main(String[] args) {
		ApplicationContext context = null;

		context = SpringApplication.run(BootExitCodeApplication.class, args);
		ThrowError throwError = context.getBean("throwError", ThrowError.class);
		// throwError.terminate();
		System.exit(SpringApplication.exit(context));
	}
	
	@Bean
	public ApplicationListener<ExitCodeEvent> exitCodeEvent() {
		return (event) -> {
			System.out.println(event.getExitCode());
		};
	}

	private final class BootExitCodeExceptionMapper implements ExitCodeExceptionMapper {
		@Override
		public int getExitCode(Throwable exception) {
			System.out.println("getExitCode()");
			if (exception.getCause() instanceof UnknownException) {
				return -10;
			}
			return -1000;
		}

	}

	@Override
	public int getExitCode() {
		return 10;
	}

}
