package com.boot.customize.beans;

public class PeriodicMaintainanceService {
	public int getMaintainaceDueInDays(String registrationNo) {
		return 35;
	}
}
