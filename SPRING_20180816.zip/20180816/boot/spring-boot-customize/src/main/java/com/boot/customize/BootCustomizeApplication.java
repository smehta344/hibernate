package com.boot.customize;

import org.springframework.boot.Banner.Mode;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ImportResource;

import com.boot.customize.beans.PeriodicMaintainanceService;

@SpringBootApplication
@ImportResource("classpath:com/boot/customize/common/application-context.xml")
public class BootCustomizeApplication {
	public static void main(String[] args) {
		ApplicationContext context = null;
		
		//ApplicationContext context = SpringApplication.run(BootCustomizeApplication.class, args);
		SpringApplication springApplication = new SpringApplicationBuilder(BootCustomizeApplication.class).bannerMode(Mode.OFF).build();
		context = springApplication.run(args);
		
		
		
		
		PeriodicMaintainanceService periodicMaintainanceService = context.getBean("periodicMaintainanceService",
				PeriodicMaintainanceService.class);
		System.out.println(periodicMaintainanceService.getMaintainaceDueInDays("rs0393"));

	}
}




