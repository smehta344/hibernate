package com.boot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.builder.SpringApplicationBuilder;
import org.springframework.context.ApplicationContext;

import com.boot.listener.BootListener;

@SpringBootApplication
public class BootListenerApplication {
	public static void main(String[] args) {
		ApplicationContext context = null;

		//SpringApplication.run(BootListenerApplication.class, args);
		SpringApplicationBuilder builder = new SpringApplicationBuilder(BootListenerApplication.class);
		BootListener bootListener = new BootListener();
		builder.listeners(bootListener);

		SpringApplication springApplication = builder.build();
		context = springApplication.run(args);
		
	}
}










