package com.boot.cli;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BootCliRunnerApplication {
	public static void main(String[] args) {
		SpringApplication.run(BootCliRunnerApplication.class, args);
	}
}
