package com.boot.profile.beans;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@Component
@ConfigurationProperties
public class JetAirwaysServiceEndpoint {
	private String endpoint;
	private boolean enableCache;

	public String getEndpoint() {
		return endpoint;
	}

	public void setEndpoint(String endpoint) {
		this.endpoint = endpoint;
	}

	public boolean isEnableCache() {
		return enableCache;
	}

	public void setEnableCache(boolean enableCache) {
		this.enableCache = enableCache;
	}

	@Override
	public String toString() {
		return "JetAirwaysServiceEndpoint [endpoint=" + endpoint + ", enableCache=" + enableCache + "]";
	}

}
