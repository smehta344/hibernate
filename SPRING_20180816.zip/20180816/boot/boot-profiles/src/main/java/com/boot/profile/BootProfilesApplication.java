package com.boot.profile;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;

import com.boot.profile.beans.JetAirwaysServiceEndpoint;

@SpringBootApplication
public class BootProfilesApplication {

	public static void main(String[] args) {
		ApplicationContext context = null;

		context = SpringApplication.run(BootProfilesApplication.class, args);
		JetAirwaysServiceEndpoint jetAirwaysServiceEndpoint = context.getBean("jetAirwaysServiceEndpoint", JetAirwaysServiceEndpoint.class);
		System.out.println(jetAirwaysServiceEndpoint); 
		
		
		System.exit(SpringApplication.exit(context));
	}

}
