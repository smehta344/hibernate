package com.boot.jpa.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boot.jpa.entities.Branch;

public interface BranchRepository extends JpaRepository<Branch, Integer>{
	@Override
	List<Branch> findAll();
}
