package com.boot.jpa;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.orm.jpa.JpaTemplate;

import com.boot.jpa.entities.Branch;
import com.boot.jpa.service.BranchService;

@SpringBootApplication
@EntityScan(basePackages = "com.boot.jpa.entities")
public class BootJpaApplication {

	public static void main(String[] args) {
		ApplicationContext context = null;
		BranchService branchService = null;

		context = SpringApplication.run(BootJpaApplication.class, args);
		branchService = context.getBean("branchService", BranchService.class);
		List<Branch> branches = branchService.getBranchesThroughDao();
		System.out.println(branches);

		System.exit(SpringApplication.exit(context));
	}

	@Bean(autowire = Autowire.BY_TYPE)
	public JpaTemplate jpaTemplate() {
		return new JpaTemplate();
	}

}
