package com.boot.jpa.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.DependsOn;
import org.springframework.orm.jpa.JpaTemplate;
import org.springframework.stereotype.Repository;

import com.boot.jpa.entities.Branch;

@Repository
@DependsOn("jpaTemplate")
public class BranchDao {
	@Autowired
	private JpaTemplate jpaTemplate;

	public List<Branch> getBranches() {
		return (List<Branch>) jpaTemplate.find("from Branch");
	}
}
