package com.boot.jpa.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.jpa.dao.BranchDao;
import com.boot.jpa.entities.Branch;
import com.boot.jpa.repository.BranchRepository;

@Service
public class BranchService {
	@Autowired
	private BranchRepository branchRepository;
	@Autowired
	private BranchDao branchDao;

	public List<Branch> getBranches() {
		return branchRepository.findAll();
	}
	public List<Branch> getBranchesThroughDao() {
		return branchDao.getBranches();
	}
}
