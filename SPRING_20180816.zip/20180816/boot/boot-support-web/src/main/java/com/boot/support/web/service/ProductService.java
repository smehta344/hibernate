package com.boot.support.web.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.support.web.entities.Product;
import com.boot.support.web.repositories.ProductRepository;

@Service
public class ProductService {
	@Autowired
	private ProductRepository productRepository;

	public List<Product> getProductsByName(String productName) {
		return productRepository.getProductsByProductNameIgnoreCaseLike("%" + productName + "%");
	}
}
