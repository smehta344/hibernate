package com.boot.support.web.endpoints;

import org.springframework.boot.actuate.endpoint.annotation.ReadOperation;
import org.springframework.boot.actuate.endpoint.annotation.Selector;
import org.springframework.boot.actuate.endpoint.web.annotation.WebEndpoint;
import org.springframework.stereotype.Component;

@Component
@WebEndpoint(id = "features", enableByDefault = true)
public class FeaturesEndpoint {
	@ReadOperation
	public String getFeatures(@Selector String version) {
		return "5.0 Reactive Support";
	}

}
