package com.boot.support.web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;

@SpringBootApplication
@EntityScan(basePackages = "com.boot.support.web.entities")
public class BootSupportWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(BootSupportWebApplication.class, args);
	}

}
