package com.boot.support.web.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.boot.support.web.entities.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {
	List<Product> getProductsByProductNameIgnoreCaseLike(String productName);
}
