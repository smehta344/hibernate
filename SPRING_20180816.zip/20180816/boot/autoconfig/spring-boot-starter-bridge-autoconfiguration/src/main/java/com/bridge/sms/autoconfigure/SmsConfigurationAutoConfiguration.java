package com.bridge.sms.autoconfigure;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.condition.ConditionalOnClass;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;

import com.bridge.sms.helper.SmsConfiguration;

@Configuration
@ConditionalOnClass({ SmsConfiguration.class })
public class SmsConfigurationAutoConfiguration {
	@Autowired
	private Environment env;

	@Bean
	public SmsConfiguration smsConfiguration() {
		SmsConfiguration smsConfiguration = null;

		smsConfiguration = new SmsConfiguration();
		smsConfiguration.setHost(env.getProperty("bridge.host"));
		smsConfiguration.setPort(Integer.parseInt(env.getProperty("bridge.port")));
		smsConfiguration.setApiKey(env.getProperty("bridge.apiKey"));

		return smsConfiguration;
	}
}
