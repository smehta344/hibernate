package com.bridge.sms.helper;

public class SmsSender {
	private SmsConfiguration smsConfiguration;

	public void send() {
		System.out.println(
				smsConfiguration.getHost() + ": " + smsConfiguration.getPort() + " : " + smsConfiguration.getApiKey());
	}

	public void setSmsConfiguration(SmsConfiguration smsConfiguration) {
		this.smsConfiguration = smsConfiguration;
	}

}
