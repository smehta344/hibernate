package com.marketplace.application;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Bean;

import com.bridge.sms.helper.SmsSender;
import com.marketplace.application.bean.NotificationHelper;

@SpringBootApplication
public class MarketPlaceApplication {
	public static void main(String[] args) {
		ApplicationContext context = null;

		context = SpringApplication.run(MarketPlaceApplication.class, args);
		NotificationHelper nh = context.getBean("notificationHelper", NotificationHelper.class);
		nh.send();
		System.exit(SpringApplication.exit(context));
	}

	@Bean(autowire = Autowire.BY_TYPE)
	public SmsSender smsSender() {
		return new SmsSender();
	}
}
