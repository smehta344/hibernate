package com.marketplace.application.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.bridge.sms.helper.SmsSender;

@Component
public class NotificationHelper {
	@Autowired
	private SmsSender smsSender;

	public void send() {
		smsSender.send();
	}
}
