package com.bl.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.bl.beans.Calculator;
import com.bl.beans.ShutdownHook;

public class BLTest {
	public static void main(String[] args) {
		BeanFactory factory = new XmlBeanFactory(new ClassPathResource("com/bl/common/application-context.xml"));
		ShutdownHook shutdownHook = factory.getBean("shutdownHook", ShutdownHook.class);
		Runtime runtime = Runtime.getRuntime();
		runtime.addShutdownHook(shutdownHook);

		Calculator calculator = factory.getBean("calculator", Calculator.class);
		System.out.println(calculator);
		// destroySingletons()
		//((ConfigurableListableBeanFactory) factory).destroySingletons();
	}
}











