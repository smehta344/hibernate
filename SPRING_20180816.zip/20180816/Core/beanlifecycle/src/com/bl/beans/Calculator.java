package com.bl.beans;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

public class Calculator implements InitializingBean, DisposableBean {
	private int i;
	private int j;
	private int sum;
	

	/*public void init() {
		this.sum = this.i + this.j;
	}*/

	@Override
	public void destroy() throws Exception {
		System.out.println("destroying...");
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		this.sum = this.i + this.j;
	}

	public Calculator(int i) {
		this.i = i;
	}

	public void setJ(int j) {
		this.j = j;
	}

	/*public void cleanup() {
		System.out.println("releasing resources...");
	}*/

	@Override
	public String toString() {
		return "Calculator [i=" + i + ", j=" + j + ", sum=" + sum + "]";
	}

}
