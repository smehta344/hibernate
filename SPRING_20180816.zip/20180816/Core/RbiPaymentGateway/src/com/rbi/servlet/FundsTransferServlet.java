package com.rbi.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class FundsTransferServlet extends HttpServlet {
	String fromAc;
	String toAc = null;
	double amount = 0;
	double fromAcBalance = 0;
	double toAcBalance = 0;

	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Connection con = null;
		PreparedStatement qPstmt = null;
		PreparedStatement uPstmt = null;
		ResultSet frs = null;
		ResultSet trs = null;

		try {
			fromAc = req.getParameter("fromAc");
			toAc = req.getParameter("toAc");
			amount = Double.parseDouble(req.getParameter("amount"));

			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/rbi", "root", "root");
			qPstmt = con.prepareStatement("select balance from accounts where account_no = ?");
			qPstmt.setString(1, fromAc);
			frs = qPstmt.executeQuery();
			if (frs.next()) {
				fromAcBalance = frs.getDouble("balance");
			}
			if (fromAc.equals("icici001")) {
				Thread.sleep(1000L);
			}
			qPstmt.setString(1, toAc);
			trs = qPstmt.executeQuery();
			if (trs.next()) {
				toAcBalance = trs.getDouble("balance");
			}

			fromAcBalance = fromAcBalance - amount;
			toAcBalance = toAcBalance + amount;
			uPstmt = con.prepareStatement("update accounts set balance = ? where account_no = ?");
			uPstmt.setDouble(1, fromAcBalance);
			uPstmt.setString(2, fromAc);
			uPstmt.executeUpdate();

			uPstmt.setDouble(1, toAcBalance);
			uPstmt.setString(2, toAc);
			uPstmt.executeUpdate();
			PrintWriter out = resp.getWriter();
			out.println("Transfer successful");

		} catch (SQLException | ClassNotFoundException | InterruptedException e) {
			throw new ServletException(e);
		} finally {
			if (frs != null) {
				try {
					frs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (trs != null) {
				try {
					trs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (uPstmt != null) {
				try {
					uPstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (qPstmt != null) {
				try {
					qPstmt.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
			if (con != null) {
				try {
					con.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			}
		}

	}
}
