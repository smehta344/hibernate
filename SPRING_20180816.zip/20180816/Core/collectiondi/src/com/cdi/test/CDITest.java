package com.cdi.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.cdi.beans.BusinessUnit;
import com.cdi.beans.Team;

public class CDITest {
	public static void main(String[] args) {
		BeanFactory factory = new XmlBeanFactory(new ClassPathResource("com/cdi/common/application-context.xml"));
		Team team = factory.getBean("team", Team.class);
		System.out.println(team);
		/*BusinessUnit businessUnit = factory.getBean("crmBusinessUnit", BusinessUnit.class);
		System.out.println(businessUnit);*/
	}
}
