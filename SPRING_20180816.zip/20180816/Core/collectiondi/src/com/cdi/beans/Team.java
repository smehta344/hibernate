package com.cdi.beans;

import java.util.List;
import java.util.Properties;
import java.util.Set;

public class Team {
	private String projectName;
	private List<String> members;
	private Set<String> tasks;
	private Properties assignedTasks;

	public Team(Set<String> tasks) {
		this.tasks = tasks;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public void setMembers(List<String> members) {
		this.members = members;
	}

	public void setAssignedTasks(Properties assignedTasks) {
		this.assignedTasks = assignedTasks;
	}

	@Override
	public String toString() {
		return "Team [projectName=" + projectName + ", members=" + members + ", tasks=" + tasks + ", assignedTasks="
				+ assignedTasks + "] List-Class : " + members.getClass().getName() + " Set-Class : "
				+ tasks.getClass().getName() + " Properties-Class : " + assignedTasks.getClass().getName();
	}

}
