package com.cdi.beans;

import java.util.Map;

public class BusinessUnit {
	private String domainName;
	private Map<String, Team> projects;

	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	public void setProjects(Map<String, Team> projects) {
		this.projects = projects;
	}

	@Override
	public String toString() {
		return "BusinessUnit [domainName=" + domainName + ", projects=" + projects + "]";
	}

}
