package com.innerbeans.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.innerbeans.beans.BiCycle;

public class InnerBeansTest {
	public static void main(String[] args) {
		BeanFactory factory = new XmlBeanFactory(
				new ClassPathResource("com/innerbeans/common/application-context.xml"));
		BiCycle biCycle = factory.getBean("biCycle", BiCycle.class);
		System.out.println(biCycle);
	}
}
