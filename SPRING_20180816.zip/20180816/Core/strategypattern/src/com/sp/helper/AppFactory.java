package com.sp.helper;

import java.io.IOException;
import java.util.Properties;

public class AppFactory {
	public static Object createObject(String lClassname)
			throws IOException, InstantiationException, IllegalAccessException, ClassNotFoundException {
		Properties props = null;
		String className = null;
		Object obj = null;

		props = new Properties();
		props.load(AppFactory.class.getClassLoader().getResourceAsStream("com\\sp\\common\\appClasses.properties"));
		className = props.getProperty(lClassname);
		obj = Class.forName(className).newInstance();

		return obj;
	}

}
