package com.sp.helper;

import com.sp.beans.HtmlMessageConverterImpl;
import com.sp.beans.IMessageConverter;
import com.sp.beans.PdfMessageConverterImpl;

public class MessageConverterFactory {
	public static IMessageConverter createMessageConverter(String type) {
		IMessageConverter messageConverter = null;
		if (type.equals("html")) {
			messageConverter = new HtmlMessageConverterImpl();
		} else if (type.equals("pdf")) {
			messageConverter = new PdfMessageConverterImpl();
		}
		return messageConverter;
	}

}
