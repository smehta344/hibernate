package com.sp.test;

import java.io.IOException;

import com.sp.beans.IMessageConverter;
import com.sp.beans.MessageWriter;
import com.sp.helper.AppFactory;

public class StrategyPatternTest {
	public static void main(String[] args)
			throws InstantiationException, IllegalAccessException, ClassNotFoundException, IOException {
		MessageWriter messageWriter = (MessageWriter) AppFactory.createObject("messageWriter.class");
		IMessageConverter messageConverter = (IMessageConverter) AppFactory.createObject("messageConverter.class");
		messageWriter.setMessageConverter(messageConverter);
		messageWriter.writeMessage("Welcome to Strategy Design Pattern");
	}
}
