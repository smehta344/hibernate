package com.bpp.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.config.ConfigurableListableBeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.bpp.beans.InstanceTrackerBeanPostProcessor;
import com.bpp.beans.Launcher;
import com.bpp.beans.Rocket;

public class BPPTest {
	public static void main(String[] args) {
		BeanFactory factory = new XmlBeanFactory(new ClassPathResource("com/bpp/common/application-context.xml"));
		InstanceTrackerBeanPostProcessor bpp = factory.getBean("instanceTrackerPostProcessor",
				InstanceTrackerBeanPostProcessor.class);

		((ConfigurableListableBeanFactory) factory).addBeanPostProcessor(bpp);

		Rocket rocket = factory.getBean("rocket", Rocket.class);
		System.out.println("instances : " + bpp.getInstances());
		Launcher launcher = factory.getBean("launcher", Launcher.class);
		System.out.println("instances : " + bpp.getInstances());
	}
}
