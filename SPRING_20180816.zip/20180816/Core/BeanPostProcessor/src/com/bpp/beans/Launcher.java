package com.bpp.beans;

public class Launcher {

}
