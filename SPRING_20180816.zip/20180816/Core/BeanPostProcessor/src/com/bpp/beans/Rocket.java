package com.bpp.beans;

public class Rocket {

}
