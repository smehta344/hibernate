package com.bpp.beans;

public class Station {

}
