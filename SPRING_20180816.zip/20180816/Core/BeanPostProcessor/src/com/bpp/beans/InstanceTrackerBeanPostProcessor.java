package com.bpp.beans;

import java.util.concurrent.atomic.AtomicInteger;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.config.BeanPostProcessor;

public class InstanceTrackerBeanPostProcessor implements BeanPostProcessor, InitializingBean {
	protected AtomicInteger instances;

	@Override
	public void afterPropertiesSet() throws Exception {
		instances = new AtomicInteger(0);
	}

	@Override
	public Object postProcessAfterInitialization(Object object, String bean) throws BeansException {
		instances.incrementAndGet();
		return object;
	}

	@Override
	public Object postProcessBeforeInitialization(Object object, String bean) throws BeansException {
		return object;
	}

	public int getInstances() {
		return instances.get();
	}

}
