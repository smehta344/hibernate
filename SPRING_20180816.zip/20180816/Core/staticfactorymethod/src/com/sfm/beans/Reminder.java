package com.sfm.beans;

import java.util.Calendar;

public class Reminder {
	private String description;
	private String action;
	private Calendar schedule;

	public void setDescription(String description) {
		this.description = description;
	}

	public void setAction(String action) {
		this.action = action;
	}

	public void setSchedule(Calendar schedule) {
		this.schedule = schedule;
	}

	@Override
	public String toString() {
		return "Reminder [description=" + description + ", action=" + action + ", schedule=" + schedule + "]";
	}

}
