package com.ss.test;

import org.springframework.core.io.ClassPathResource;

import com.ss.beans.MessageWriter;

import org.springframework.beans.factory.xml.XmlBeanFactory;

import org.springframework.beans.factory.BeanFactory;

public class SSTest {
	public static void main(String[] args) {
		BeanFactory factory = new XmlBeanFactory(new ClassPathResource("com/ss/common/application-context.xml"));
		MessageWriter writer = factory.getBean("messageWriter", MessageWriter.class);
		writer.writeMessage("welcome to spring");
	}
}
