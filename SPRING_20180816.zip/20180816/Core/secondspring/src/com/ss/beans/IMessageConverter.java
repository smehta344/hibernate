package com.ss.beans;

public interface IMessageConverter {
	String convert(String message);
}
