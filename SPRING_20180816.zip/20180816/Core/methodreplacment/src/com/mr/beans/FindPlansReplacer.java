package com.mr.beans;

import java.lang.reflect.Method;

import org.springframework.beans.factory.support.MethodReplacer;

public class FindPlansReplacer implements MethodReplacer {

	@Override
	public Object reimplement(Object target, Method method, Object[] args) throws Throwable {
		if (method.getName().equals("findPlans")) {
			int age = ((Integer) args[0]).intValue();
			System.out.println("age : " + age);
		}
		return new String[] { "localplan1", "localplan2" };
	}

}
