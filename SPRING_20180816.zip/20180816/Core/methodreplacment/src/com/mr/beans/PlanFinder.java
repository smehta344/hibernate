package com.mr.beans;

public class PlanFinder {
	public String[] findPlans(int age, String gender, int copay, int coverageType, int networkType) {
		return new String[] { "plan1", "plan2" };
	}
}
