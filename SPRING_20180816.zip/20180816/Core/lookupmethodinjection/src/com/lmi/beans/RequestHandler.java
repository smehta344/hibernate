package com.lmi.beans;

public class RequestHandler {
	private String data;

	public void process() {
		System.out.println("processing data :" + data + " hashCode : " + this.hashCode());
	}

	public void setData(String data) {
		this.data = data;
	}

}
