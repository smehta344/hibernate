package com.lmi.beans;

abstract public class Container {

	public void receive(String data) {
		RequestHandler handler = null;

		handler = lookupRequestHandler();
		handler.setData(data);
		handler.process();
	}

	abstract public RequestHandler lookupRequestHandler();
}
