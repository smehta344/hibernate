package com.pac.beans;

public class Toy {
	private int toyNo;
	private String toyName;
	private String description;
	private Manufacturer manufacturer;
	private String ageLimit;
	private float price;

	public void setToyNo(int toyNo) {
		this.toyNo = toyNo;
	}

	public void setToyName(String toyName) {
		this.toyName = toyName;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public void setManufacturer(Manufacturer manufacturer) {
		this.manufacturer = manufacturer;
	}

	public void setAgeLimit(String ageLimit) {
		this.ageLimit = ageLimit;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Toy [toyNo=" + toyNo + ", toyName=" + toyName + ", description=" + description + ", manufacturer="
				+ manufacturer + ", ageLimit=" + ageLimit + ", price=" + price + "]";
	}

}
