package com.pac.beans;

public class Manufacturer {
	private int manufacturerNo;
	private String manufacturerName;
	private String location;

	public Manufacturer(int manufacturerNo, String manufacturerName, String location) {
		this.manufacturerNo = manufacturerNo;
		this.manufacturerName = manufacturerName;
		this.location = location;
	}

	@Override
	public String toString() {
		return "Manufacturer [manufacturerNo=" + manufacturerNo + ", manufacturerName=" + manufacturerName
				+ ", location=" + location + "]";
	}

}
