package com.ba.beans;

public class Toy {
	private int id;
	private String toyName;

	public void setId(int id) {
		this.id = id;
	}

	public void setToyName(String toyName) {
		this.toyName = toyName;
	}

	@Override
	public String toString() {
		return "Toy [id=" + id + ", toyName=" + toyName + "]";
	}

}
