package com.beanscopes.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.beanscopes.beans.UnitsConverter;

public class BeanScopesTest {
	public static void main(String[] args) {
		BeanFactory factory = new XmlBeanFactory(
				new ClassPathResource("com/beanscopes/common/application-context.xml"));
		UnitsConverter unitsConverter1 = factory.getBean("unitsConverter", UnitsConverter.class);
		
		UnitsConverter unitsConverter2 = factory.getBean("unitsConverter", UnitsConverter.class);
		
		System.out.println("unitsConverter1 == unitsConverter2 ? : " + (unitsConverter1 == unitsConverter2));
	}
}













