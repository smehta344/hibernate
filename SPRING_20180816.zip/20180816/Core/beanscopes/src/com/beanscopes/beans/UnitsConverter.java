package com.beanscopes.beans;

public class UnitsConverter {
	public float cmToMeters(float centimeters) {
		return 84.34f;
	}
}
