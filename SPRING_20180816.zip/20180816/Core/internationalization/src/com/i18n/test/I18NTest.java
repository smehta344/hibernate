package com.i18n.test;

import java.util.Locale;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.MessageSource;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

public class I18NTest {
	public static void main(String[] args) {
//		BeanFactory factory = new XmlBeanFactory(new ClassPathResource("com/i18n/common/application-context.xml"));
//		MessageSource messageSource = factory.getBean("messageSource", MessageSource.class);
//		String message = messageSource.getMessage("welcome.message", null, Locale.SIMPLIFIED_CHINESE);
		ApplicationContext context = new ClassPathXmlApplicationContext("com/i18n/common/application-context.xml");

		String message = context.getMessage("welcome.message", null, "No Message", Locale.getDefault());
		System.out.println(message);

	}
}
