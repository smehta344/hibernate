package com.nestedbeanfactories.beans;

public class FuelTank {
	private String fuelTankType;
	private int capacity;

	public void setFuelTankType(String fuelTankType) {
		this.fuelTankType = fuelTankType;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	@Override
	public String toString() {
		return "FuelTank [fuelTankType=" + fuelTankType + ", capacity=" + capacity + "]";
	}

}
