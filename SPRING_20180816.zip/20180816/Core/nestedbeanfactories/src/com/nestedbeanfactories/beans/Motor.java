package com.nestedbeanfactories.beans;

public class Motor {
	private FuelTank fuelTank;

	public void setFuelTank(FuelTank fuelTank) {
		this.fuelTank = fuelTank;
	}

	@Override
	public String toString() {
		return "Motor [fuelTank=" + fuelTank + "]";
	}

}
