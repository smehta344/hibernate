package com.nestedbeanfactories.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.nestedbeanfactories.beans.Motor;

public class NestedBeanFactoriesTest {
	public static void main(String[] args) {
		// parent factory
		BeanFactory fuelTankFactory = new XmlBeanFactory(
				new ClassPathResource("com/nestedbeanfactories/common/fuel-tanks-beans.xml"));

		// child factory (nested bean factories)
		BeanFactory motorFactory = new XmlBeanFactory(
				new ClassPathResource("com/nestedbeanfactories/common/motor-beans.xml"), fuelTankFactory);

		Motor motor = motorFactory.getBean("motor", Motor.class);
		System.out.println(motor);
	}
}
