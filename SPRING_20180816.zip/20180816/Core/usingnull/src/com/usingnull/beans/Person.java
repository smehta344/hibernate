package com.usingnull.beans;

public class Person {
	private int ssn;
	private String fullName;
	private Address address;

	public Person(int ssn, Address address) {
		this.ssn = ssn;
		this.address = address;
	}

	public void setFullName(String fullName) {
		this.fullName = fullName;
	}

	@Override
	public String toString() {
		return "Person [ssn=" + ssn + ", fullName=" + fullName + ", address=" + address + "]";
	}

}
