package com.idref.beans;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

public class Car {
	private IEngine engine;
	private String manufacturer;

	public void drive() {
		BeanFactory factory = null;

		factory = new XmlBeanFactory(new ClassPathResource("com/idref/common/application-context.xml"));
		engine = factory.getBean(manufacturer, IEngine.class);

		engine.start();
		System.out.println("driving car");
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

}
