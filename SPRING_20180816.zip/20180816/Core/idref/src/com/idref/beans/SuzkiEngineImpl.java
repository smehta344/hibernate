package com.idref.beans;

public class SuzkiEngineImpl implements IEngine {

	@Override
	public void start() {
		System.out.println("suzki engine has been started");
	}

}
