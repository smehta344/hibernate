package com.idref.beans;

public interface IEngine {
	void start();
}
