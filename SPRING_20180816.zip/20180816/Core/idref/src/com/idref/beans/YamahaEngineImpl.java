package com.idref.beans;

public class YamahaEngineImpl implements IEngine {

	@Override
	public void start() {
		System.out.println("yamaha engine has been started");
	}

}
