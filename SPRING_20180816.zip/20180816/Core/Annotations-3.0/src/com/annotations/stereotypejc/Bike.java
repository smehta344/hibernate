package com.annotations.stereotypejc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

// source code
@Component
public class Bike {
	@Autowired
	private Tank tank;

	public void ride() {
		System.out.println("riding bike with " + tank);
	}
}
