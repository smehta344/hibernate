package com.annotations.stereotypexml;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

// source code
@Component
public class Motor {
	@Autowired
	private Tank tank;

	@Override
	public String toString() {
		return "Motor [tank=" + tank + "]";
	}

}
