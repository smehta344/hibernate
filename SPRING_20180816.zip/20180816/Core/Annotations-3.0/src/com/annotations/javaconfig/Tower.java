package com.annotations.javaconfig;

// no code - assumption
public class Tower {
	public void signal() {
		System.out.println("receiving...");
	}
}
