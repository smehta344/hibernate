package com.annotations.javaconfig;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

@Configuration
public class AppConfig {
	@Scope("prototype")
	@Lazy
	@Bean(name = { "tower1", "tower2" })
	public Tower tower() {
		System.out.println("tower()");
		return new Tower();
	}
}
