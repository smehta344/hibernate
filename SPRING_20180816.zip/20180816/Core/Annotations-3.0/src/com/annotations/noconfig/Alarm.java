package com.annotations.noconfig;

import org.springframework.stereotype.Component;

@Component
public class Alarm {
	public void buzz() {
		System.out.println("buzz...");
	}
}
