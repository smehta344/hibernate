package com.annotations.stereotype;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component("toy1")
@Lazy
public class Toy {

	public Toy() {
		System.out.println("Toy()");
	}

	public void play() {
		System.out.println("playing...");
	}
}
