package com.annotations.pi;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class PITest {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/annotations/pi/pi-beans.xml");
		Square square = context.getBean("square", Square.class);
		System.out.println("area : " + square.area());
	}
}
