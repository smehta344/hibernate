package com.annotations.pi;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

@Component
public class Square {
	@Value("#{beanValues.Square_side}")
	private double side;

	public double area() {
		return side * side;
	}

}
