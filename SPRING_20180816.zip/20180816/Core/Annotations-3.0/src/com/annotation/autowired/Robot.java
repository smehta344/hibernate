package com.annotation.autowired;

import javax.annotation.Resource;
import javax.inject.Named;

@Named
public class Robot {
	private Chip chip;

	@Resource(name = "amdChip")
	public void newRobot(Chip chip) {
		this.chip = chip;
	}

	public void setChip(Chip chip) {
		System.out.println("injectChip(chip)");
		this.chip = chip;
	}

	@Override
	public String toString() {
		return "Robot [chip=" + chip + "]";
	}

}
