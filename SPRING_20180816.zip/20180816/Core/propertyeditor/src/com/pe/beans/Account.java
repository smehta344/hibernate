package com.pe.beans;

import java.io.File;
import java.net.URL;
import java.util.Arrays;
import java.util.Date;

public class Account {
	private int accountNo;
	private String accountName;
	private File accountImage;
	private Date dob;
	private URL accountPage;
	private String[] friends;

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public void setAccountImage(File accountImage) {
		this.accountImage = accountImage;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public void setAccountPage(URL accountPage) {
		this.accountPage = accountPage;
	}

	public void setFriends(String[] friends) {
		this.friends = friends;
	}

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountName=" + accountName + ", accountImage=" + accountImage.exists()
				+ ", dob=" + dob + ", accountPage=" + accountPage.getHost() + ", friends=" + Arrays.toString(friends) + "]";
	}

}
