package com.ifm.beans;

import java.util.List;

import com.ifm.google.beans.GoogleLocationService;

public class MapRenderer {
	private GoogleLocationService googleLocationService;

	public void render(String source, String destination) {
		List<String> coordinates = null;
		coordinates = googleLocationService.getCoordinates(source, destination);
		for(String coordinate : coordinates) {
			System.out.println(coordinate);
		}
	}

	public void setGoogleLocationService(GoogleLocationService googleLocationService) {
		this.googleLocationService = googleLocationService;
	}

}
