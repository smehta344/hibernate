package com.ifm.beans;

import com.ifm.google.beans.GoogleIndiaLocationServiceImpl;

import com.ifm.google.beans.GoogleLocationService;
import com.ifm.google.beans.GoogleUSLocationServiceImpl;

public class GoogleServiceLocator {
	public GoogleLocationService locateIndiaGoogleLocationService() {
		return new GoogleIndiaLocationServiceImpl();
	}

	public GoogleLocationService locateUSGoogleLocationService() {
		return new GoogleUSLocationServiceImpl();
	}
}
