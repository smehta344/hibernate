package com.ifm.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.ifm.beans.MapRenderer;

public class IFMTest {
	public static void main(String[] args) {
		BeanFactory factory = new XmlBeanFactory(new ClassPathResource("com/ifm/common/application-context.xml"));
		MapRenderer mapRenderer = factory.getBean("mapRenderer", MapRenderer.class);
		mapRenderer.render("hyderbad", "chennai");
	}
}
