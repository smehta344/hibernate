package com.ifm.google.beans;

import java.util.List;

public interface GoogleLocationService {
	List<String> getCoordinates(String source, String destination);
}
