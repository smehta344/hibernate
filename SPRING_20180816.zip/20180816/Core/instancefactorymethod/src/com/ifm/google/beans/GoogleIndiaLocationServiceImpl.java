package com.ifm.google.beans;

import java.util.Arrays;
import java.util.List;

public class GoogleIndiaLocationServiceImpl implements GoogleLocationService {

	@Override
	public List<String> getCoordinates(String source, String destination) {
		return Arrays.asList(new String[] { "(83,39)", "(25,45)" });
	}

}
