package com.ifm.google.beans;

import java.util.Arrays;
import java.util.List;

public class GoogleUSLocationServiceImpl implements GoogleLocationService {

	@Override
	public List<String> getCoordinates(String source, String destination) {
		return Arrays.asList(new String[] { "(89,49)", "(28,27)", "(98,84)" });
	}

}
