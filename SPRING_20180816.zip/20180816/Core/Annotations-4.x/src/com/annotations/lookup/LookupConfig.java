package com.annotations.lookup;

import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Scope;

@Configuration
public class LookupConfig implements ApplicationContextAware {
	private ApplicationContext context;

	@Bean
	@Scope("prototype")
	public RequestHandler requestHandler() {
		return new RequestHandler();
	}

	@Bean
	public Container container() {
		return new Container() {
			@Override
			public RequestHandler lookupRequestHandler() {
				return context.getBean("requestHandler", RequestHandler.class);
			}
		};
	}

	@Override
	public void setApplicationContext(ApplicationContext context) throws BeansException {
		this.context = context;
	}

}
