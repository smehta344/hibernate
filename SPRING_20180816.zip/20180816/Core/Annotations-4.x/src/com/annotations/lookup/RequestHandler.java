package com.annotations.lookup;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;

@Component
@Scope("prototype")
public class RequestHandler {
	private String data;

	public void process() {
		System.out.println("processing : " + data + " hashCode : " + this.hashCode());
	}

	public void setData(String data) {
		this.data = data;
	}

}
