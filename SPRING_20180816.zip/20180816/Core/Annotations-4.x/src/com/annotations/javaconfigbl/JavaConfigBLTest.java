package com.annotations.javaconfigbl;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;

public class JavaConfigBLTest {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(BLJavaConfig.class);
		((ConfigurableApplicationContext)context).registerShutdownHook();
		Calculator calculator = context.getBean("calculator", Calculator.class);
		System.out.println(calculator);
	}
}
