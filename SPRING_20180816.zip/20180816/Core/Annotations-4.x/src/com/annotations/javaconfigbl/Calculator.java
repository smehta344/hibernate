package com.annotations.javaconfigbl;

// no source code
public class Calculator {
	private int a;
	private int b;
	private int sum;

	public Calculator(int a) {
		this.a = a;
	}

	public void setB(int b) {
		this.b = b;
	}

	public void init() {
		this.sum = this.a + this.b;
	}

	public void release() {
		System.out.println("released...");
	}

	@Override
	public String toString() {
		return "Calculator [a=" + a + ", b=" + b + ", sum=" + sum + "]";
	}

}
