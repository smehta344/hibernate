package com.annotations.javaconfigbl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

@Configuration
@PropertySource("classpath:com/annotations/javaconfigbl/calc.properties")
public class BLJavaConfig {
	@Autowired
	private Environment env;

	@Bean(initMethod = "init", destroyMethod = "release")
	public Calculator calculator() {
		int a = 0;
		int b = 0;
		Calculator calculator = null;

		a = Integer.parseInt(env.getProperty("a"));
		b = Integer.parseInt(env.getProperty("b"));
		calculator = new Calculator(a);
		calculator.setB(b);
		return calculator;
	}
}
