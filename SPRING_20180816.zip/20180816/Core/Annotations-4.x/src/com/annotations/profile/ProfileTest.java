package com.annotations.profile;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ProfileTest {
	public static void main(String[] args) {
		System.setProperty("spring.profiles.active", "dev");
		ApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);
		//((AnnotationConfigApplicationContext)context).getEnvironment().setActiveProfiles("test");
		//((AnnotationConfigApplicationContext)context).refresh();
		
		DataSource dataSource = context.getBean("dataSource", DataSource.class);
		System.out.println(dataSource);
	}
}
