package com.annotations.profile;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;

public class BaseConfig {
	@Autowired
	private Environment env;

	@Bean
	public DataSource dataSource() {
		DataSource dataSource = null;

		dataSource = new DataSource();
		dataSource.setDriverClassname(env.getProperty("driverClassName"));
		dataSource.setUrl(env.getProperty("url"));
		dataSource.setUsername(env.getProperty("username"));
		dataSource.setPassword(env.getProperty("password"));

		return dataSource;
	}
}
