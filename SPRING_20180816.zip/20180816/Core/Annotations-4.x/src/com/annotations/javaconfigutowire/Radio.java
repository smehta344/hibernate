package com.annotations.javaconfigutowire;

// no code
public class Radio {
	private Station station;

	public void setStation(Station station) {
		this.station = station;
	}

	@Override
	public String toString() {
		return "Radio [station=" + station + "]";
	}

}
