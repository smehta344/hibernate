package com.annotations.javaconfigutowire;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

// source code
@Component
@PropertySource("classpath:com/annotations/javaconfigutowire/station.properties")
public class Station {
	@Value("${frequency}")
	private float frequency;
	@Value("${stationName}")
	private String stationName;

	@Override
	public String toString() {
		return "Station [frequency=" + frequency + ", stationName=" + stationName + "]";
	}

}
