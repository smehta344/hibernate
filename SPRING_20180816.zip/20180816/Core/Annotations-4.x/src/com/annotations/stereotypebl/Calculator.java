package com.annotations.stereotypebl;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.PropertySource;
import org.springframework.stereotype.Component;

@Component
@PropertySource("classpath:com/annotations/stereotypebl/calculator.properties")
public class Calculator {
	@Value("${a}")
	private int a;
	@Value("${b}")
	private int b;
	private int sum;

	@PostConstruct
	public void init() {
		this.sum = this.a + this.b;
	}

	@PreDestroy
	public void release() {
		System.out.println("cleaned...");
	}

	@Override
	public String toString() {
		return "Calculator [a=" + a + ", b=" + b + ", sum=" + sum + "]";
	}

}
