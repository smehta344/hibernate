package com.annotations.stereotypejc;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
// enables bean post processors
@ComponentScan(basePackages = { "com.annotations.stereotypejc" })
public class StereotypeJCConfig {

	@Bean
	public Tank tank() {
		Tank tank = null;
		tank = new Tank();
		tank.setCapacity(10);
		tank.setFuelType("diesel");
		return tank;
	}
}
