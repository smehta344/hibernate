package com.annotations.imp;

import org.springframework.beans.factory.annotation.Autowire;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class BankConfig {

	@Bean(autowire = Autowire.BY_TYPE)
	public Bank bank() {
		Bank bank = null;
		bank = new Bank();
		return bank;
	}
}
