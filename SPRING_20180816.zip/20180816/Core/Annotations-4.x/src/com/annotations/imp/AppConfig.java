package com.annotations.imp;

import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;

@Configuration
@Import({ AccountsConfig.class, BankConfig.class })
public class AppConfig {

}
