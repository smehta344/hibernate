package com.annotations.imp;

public class Account {
	private int accountNo;
	private String accountHolderName;
	private String accountType;

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountHolderName=" + accountHolderName + ", accountType="
				+ accountType + "]";
	}

}
