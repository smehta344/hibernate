package com.annotations.imp;

public class Bank {
	private Account account;

	public void setAccount(Account account) {
		this.account = account;
	}

	@Override
	public String toString() {
		return "Bank [account=" + account + "]";
	}

}
