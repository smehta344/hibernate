package com.annotations.imp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

@Configuration
@PropertySource("classpath:com/annotations/imp/accounts.properties")
public class AccountsConfig {
	@Autowired
	private Environment env;

	@Bean
	public Account susanAccount() {
		Account account = null;
		account = new Account();
		account.setAccountNo(Integer.parseInt(env.getProperty("accountNo")));
		account.setAccountHolderName(env.getProperty("accountHolderName"));
		account.setAccountType(env.getProperty("accountType"));

		return account;
	}
}
