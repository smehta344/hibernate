package com.annotations.dependson;

import org.springframework.stereotype.Component;

@Component
public class LoanCalculator {

	public LoanCalculator() {
		System.out.println("LoanCalculator()");
	}

}
