package com.annotations.javaconfigpri;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class PriTest {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(PriJavaConfig.class);
		Ticket ticket = context.getBean("ticket", Ticket.class);
		System.out.println(ticket);
	}
}
