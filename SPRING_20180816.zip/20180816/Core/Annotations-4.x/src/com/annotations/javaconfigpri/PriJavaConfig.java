package com.annotations.javaconfigpri;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;
import org.springframework.context.annotation.PropertySources;
import org.springframework.core.env.Environment;

@Configuration
@PropertySources({ @PropertySource("classpath:com/annotations/javaconfigpri/app.properties") })
public class PriJavaConfig {
	@Autowired
	private Environment env;

	@Bean
	public Ticket ticket() {
		Ticket ticket = null;
		ticket = new Ticket();
		ticket.setTicketNo(Integer.parseInt(env.getProperty("ticketNo")));
		ticket.setFlightName(env.getProperty("flightName"));

		return ticket;
	}
}





