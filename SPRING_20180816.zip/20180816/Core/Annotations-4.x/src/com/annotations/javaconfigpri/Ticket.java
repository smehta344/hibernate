package com.annotations.javaconfigpri;

// no source code
public class Ticket {
	private int ticketNo;
	private String flightName;

	public void setTicketNo(int ticketNo) {
		this.ticketNo = ticketNo;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	@Override
	public String toString() {
		return "Ticket [ticketNo=" + ticketNo + ", flightName=" + flightName + "]";
	}

}
