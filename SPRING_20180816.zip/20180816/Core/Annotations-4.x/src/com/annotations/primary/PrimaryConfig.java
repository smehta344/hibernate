package com.annotations.primary;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

@Configuration
@PropertySource("classpath:com/annotations/primary/chip.properties")
@ComponentScan(basePackages = { "com.annotations.primary" })
public class PrimaryConfig {
	@Autowired
	private Environment env;

	@Bean
	@Primary
	public Chip intelChip() {
		Chip chip = null;
		chip = new Chip();
		chip.setId(Integer.parseInt(env.getProperty("intelId")));
		chip.setChipType(env.getProperty("intelChipType"));
		return chip;
	}

	@Bean
	public Chip amdChip() {
		Chip chip = null;
		chip = new Chip();
		chip.setId(Integer.parseInt(env.getProperty("amdId")));
		chip.setChipType(env.getProperty("amdChipType"));
		return chip;
	}

}
