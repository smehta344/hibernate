package com.ai.beans;

public class SuzkiEngineImpl implements IEngine {

	@Override
	public void start() {
		System.out.println("suzki engine started...");
	}

}
