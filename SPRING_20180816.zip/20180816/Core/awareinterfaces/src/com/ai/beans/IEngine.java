package com.ai.beans;

public interface IEngine {
	void start();
}
