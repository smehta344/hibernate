package com.ai.beans;

import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.BeanFactoryAware;

public class Car implements BeanFactoryAware {
	private IEngine engine;
	private String engineName;
	private BeanFactory factory;

	public Car(String engineName) {
		System.out.println("car(..)");
		this.engineName = engineName;
	}

	public void drive() {
		engine = factory.getBean(engineName, IEngine.class);
		engine.start();
		System.out.println("driving...");
	}

	@Override
	public void setBeanFactory(BeanFactory factory) throws BeansException {
		System.out.println("setBeanFactory(..)");
		this.factory = factory;
	}

}
