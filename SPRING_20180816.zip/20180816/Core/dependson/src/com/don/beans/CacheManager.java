package com.don.beans;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class CacheManager {
	private Cache cache;
	private List<Accessor> accessors;

	public CacheManager(Cache cache, List<Accessor> accessors) throws Exception {
		super();
		this.cache = cache;
		this.accessors = accessors;
		load();
	}

	public void load() throws Exception {
		Map<String, Object> dataMap = null;

		dataMap = new HashMap<>();

		for (Accessor accessor : accessors) {
			dataMap.put(accessor.getDataKey(), accessor.getData());
		}
		cache.load(dataMap);
	}
}
