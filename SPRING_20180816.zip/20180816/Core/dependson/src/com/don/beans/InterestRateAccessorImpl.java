package com.don.beans;

import java.io.IOException;
import java.util.Properties;

public class InterestRateAccessorImpl extends AbstractAccessor {

	public InterestRateAccessorImpl(String dataKey) {
		super(dataKey);
	}

	@Override
	public Object getData() throws IOException {
		Properties props = null;
		props = new Properties();
		props.load(this.getClass().getClassLoader().getResourceAsStream("interestrate.properties"));

		return props;
	}

}
