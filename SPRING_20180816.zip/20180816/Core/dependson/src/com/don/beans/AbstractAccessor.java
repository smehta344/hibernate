package com.don.beans;

abstract public class AbstractAccessor implements Accessor {
	protected String dataKey;

	public AbstractAccessor(String dataKey) {
		super();
		this.dataKey = dataKey;
	}

	@Override
	public String getDataKey() {
		return dataKey;
	}
}
