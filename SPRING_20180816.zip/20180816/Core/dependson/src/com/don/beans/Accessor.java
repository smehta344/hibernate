package com.don.beans;

public interface Accessor {
	String getDataKey();

	Object getData() throws Exception;
}
