package com.don.beans;

import java.util.Properties;

public class PersonalLoanCalculator {
	private Cache cache;

	public double calculate(double principle, int tenure, String profession, String place) {
		Properties props = null;
		double interestRate = 0;
		double totalAmount = 0;
		double interestAmount = 0;

		props = (Properties) cache.get("interestRate");
		interestRate = Double.parseDouble(props.getProperty(place));
		interestAmount = (principle * tenure * interestRate) / 100;
		totalAmount = principle + interestAmount;
		return totalAmount;
	}

	public void setCache(Cache cache) {
		this.cache = cache;
	}

}
