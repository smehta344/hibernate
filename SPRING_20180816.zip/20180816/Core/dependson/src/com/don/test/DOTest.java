package com.don.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.don.beans.PersonalLoanCalculator;

public class DOTest {
	public static void main(String[] args) {
		BeanFactory factory = new XmlBeanFactory(new ClassPathResource("com/don/common/application-context.xml"));
		PersonalLoanCalculator plc = factory.getBean("pLoanCalculator", PersonalLoanCalculator.class);
		double ta = plc.calculate(100000, 12, "salaried", "hyderabad");
		System.out.println("total amount : " + ta);
	}
}
