package com.di.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.di.beans.Assistant;

public class DepedencyInjectionTest {
	public static void main(String[] args) {
		BeanFactory factory = new XmlBeanFactory(new ClassPathResource("com/di/common/application-context.xml"));
		Assistant assistant = factory.getBean("assistant", Assistant.class);
		assistant.help("good morning");
	}
}
