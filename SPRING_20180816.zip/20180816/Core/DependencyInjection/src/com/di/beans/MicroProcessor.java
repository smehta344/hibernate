package com.di.beans;

public class MicroProcessor {

	public MicroProcessor() {
		System.out.println("MicroProcessor()");
	}

	public String process(String voiceCommand) {
		String message = null;

		if (voiceCommand.equals("hello")) {
			message = "Hello! How are you?";
		} else if (voiceCommand.equals("good morning")) {
			message = "Good Morning! Have a nice day!";
		}
		return message;
	}

}
