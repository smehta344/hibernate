package com.di.beans;

public class Assistant {
	private MicroProcessor microProcessor;

	public Assistant(MicroProcessor microProcessor) {
		System.out.println("Assistant(MicroProcessor)");
		this.microProcessor = microProcessor;
	}

	public void help(String voiceCommand) {
		String message = null;

		message = microProcessor.process(voiceCommand);
		System.out.println(message);
	}

}
