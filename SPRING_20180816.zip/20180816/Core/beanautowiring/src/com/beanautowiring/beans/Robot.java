package com.beanautowiring.beans;

public class Robot {
	private MicroProcessor microProcessor;
	private Sensor sensor;

	public Robot(MicroProcessor microProcessor) {
		this.microProcessor = microProcessor;
	}

	public Robot(Sensor sensor) {
		this.sensor = sensor;
	}

	@Override
	public String toString() {
		return "Robot [microProcessor=" + microProcessor + ", sensor=" + sensor + "]";
	}

}
