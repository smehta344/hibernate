package com.ci.beans;

public class House {
	private int houseNo;
	private String color;
	private float sqft;

	public House(String color, int houseNo) {
		this.color = color;
		this.houseNo = houseNo;
	}

	public House(float sqft, String color) {
		this.sqft = sqft;
		this.color = color;
	}

	@Override
	public String toString() {
		return "House [houseNo=" + houseNo + ", color=" + color + ", sqft=" + sqft + "]";
	}

}
