package com.ci.beans;

import java.beans.ConstructorProperties;

public class JetPro {
	private int fuelCapacity;
	private String engineType;
	private float threshold;
	private double distance;
	private long height;

	@ConstructorProperties({ "engineType", "fuelCapacity", "distance" })
	public JetPro(String engineType, int fuelCapacity, double distance) {
		this.engineType = engineType;
		this.fuelCapacity = fuelCapacity;
		this.distance = distance;
	}

	@ConstructorProperties({ "threshold", "engineType", "fuelCapacity" })
	public JetPro(float threshold, String engineType, int fuelCapacity) {
		this.threshold = threshold;
		this.engineType = engineType;
		this.fuelCapacity = fuelCapacity;
	}

	@ConstructorProperties({ "engineType", "height", "threshold" })
	public JetPro(String engineType, long height, float threshold) {
		this.engineType = engineType;
		this.height = height;
		this.threshold = threshold;
	}

	@Override
	public String toString() {
		return "JetPro [fuelCapacity=" + fuelCapacity + ", engineType=" + engineType + ", threshold=" + threshold
				+ ", distance=" + distance + ", height=" + height + "]";
	}

}
