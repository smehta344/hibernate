package com.ci.beans;

public class Jet {
	private String engineType;
	private int fuelCapacity;

	public Jet(String engineType) {
		this.engineType = engineType;
	}

	public Jet(int fuelCapacity) {
		this.fuelCapacity = fuelCapacity;
	}

	@Override
	public String toString() {
		return "Jet [engineType=" + engineType + ", fuelCapacity=" + fuelCapacity + "]";
	}

}
