package com.ci.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.ci.beans.House;
import com.ci.beans.Jet;
import com.ci.beans.JetPro;

public class CITest {
	public static void main(String[] args) {
		BeanFactory factory = new XmlBeanFactory(new ClassPathResource("com/ci/common/application-context.xml"));
		/*Jet jet = factory.getBean("jet", Jet.class);
		System.out.println(jet);*/
		/*House house = factory.getBean("house", House.class);
		System.out.println(house);*/
		JetPro jetPro = factory.getBean("jetPro", JetPro.class);
		System.out.println(jetPro);
	}
}
