package com.collectionmerging.beans;

import java.util.List;

public class Course {
	private String courseName;
	private List<String> subjects;

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public void setSubjects(List<String> subjects) {
		this.subjects = subjects;
	}

	@Override
	public String toString() {
		return "Course [courseName=" + courseName + ", subjects=" + subjects + "]";
	}

}
