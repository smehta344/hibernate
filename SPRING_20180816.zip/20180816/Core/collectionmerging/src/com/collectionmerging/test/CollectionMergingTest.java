package com.collectionmerging.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.collectionmerging.beans.Course;

public class CollectionMergingTest {
	public static void main(String[] args) {
		BeanFactory factory = new XmlBeanFactory(
				new ClassPathResource("com/collectionmerging/common/application-context.xml"));
		Course course = factory.getBean("course2", Course.class);
		System.out.println(course);
	}
}
