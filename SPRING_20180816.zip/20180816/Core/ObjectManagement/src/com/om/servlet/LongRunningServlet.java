package com.om.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LongRunningServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		int hashCode = 0;
		PrintWriter out = null;

		hashCode = this.hashCode();
		out = resp.getWriter();
		for (int i = 1; i < 10000; i++) {
			out.print("Agent : " + hashCode + " i : " + i);
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			out.flush();
		}
		out.close();
	}
}
