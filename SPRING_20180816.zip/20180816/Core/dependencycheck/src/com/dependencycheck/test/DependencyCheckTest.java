package com.dependencycheck.test;

import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.core.io.ClassPathResource;

import com.dependencycheck.beans.Motor;

public class DependencyCheckTest {
	public static void main(String[] args) {
		BeanFactory factory = new XmlBeanFactory(
				new ClassPathResource("com/dependencycheck/common/application-context.xml"));
		Motor motor = (Motor) factory.getBean("motor");
		System.out.println(motor);
	}
}
