package com.dependencycheck.beans;

public class Motor {
	private int motorNo;
	private String direction;
	private String motorType;
	private int power;
	private Switch motorSwitch;

	public Motor() {
		System.out.println("motor()");
	}

	public void setMotorNo(int motorNo) {
		this.motorNo = motorNo;
	}

	public void setDirection(String direction) {
		this.direction = direction;
	}

	public void setMotorType(String motorType) {
		this.motorType = motorType;
	}

	public void setPower(int power) {
		this.power = power;
	}

	public void setMotorSwitch(Switch motorSwitch) {
		this.motorSwitch = motorSwitch;
	}

	@Override
	public String toString() {
		return "Motor [motorNo=" + motorNo + ", direction=" + direction + ", motorType=" + motorType + ", power="
				+ power + ", motorSwitch=" + motorSwitch + "]";
	}

}
