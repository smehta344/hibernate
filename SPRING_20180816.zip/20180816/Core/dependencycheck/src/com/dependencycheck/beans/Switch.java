package com.dependencycheck.beans;

public class Switch {
	private boolean automaticMode;
	private float maxCapacity;

	public void setAutomaticMode(boolean automaticMode) {
		this.automaticMode = automaticMode;
	}

	public void setMaxCapacity(float maxCapacity) {
		this.maxCapacity = maxCapacity;
	}

	@Override
	public String toString() {
		return "Switch [automaticMode=" + automaticMode + ", maxCapacity=" + maxCapacity + "]";
	}

}
