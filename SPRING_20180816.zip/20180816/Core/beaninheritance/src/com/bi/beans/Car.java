package com.bi.beans;

import java.beans.ConstructorProperties;

public class Car {
	private int id;
	private String model;
	private String manufacturer;
	private String color;
	private String fuelType;
	private float mileage;
	private float price;

	@ConstructorProperties({ "id", "model", "manufacturer", "color", "fuelType", "mileage", "price" })
	public Car(int id, String model, String manufacturer, String color, String fuelType, float mileage, float price) {
		this.id = id;
		this.model = model;
		this.manufacturer = manufacturer;
		this.color = color;
		this.fuelType = fuelType;
		this.mileage = mileage;
		this.price = price;
	}

	@Override
	public String toString() {
		return "Car [id=" + id + ", model=" + model + ", manufacturer=" + manufacturer + ", color=" + color
				+ ", fuelType=" + fuelType + ", mileage=" + mileage + ", price=" + price + "]";
	}

}
