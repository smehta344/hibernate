package com.bi.beans;

public class Bus {
	private int id;
	private String model;
	private String manufacturer;
	private String color;
	private String fuelType;
	private float mileage;
	private float price;
	private int capacity;

	public void setId(int id) {
		this.id = id;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public void setColor(String color) {
		this.color = color;
	}

	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}

	public void setMileage(float mileage) {
		this.mileage = mileage;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public void setCapacity(int capacity) {
		this.capacity = capacity;
	}

	@Override
	public String toString() {
		return "Bus [id=" + id + ", model=" + model + ", manufacturer=" + manufacturer + ", color=" + color
				+ ", fuelType=" + fuelType + ", mileage=" + mileage + ", price=" + price + ", capacity=" + capacity
				+ "]";
	}

}
