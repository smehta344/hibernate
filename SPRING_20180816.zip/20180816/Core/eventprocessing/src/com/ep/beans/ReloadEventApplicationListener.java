package com.ep.beans;

import org.springframework.context.ApplicationListener;

public class ReloadEventApplicationListener implements ApplicationListener<ReloadCacheEvent> {

	@Override
	public void onApplicationEvent(ReloadCacheEvent event) {
		System.out.println("Reloading data for table : " + event.getTableName());
	}

}
