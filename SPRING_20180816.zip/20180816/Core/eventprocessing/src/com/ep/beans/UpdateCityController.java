package com.ep.beans;

import org.springframework.context.ApplicationEventPublisher;
import org.springframework.context.ApplicationEventPublisherAware;

public class UpdateCityController implements ApplicationEventPublisherAware {
	private ApplicationEventPublisher publisher;

	public void updateCity(int cityId, String cityName) {
		ReloadCacheEvent event = null;

		System.out.println("storing data into database");
		event = new ReloadCacheEvent(this);
		event.setTableName("cities");
		publisher.publishEvent(event);
	}

	@Override
	public void setApplicationEventPublisher(ApplicationEventPublisher publisher) {
		this.publisher = publisher;
	}

}
