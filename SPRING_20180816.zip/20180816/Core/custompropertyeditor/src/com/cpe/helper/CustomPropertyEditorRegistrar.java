package com.cpe.helper;

import org.springframework.beans.PropertyEditorRegistrar;
import org.springframework.beans.PropertyEditorRegistry;

import com.cpe.beans.Coordinate;
import com.cpe.beans.CoordinatePropertyEditor;

public class CustomPropertyEditorRegistrar implements PropertyEditorRegistrar {

	@Override
	public void registerCustomEditors(PropertyEditorRegistry registry) {
		registry.registerCustomEditor(Coordinate.class, new CoordinatePropertyEditor());
	}

}
