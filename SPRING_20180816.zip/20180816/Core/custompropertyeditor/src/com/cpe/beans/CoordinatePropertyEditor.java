package com.cpe.beans;

import java.beans.PropertyEditorSupport;

public class CoordinatePropertyEditor extends PropertyEditorSupport {

	@Override
	public void setAsText(String text) throws IllegalArgumentException {
		Coordinate coordinate = null;
		double xCoordinate = 0;
		double yCoordinate = 0;
		String[] tokens = null;

		tokens = text.split(",");
		xCoordinate = Double.parseDouble(tokens[0]);
		yCoordinate = Double.parseDouble(tokens[1]);
		coordinate = new Coordinate();
		coordinate.setxCoordinate(xCoordinate);
		coordinate.setyCoordinate(yCoordinate);
		super.setValue(coordinate);
	}

}
