package com.cpe.beans;

public class TrafficAdvisor {
	private Coordinate sourceCoordinate;
	private Coordinate destinationCoordinate;
	private String transportMode;

	public void setSourceCoordinate(Coordinate sourceCoordinate) {
		this.sourceCoordinate = sourceCoordinate;
	}

	public void setDestinationCoordinate(Coordinate destinationCoordinate) {
		this.destinationCoordinate = destinationCoordinate;
	}

	public void setTransportMode(String transportMode) {
		this.transportMode = transportMode;
	}

	@Override
	public String toString() {
		return "TrafficAdvisor [sourceCoordinate=" + sourceCoordinate + ", destinationCoordinate="
				+ destinationCoordinate + ", transportMode=" + transportMode + "]";
	}

}
