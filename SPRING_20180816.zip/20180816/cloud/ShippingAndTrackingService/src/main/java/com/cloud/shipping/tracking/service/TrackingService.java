package com.cloud.shipping.tracking.service;

import java.util.Date;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cloud.shipping.tracking.dto.TrackingStatus;

@RestController
public class TrackingService {

	@GetMapping(value = "/track/{orderNo}", produces = { "application/json" })
	public TrackingStatus getOrderStatus(@PathVariable("orderNo") String orderNo) {
		TrackingStatus trackingStatus = null;

		trackingStatus = new TrackingStatus(orderNo, new Date(), "Madhapur Hub", new Date(), "in-transit");
		return trackingStatus;
	}

}
