package com.cloud.shipping.tracking.dto;

import java.util.Date;

public class TrackingStatus {
	protected String orderNo;
	protected Date shippedDate;
	protected String location;
	protected Date expectedDeliveryDate;
	protected String status;

	public TrackingStatus(String orderNo, Date shippedDate, String location, Date expectedDeliveryDate, String status) {
		super();
		this.orderNo = orderNo;
		this.shippedDate = shippedDate;
		this.location = location;
		this.expectedDeliveryDate = expectedDeliveryDate;
		this.status = status;
	}

	public String getOrderNo() {
		return orderNo;
	}

	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}

	public Date getShippedDate() {
		return shippedDate;
	}

	public void setShippedDate(Date shippedDate) {
		this.shippedDate = shippedDate;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Date getExpectedDeliveryDate() {
		return expectedDeliveryDate;
	}

	public void setExpectedDeliveryDate(Date expectedDeliveryDate) {
		this.expectedDeliveryDate = expectedDeliveryDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
