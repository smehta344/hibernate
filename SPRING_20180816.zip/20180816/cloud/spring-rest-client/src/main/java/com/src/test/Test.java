package com.src.test;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.src.config.RootConfig;
import com.src.dto.CabRequest;
import com.src.dto.Ride;
import com.src.endpoints.CabServiceEndpoint;

public class Test {
	public static void main(String[] args) {
		ApplicationContext context = new AnnotationConfigApplicationContext(RootConfig.class);
		CabServiceEndpoint cabServiceEndpoint = context.getBean("cabServiceEndpoint", CabServiceEndpoint.class);
		CabRequest cabRequest = new CabRequest("ameerpet", "secunderabad", "share");

		Ride ride = cabServiceEndpoint.bookRide(cabRequest);
		System.out.println(ride);
	}
}
