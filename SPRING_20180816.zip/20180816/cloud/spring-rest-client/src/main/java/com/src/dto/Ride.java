package com.src.dto;

public class Ride {
	protected String rideNo;
	protected String driverName;
	protected String cabRegistrationNo;
	protected double estimatedAmount;

	public String getRideNo() {
		return rideNo;
	}

	public void setRideNo(String rideNo) {
		this.rideNo = rideNo;
	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public String getCabRegistrationNo() {
		return cabRegistrationNo;
	}

	public void setCabRegistrationNo(String cabRegistrationNo) {
		this.cabRegistrationNo = cabRegistrationNo;
	}

	public double getEstimatedAmount() {
		return estimatedAmount;
	}

	public void setEstimatedAmount(double estimatedAmount) {
		this.estimatedAmount = estimatedAmount;
	}

	@Override
	public String toString() {
		return "Ride [rideNo=" + rideNo + ", driverName=" + driverName + ", cabRegistrationNo=" + cabRegistrationNo
				+ ", estimatedAmount=" + estimatedAmount + "]";
	}

}
