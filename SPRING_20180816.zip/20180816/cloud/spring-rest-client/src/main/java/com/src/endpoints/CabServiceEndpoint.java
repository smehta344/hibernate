package com.src.endpoints;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.src.dto.CabRequest;
import com.src.dto.Ride;

@Component
public class CabServiceEndpoint {
	@Autowired
	private RestTemplate restTemplate;

	public Ride bookRide(CabRequest cabRequest) {
		Ride ride = null;
		ResponseEntity<Ride> responseEntity = null;

		responseEntity = restTemplate.postForEntity("http://localhost:8081/spring-rest/ride", cabRequest, Ride.class);
		ride = responseEntity.getBody();

		return ride;
	}
}










