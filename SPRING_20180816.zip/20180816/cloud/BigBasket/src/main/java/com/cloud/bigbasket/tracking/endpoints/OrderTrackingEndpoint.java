package com.cloud.bigbasket.tracking.endpoints;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import com.cloud.bigbasket.tracking.dto.TrackingStatus;

@Component
public class OrderTrackingEndpoint {
	@Autowired
	private RestTemplate restTemplate;

	public TrackingStatus getOrderStatus(String orderNo) {
		TrackingStatus trackingStatus = null;

		trackingStatus = restTemplate.getForObject("http://SHIPPING-AND-TRACKING:8088/track/" + orderNo,
				TrackingStatus.class);

		return trackingStatus;
	}
}
