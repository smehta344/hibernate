package com.sr.rest.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.sr.dto.CabRequest;
import com.sr.dto.Ride;

@RestController
public class CabService {
	@PostMapping(value = "/ride", consumes = { "application/json" }, produces = { "application/json" })
	public ResponseEntity<Ride> bookCab(@RequestBody CabRequest cabRequest) {
		ResponseEntity<Ride> responseEntity = null;
		Ride ride = null;

		System.out.println("source :" + cabRequest.getSource());
		ride = new Ride("r0393", "mathew", "abc0303", 393);
		responseEntity = ResponseEntity.status(HttpStatus.ACCEPTED).body(ride);

		return responseEntity;
	}

}
