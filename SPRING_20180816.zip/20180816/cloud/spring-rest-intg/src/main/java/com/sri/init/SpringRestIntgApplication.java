package com.sri.init;

import java.util.HashSet;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;
import javax.ws.rs.core.Context;

import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

@ApplicationPath("/services")
public class SpringRestIntgApplication extends Application {
	private Set<Object> singletons;

	public SpringRestIntgApplication(@Context ServletContext servletContext) {
		ApplicationContext context = null;

		singletons = new HashSet<>();
		context = WebApplicationContextUtils.getRequiredWebApplicationContext(servletContext);
		String[] beanNames = context.getBeanDefinitionNames();
		for (String beanName : beanNames) {
			if (beanName.endsWith("Resource")) {
				Object obj = context.getBean(beanName);
				singletons.add(obj);
			}
		}
	}

	@Override
	public Set<Object> getSingletons() {
		return singletons;
	}

}
