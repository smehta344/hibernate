package com.sri.dto;

import java.util.Date;

public class Policy {
	protected int policyNo;
	protected String policyName;
	protected String policyHolderName;
	protected Date effectiveDate;
	protected Date endDate;
	protected double sumInsurred;

	public Policy(int policyNo, String policyName, String policyHolderName, Date effectiveDate, Date endDate,
			double sumInsurred) {
		this.policyNo = policyNo;
		this.policyName = policyName;
		this.policyHolderName = policyHolderName;
		this.effectiveDate = effectiveDate;
		this.endDate = endDate;
		this.sumInsurred = sumInsurred;
	}

	public int getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(int policyNo) {
		this.policyNo = policyNo;
	}

	public String getPolicyName() {
		return policyName;
	}

	public void setPolicyName(String policyName) {
		this.policyName = policyName;
	}

	public String getPolicyHolderName() {
		return policyHolderName;
	}

	public void setPolicyHolderName(String policyHolderName) {
		this.policyHolderName = policyHolderName;
	}

	public Date getEffectiveDate() {
		return effectiveDate;
	}

	public void setEffectiveDate(Date effectiveDate) {
		this.effectiveDate = effectiveDate;
	}

	public Date getEndDate() {
		return endDate;
	}

	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	public double getSumInsurred() {
		return sumInsurred;
	}

	public void setSumInsurred(double sumInsurred) {
		this.sumInsurred = sumInsurred;
	}

}
