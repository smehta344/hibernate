package com.sri.service;

import java.util.Date;

import org.springframework.stereotype.Service;

import com.sri.dto.Policy;

@Service
public class PolicyService {
	public Policy getPolicy(int policyNo) {
		return new Policy(policyNo, "Jeeval Anand", "Jane Smith", new Date(), new Date(), 100039);
	}
}
