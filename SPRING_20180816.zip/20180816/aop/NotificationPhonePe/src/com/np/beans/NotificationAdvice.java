package com.np.beans;

import java.lang.reflect.Method;

import org.springframework.aop.AfterReturningAdvice;

public class NotificationAdvice implements AfterReturningAdvice {
	@Override
	public void afterReturning(Object ret, Method method, Object[] args, Object target) throws Throwable {
		if (method.getName().equals("pay")) {
			notifyPay((String) ret, (String) args[0], (String) args[1], (String) args[2], (Double) args[3]);
		}
	}

	private void notifyPay(String transactionNo, String accountNo, String merchantNo, String description,
			double amount) {
		System.out.println("PhonePe Alert!, amount " + amount + " has been paid from your account : " + accountNo
				+ " to merchant : " + merchantNo + " with comments : " + description + " the transaction ref no # "
				+ transactionNo);

		System.out.println("PhonePe Alert! received amount : " + amount + " from " + accountNo + " with comments : "
				+ description);
	}
}
