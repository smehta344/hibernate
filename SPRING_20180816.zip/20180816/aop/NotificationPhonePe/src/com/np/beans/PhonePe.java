package com.np.beans;

import java.util.UUID;

public class PhonePe {
	public String pay(String accountNo, String merchantNo, String description, double amount) {
		return UUID.randomUUID().toString();
	}
}
