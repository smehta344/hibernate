package com.np.test;

import org.springframework.aop.framework.ProxyFactory;

import com.np.beans.NotificationAdvice;
import com.np.beans.PhonePe;

public class NPTest {
	public static void main(String[] args) {
		ProxyFactory pf = new ProxyFactory();
		pf.setTarget(new PhonePe());
		pf.addAdvice(new NotificationAdvice());

		PhonePe pp = (PhonePe) pf.getProxy();
		String tx = pp.pay("938940039", "930490393", "Paid for breakfast", 50);
		System.out.println("tx : " + tx);
	}
}
