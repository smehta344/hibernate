package com.mba.test;

import org.springframework.aop.framework.ProxyFactory;

import com.mba.beans.AuditAdvice;
import com.mba.beans.LoanManager;
import com.mba.beans.SecurityAdvice;
import com.mba.helper.SecurityHelper;

public class MBATest {
	public static void main(String[] args) {
		ProxyFactory pf = new ProxyFactory();
		pf.setTarget(new LoanManager());
		pf.addAdvice(new AuditAdvice());
		pf.addAdvice(new SecurityAdvice());

		LoanManager lm = (LoanManager) pf.getProxy();
		SecurityHelper securityHelper = SecurityHelper.getInstance();
		securityHelper.login("john", "welcome12");

		System.out.println("approve loan : " + lm.approveLoan(1));

		securityHelper.logout();
	}
}
