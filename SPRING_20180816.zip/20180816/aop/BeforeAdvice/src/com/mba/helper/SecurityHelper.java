package com.mba.helper;

public class SecurityHelper {
	private static SecurityHelper instance;
	private ThreadLocal<User> localUsers;

	private SecurityHelper() {
		localUsers = new ThreadLocal<>();
	}

	public synchronized static SecurityHelper getInstance() {
		if (instance == null) {
			instance = new SecurityHelper();
		}
		return instance;
	}

	public void login(String un, String pwd) {
		User user = null;
		user = new User(un, pwd);
		localUsers.set(user);
	}

	public boolean authenticate() {
		User user = null;
		user = localUsers.get();
		if (user != null) {
			if (user.getUn().equals("john") && user.getPwd().equals("welcome1")) {
				return true;
			}
		}
		return false;
	}

	public String getLoggedInUser() {
		if (localUsers.get() != null) {
			return localUsers.get().getUn();
		}
		return null;
	}

	public void logout() {
		localUsers.set(null);
	}
}
