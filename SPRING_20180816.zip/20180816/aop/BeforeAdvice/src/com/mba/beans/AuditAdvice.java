package com.mba.beans;

import java.lang.reflect.Method;

import org.springframework.aop.MethodBeforeAdvice;

import com.mba.helper.SecurityHelper;

public class AuditAdvice implements MethodBeforeAdvice {
	@Override
	public void before(Method method, Object[] args, Object target) throws Throwable {
		SecurityHelper securityHelper = null;

		securityHelper = SecurityHelper.getInstance();

		System.out.print(securityHelper.getLoggedInUser() + " is accessing the method : " + method.getName() + "(");
		for (int i = 0; i < args.length; i++) {
			if (i == 0) {
				System.out.print(args[0]);
				continue;
			}
			System.out.print("," + args[i]);
		}
		System.out.println(")");
		args[0] = (Long) args[0] + 1;
	}
}
