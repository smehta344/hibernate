package com.ta.test;

import com.ta.beans.ExceptionLoggingAdvice;
import com.ta.beans.Thrower;

import org.springframework.aop.framework.ProxyFactory;

public class TATest {
	public static void main(String[] args) {
		ProxyFactory pf = new ProxyFactory();
		pf.setTarget(new Thrower());
		pf.addAdvice(new ExceptionLoggingAdvice());

		Thrower thrower = (Thrower) pf.getProxy();
		int i = thrower.willThrow(-10);
		System.out.println("i :  " + i);
	}
}
