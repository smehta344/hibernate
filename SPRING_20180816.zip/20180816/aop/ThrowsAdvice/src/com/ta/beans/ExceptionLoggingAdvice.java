package com.ta.beans;

import java.lang.reflect.Method;

import org.springframework.aop.ThrowsAdvice;

public class ExceptionLoggingAdvice implements ThrowsAdvice {
	public void afterThrowing(Throwable t) {
		System.out.println("base exception handler with message :" + t.getMessage());
	}

	/*public void afterThrowing(IllegalArgumentException e) {
		System.out.println("exception message: " + e.getMessage());
	}*/

	/*public void afterThrowing(Method method, Object[] args, Object target, IllegalArgumentException e) {
		System.out.print("Method " + method.getName() + "(");
		for (int i = 0; i < args.length; i++) {
			if (i == 0) {
				System.out.print(args[i]);
				continue;
			}
			System.out.print("," + args[i]);
		}
		System.out.print(") has reported exception with message : " + e.getMessage());
	}*/
}
