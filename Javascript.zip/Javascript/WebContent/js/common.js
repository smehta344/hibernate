
function changeImage(imageName, imgCtrlId, imgTextId) {
	document.getElementById(imgCtrlId).src="images/"+imageName+".jpg";
	document.getElementById(imgTextId).innerHTML=imageName;
}