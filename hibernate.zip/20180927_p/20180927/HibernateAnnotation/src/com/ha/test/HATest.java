package com.ha.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.ha.entities.Branch;
import com.ha.helper.SessionFactoryHelper;

public class HATest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Transaction transaction = null;
		Session session = null;
		Branch branch = null;
		boolean flag = false;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			branch = new Branch();
			branch.setBranchNo(3);
			branch.setBranchName("S R Nagar Branch");
			branch.setContactPerson("Mahendra");
			branch.setContactNo("393503835");
			branch.setLocation("SR Nagar");

			session.save(branch);
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
			}
			if (session != null) {
				session.close();
			}
			SessionFactoryHelper.close();
		}
	}
}
