package com.h4b.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.h4b.entities.Staff;
import com.h4b.helper.SessionFactoryHelper;

public class H4BTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Transaction transaction = null;
		Session session = null;
		Staff staff = null;
		boolean flag = false;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			staff = new Staff();
			staff.setStaffNo(13);
			staff.setFirstName("Ram");
			staff.setLastName("Shekar");
			staff.setGender("Male");
			staff.setAge(34);
			staff.setExperience(3);
			staff.setDesignation("Driver");
			staff.setDepartment("sales");

			session.save(staff);
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
			}
			if (session != null) {
				session.close();
			}
			SessionFactoryHelper.close();
		}

	}
}
