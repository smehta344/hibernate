package com.eh.test;

import net.sf.ehcache.Cache;
import net.sf.ehcache.CacheManager;
import net.sf.ehcache.Element;

public class Test {
	public static void main(String[] args) {
		CacheManager cm = new CacheManager("D:\\work\\master\\hibernate\\20180927\\EHCache\\src\\ehcache.xml");
		Cache cache = cm.getCache("branchCache");
		cache.put(new Element("1", "a"));
		
		Element e= cache.get("1");
		String val = (String) e.getValue();
		System.out.println(val);
		
	}
}
