package com.ci.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.ci.entities.WorkLog;
import com.ci.entities.WorkLogPK;
import com.ci.helper.SessionFactoryHelper;

public class CITest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		WorkLog wl = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			/*wl = new WorkLog();
			wl.setJobSheetNo("j039");
			wl.setStaffNo(39);
			wl.setDescription("Break adjustment");
			wl.setComments("In Progress");
			session.save(wl);*/
			
			WorkLogPK id = new WorkLogPK();
			id.setJobSheetNo("j039");
			id.setStaffNo(39);
			
			wl = (WorkLog) session.get(WorkLog.class, id);
			System.out.println(wl);

			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}
			SessionFactoryHelper.close();
		}
	}
}
