package com.ig.entities;

import java.io.Serializable;
import java.util.Date;

public class Pensioner implements Serializable {
	protected String pensionerNo;
	protected String firstName;
	protected String lastName;
	protected Date dob;
	protected String gender;

	public String getPensionerNo() {
		return pensionerNo;
	}

	public void setPensionerNo(String pensionerNo) {
		this.pensionerNo = pensionerNo;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Date getDob() {
		return dob;
	}

	public void setDob(Date dob) {
		this.dob = dob;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

}
