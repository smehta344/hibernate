package com.ig.test;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.ig.entities.Pensioner;
import com.ig.helper.SessionFactoryHelper;

public class IGTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction transaction = null;
		Pensioner pensioner = null;
		boolean flag = false;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			//for (int i = 0; i < 8; i++) {
				pensioner = new Pensioner();
				pensioner.setFirstName("Sam");
				pensioner.setLastName("K");
				pensioner.setDob(new Date());
				pensioner.setGender("Male");
				session.save(pensioner);
			//}

			/*
			 * Pensioner pensioner1 = new Pensioner(); pensioner1.setFirstName("Sam");
			 * pensioner1.setLastName("K"); pensioner1.setDob(new Date());
			 * pensioner1.setGender("Male"); session.save(pensioner1);
			 */

			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}
			SessionFactoryHelper.close();
		}
	}
}
