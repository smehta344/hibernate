package com.inverse.test;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.inverse.entities.Member;
import com.inverse.entities.Policy;
import com.inverse.helper.SessionFactoryHelper;

public class InverseTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		Member member = null;
		Policy p1 = null;
		Policy p2 = null;
		Set<Policy> policies = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			member = new Member();
			member.setMemberName("Trail");
			member.setAge(24);
			member.setGender("Male");

			p1 = new Policy();
			p1.setPlanName("Jeevan Gold");
			p1.setIssuedDate(new Date());
			p1.setInsurredYears(30);
			p1.setSumInsurred(200000);
			p1.setMember(member);

			p2 = new Policy();
			p2.setPlanName("Jeevan Gold");
			p2.setIssuedDate(new Date());
			p2.setInsurredYears(30);
			p2.setSumInsurred(200000);
			p2.setMember(member);

			policies = new HashSet<>();
			policies.add(p1);
			policies.add(p2);
			member.setPolicies(policies);

			session.save(member);
			session.save(p1);
			session.save(p2);

			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}
			SessionFactoryHelper.close();
		}
	}
}
