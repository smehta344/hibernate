package com.inverse.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "policy")
public class Policy implements Serializable {
	@Id
	@Column(name = "policy_no")
	@GeneratedValue(strategy = GenerationType.AUTO)
	protected int policyNo;
	@Column(name = "plan_nm")
	protected String planName;
	@Column(name = "issued_dt")
	protected Date issuedDate;
	@Column(name = "insurred_years")
	protected int insurredYears;
	@Column(name = "sum_insurred")
	protected double sumInsurred;

	@ManyToOne
	@JoinColumn(name = "member_no", nullable = true)
	protected Member member;

	public int getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(int policyNo) {
		this.policyNo = policyNo;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public Date getIssuedDate() {
		return issuedDate;
	}

	public void setIssuedDate(Date issuedDate) {
		this.issuedDate = issuedDate;
	}

	public int getInsurredYears() {
		return insurredYears;
	}

	public void setInsurredYears(int insurredYears) {
		this.insurredYears = insurredYears;
	}

	public double getSumInsurred() {
		return sumInsurred;
	}

	public void setSumInsurred(double sumInsurred) {
		this.sumInsurred = sumInsurred;
	}

	public Member getMember() {
		return member;
	}

	public void setMember(Member member) {
		this.member = member;
	}

}
