package com.ja.service;

public interface TransferService {
	String neftTransfer(String fromAc, String toAc, float amount);
	String impsTransfer(String fromAc, String toAc, float amount);
}
