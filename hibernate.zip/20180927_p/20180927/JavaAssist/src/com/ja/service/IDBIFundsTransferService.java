package com.ja.service;

import java.util.UUID;

public class IDBIFundsTransferService implements TransferService {

	@Override
	public String neftTransfer(String fromAc, String toAc, float amount) {
		System.out.println("idbi neftTransfer()");
		return "IDBI-" + UUID.randomUUID().toString();
	}

	@Override
	public String impsTransfer(String fromAc, String toAc, float amount) {
		System.out.println("idbi impsTransfer()");
		return "IDBI-" + UUID.randomUUID().toString();
	}

}
