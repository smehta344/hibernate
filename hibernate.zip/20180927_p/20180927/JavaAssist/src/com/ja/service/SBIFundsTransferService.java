package com.ja.service;

import java.util.UUID;

public class SBIFundsTransferService implements TransferService {
	public String neftTransfer(String fromAc, String toAc, float amount) {
		System.out.println("sbi neftTransfer()");
		return UUID.randomUUID().toString();
	}

	public String impsTransfer(String fromAc, String toAc, float amount) {
		System.out.println("sbi impsTransfer()");
		return UUID.randomUUID().toString();
	}
}
