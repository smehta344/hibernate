package com.ja.handler;

import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Method;

import com.ja.service.TransferService;

public class WebSecurityInvocationHandler implements InvocationHandler {
	private TransferService transferService;

	public WebSecurityInvocationHandler(TransferService transferService) {
		this.transferService = transferService;
	}

	@Override
	public Object invoke(Object proxy, Method method, Object[] args) throws Throwable {
		if (method.getName().equals("neftTransfer")) {
			System.out.println("Neft WebSecurity has been passed");
			return transferService.neftTransfer((String) args[0], (String) args[1], (Float) args[2]);
		} else if (method.getName().equals("impsTransfer")) {
			Object ret = transferService.impsTransfer((String) args[0], (String) args[1], (Float) args[2]);
			System.out.println("Sending imps message to mobile");
			return ret;
		}
		return null;
	}

}
