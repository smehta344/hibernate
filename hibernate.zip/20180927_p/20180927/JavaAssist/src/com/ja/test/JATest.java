package com.ja.test;

import java.lang.reflect.Proxy;

import com.ja.handler.WebSecurityInvocationHandler;
import com.ja.service.IDBIFundsTransferService;
import com.ja.service.SBIFundsTransferService;
import com.ja.service.TransferService;

public class JATest {
	public static void main(String[] args) {
		TransferService transferService = null;
		TransferService transferServiceProxy = null;

		transferService = new IDBIFundsTransferService();
		WebSecurityInvocationHandler handler = new WebSecurityInvocationHandler(transferService);
		transferServiceProxy = (TransferService) Proxy.newProxyInstance(JATest.class.getClassLoader(),
				new Class[] { TransferService.class }, handler);
		
		String tx = transferServiceProxy.neftTransfer("ac1", "ac2", 330);
		System.out.println("tx : " +tx);

	}
}















