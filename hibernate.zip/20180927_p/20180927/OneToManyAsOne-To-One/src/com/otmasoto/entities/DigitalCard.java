package com.otmasoto.entities;

import java.io.Serializable;

public class DigitalCard implements Serializable {
	protected int digitalCardNo;
	protected String cardType;
	protected String subscription;
	protected int frequency;

	public int getDigitalCardNo() {
		return digitalCardNo;
	}

	public void setDigitalCardNo(int digitalCardNo) {
		this.digitalCardNo = digitalCardNo;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getSubscription() {
		return subscription;
	}

	public void setSubscription(String subscription) {
		this.subscription = subscription;
	}

	public int getFrequency() {
		return frequency;
	}

	public void setFrequency(int frequency) {
		this.frequency = frequency;
	}

	@Override
	public String toString() {
		return "DigitalCard [digitalCardNo=" + digitalCardNo + ", cardType=" + cardType + ", subscription="
				+ subscription + ", frequency=" + frequency + "]";
	}

}
