package com.otmasoto.entities;

import java.io.Serializable;

public class DTHBox implements Serializable {
	protected int dthBoxNo;
	protected String boxType;
	protected String manufacturer;
	protected float price;
	protected DigitalCard digitalCard;

	public int getDthBoxNo() {
		return dthBoxNo;
	}

	public void setDthBoxNo(int dthBoxNo) {
		this.dthBoxNo = dthBoxNo;
	}

	public String getBoxType() {
		return boxType;
	}

	public void setBoxType(String boxType) {
		this.boxType = boxType;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public DigitalCard getDigitalCard() {
		return digitalCard;
	}

	public void setDigitalCard(DigitalCard digitalCard) {
		this.digitalCard = digitalCard;
	}

	@Override
	public String toString() {
		return "DTHBox [dthBoxNo=" + dthBoxNo + ", boxType=" + boxType + ", manufacturer=" + manufacturer + ", price="
				+ price + ", digitalCard=" + digitalCard + "]";
	}

}
