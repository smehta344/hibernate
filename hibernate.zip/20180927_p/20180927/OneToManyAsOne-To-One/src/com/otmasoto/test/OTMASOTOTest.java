package com.otmasoto.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.otmasoto.entities.DTHBox;
import com.otmasoto.entities.DigitalCard;
import com.otmasoto.helper.SessionFactoryHelper;

public class OTMASOTOTest {

	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		DigitalCard digitalCard = null;
		DTHBox dthBox = null;
		
		
		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			
			/*digitalCard = new DigitalCard();
			digitalCard.setCardType("chip");
			digitalCard.setFrequency(393);
			digitalCard.setSubscription("Annual");
			session.save(digitalCard);
			
			dthBox= new DTHBox();
			dthBox.setBoxType("HD");
			dthBox.setManufacturer("Cisco");
			dthBox.setPrice(3939);
			dthBox.setDigitalCard(digitalCard);
			session.save(dthBox);*/
			
			dthBox = (DTHBox) session.get(DTHBox.class, 1);
			System.out.println(dthBox);

			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}
			SessionFactoryHelper.close();
		}
	}

}












