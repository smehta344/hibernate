package com.dmlop.test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;

import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.dmlop.entities.Owner;
import com.dmlop.helper.SessionFactoryHelper;

public class DMLOPTest {
	public static void main(String[] args) throws IOException {
		SessionFactory sessionFactory = null;
		Transaction transaction = null;
		Session session = null;
		boolean flag = false;
		Owner owner = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			// owner = new Owner("Jack", "J", "Male", null, "93930440", "jack@gmail.com");
			// Object id = session.save(owner);
			// session.persist(owner);
			/*
			 * owner =(Owner) session.get(Owner.class, 1); owner.setFirstName("Ryan");
			 * session.update(owner);
			 */

			/*
			 * owner = new Owner("Jack Ryan", "J", "Male", null, "93930440",
			 * "jack@gmail.com"); owner.setOwnerNo(1); session.update(owner);
			 */

			/*
			 * owner = new Owner("Steve John", "P", "Male", null, "49404",
			 * "steve@gmail.com"); session.saveOrUpdate(owner);
			 */
			/*
			 * owner = new Owner("Steve John", "P", "Male", null, "49404",
			 * "steve@gmail.com"); owner.setFirstName("Rock"); owner.setOwnerNo(7);
			 * session.saveOrUpdate(owner);
			 */

			// System.out.println("id : " +id);
			// System.out.println("owner no : " +owner.getOwnerNo());
			/*
			 * owner = new Owner(); owner.setOwnerNo(5);
			 */
			/*
			 * owner = (Owner) session.load(Owner.class, 2); session.delete(owner);
			 */

			// owner = (Owner) session.get(Owner.class, 1);
			Owner owner1 = new Owner();
			owner1.setFirstName("Rock");
			owner1.setLastName("K");
			owner1.setEmailAddress("rock@gmail.com");
			owner1.setGender("male");
			owner1.setDob(new Date());
			owner1.setMobileNo("393090044");
			File f = new File("C:\\Users\\Sriman\\Pictures\\KoushikPaints\\paint1.png");
			FileInputStream fis = new FileInputStream(f);
			List<Byte> bytesList = new ArrayList<>();
			int b = 0;
			while ((b = fis.read()) != -1) {
				bytesList.add((byte) b);
			}
			byte[] images = new byte[bytesList.size()];
			int i = 0;
			for (byte bt : bytesList) {
				images[i] = bt;
				i++;
			}
			owner1.setPhoto(images);
			session.save(owner1);

			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}
			SessionFactoryHelper.close();
		}

	}
}
