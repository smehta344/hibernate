package com.oto.test;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.oto.entities.Product;
import com.oto.helper.SessionFactoryHelper;

public class HQLTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Query allProductsQuery = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			allProductsQuery = session.createQuery("from Product p where p.price > ?");
			allProductsQuery.setParameter(0, 5000f);
			
			List<Product> products = allProductsQuery.list();
			for (Product product : products) {
				System.out.println(product);
			}
		} finally {
			if (session != null) {
				session.close();
			}
			SessionFactoryHelper.close();
		}

	}
}
