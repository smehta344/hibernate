package com.oto.test;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.oto.entities.Product;
import com.oto.entities.Warranty;
import com.oto.helper.SessionFactoryHelper;

public class OTOTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		Product product = null;
		Warranty warranty = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			
			/*product = new Product();
			product.setProductName("Led 32 tv");
			product.setDescription("Led television");
			product.setPrice(39303.34f);
			session.save(product);
			System.out.println("product no : " + product.getProductNo());
			
			warranty = new Warranty();
			warranty.setPurchaseDate(new Date());
			warranty.setManufacturerName("Anil Trading co");
			warranty.setWarrantyYears(1);
			warranty.setProduct(product);
			session.save(warranty);
			System.out.println("warranty product no : " + warranty.getProductNo());*/
			
			warranty = (Warranty) session.get(Warranty.class, 1);
			System.out.println(warranty);

			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}
			SessionFactoryHelper.close();
		}
	}
}







