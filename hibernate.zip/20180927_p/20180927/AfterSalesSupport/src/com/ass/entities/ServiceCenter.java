package com.ass.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "service_center")
public class ServiceCenter implements Serializable {
	@Id
	@Column(name = "service_center_no")
	@GeneratedValue(strategy = GenerationType.AUTO)
	protected int serviceCenterNo;
	@Column(name = "service_center_nm")
	protected String serviceCenterName;
	@Column(name = "primary_contact_no")
	protected String primaryContactNo;
	@Column(name = "email_address")
	protected String emailAddress;
	@Column(name = "established_dt")
	protected Date establishedDate;
	@Column(name = "services_offered")
	protected String servicesOffered;
	@OneToMany(mappedBy = "serviceCenter", fetch = FetchType.LAZY)
	protected Set<Technician> techicians;
	@OneToMany(mappedBy = "serviceCenter", fetch = FetchType.LAZY)
	protected Set<Complaint> complaints;
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "company_no", nullable = false)
	protected Company company;

	public int getServiceCenterNo() {
		return serviceCenterNo;
	}

	public void setServiceCenterNo(int serviceCenterNo) {
		this.serviceCenterNo = serviceCenterNo;
	}

	public String getServiceCenterName() {
		return serviceCenterName;
	}

	public void setServiceCenterName(String serviceCenterName) {
		this.serviceCenterName = serviceCenterName;
	}

	public String getPrimaryContactNo() {
		return primaryContactNo;
	}

	public void setPrimaryContactNo(String primaryContactNo) {
		this.primaryContactNo = primaryContactNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public Date getEstablishedDate() {
		return establishedDate;
	}

	public void setEstablishedDate(Date establishedDate) {
		this.establishedDate = establishedDate;
	}

	public String getServicesOffered() {
		return servicesOffered;
	}

	public void setServicesOffered(String servicesOffered) {
		this.servicesOffered = servicesOffered;
	}

	public Set<Technician> getTechicians() {
		return techicians;
	}

	public void setTechicians(Set<Technician> techicians) {
		this.techicians = techicians;
	}

	public Set<Complaint> getComplaints() {
		return complaints;
	}

	public void setComplaints(Set<Complaint> complaints) {
		this.complaints = complaints;
	}

	public Company getCompany() {
		return company;
	}

	public void setCompany(Company company) {
		this.company = company;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((emailAddress == null) ? 0 : emailAddress.hashCode());
		result = prime * result + ((establishedDate == null) ? 0 : establishedDate.hashCode());
		result = prime * result + ((primaryContactNo == null) ? 0 : primaryContactNo.hashCode());
		result = prime * result + ((serviceCenterName == null) ? 0 : serviceCenterName.hashCode());
		result = prime * result + serviceCenterNo;
		result = prime * result + ((servicesOffered == null) ? 0 : servicesOffered.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		ServiceCenter other = (ServiceCenter) obj;
		if (emailAddress == null) {
			if (other.emailAddress != null)
				return false;
		} else if (!emailAddress.equals(other.emailAddress))
			return false;
		if (establishedDate == null) {
			if (other.establishedDate != null)
				return false;
		} else if (!establishedDate.equals(other.establishedDate))
			return false;
		if (primaryContactNo == null) {
			if (other.primaryContactNo != null)
				return false;
		} else if (!primaryContactNo.equals(other.primaryContactNo))
			return false;
		if (serviceCenterName == null) {
			if (other.serviceCenterName != null)
				return false;
		} else if (!serviceCenterName.equals(other.serviceCenterName))
			return false;
		if (serviceCenterNo != other.serviceCenterNo)
			return false;
		if (servicesOffered == null) {
			if (other.servicesOffered != null)
				return false;
		} else if (!servicesOffered.equals(other.servicesOffered))
			return false;
		return true;
	}

}
