package com.ass.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "work_order")
public class Workorder implements Serializable {
	@Id
	@Column(name = "work_order_no")
	@GeneratedValue(strategy = GenerationType.AUTO)
	protected int workOrderNo;
	@Column(name = "work_order_type")
	protected String workOrderType;
	@Column(name = "work_order_created_dt")
	protected Date workOrderCreatedDate;
	@Column(name = "work_order_start_dt")
	protected Date workOrderStartDate;
	@Column(name = "work_order_end_dt")
	protected Date workOrderEndDate;
	protected String status;
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "technician_no", nullable = false)
	protected Technician technician;
	@ManyToOne(fetch = FetchType.EAGER)
	@JoinColumn(name = "complaint_no", nullable = false, unique = true)
	protected Complaint complaint;

	public int getWorkOrderNo() {
		return workOrderNo;
	}

	public void setWorkOrderNo(int workOrderNo) {
		this.workOrderNo = workOrderNo;
	}

	public String getWorkOrderType() {
		return workOrderType;
	}

	public void setWorkOrderType(String workOrderType) {
		this.workOrderType = workOrderType;
	}

	public Date getWorkOrderCreatedDate() {
		return workOrderCreatedDate;
	}

	public void setWorkOrderCreatedDate(Date workOrderCreatedDate) {
		this.workOrderCreatedDate = workOrderCreatedDate;
	}

	public Date getWorkOrderStartDate() {
		return workOrderStartDate;
	}

	public void setWorkOrderStartDate(Date workOrderStartDate) {
		this.workOrderStartDate = workOrderStartDate;
	}

	public Date getWorkOrderEndDate() {
		return workOrderEndDate;
	}

	public void setWorkOrderEndDate(Date workOrderEndDate) {
		this.workOrderEndDate = workOrderEndDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Technician getTechnician() {
		return technician;
	}

	public void setTechnician(Technician technician) {
		this.technician = technician;
	}

	public Complaint getComplaint() {
		return complaint;
	}

	public void setComplaint(Complaint complaint) {
		this.complaint = complaint;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((status == null) ? 0 : status.hashCode());
		result = prime * result + ((workOrderCreatedDate == null) ? 0 : workOrderCreatedDate.hashCode());
		result = prime * result + ((workOrderEndDate == null) ? 0 : workOrderEndDate.hashCode());
		result = prime * result + workOrderNo;
		result = prime * result + ((workOrderStartDate == null) ? 0 : workOrderStartDate.hashCode());
		result = prime * result + ((workOrderType == null) ? 0 : workOrderType.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Workorder other = (Workorder) obj;
		if (status == null) {
			if (other.status != null)
				return false;
		} else if (!status.equals(other.status))
			return false;
		if (workOrderCreatedDate == null) {
			if (other.workOrderCreatedDate != null)
				return false;
		} else if (!workOrderCreatedDate.equals(other.workOrderCreatedDate))
			return false;
		if (workOrderEndDate == null) {
			if (other.workOrderEndDate != null)
				return false;
		} else if (!workOrderEndDate.equals(other.workOrderEndDate))
			return false;
		if (workOrderNo != other.workOrderNo)
			return false;
		if (workOrderStartDate == null) {
			if (other.workOrderStartDate != null)
				return false;
		} else if (!workOrderStartDate.equals(other.workOrderStartDate))
			return false;
		if (workOrderType == null) {
			if (other.workOrderType != null)
				return false;
		} else if (!workOrderType.equals(other.workOrderType))
			return false;
		return true;
	}

}
