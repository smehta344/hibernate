package com.ass.test;

import java.util.List;
import java.util.Set;

import org.hibernate.Criteria;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;
import org.hibernate.sql.JoinType;

import com.ass.bo.ComplaintStatus;
import com.ass.entities.Complaint;
import com.ass.entities.Customer;
import com.ass.entities.Product;
import com.ass.entities.Technician;
import com.ass.helper.SessionFactoryHelper;

public class HQLTest {

	public static void showNoOfCustomers(Session session) {
		Query query = null;
		List<Integer> count = null;

		query = session.createQuery("select count(c) from Customer c");
		
		count = query.list();
		System.out.println(count.get(0));
	}

	private static void showNoOfCustomersC(Session session) {
		Criteria customerCriteria = null;
		List<Integer> count = null;

		customerCriteria = session.createCriteria(Customer.class);
		customerCriteria.setProjection(Projections.count("customerNo"));
		count = customerCriteria.list();
		System.out.println(count.get(0));
	}

	public static void showCustomersByGender(Session session, String gender) {
		Query customerByGender = null;
		List<Customer> customers = null;

		customerByGender = session.createQuery("select c from Customer c where c.gender=?");
		customerByGender.setParameter(0, gender);
		customers = customerByGender.list();
		for (Customer c : customers) {
			System.out.println("name : " + c.getCustomerName() + " gender: " + c.getGender());
		}
	}

	private static void showCustomersByGenderC(Session session, String gender) {
		List<Customer> customers = null;

		Criteria c = session.createCriteria(Customer.class).add(Restrictions.eq("gender", gender));
		customers = c.list();
		for (Customer customer : customers) {
			System.out.println(customer.getCustomerName());
		}

	}

	private static void showCustomersByDobAndGender(Session session, int year, String gender) {
		Query customerQuery = null;
		List<Customer> customers = null;

		customerQuery = session.createQuery("select c from Customer c where year(c.dob) >= ? and c.gender = ?");
		customerQuery.setParameter(0, year);
		customerQuery.setParameter(1, gender);
		customers = customerQuery.list();
		for (Customer c : customers) {
			System.out.println(c.getCustomerName());
		}
	}

	/*
	 * private static void showCustomersByDobAndGenderC(Session session, int year,
	 * String gender) { Criteria c = null; List<Customer> customers = null;
	 * 
	 * c = session.createCriteria(Customer.class)
	 * .add(Restrictions.and(Restrictions.sqlRestriction("year(dob)", year,
	 * TypeFactory.), Restrictions.eqOrIsNull("gender", gender))); customers =
	 * c.list(); for(Customer customer : customers) {
	 * System.out.println(customer.getCustomerName()); } }
	 */

	private static void showCustomersByNameAndGender(Session session, String name, String gender) {
		Query query = null;
		List<Customer> customers = null;

		query = session.createQuery("select c from Customer c where c.customerName like ? and c.gender = ?");
		query.setParameter(0, "%" + name + "%");
		query.setParameter(1, gender);
		customers = query.list();
		for (Customer c : customers) {
			System.out.println(c.getCustomerName());
		}
	}

	private static void showTechniciansByExperienceAndDesignation(Session session, int experience, String designation) {
		Query query = null;
		List<Technician> technicians = null;

		query = session.createQuery("select t from Technician t where t.experience > ? and t.designation = ?");
		query.setParameter(0, experience);
		query.setParameter(1, designation);
		technicians = query.list();
		for (Technician t : technicians) {
			System.out.println(t.getTechnicianName());
		}
	}

	private static void showNoOfTechniciansByExperience(Session session) {
		Query query = null;
		List<Object[]> records = null;

		query = session.createQuery("select t.experience, count(t) from Technician t group by t.experience");
		records = query.list();
		for (Object[] row : records) {
			System.out.println("experience : " + row[0] + " count : " + row[1]);
		}
	}

	private static void showCustomerByProductName(Session session, String productName) {
		Query query = null;
		List<Customer> customers = null;

		query = session.createQuery("select c from Customer c inner join c.products p where p.productName = ?");

		query.setParameter(0, productName);
		customers = query.list();
		for (Customer c : customers) {
			System.out.println(c.getCustomerName());
		}
	}

	private static void showCustomerByProductNameC(Session session, String productName) {
		List<Customer> customers = null;
		Criteria customerCriteria = null;

		customerCriteria = session.createCriteria(Customer.class).createAlias("products", "p")
				.add(Restrictions.eq("p.productName", productName));
		customers = customerCriteria.list();
		for (Customer c : customers) {
			System.out.println(c.getCustomerName());
		}
	}

	private static void showCustomerAndProduct(Session session, int year) {
		Query query = null;
		List<Object[]> records = null;

		query = session.createQuery(
				"select c.customerName, p.productName from Customer c inner join c.products p where year(p.purchaseDate) = ?");
		query.setParameter(0, year);

		records = query.list();
		for (Object[] row : records) {
			System.out.println("customer name : " + row[0] + " product : " + row[1]);
		}

	}

	private static void showTechniciansByServiceCenter(Session session, String serviceCenterName) {
		Query query = null;
		List<Technician> technicians = null;

		// query = session.createQuery("select t from Technician t inner join
		// t.serviceCenter sc where sc.serviceCenterName = ?");
		query = session.createQuery("select t from Technician t where t.serviceCenter.serviceCenterName = ?");
		query.setParameter(0, serviceCenterName);
		technicians = query.list();
		for (Technician t : technicians) {
			System.out.println(t.getTechnicianName());
		}
	}

	private static void showTechniciansByServiceCenterC(Session session, String serviceCenterName) {
		List<Technician> techicians = null;
		Criteria techiciansCriteria = null;

		techiciansCriteria = session.createCriteria(Technician.class).createAlias("serviceCenter", "sc")
				.add(Restrictions.eq("sc.serviceCenterName", serviceCenterName));
		techicians = techiciansCriteria.list();
		for (Technician t : techicians) {
			System.out.println(t.getTechnicianName());
		}
	}

	private static void showCustomersByNoOfProducts(Session session, int count) {
		Query query = null;
		List<Customer> customers = null;

		/*
		 * query = session.createQuery(
		 * "select c from Customer c where c.customerNo in (select c1.customerNo from Customer c1 inner join c1.products p group by c1.customerNo having count(c1.customerNo) >= ?)"
		 * );
		 */

		query = session.createQuery("select c from Customer c where size(c.products) >= :count");

		query.setParameter("count", count);
		customers = query.list();
		for (Customer c : customers) {
			System.out.println(c.getCustomerName());
		}
	}

	private static void showCustomersAndNoOfProducts(Session session, Integer count) {
		List<Object[]> records = null;
		Criteria c = null;

		c = session.createCriteria(Customer.class).createAlias("products", "p")
				.setProjection(Projections.projectionList().add(Projections.property("customerName"))
						.add(Projections.count("p.productNo")).add(Projections.groupProperty("customerNo")));

		records = c.list();
		for (Object[] row : records) {
			System.out.println(row[0] + " - " + row[1]);
		}
	}

	private static void showServiceCenterNoOfComplaints(Session session) {
		Query query = null;
		List<Object[]> records = null;

		/*
		 * query = session.createQuery(
		 * "select sc.serviceCenterName, count(c.complaintNo) from ServiceCenter sc inner join sc.complaints c group by sc.serviceCenterNo"
		 * );
		 */
		query = session.createQuery(
				"select sc.serviceCenterName, size(sc.complaints) from ServiceCenter sc group by sc.serviceCenterNo");
		records = query.list();
		for (Object[] row : records) {
			System.out.println(row[0] + " - " + row[1]);

		}
	}

	private static void showComplaintsWithProductsServiceCenterAndWorkOrder(Session session) {
		Query query = null;
		List<ComplaintStatus> complaints = null;

		query = session.createQuery(
				"select new com.ass.bo.ComplaintStatus(c.complaintNo, c.complaintTitle, c.product.productName, sc.serviceCenterName, w.workOrderNo, w.status) from Complaint c left outer join c.serviceCenter sc left outer join c.workorders w");
		complaints = query.list();
		for (ComplaintStatus cs : complaints) {
			System.out.println(cs);
		}

	}

	private static void showComplaintsWithProductsServiceCenterAndWorkOrderC(Session session) {
		List<Object[]> records = null;
		Criteria c = null;

		c = session.createCriteria(Complaint.class).createAlias("product", "p")
				.createAlias("serviceCenter", "sc", JoinType.LEFT_OUTER_JOIN)
				.createAlias("workorders", "wo", JoinType.LEFT_OUTER_JOIN)
				.setProjection(Projections.projectionList().add(Projections.property("complaintNo"))
						.add(Projections.property("complaintTitle")).add(Projections.property("sc.serviceCenterName"))
						.add(Projections.property("wo.workOrderNo")).add(Projections.property("wo.status"))
						.add(Projections.property("p.productName")));

		records = c.list();
		for (Object[] row : records) {
			for (Object o : row) {
				System.out.print(o + " ");
			}
			System.out.println("");
		}
	}

	private static void showTechicianComplaintsByStatus(Session session, String status) {
		Query query = null;
		List<Object[]> records = null;

		query = session.createQuery(
				"select t.technicianNo, c.complaintNo, c.complaintTitle from Technician t inner join t.assignedWorkorders w inner join w.complaint c where w.status = ?");
		query.setParameter(0, status);
		records = query.list();
		for (Object[] row : records) {
			System.out.println(row[0] + " - " + row[1] + " - " + row[2]);
		}

	}

	public static void nPlus1Problem(Session session) {
		Query query = null;
		List<Product> products = null;
		Set<Complaint> complaints = null;

		query = session.createQuery("from Product p inner join fetch p.complaints");
		products = query.list();
		for (Product product : products) {
			complaints = product.getComplaints();
			for (Complaint complaint : complaints) {
				System.out.println(complaint.getComplaintNo());
			}
		}
	}

	private static void showTechiciansByServiceCenterNamedQuery(Session session, String serviceCenterName) {
		Query query = null;
		List<Technician> technicians = null;

		query = session.getNamedQuery("techiciansByServiceCenter");
		query.setParameter("serviceCenterName", serviceCenterName);

		technicians = query.list();
		for (Technician t : technicians) {
			System.out.println(t.getTechnicianName());
		}

	}

	private static void showProductsC(Session session) {
		Criteria productsCriteria = null;
		List<Product> products = null;

		productsCriteria = session.createCriteria(Product.class);
		products = productsCriteria.list();
		for (Product p : products) {
			System.out.println(p.getProductName());
		}
	}

	private static void showProductsByProductNameC(Session session, String productName) {
		Criteria productsByNameCriteria = null;
		List<Product> products = null;

		productsByNameCriteria = session.createCriteria(Product.class);
		productsByNameCriteria.add(Restrictions.like("productName", productName));
		products = productsByNameCriteria.list();
		for (Product p : products) {
			System.out.println(p.getProductName());
		}
	}

	private static void showTechniciansByExperienceAndDesignationC(Session session, String designation,
			int experience) {
		List<Technician> technicians = null;

		Criteria c = session.createCriteria(Technician.class).add(Restrictions
				.and(Restrictions.eq("designation", designation), Restrictions.gt("experience", experience)));
		technicians = c.list();
		for (Technician t : technicians) {
			System.out.println(t.getTechnicianName());
		}
	}

	private static void showTechincianByDesignationC(Session session, String designation) {
		Criteria technicianCriteria = null;
		List<Object[]> records = null;

		technicianCriteria = session.createCriteria(Technician.class);
		technicianCriteria.add(Restrictions.eq("designation", designation));
		technicianCriteria.setProjection(Projections.projectionList().add(Projections.property("technicianName"))
				.add(Projections.property("experience")));

		records = technicianCriteria.list();
		for (Object[] row : records) {
			System.out.println(row[0] + " - " + row[1]);
		}
	}

	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			// showProductsC(session);
			// showProductsByProductNameC(session, "%a%");
			// showTechniciansByExperienceAndDesignationC(session, "techinical engineer",
			// 3);
			// showTechincianByDesignationC(session,"techinical engineer");

			// showNoOfCustomers(session);
			// showNoOfCustomersC(session);
			// showCustomersByGender(session, "female");
			// showCustomersByGenderC(session, "female");
			// showCustomersByDobAndGender(session, 1990, "male");
			// showCustomersByDobAndGenderC(session, 1990, "male");
			// showCustomersByNameAndGender(session, "r", "male");
			// showTechniciansByExperienceAndDesignation(session, 2, "techinical engineer");
			// showNoOfTechniciansByExperience(session);
			// showCustomerByProductName(session, "television");
			// showCustomerByProductNameC(session, "television");
			// showCustomerAndProduct(session, 2011);

			// showTechniciansByServiceCenter(session,"sri venkateswara service center");
			// showTechniciansByServiceCenterC(session,"sri venkateswara service center");

			// showCustomersByNoOfProducts(session, 2);
			// showCustomersAndNoOfProducts(session,2);

			// showServiceCenterNoOfComplaints(session);
			// showComplaintsWithProductsServiceCenterAndWorkOrder(session);
			// showComplaintsWithProductsServiceCenterAndWorkOrderC(session);

			// showTechicianComplaintsByStatus(session, "in progress");
			// nPlus1Problem(session);
			// showTechiciansByServiceCenterNamedQuery(session, "krishna service center");
		} finally {
			if (session != null) {
				session.close();
			}
			SessionFactoryHelper.close();
		}
	}

}
