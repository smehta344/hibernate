package com.ass.test;

import java.util.Date;

import com.ass.dao.CompanyDao;
import com.ass.entities.Company;
import com.ass.helper.SessionFactoryHelper;

public class CompanyTest {
	public static void main(String[] args) {
		CompanyDao companyDao = null;
		Company company = null;
		try {
			companyDao = new CompanyDao();
			company = new Company();
			company.setCompanyName("Philips");
			company.setEstablishedDate(new Date(1980, 01, 25));
			company.setLicenseNo("li303484");
			company.setRegisteredBusinessName("Philips Electronics");
			int companyNo = companyDao.saveCompany(company);
			System.out.println("companyNo : " + companyNo);
		} finally {
			SessionFactoryHelper.close();
		}
	}

}
