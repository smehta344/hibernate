package com.h5b.entities;

import java.io.Serializable;
import java.util.Date;

public class Provider implements Serializable {
	protected int providerNo;
	protected String providerName;
	protected Date establishedDate;
	protected String contactNo;
	protected String emailAddress;

	public int getProviderNo() {
		return providerNo;
	}

	public void setProviderNo(int providerNo) {
		this.providerNo = providerNo;
	}

	public String getProviderName() {
		return providerName;
	}

	public void setProviderName(String providerName) {
		this.providerName = providerName;
	}

	public Date getEstablishedDate() {
		return establishedDate;
	}

	public void setEstablishedDate(Date establishedDate) {
		this.establishedDate = establishedDate;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	@Override
	public String toString() {
		return "Provider [providerNo=" + providerNo + ", providerName=" + providerName + ", establishedDate="
				+ establishedDate + ", contactNo=" + contactNo + ", emailAddress=" + emailAddress + "]";
	}

}
