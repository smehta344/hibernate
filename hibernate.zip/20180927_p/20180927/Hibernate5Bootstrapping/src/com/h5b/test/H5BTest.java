package com.h5b.test;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.h5b.entities.Provider;
import com.h5b.helper.SessionFactoryHelper;

public class H5BTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Provider provider = null;

		provider = new Provider();
		provider.setProviderNo(35);
		provider.setProviderName("Morning Star");
		provider.setEstablishedDate(new Date());
		provider.setContactNo("08404");
		provider.setEmailAddress("morningstart@gmail.com");
		sessionFactory = SessionFactoryHelper.getSessionFactory();
		session = sessionFactory.openSession();
		session.save(provider);
		System.out.println("saved..");
		session.flush();
		session.close();
	}
}
