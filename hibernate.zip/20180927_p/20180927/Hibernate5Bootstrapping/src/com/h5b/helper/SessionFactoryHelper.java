package com.h5b.helper;

import org.hibernate.SessionFactory;
import org.hibernate.boot.Metadata;
import org.hibernate.boot.MetadataBuilder;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.SessionFactoryBuilder;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;

import com.h5b.interceptor.UserInterceptor;

public class SessionFactoryHelper {
	private static SessionFactory sessionFactory;

	static {
		StandardServiceRegistry registry = new StandardServiceRegistryBuilder()
				.configure("com/h5b/config/hibernate.cfg.xml").build();
		MetadataSources metadataSource = new MetadataSources(registry);
		MetadataBuilder metadataBuilder = metadataSource.getMetadataBuilder();
		Metadata metadata = metadataBuilder.build();
		SessionFactoryBuilder sessionFactoryBuilder = metadata.getSessionFactoryBuilder();
		sessionFactoryBuilder.allowOutOfTransactionUpdateOperations(true);
		sessionFactoryBuilder.applyInterceptor(new UserInterceptor());
		sessionFactory = sessionFactoryBuilder.build();

	}

	public static SessionFactory getSessionFactory() {
		return sessionFactory;
	}

	public static void close() {
		if (sessionFactory != null) {
			sessionFactory.close();
		}
	}
}
