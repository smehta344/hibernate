package com.h5b.interceptor;

import java.io.Serializable;
import java.util.Iterator;

import org.hibernate.CallbackException;
import org.hibernate.EmptyInterceptor;
import org.hibernate.type.Type;

public class UserInterceptor extends EmptyInterceptor {

	@Override
	public String onPrepareStatement(String sql) {
		System.out.println(sql);
		return sql;
	}

	@Override
	public boolean onSave(Object arg0, Serializable arg1, Object[] arg2, String[] arg3, Type[] arg4)
			throws CallbackException {
		System.out.println("saving object " + arg0.getClass().getName());
		return true;
	}

	@Override
	public void postFlush(Iterator arg0) throws CallbackException {
		System.out.println("flushing completed");
	}

	@Override
	public void preFlush(Iterator arg0) throws CallbackException {
		System.out.println("before flushing");
	}

}
