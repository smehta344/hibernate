package com.jpa.test;

import java.util.Date;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import com.jpa.entities.Ticket;

public class JPATest {
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = null;
		EntityManager entityManager = null;
		EntityTransaction transaction = null;
		Ticket ticket = null;
		boolean flag = false;

		try {
			entityManagerFactory = Persistence.createEntityManagerFactory("support-unit");
			entityManager = entityManagerFactory.createEntityManager();
			transaction = entityManager.getTransaction();
			transaction.begin();

			ticket = new Ticket();
			ticket.setTicketNo(39);
			ticket.setSource("hyderabad");
			ticket.setDestination("banglore");
			ticket.setAge(35);
			ticket.setGender("Male");
			ticket.setPassengerName("Abbas");
			ticket.setAmount(394.3f);
			ticket.setJourneyDate(new Date());

			entityManager.persist(ticket);
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				entityManager.close();
			}
			if (entityManagerFactory != null) {
				entityManagerFactory.close();
			}
		}
	}
}
