package com.legacy.entities;

import java.io.Serializable;
import java.util.Date;

public class Journey implements Serializable {
	protected int journeyNo;
	protected String source;
	protected String destination;
	protected Date journeyDate;
	protected float estimatedHours;
	protected int distanceInKms;
	protected float price;

	public int getJourneyNo() {
		return journeyNo;
	}

	public void setJourneyNo(int journeyNo) {
		this.journeyNo = journeyNo;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Date getJourneyDate() {
		return journeyDate;
	}

	public void setJourneyDate(Date journeyDate) {
		this.journeyDate = journeyDate;
	}

	public float getEstimatedHours() {
		return estimatedHours;
	}

	public void setEstimatedHours(float estimatedHours) {
		this.estimatedHours = estimatedHours;
	}

	public int getDistanceInKms() {
		return distanceInKms;
	}

	public void setDistanceInKms(int distanceInKms) {
		this.distanceInKms = distanceInKms;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	@Override
	public String toString() {
		return "Journey [journeyNo=" + journeyNo + ", source=" + source + ", destination=" + destination
				+ ", journeyDate=" + journeyDate + ", estimatedHours=" + estimatedHours + ", distanceInKms="
				+ distanceInKms + ", price=" + price + "]";
	}

}
