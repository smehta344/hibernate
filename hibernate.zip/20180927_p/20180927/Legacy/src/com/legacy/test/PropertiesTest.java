package com.legacy.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.legacy.entities.Journey;

public class PropertiesTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Journey journey = null;

		try {
			Configuration configuration = new Configuration();
			configuration.addResource("com/legacy/entities/Journey.hbm.xml");
			sessionFactory = configuration.buildSessionFactory();
			session = sessionFactory.openSession();
			journey = (Journey) session.get(Journey.class, 2);
			System.out.println(journey);
		} finally {
			if (session != null) {
				session.close();
			}
			if (sessionFactory != null) {
				sessionFactory.close();
			}
		}

	}

}
