package com.legacy.test;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.legacy.entities.Journey;

public class ConfigurationTest {
	public static void main(String[] args) {
		boolean flag = false;
		Session session = null;
		Journey journey = null;
		Transaction transaction = null;
		Configuration configuration = null;
		SessionFactory sessionFactory = null;

		try {
			configuration = new Configuration().configure("com/legacy/config/legacy.cfg.xml");
			sessionFactory = configuration.buildSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			journey = new Journey();
			journey.setJourneyNo(2);
			journey.setSource("hyderabad");
			journey.setDestination("chennai");
			journey.setJourneyDate(new Date());
			journey.setDistanceInKms(500);
			journey.setEstimatedHours(8);
			journey.setPrice(345);

			session.save(journey);
			System.out.println("saved journey");

			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
			}
			if (sessionFactory != null) {
				sessionFactory.close();
			}
		}
	}
}
