package com.legacy.test;

import java.io.IOException;
import java.util.Properties;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

import com.legacy.entities.Journey;

public class ProgrammaticTest {
	public static void main(String[] args) throws IOException {
		Configuration configuration = null;
		SessionFactory sessionFactory = null;
		Session session = null;

		try {
			Properties props = new Properties();
			props.load(ProgrammaticTest.class.getClassLoader().getResourceAsStream("app.properties"));

			configuration = new Configuration();
			configuration.setProperty("hibernate.connection.driver_class", props.getProperty("driver_class"));
			configuration.setProperty("hibernate.connection.url", props.getProperty("url"));
			configuration.setProperty("hibernate.connection.username", props.getProperty("username"));
			configuration.setProperty("hibernate.connection.password", props.getProperty("password"));

			configuration.setProperty("hibernate.dialect", props.getProperty("dialect"));
			configuration.addResource("com/legacy/entities/Journey.hbm.xml");

			sessionFactory = configuration.buildSessionFactory();
			session = sessionFactory.openSession();
			Journey journey = (Journey) session.get(Journey.class, 2);
			System.out.println(journey);

		} finally {
			if (session != null) {
				session.close();
			}
			if (sessionFactory != null) {
				sessionFactory.close();
			}
		}
	}
}
