package com.mtmm.entities;

import java.io.Serializable;
import java.util.Date;
import java.util.Map;

public class Game implements Serializable {
	protected int gameNo;
	protected String seriesName;
	protected Date matchConductedDate;
	protected String location;
	// player participated in the match has what world rank at that time
	protected Map<Integer, Player> players;

	public int getGameNo() {
		return gameNo;
	}

	public void setGameNo(int gameNo) {
		this.gameNo = gameNo;
	}

	public String getSeriesName() {
		return seriesName;
	}

	public void setSeriesName(String seriesName) {
		this.seriesName = seriesName;
	}

	public Date getMatchConductedDate() {
		return matchConductedDate;
	}

	public void setMatchConductedDate(Date matchConductedDate) {
		this.matchConductedDate = matchConductedDate;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Map<Integer, Player> getPlayers() {
		return players;
	}

	public void setPlayers(Map<Integer, Player> players) {
		this.players = players;
	}

	@Override
	public String toString() {
		return "Game [gameNo=" + gameNo + ", seriesName=" + seriesName + ", matchConductedDate=" + matchConductedDate
				+ ", location=" + location + ", players=" + players + "]";
	}

}
