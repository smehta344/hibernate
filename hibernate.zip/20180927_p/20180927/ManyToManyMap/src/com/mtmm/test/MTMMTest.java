package com.mtmm.test;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.mtmm.entities.Game;
import com.mtmm.entities.Player;
import com.mtmm.helper.SessionFactoryHelper;

public class MTMMTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		Player p1 = null;
		Player p2 = null;
		Game game = null;
		Map<Integer, Player> players = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			p1 = new Player();
			p1.setPlayerName("Dhoni");
			p1.setGender("Male");
			p1.setAge(35);
			session.save(p1);
			
			p2 = new Player();
			p2.setPlayerName("Virat");
			p2.setGender("Male");
			p2.setAge(25);
			session.save(p2);
			
			game = new Game();
			game.setSeriesName("Pakistan India ODI Series2015");
			game.setMatchConductedDate(new Date());
			game.setLocation("Mumbai");
			players = new HashMap<>();
			players.put(23, p1);
			players.put(35, p2);
			game.setPlayers(players);
			session.save(game);
			

			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}
			SessionFactoryHelper.close();
		}
	}
}
