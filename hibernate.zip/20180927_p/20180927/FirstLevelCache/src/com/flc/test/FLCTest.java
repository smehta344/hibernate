package com.flc.test;

import java.util.Date;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.flc.entities.Schedule;
import com.flc.helper.SessionFactoryHelper;

public class FLCTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Schedule schedule = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			// saveSchedule(session);

			/*Schedule s1 = (Schedule) session.get(Schedule.class, 3);
			System.out.println(s1);
			System.out.println("try query again");
			//session.clear();
			//session.evict(s1);
			Schedule s2 = (Schedule) session.get(Schedule.class, 3);
			System.out.println("s1 == s2 ? :" + (s1 == s2));*/
			session.beginTransaction();
			Schedule s1 = (Schedule) session.get(Schedule.class, 3);
			s1.setSource("Chennai");
			session.update(s1);
			System.out.println("updated object source");
			
			Schedule s2 = (Schedule) session.get(Schedule.class, 3);
			s2.setDestination("Pune");
			session.update(s2);
			System.out.println("updated object destination");
			session.getTransaction().commit();
			//session.flush();	

		} finally {
			sessionFactory.close();
		}

	}

	public static void saveSchedule(Session session) {
		Transaction transaction = null;
		Schedule schedule = null;
		boolean flag = false;

		try {
			transaction = session.beginTransaction();
			schedule = new Schedule();
			schedule.setId(3);
			schedule.setSource("Hyderabad");
			schedule.setDestination("Banglore");
			schedule.setPlannedDate(new Date());
			session.save(schedule);
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}
		}
	}
}
