package com.flc.entities;

import java.io.Serializable;
import java.util.Date;

public class Schedule implements Serializable {
	protected int id;
	protected String source;
	protected String destination;
	protected Date plannedDate;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Date getPlannedDate() {
		return plannedDate;
	}

	public void setPlannedDate(Date plannedDate) {
		this.plannedDate = plannedDate;
	}

	@Override
	public String toString() {
		return "Schedule [id=" + id + ", source=" + source + ", destination=" + destination + ", plannedDate="
				+ plannedDate + "]";
	}

}
