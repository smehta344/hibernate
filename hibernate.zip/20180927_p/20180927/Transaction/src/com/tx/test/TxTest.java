package com.tx.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import com.tx.entities.Bus;

public class TxTest {
	public static void main(String[] args) {
		Configuration configuration = null;
		SessionFactory sessionFactory = null;
		Transaction transaction = null;
		Session session = null;
		boolean flag = false;

		try {
			configuration = new Configuration().configure();
			sessionFactory = configuration.buildSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			Bus bus = new Bus();
			bus.setBusNo(1);
			bus.setBusType("Volvo");
			bus.setFuelType("Diesel");
			bus.setSeatingCapacity(39);
			bus.setServiceNo("s0393");
			bus.setCost(9384049);

			session.save(bus);

			flag = true;
		} finally {

			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}
			if (sessionFactory != null) {
				sessionFactory.close();
			}
		}
	}
}
