package com.tx.entities;

import java.io.Serializable;

public class Bus implements Serializable {
	protected int busNo;
	protected String busType;
	protected String serviceNo;
	protected String fuelType;
	protected int seatingCapacity;
	protected double cost;

	public int getBusNo() {
		return busNo;
	}

	public void setBusNo(int busNo) {
		this.busNo = busNo;
	}

	public String getBusType() {
		return busType;
	}

	public void setBusType(String busType) {
		this.busType = busType;
	}

	public String getServiceNo() {
		return serviceNo;
	}

	public void setServiceNo(String serviceNo) {
		this.serviceNo = serviceNo;
	}

	public String getFuelType() {
		return fuelType;
	}

	public void setFuelType(String fuelType) {
		this.fuelType = fuelType;
	}

	public int getSeatingCapacity() {
		return seatingCapacity;
	}

	public void setSeatingCapacity(int seatingCapacity) {
		this.seatingCapacity = seatingCapacity;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "Bus [busNo=" + busNo + ", busType=" + busType + ", serviceNo=" + serviceNo + ", fuelType=" + fuelType
				+ ", seatingCapacity=" + seatingCapacity + ", cost=" + cost + "]";
	}

}
