package com.otml.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "service_request")
public class ServiceRequest implements Serializable {
	@Id
	@Column(name = "request_no")
	@GeneratedValue(strategy = GenerationType.AUTO)
	protected int requestNo;
	@Column(name = "request_type")
	protected String requestType;
	@Column(name = "requested_dt")
	protected Date requestedDate;
	protected String description;
	protected String status;

	public int getRequestNo() {
		return requestNo;
	}

	public void setRequestNo(int requestNo) {
		this.requestNo = requestNo;
	}

	public String getRequestType() {
		return requestType;
	}

	public void setRequestType(String requestType) {
		this.requestType = requestType;
	}

	public Date getRequestedDate() {
		return requestedDate;
	}

	public void setRequestedDate(Date requestedDate) {
		this.requestedDate = requestedDate;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	@Override
	public String toString() {
		return "ServiceRequest [requestNo=" + requestNo + ", requestType=" + requestType + ", requestedDate="
				+ requestedDate + ", description=" + description + ", status=" + status + "]";
	}

}
