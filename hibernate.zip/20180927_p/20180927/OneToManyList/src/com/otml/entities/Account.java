package com.otml.entities;

import java.io.Serializable;
import java.util.List;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Index;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OrderColumn;
import javax.persistence.Table;

import org.hibernate.annotations.IndexColumn;
import org.hibernate.annotations.ListIndexBase;

@Entity
@Table(name = "account")
public class Account implements Serializable {
	@Id
	@Column(name = "account_no")
	@GeneratedValue(strategy = GenerationType.AUTO)
	protected int accountNo;
	@Column(name = "account_holder_nm")
	protected String accountHolderName;
	@Column(name = "subscribed_package")
	protected String subscribedPackage;
	@Column(name = "account_type")
	protected String accountType;
	@Column(name = "registered_mobile_no")
	protected String registeredMobileNo;
	@Column(name = "email_address")
	protected String emailAddress;

	@OneToMany
	@JoinColumn(name = "account_no", nullable = true)
	@OrderColumn(name = "assigned_order")
	protected List<ServiceRequest> serviceRequests;

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getSubscribedPackage() {
		return subscribedPackage;
	}

	public void setSubscribedPackage(String subscribedPackage) {
		this.subscribedPackage = subscribedPackage;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getRegisteredMobileNo() {
		return registeredMobileNo;
	}

	public void setRegisteredMobileNo(String registeredMobileNo) {
		this.registeredMobileNo = registeredMobileNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public List<ServiceRequest> getServiceRequests() {
		return serviceRequests;
	}

	public void setServiceRequests(List<ServiceRequest> serviceRequests) {
		this.serviceRequests = serviceRequests;
	}

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountHolderName=" + accountHolderName + ", subscribedPackage="
				+ subscribedPackage + ", accountType=" + accountType + ", registeredMobileNo=" + registeredMobileNo
				+ ", emailAddress=" + emailAddress + ", serviceRequests=" + serviceRequests + "]";
	}

}
