package com.otml.test;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.otml.entities.Account;
import com.otml.entities.ServiceRequest;
import com.otml.helper.SessionFactoryHelper;

public class OTMLTest {

	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		ServiceRequest sr1 = null;
		ServiceRequest sr2 = null;
		Account account = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			sr1 = new ServiceRequest();
			sr1.setRequestType("recharge");
			sr1.setRequestedDate(new Date());
			sr1.setDescription("recharge with 500");
			sr1.setStatus("created");
			session.save(sr1);
			
			sr2 = new ServiceRequest();
			sr2.setRequestType("activate");
			sr2.setRequestedDate(new Date());
			sr2.setDescription("activate sports package");
			sr2.setStatus("created");
			session.save(sr2);
			
			account = new Account();
			account.setAccountHolderName("smith");
			account.setAccountType("HD");
			account.setSubscribedPackage("South HD Package");
			account.setRegisteredMobileNo("039304404");
			account.setEmailAddress("smith@gmail.com");
			List<ServiceRequest> serviceRequests = new ArrayList<>();
			serviceRequests.add(sr1);
			serviceRequests.add(sr2);
			account.setServiceRequests(serviceRequests);
			session.save(account);
			
			/*account = (Account) session.get(Account.class, 1);
			System.out.println(account);*/
			
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}
			SessionFactoryHelper.close();
		}
	}

}








