package com.gt.servlet;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.gt.entities.Technician;
import com.gt.helper.SessionFactoryHelper;

public class AddTechnicianServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		SessionFactory sessionFactory = null;
		Transaction transaction = null;
		Technician technician = null;
		Session session = null;
		boolean flag = false;

		try {
			technician = new Technician();
			technician.setTechnicianName(req.getParameter("technicianName"));
			technician.setDesignation(req.getParameter("designation"));
			technician.setExperience(Integer.parseInt(req.getParameter("experience")));
			technician.setEmailAddress(req.getParameter("emailAddress"));
			technician.setMobileNo(req.getParameter("mobileNo"));

			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			session.save(technician);

			flag = true;
			req.setAttribute("technicianNo", technician.getTechnicianNo());
			req.setAttribute("techicianName", technician.getTechnicianName());
			req.getRequestDispatcher("/technician-info.jsp").forward(req, resp);
		} finally {
			if (transaction != null) {
				if (flag == true) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
			}
			if (session != null) {
				session.close();
			}
		}

	}
}
