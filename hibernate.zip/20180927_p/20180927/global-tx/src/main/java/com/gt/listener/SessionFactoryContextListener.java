package com.gt.listener;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import com.gt.helper.SessionFactoryHelper;

public class SessionFactoryContextListener implements ServletContextListener {

	@Override
	public void contextInitialized(ServletContextEvent sce) {
		SessionFactoryHelper.getSessionFactory();
	}

	@Override
	public void contextDestroyed(ServletContextEvent sce) {
		SessionFactoryHelper.closeSessionFactory();
	}

}
