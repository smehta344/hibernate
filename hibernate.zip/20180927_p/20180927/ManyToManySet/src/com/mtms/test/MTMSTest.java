package com.mtms.test;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.mtms.entities.Member;
import com.mtms.entities.Project;
import com.mtms.helper.SessionFactoryHelper;

public class MTMSTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		Member member1 = null;
		Member member2 = null;
		Member member3 = null;
		Project project = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			
			/*member3 = new Member();
			member3.setMemberName("david");
			member3.setDesignation("developer");
			member3.setExperience(3);
			member3.setPrimarySkill("java");
			session.save(member3);*/
			
			project = (Project) session.get(Project.class, 1);
			//project.getMembers().add(member3);
			//session.update(project);
			Iterator<Member> it = project.getMembers().iterator();
			if(it.hasNext()) {
				it.next();
				it.remove();
			}
			session.update(project);
			
			/*member2 = new Member();
			member2.setMemberName("ray");
			member2.setDesignation("developer");
			member2.setExperience(1);
			member2.setPrimarySkill("html");
			session.save(member2);
			
			project = new Project();
			project.setTitle("HMS System");
			project.setDescription("Hospital management system");
			project.setDuration(6);
			project.setDomain("Healthcare");
			Set<Member> members = new HashSet<>();
			members.add(member1);
			members.add(member2);
			project.setMembers(members);
			session.save(project);*/
			

			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}
			SessionFactoryHelper.close();
		}
	}
}




