package com.otms.test;

import java.util.List;
import java.util.Set;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.otms.entities.Complaint;
import com.otms.entities.Customer;
import com.otms.helper.SessionFactoryHelper;

public class FetchTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		Customer customer = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			
			/*customer = (Customer) session.get(Customer.class, 1);
			System.out.println(customer.getFirstName());
			Set<Complaint> complaints = customer.getComplaints();
			
			for(Complaint complaint : complaints) {
				System.out.println(complaint);
			}*/
			
			Query query = session.createQuery("from Customer");
			List<Customer> customers = query.list();
			Set<Complaint> complaints = null;
			
			for(Customer c : customers) {
				complaints = c.getComplaints();
				for(Complaint complaint : complaints) {
					System.out.println(complaint.getComplaintNo());
				}
			}
			
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}
			SessionFactoryHelper.close();
		}
	}

}
