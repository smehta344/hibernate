package com.otms.test;

import java.util.Iterator;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.otms.entities.Complaint;
import com.otms.entities.Customer;
import com.otms.helper.SessionFactoryHelper;

public class CascadeTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		Set<Complaint> complaints = null;
		Complaint complaint1 = null;
		Complaint complaint2 = null;
		Customer customer = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			// transient objects
			/*complaint1 = new Complaint();
			complaint1.setProblem("Battery Problem");
			complaint1.setDescription("Not charging");
			complaint1.setLoggedDate(new Date());

			complaint2 = new Complaint();
			complaint2.setProblem("signal problem");
			complaint2.setDescription("Call drop");
			complaint2.setLoggedDate(new Date());
			
			complaints = new HashSet<>();
			complaints.add(complaint1);
			complaints.add(complaint2);
			
			customer = new Customer();
			customer.setFirstName("Rod");
			customer.setLastName("l");
			customer.setMobileNo("393940408");
			customer.setEmailAddress("rod@gmail.com");
			customer.setComplaints(complaints);
			session.save(customer);*/
			
			/*customer = (Customer) session.get(Customer.class, 1);
			customer.setFirstName("Yray");
			complaint1 = customer.getComplaints().iterator().next();
			complaint1.setDescription("Severity High");
			
			session.update(customer);*/
			/*customer = (Customer) session.get(Customer.class, 1);
			session.delete(customer);*/

			customer = (Customer) session.get(Customer.class, 1);
			Iterator it = customer.getComplaints().iterator();
			it.next();
			it.remove();
			session.update(customer);
			
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}
			SessionFactoryHelper.close();
		}
	}

}








