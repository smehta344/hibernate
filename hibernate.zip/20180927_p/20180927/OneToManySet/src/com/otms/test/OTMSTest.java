package com.otms.test;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.otms.entities.Complaint;
import com.otms.entities.Customer;
import com.otms.helper.SessionFactoryHelper;

public class OTMSTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		Set<Complaint> complaints = null;
		Complaint complaint = null;
		Customer customer = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			/*complaints = new HashSet<>();

			complaint = new Complaint();
			complaint.setProblem("Battery Problem");
			complaint.setDescription("Not charging");
			complaint.setLoggedDate(new Date());
			session.save(complaint);
			complaints.add(complaint);

			complaint = new Complaint();
			complaint.setProblem("signal problem");
			complaint.setDescription("Call drop");
			complaint.setLoggedDate(new Date());
			session.save(complaint);
			complaints.add(complaint);
			
			customer = new Customer();
			customer.setFirstName("Rod");
			customer.setLastName("l");
			customer.setMobileNo("393940408");
			customer.setEmailAddress("rod@gmail.com");
			customer.setComplaints(complaints);
			session.save(customer);*/
			
			customer = (Customer) session.get(Customer.class, 1);
			System.out.println(customer);
			
			

			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}
			SessionFactoryHelper.close();
		}
	}
}











