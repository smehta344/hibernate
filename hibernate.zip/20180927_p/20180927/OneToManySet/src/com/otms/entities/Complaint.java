package com.otms.entities;

import java.io.Serializable;
import java.util.Date;

public class Complaint implements Serializable {
	protected int complaintNo;
	protected String problem;
	protected String description;
	protected Date loggedDate;

	public int getComplaintNo() {
		return complaintNo;
	}

	public void setComplaintNo(int complaintNo) {
		this.complaintNo = complaintNo;
	}

	public String getProblem() {
		return problem;
	}

	public void setProblem(String problem) {
		this.problem = problem;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Date getLoggedDate() {
		return loggedDate;
	}

	public void setLoggedDate(Date loggedDate) {
		this.loggedDate = loggedDate;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + complaintNo;
		result = prime * result + ((description == null) ? 0 : description.hashCode());
		result = prime * result + ((loggedDate == null) ? 0 : loggedDate.hashCode());
		result = prime * result + ((problem == null) ? 0 : problem.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Complaint other = (Complaint) obj;
		if (complaintNo != other.complaintNo)
			return false;
		if (description == null) {
			if (other.description != null)
				return false;
		} else if (!description.equals(other.description))
			return false;
		if (loggedDate == null) {
			if (other.loggedDate != null)
				return false;
		} else if (!loggedDate.equals(other.loggedDate))
			return false;
		if (problem == null) {
			if (other.problem != null)
				return false;
		} else if (!problem.equals(other.problem))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "Complaint [complaintNo=" + complaintNo + ", problem=" + problem + ", description=" + description
				+ ", loggedDate=" + loggedDate + "]";
	}

}
