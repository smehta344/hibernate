package com.msf.accessor;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.msf.entities.Passenger;
import com.msf.helper.SessionFactoryHelper;

public class PassengerDao {

	public Passenger getPassenger(int passengerNo) {
		SessionFactory sessionFactory = null;
		Passenger passenger = null;
		Session session = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			passenger = (Passenger) session.get(Passenger.class, passengerNo);
		} finally {
			if (session != null) {
				session.close();
			}
		}
		return passenger;
	}

	public void savePassenger(Passenger passenger) {
		SessionFactory sessionFactory = null;
		Transaction transaction = null;
		Session session = null;
		boolean flag = false;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			session.save(passenger);
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
			}
			if (session != null) {
				session.close();
			}
		}
	}
}
