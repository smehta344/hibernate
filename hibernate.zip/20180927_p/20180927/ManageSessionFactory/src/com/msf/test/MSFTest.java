package com.msf.test;

import com.msf.accessor.PassengerDao;
import com.msf.entities.Passenger;
import com.msf.helper.SessionFactoryHelper;

public class MSFTest {
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		PassengerDao passengerDao = null;
		Passenger passenger = null;
		try {
			passenger = new Passenger();
			passenger.setPassengerNo(3);
			passenger.setFirstName("Susan");
			passenger.setLastName("x");
			passenger.setAge(35);
			passenger.setGender("Female");
			passenger.setMobileNbr("394950");
			passenger.setEmailAddress("susan@yahoo.com");
			
			passengerDao = new PassengerDao();
			//passengerDao.savePassenger(passenger);
			
			Passenger passenger1 = passengerDao.getPassenger(3);
			System.out.println(passenger1);
		} finally {
			SessionFactoryHelper.close();
		}

	}
}





