package com.aim.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.aim.entities.SavingsAccount;
import com.aim.helper.SessionFactoryHelper;
import com.aim.entities.Account;
import com.aim.entities.CurrentAccount;

public class AIMSTTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		Account account = null;
		SavingsAccount savingsAccount = null;
		CurrentAccount currentAccount = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			/*account = new Account();
			account.setAccountHolderName("Steve");
			account.setBranch("ameerpet");
			account.setBalance(393);*/
			
			/*savingsAccount = new SavingsAccount();
			savingsAccount.setAccountHolderName("Williams");
			savingsAccount.setBranch("miyapur");
			savingsAccount.setBalance(9393);
			savingsAccount.setMaxTransactionLimit(100000);
			savingsAccount.setMinBalance(1000);
			savingsAccount.setAnnualCharges(500);*/
			
			/*currentAccount = new CurrentAccount();
			currentAccount.setAccountHolderName("Tod");
			currentAccount.setBranch("miyapur");
			currentAccount.setBalance(19393);
			currentAccount.setMaxDepositeLimit(200000);
			currentAccount.setMaxWithdrawLimit(100000);
			currentAccount.setOverdraftLimit(500000);*/
			
			

			/*int accountNo = (Integer) session.save(currentAccount);
			System.out.println("accountNo : " + accountNo);*/
			
			/*savingsAccount = (SavingsAccount) session.get(SavingsAccount.class, 2);
			System.out.println(savingsAccount);*/
			
			account = (Account) session.get(Account.class, 2);
			System.out.println(account);
			
			
			
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}
			SessionFactoryHelper.close();
		}
	}
}






