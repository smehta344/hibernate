package com.aim.entities;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name="savings_account")
/*@DiscriminatorValue("savings_account")*/
/*@PrimaryKeyJoinColumn(name="savings_account_no")*/
@AttributeOverrides({@AttributeOverride(name="accountNo", column=@Column(name="savings_account_no"))})
public class SavingsAccount extends Account {
	@Column(name = "min_balance")
	protected int minBalance;
	@Column(name = "max_transaction_limit")
	protected int maxTransactionLimit;
	@Column(name = "annual_charges")
	protected float annualCharges;

	public int getMinBalance() {
		return minBalance;
	}

	public void setMinBalance(int minBalance) {
		this.minBalance = minBalance;
	}

	public int getMaxTransactionLimit() {
		return maxTransactionLimit;
	}

	public void setMaxTransactionLimit(int maxTransactionLimit) {
		this.maxTransactionLimit = maxTransactionLimit;
	}

	public float getAnnualCharges() {
		return annualCharges;
	}

	public void setAnnualCharges(float annualCharges) {
		this.annualCharges = annualCharges;
	}

	@Override
	public String toString() {
		return "SavingsAccount [minBalance=" + minBalance + ", maxTransactionLimit=" + maxTransactionLimit
				+ ", annualCharges=" + annualCharges + "]";
	}

}
