package com.aim.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "account")
/*@Inheritance(strategy = InheritanceType.SINGLE_TABLE)
@DiscriminatorColumn(name = "account_type")
@DiscriminatorValue("account")*/
/*@Inheritance(strategy=InheritanceType.JOINED)*/
@Inheritance(strategy=InheritanceType.TABLE_PER_CLASS)
public class Account implements Serializable {
	@Id
	@Column(name = "account_no")
	@GeneratedValue(generator = "increment_generator")
	@GenericGenerator(name = "increment_generator", strategy = "increment")
	protected int accountNo;
	@Column(name = "account_holder_nm")
	protected String accountHolderName;
	protected String branch;
	protected double balance;

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public double getBalance() {
		return balance;
	}

	public void setBalance(double balance) {
		this.balance = balance;
	}

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", accountHolderName=" + accountHolderName + ", branch=" + branch
				+ ", balance=" + balance + "]";
	}

}
