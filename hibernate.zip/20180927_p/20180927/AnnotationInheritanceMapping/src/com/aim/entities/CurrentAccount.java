package com.aim.entities;

import javax.persistence.AttributeOverride;
import javax.persistence.AttributeOverrides;
import javax.persistence.Column;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

@Entity
@Table(name = "current_account")
/* @DiscriminatorValue("current_account") */
/* @PrimaryKeyJoinColumn(name="current_account_no") */
@AttributeOverrides(@AttributeOverride(name = "accountNo", column = @Column(name = "current_account_no")))
public class CurrentAccount extends Account {
	@Column(name = "max_withdraw_limit")
	protected int maxWithdrawLimit;
	@Column(name = "max_deposite_limit")
	protected int maxDepositeLimit;
	@Column(name = "overdraft_limit")
	protected double overdraftLimit;

	public int getMaxWithdrawLimit() {
		return maxWithdrawLimit;
	}

	public void setMaxWithdrawLimit(int maxWithdrawLimit) {
		this.maxWithdrawLimit = maxWithdrawLimit;
	}

	public int getMaxDepositeLimit() {
		return maxDepositeLimit;
	}

	public void setMaxDepositeLimit(int maxDepositeLimit) {
		this.maxDepositeLimit = maxDepositeLimit;
	}

	public double getOverdraftLimit() {
		return overdraftLimit;
	}

	public void setOverdraftLimit(double overdraftLimit) {
		this.overdraftLimit = overdraftLimit;
	}

	@Override
	public String toString() {
		return "CurrentAccount [maxWithdrawLimit=" + maxWithdrawLimit + ", maxDepositeLimit=" + maxDepositeLimit
				+ ", overdraftLimit=" + overdraftLimit + "]";
	}

}
