package com.otmasotobi.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "emergency_contact")
public class EmergencyContact implements Serializable {
	@Id
	@Column(name = "emergency_contact_no")
	@GeneratedValue(generator = "inc_gen")
	@GenericGenerator(name = "inc_gen", strategy = "increment")
	protected int emergencyContactNo;
	@Column(name = "contact_nm")
	protected String contactName;
	@Column(name = "relation_ship")
	protected String relationShip;
	@Column(name = "mobile_no")
	protected String mobileNo;

	@ManyToOne
	@JoinColumn(name = "account_no", unique = true, nullable = false)
	protected Account account;

	public int getEmergencyContactNo() {
		return emergencyContactNo;
	}

	public void setEmergencyContactNo(int emergencyContactNo) {
		this.emergencyContactNo = emergencyContactNo;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getRelationShip() {
		return relationShip;
	}

	public void setRelationShip(String relationShip) {
		this.relationShip = relationShip;
	}

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Account getAccount() {
		return account;
	}

	public void setAccount(Account account) {
		this.account = account;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((contactName == null) ? 0 : contactName.hashCode());
		result = prime * result + emergencyContactNo;
		result = prime * result + ((mobileNo == null) ? 0 : mobileNo.hashCode());
		result = prime * result + ((relationShip == null) ? 0 : relationShip.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		EmergencyContact other = (EmergencyContact) obj;
		if (contactName == null) {
			if (other.contactName != null)
				return false;
		} else if (!contactName.equals(other.contactName))
			return false;
		if (emergencyContactNo != other.emergencyContactNo)
			return false;
		if (mobileNo == null) {
			if (other.mobileNo != null)
				return false;
		} else if (!mobileNo.equals(other.mobileNo))
			return false;
		if (relationShip == null) {
			if (other.relationShip != null)
				return false;
		} else if (!relationShip.equals(other.relationShip))
			return false;
		return true;
	}

	@Override
	public String toString() {
		return "EmergencyContact [emergencyContactNo=" + emergencyContactNo + ", contactName=" + contactName
				+ ", relationShip=" + relationShip + ", mobileNo=" + mobileNo + "]";
	}

}
