package com.otmasotobi.entities;

import java.io.Serializable;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.annotations.GenericGenerator;

@Entity
@Table(name = "account")
public class Account implements Serializable {
	@Id
	@Column(name = "account_no")
	@GeneratedValue(generator = "inc_gen")
	@GenericGenerator(name = "inc_gen", strategy = "increment")
	protected int accountNo;
	@Column(name = "member_nm")
	protected String memberName;
	@Column(name = "registered_mobile_no")
	protected String registeredMobileNo;
	@Column(name = "email_address")
	protected String emailAddress;

	@OneToMany(mappedBy = "account")
	// @JoinColumn(name = "account_no", unique = true, nullable = false)
	// it has only one emergency contact as foreign key is unique
	protected Set<EmergencyContact> emergencyContacts;

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getMemberName() {
		return memberName;
	}

	public void setMemberName(String memberName) {
		this.memberName = memberName;
	}

	public String getRegisteredMobileNo() {
		return registeredMobileNo;
	}

	public void setRegisteredMobileNo(String registeredMobileNo) {
		this.registeredMobileNo = registeredMobileNo;
	}

	public String getEmailAddress() {
		return emailAddress;
	}

	public void setEmailAddress(String emailAddress) {
		this.emailAddress = emailAddress;
	}

	public Set<EmergencyContact> getEmergencyContacts() {
		return emergencyContacts;
	}

	public void setEmergencyContacts(Set<EmergencyContact> emergencyContacts) {
		this.emergencyContacts = emergencyContacts;
	}

	@Override
	public String toString() {
		return "Account [accountNo=" + accountNo + ", memberName=" + memberName + ", registeredMobileNo="
				+ registeredMobileNo + ", emailAddress=" + emailAddress + ", emergencyContacts=" + emergencyContacts
				+ "]";
	}

}
