package com.otmasotobi.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.otmasotobi.entities.Account;
import com.otmasotobi.entities.EmergencyContact;
import com.otmasotobi.helper.SessionFactoryHelper;

public class Test {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		EmergencyContact ec1 = null;
		EmergencyContact ec2 = null;
		Account account = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			
			/*account = new Account();
			account.setMemberName("Mark");
			account.setEmailAddress("mark@yahoo.com");
			account.setRegisteredMobileNo("9893849484");
			session.save(account);
			
			ec1 = new EmergencyContact();
			ec1.setContactName("Marinda");
			ec1.setRelationShip("Spouse");
			ec1.setMobileNo("9304940");
			ec1.setAccount(account);
			session.save(ec1);*/
			
			/*ec2 = new EmergencyContact();
			ec2.setContactName("Steve");
			ec2.setRelationShip("Friend");
			ec2.setMobileNo("93435366");
			ec2.setAccount(account);
			session.save(ec2);*/
			
			account = (Account) session.get(Account.class, 1);
			System.out.println(account);
			

			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}
			SessionFactoryHelper.close();
		}
	}
}
