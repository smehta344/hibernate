package com.otmm.test;

import java.util.HashMap;
import java.util.Map;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.otmm.entities.Account;
import com.otmm.entities.CreditCard;
import com.otmm.helper.SessionFactoryHelper;

public class OTMMTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		CreditCard cc1 = null;
		CreditCard cc2 = null;
		Account account = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			cc1 = new CreditCard();
			cc1.setCreditCardNo("0303809404904");
			cc1.setCardType("visa");
			cc1.setCvv(393);
			cc1.setExpiryDate("01/22");
			cc1.setIssuedDate("01/19");
			cc1.setNameOnCard("siva");
			session.save(cc1);

			cc2 = new CreditCard();
			cc2.setCreditCardNo("999807938");
			cc2.setCardType("visa");
			cc2.setCvv(393);
			cc2.setExpiryDate("01/21");
			cc2.setIssuedDate("01/18");
			cc2.setNameOnCard("ramu");
			session.save(cc2);

			account = new Account();
			account.setAccountHolderName("siva");
			account.setAccountType("credit");
			account.setBranch("jublee");
			account.setCashLimit(90000);
			account.setCreditLimit(150000);

			Map<String, CreditCard> issuedCards = new HashMap<String, CreditCard>();
			issuedCards.put("ac3", cc1);
			issuedCards.put("ac4", cc2);
			account.setIssuedCards(issuedCards);
			session.save(account);

			/*
			 * account = (Account) session.get(Account.class, 1);
			 * System.out.println(account);
			 */
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}
			SessionFactoryHelper.close();
		}
	}
}
