package com.otmm.entities;

import java.io.Serializable;
import java.util.Map;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.MapKey;
import javax.persistence.MapKeyColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name = "account")
public class Account implements Serializable {
	@Id
	@Column(name = "account_no")
	@GeneratedValue(strategy = GenerationType.AUTO)
	protected int accountNo;
	@Column(name = "account_holder_nm")
	protected String accountHolderName;
	@Column(name = "account_type")
	protected String accountType;
	protected String branch;
	@Column(name = "credit_limit")
	protected double creditLimit;
	@Column(name = "cash_limit")
	protected double cashLimit;

	@OneToMany
	@JoinColumn(name = "account_no", nullable = true)
	@MapKeyColumn(name = "activation_code", nullable = true)
	protected Map<String, CreditCard> issuedCards;

	public int getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(int accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountHolderName() {
		return accountHolderName;
	}

	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getBranch() {
		return branch;
	}

	public void setBranch(String branch) {
		this.branch = branch;
	}

	public double getCreditLimit() {
		return creditLimit;
	}

	public void setCreditLimit(double creditLimit) {
		this.creditLimit = creditLimit;
	}

	public double getCashLimit() {
		return cashLimit;
	}

	public void setCashLimit(double cashLimit) {
		this.cashLimit = cashLimit;
	}

	public Map<String, CreditCard> getIssuedCards() {
		return issuedCards;
	}

	public void setIssuedCards(Map<String, CreditCard> issuedCards) {
		this.issuedCards = issuedCards;
	}

}
