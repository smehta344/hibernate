package com.otmm.entities;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "credit_card")
public class CreditCard implements Serializable {
	@Id
	@Column(name = "card_no")
	@GeneratedValue(strategy = GenerationType.AUTO)
	protected int cardNo;
	@Column(name = "credit_card_no")
	protected String creditCardNo;
	@Column(name = "name_on_card")
	protected String nameOnCard;
	@Column(name = "card_type")
	protected String cardType;
	@Column(name = "issued_dt")
	protected String issuedDate;
	@Column(name = "expiry_dt")
	protected String expiryDate;
	protected int cvv;

	public int getCardNo() {
		return cardNo;
	}

	public void setCardNo(int cardNo) {
		this.cardNo = cardNo;
	}

	public String getCreditCardNo() {
		return creditCardNo;
	}

	public void setCreditCardNo(String creditCardNo) {
		this.creditCardNo = creditCardNo;
	}

	public String getNameOnCard() {
		return nameOnCard;
	}

	public void setNameOnCard(String nameOnCard) {
		this.nameOnCard = nameOnCard;
	}

	public String getCardType() {
		return cardType;
	}

	public void setCardType(String cardType) {
		this.cardType = cardType;
	}

	public String getIssuedDate() {
		return issuedDate;
	}

	public void setIssuedDate(String issuedDate) {
		this.issuedDate = issuedDate;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}

	public int getCvv() {
		return cvv;
	}

	public void setCvv(int cvv) {
		this.cvv = cvv;
	}

	@Override
	public String toString() {
		return "CreditCard [cardNo=" + cardNo + ", creditCardNo=" + creditCardNo + ", nameOnCard=" + nameOnCard
				+ ", cardType=" + cardType + ", issuedDate=" + issuedDate + ", expiryDate=" + expiryDate + ", cvv="
				+ cvv + "]";
	}

}
