package com.gvl.entities;

public interface IDriver {
	public int getDriverNo();
	public void setDriverNo(int driverNo);
	public String getDriverName();
	public void setDriverName(String driverName);
	public int getExperience();
	public void setExperience(int experience);
	public int getAge();
	public void setAge(int age);
	public String getGender();
	public void setGender(String gender);
}
