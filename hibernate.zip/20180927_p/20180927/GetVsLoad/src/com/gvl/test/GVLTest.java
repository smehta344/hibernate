package com.gvl.test;

import org.hibernate.Transaction;

import com.gvl.entities.Driver;
import com.gvl.entities.IDriver;
import com.gvl.helper.SessionFactoryHelper;

import org.hibernate.Session;

import org.hibernate.SessionFactory;

public class GVLTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction transaction = null;
		IDriver driver = null;
		boolean flag = false;
		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			//transaction = session.beginTransaction();
			/*
			 * driver = new Driver(); driver.setDriverNo(35); driver.setDriverName("Smith");
			 * driver.setAge(35); driver.setExperience(2); driver.setGender("Male");
			 * session.save(driver);
			 */

			driver = (IDriver) session.load(Driver.class, 35);
			System.out.println("driver retrieved : " + driver.getClass().getName());
			if (driver != null) {
				System.out.println(driver.getDriverName());
			}

			flag = true;
		} finally {
			/*if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}*/
			SessionFactoryHelper.close();
		}
	}
}
