package com.jpagen.entities;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.TableGenerator;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "job_sheet")
public class JobSheet implements Serializable {
	@Id
	@Column(name = "job_sheet_no")
	/* @GeneratedValue(strategy=GenerationType.AUTO) */
//	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "jobsheet_seq_generator")
//	@SequenceGenerator(name = "jobsheet_seq_generator", sequenceName = "jobsheet_seq", initialValue = 1, allocationSize = 1)
	/*
	 * @GeneratedValue(strategy=GenerationType.TABLE,
	 * generator="jobsheet_generator")
	 * 
	 * @TableGenerator(name="jobsheet_generator", table="jobsheet_gen",
	 * initialValue=1, pkColumnName="job_sheet_pk", pkColumnValue="job_sheet",
	 * valueColumnName="job_sheet_no")
	 */
	/*
	 * @GeneratedValue(generator="increment_gen")
	 * 
	 * @GenericGenerator(name="increment_gen", strategy="increment")
	 */

	@GeneratedValue(generator = "hilo_generator")
	@GenericGenerator(name = "hilo_generator", strategy = "hilo", parameters = {
			@Parameter(name = "max_lo", value = "5"), @Parameter(name = "table", value = "jobsheet_hilo"),
			@Parameter(name = "column", value = "next_job_sheet_no") })
	protected int jobSheetNo;
	@Column(name = "model_nm")
	protected String modelName;
	@Column(name = "reg_no")
	protected String regNo;
	@Column(name = "service_type")
	protected String serviceType;
	@Column(name = "job_sheet_opened_dt")
	protected Date jobSheetOpenedDate;
	@Column(name = "estimated_hours")
	protected int estimatedHours;
	@Column(name = "estimated_amount")
	protected float estimatedAmount;

	public JobSheet() {
	}

	public JobSheet(String modelName, String regNo, String serviceType, Date jobSheetOpenedDate, int estimatedHours,
			float estimatedAmount) {
		this.modelName = modelName;
		this.regNo = regNo;
		this.serviceType = serviceType;
		this.jobSheetOpenedDate = jobSheetOpenedDate;
		this.estimatedHours = estimatedHours;
		this.estimatedAmount = estimatedAmount;
	}

	public int getJobSheetNo() {
		return jobSheetNo;
	}

	public void setJobSheetNo(int jobSheetNo) {
		this.jobSheetNo = jobSheetNo;
	}

	public String getModelName() {
		return modelName;
	}

	public void setModelName(String modelName) {
		this.modelName = modelName;
	}

	public String getRegNo() {
		return regNo;
	}

	public void setRegNo(String regNo) {
		this.regNo = regNo;
	}

	public String getServiceType() {
		return serviceType;
	}

	public void setServiceType(String serviceType) {
		this.serviceType = serviceType;
	}

	public Date getJobSheetOpenedDate() {
		return jobSheetOpenedDate;
	}

	public void setJobSheetOpenedDate(Date jobSheetOpenedDate) {
		this.jobSheetOpenedDate = jobSheetOpenedDate;
	}

	public int getEstimatedHours() {
		return estimatedHours;
	}

	public void setEstimatedHours(int estimatedHours) {
		this.estimatedHours = estimatedHours;
	}

	public float getEstimatedAmount() {
		return estimatedAmount;
	}

	public void setEstimatedAmount(float estimatedAmount) {
		this.estimatedAmount = estimatedAmount;
	}

	@Override
	public String toString() {
		return "JobSheet [jobSheetNo=" + jobSheetNo + ", modelName=" + modelName + ", regNo=" + regNo + ", serviceType="
				+ serviceType + ", jobSheetOpenedDate=" + jobSheetOpenedDate + ", estimatedHours=" + estimatedHours
				+ ", estimatedAmount=" + estimatedAmount + "]";
	}

}
