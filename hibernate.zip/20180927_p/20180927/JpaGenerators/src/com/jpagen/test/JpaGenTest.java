package com.jpagen.test;

import java.util.Date;

import javax.persistence.EntityManager;

import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import com.jpagen.entities.JobSheet;
import com.jpagen.helper.EntityManagerFactoryHelper;

public class JpaGenTest {
	public static void main(String[] args) {
		EntityManagerFactory entityManagerFactory = null;
		EntityTransaction transaction = null;
		EntityManager entityManager = null;
		JobSheet jobSheet = null;
		boolean flag = false;

		try {
			entityManagerFactory = EntityManagerFactoryHelper.getEntityManagerFactory();
			entityManager = entityManagerFactory.createEntityManager();
			transaction = entityManager.getTransaction();
			transaction.begin();

			jobSheet = new JobSheet("Wagnor", "TS 09 3939", "Free", new Date(), 8, 339.34f);
			entityManager.persist(jobSheet);
			System.out.println("jobSheetNo : " + jobSheet.getJobSheetNo());
			
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				entityManager.close();
			}
			EntityManagerFactoryHelper.close();
		}
	}
}
