package com.cs.service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Map;

import org.hibernate.HibernateException;
import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;
import org.hibernate.service.spi.Configurable;
import org.hibernate.service.spi.Startable;
import org.hibernate.service.spi.Stoppable;

public class JdbcConnectionProviderImpl implements ConnectionProvider, Startable, Stoppable, Configurable {
	private String driverClassname;
	private String url;
	private String username;
	private String password;

	@Override
	public boolean isUnwrappableAs(Class unwrapType) {
		return false;
	}

	@Override
	public <T> T unwrap(Class<T> unwrapType) {
		return null;
	}

	@Override
	public void configure(Map configurationValues) {
		driverClassname = (String) configurationValues.get("hibernate.connection.driver_class");
		url = (String) configurationValues.get("connection.url");
		username = (String) configurationValues.get("hibernate.connection.username");
		password = (String) configurationValues.get("connection.password");

	}

	@Override
	public void stop() {
		System.out.println("stop()");
	}

	@Override
	public void start() {
		try {
			System.out.println("getConnection()");
			Class.forName(driverClassname);
		} catch (Exception e) {
			throw new HibernateException("driver loading failed", e);
		}
	}

	@Override
	public Connection getConnection() throws SQLException {
		Connection con = null;

		con = DriverManager.getConnection(url, username, password);
		con.setAutoCommit(false);

		return con;
	}

	@Override
	public void closeConnection(Connection conn) throws SQLException {
		if (conn != null && conn.isClosed() == false) {
			conn.close();
		}
	}

	@Override
	public boolean supportsAggressiveRelease() {
		return false;
	}

}
