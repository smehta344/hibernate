package com.cs.service;

import java.util.Map;

import org.hibernate.boot.registry.StandardServiceInitiator;
import org.hibernate.engine.jdbc.connections.spi.ConnectionProvider;
import org.hibernate.service.spi.ServiceRegistryImplementor;

public class JdbcConnectionServiceInitiator implements StandardServiceInitiator<ConnectionProvider> {

	@Override
	public Class<ConnectionProvider> getServiceInitiated() {
		return ConnectionProvider.class;
	}

	@Override
	public ConnectionProvider initiateService(Map configurationValues, ServiceRegistryImplementor registry) {
		JdbcConnectionProviderImpl jdbcConnectionProvider = null;
		jdbcConnectionProvider = new JdbcConnectionProviderImpl();

		return jdbcConnectionProvider;
	}

}
