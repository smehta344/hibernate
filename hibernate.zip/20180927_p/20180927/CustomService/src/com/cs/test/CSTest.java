package com.cs.test;

import org.hibernate.Session;
import org.hibernate.SessionFactory;

import com.cs.entities.Staff;
import com.cs.helper.SessionFactoryHelper;

public class CSTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Staff staff = null;
		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			staff = (Staff) session.get(Staff.class, 3);
			System.out.println(staff);
		} finally {
			SessionFactoryHelper.close();
		}
	}
}
