package com.mtml.test;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.mtml.entities.MedicalCheckup;
import com.mtml.entities.Patient;
import com.mtml.helper.SessionFactoryHelper;

public class MTMLTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		Patient patient = null;
		MedicalCheckup mc1 = null;
		MedicalCheckup mc2 = null;
		List<MedicalCheckup> medicalChecks = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();

			mc1 = new MedicalCheckup();
			mc1.setMedicalCheckupName("Random BloodSugar");
			mc1.setDescription("Blood Sugar check");
			mc1.setCost(70);
			session.save(mc1);

			mc2 = new MedicalCheckup();
			mc2.setMedicalCheckupName("T3 and TSH Check");
			mc2.setDescription("Thyroid Check");
			mc2.setCost(250);
			session.save(mc2);

			patient = new Patient();
			patient.setPatientName("Random");
			patient.setAge(32);
			patient.setGender("Male");
			patient.setEmailAddress("random@gmail.com");
			patient.setMobileNo("989373937");

			medicalChecks = new ArrayList<>();
			medicalChecks.add(mc2);
			medicalChecks.add(mc1);
			patient.setMedicalChecks(medicalChecks);
			session.save(patient);

			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}
			SessionFactoryHelper.close();
		}
	}
}
