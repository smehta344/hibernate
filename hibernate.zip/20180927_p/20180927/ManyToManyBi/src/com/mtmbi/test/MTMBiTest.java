package com.mtmbi.test;

import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.mtmbi.entities.Passenger;
import com.mtmbi.entities.Ticket;
import com.mtmbi.helper.SessionFactoryHelper;

public class MTMBiTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		Passenger p1 = null;
		Passenger p2 = null;
		Ticket ticket = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();
			session = sessionFactory.openSession();
			transaction = session.beginTransaction();
			/*p1 = new Passenger();
			p1.setPassengerName("bob");
			p1.setAge(29);
			p1.setGender("Male");
			p1.setMobileNo("3934904");
			session.save(p1);

			p2 = new Passenger();
			p2.setPassengerName("alice");
			p2.setAge(25);
			p2.setGender("Female");
			p2.setMobileNo("33934904");
			session.save(p2);
			
			Set<Passenger> passengers = new HashSet<>();
			passengers.add(p1);
			passengers.add(p2);
			
			ticket = new Ticket();
			ticket.setSource("hyderbad");
			ticket.setDestination("banglore");
			ticket.setBookedDate(new Date());
			ticket.setJourneyDate(new Date());
			ticket.setAmount(393);
			ticket.setPassengers(passengers);
			session.save(ticket);*/
			
			p1 = (Passenger) session.get(Passenger.class, 1);
			System.out.println(p1.getTickets().iterator().next().getSource());

			ticket = (Ticket) session.get(Ticket.class, 1);
			System.out.println(ticket);
			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
				session.close();
			}
			SessionFactoryHelper.close();
		}
	}
}
