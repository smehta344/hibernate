package com.slc.test;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.stat.Statistics;

import com.slc.entities.Branch;
import com.slc.helper.SessionFactoryHelper;

public class SLCTest {
	public static void main(String[] args) {
		SessionFactory sessionFactory = null;
		Session session = null;
		Transaction transaction = null;
		boolean flag = false;
		Branch branch = null;

		try {
			sessionFactory = SessionFactoryHelper.getSessionFactory();

			// transaction = session.beginTransaction();

			/*
			 * branch = new Branch(); branch.setBranchName("Madhapur");
			 * branch.setIfscCode("62738"); branch.setAddressLine1("Hitech City Roads");
			 * branch.setCity("Hyderabad"); branch.setState("TS");
			 */

			// session.save(branch);

			// conversation#1
			/*session = sessionFactory.openSession();
			System.out.println("fetch branch1");
			branch = (Branch) session.get(Branch.class, 1);
			System.out.println("fetch branch2");
			Branch branch1 = (Branch) session.get(Branch.class, 1);
			session.close();*/

			// conversation#2
			/*session = sessionFactory.openSession();
			System.out.println("fetch branch3");
			branch = (Branch) session.get(Branch.class, 1);
			session.close();*/

			// conversation#2
			/*session = sessionFactory.openSession();
			System.out.println("fetch branch3");
			branch = (Branch) session.get(Branch.class, 1);
			session.close();*/

			session = sessionFactory.openSession();
			Query query = session.createQuery("from Branch where city = ?");
			query.setCacheable(true);
			query.setParameter(0, "Hyderabad");
			
			List<Branch> branches = query.list();
			for(Branch b : branches) {
				System.out.println(b.hashCode());
			}
			//session.close();
			
			//session = sessionFactory.openSession();
			query = session.createQuery("from Branch where city = ?");
			query.setParameter(0, "Hyderabad");
			branches = query.list();
			for(Branch b : branches) {
				System.out.println(b.hashCode());
			}
			session.close();
			
			Statistics stat = sessionFactory.getStatistics();
			System.out.println("query level hit : " + stat.getQueryCacheHitCount());

			flag = true;
		} finally {
			if (transaction != null) {
				if (flag) {
					transaction.commit();
				} else {
					transaction.rollback();
				}
			}

			SessionFactoryHelper.closeSessionFactory();
		}
	}
}
