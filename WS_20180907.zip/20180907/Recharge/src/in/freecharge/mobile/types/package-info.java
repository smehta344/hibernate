@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.freecharge.in/mobile/types")
package in.freecharge.mobile.types;
