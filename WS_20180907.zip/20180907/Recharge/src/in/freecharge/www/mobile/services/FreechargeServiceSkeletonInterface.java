/**
 * FreechargeServiceSkeletonInterface.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.9  Built on : Nov 16, 2018 (12:05:37 GMT)
 */
package in.freecharge.www.mobile.services;

/**
 * FreechargeServiceSkeletonInterface java skeleton interface for the
 * axisService
 */
public interface FreechargeServiceSkeletonInterface {
	/**
	 * Auto generated method signature
	 *
	 * @param rechargeIn
	 */
	public in.freecharge.mobile.types.Invoice recharge(in.freecharge.mobile.types.RechargeIn rechargeIn);
}
