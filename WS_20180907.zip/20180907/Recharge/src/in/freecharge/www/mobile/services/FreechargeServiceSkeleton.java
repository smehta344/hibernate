/**
 * FreechargeServiceSkeleton.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis2 version: 1.7.9  Built on : Nov 16, 2018 (12:05:37 GMT)
 */
package in.freecharge.www.mobile.services;

import java.util.UUID;

import in.freecharge.mobile.types.Invoice;

/**
 * FreechargeServiceSkeleton java skeleton for the axisService
 */
public class FreechargeServiceSkeleton implements FreechargeServiceSkeletonInterface {
	/**
	 * Auto generated method signature
	 *
	 * @param rechargeIn0
	 * @return invoice1
	 */
	public in.freecharge.mobile.types.Invoice recharge(in.freecharge.mobile.types.RechargeIn rechargeIn) {
		Invoice invoice = new Invoice();
		invoice.setTxNo(UUID.randomUUID().toString());
		invoice.setDescription("recharged");
		invoice.setStatus("success");
		
		return invoice;
	}
}
