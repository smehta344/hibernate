package org.lic.insurance.service;

import java.rmi.RemoteException;
import java.util.UUID;

public class InsuranceImpl implements Insurance {

	public Policy enroll(EnrollmentDetails enrollmentDetails, Member member)
			throws RemoteException {
		Policy policy = null;

		policy = new Policy();
		policy.setPolicyNo(UUID.randomUUID().toString());
		policy.setPlanName(enrollmentDetails.getPlanName());
		policy.setMemberName(member.getFirstName() + " " + member.getLastName());
		policy.setPremiumAmount(12404);
		policy.setStatus("active");
		return policy;
	}

}
