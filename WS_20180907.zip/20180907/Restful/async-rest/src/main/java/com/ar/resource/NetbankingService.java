package com.ar.resource;

import java.util.UUID;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.client.Entity;
import javax.ws.rs.container.AsyncResponse;
import javax.ws.rs.container.Suspended;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.ar.dto.Receipt;
import com.ar.dto.TransferRequest;

@Path("/iservices")
public class NetbankingService {
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/neft")
	public void neftTransfer(final TransferRequest transferRequest, final @Suspended AsyncResponse asyncResponse) {
		Runnable r = () -> {
			Response response = null;
			Receipt receipt = null;

			try {
				Thread.sleep(6000L);
				receipt = new Receipt();
				receipt.setTransactionNo(UUID.randomUUID().toString());
				receipt.setStatus(transferRequest.getFromAccount().getAccountNo() + " to "
						+ transferRequest.getToAccount().getAccountNo() + " transfered completed");
				response = Response.ok(Entity.json(receipt)).build();
				asyncResponse.resume(response);
			} catch (InterruptedException e) {
				throw new WebApplicationException(Status.INTERNAL_SERVER_ERROR);
			}
		};
		new Thread(r).start();
	}
}
