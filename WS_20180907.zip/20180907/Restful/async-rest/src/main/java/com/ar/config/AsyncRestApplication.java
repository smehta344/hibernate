package com.ar.config;

import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.server.ResourceConfig;

import com.ar.resource.NetbankingService;

@ApplicationPath("/api")
public class AsyncRestApplication extends ResourceConfig {

	public AsyncRestApplication() {
		System.out.println("asyncRestApplication()");
		super.register(NetbankingService.class);
	}
}
