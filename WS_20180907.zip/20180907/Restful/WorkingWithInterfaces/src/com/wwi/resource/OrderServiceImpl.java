package com.wwi.resource;

public class OrderServiceImpl implements OrderService {

	@Override
	public String getOrderStatus(String orderNo) {
		return "approved";
	}

}
