package com.wwa.dto;

public class Forecaste {
	protected double foreignHeat;
	protected String predictions;

	public Forecaste(double foreignHeat, String predictions) {
		super();
		this.foreignHeat = foreignHeat;
		this.predictions = predictions;
	}

	public double getForeignHeat() {
		return foreignHeat;
	}

	public void setForeignHeat(double foreignHeat) {
		this.foreignHeat = foreignHeat;
	}

	public String getPredictions() {
		return predictions;
	}

	public void setPredictions(String predictions) {
		this.predictions = predictions;
	}

}
