package com.wwa.resource;

import javax.ws.rs.Path;

import com.wwa.dto.Forecaste;

@Path("/xmlForecastor")
public class XmlWeatherForecastor extends AbstractWeatherForecastor {

	@Override
	protected String formatForeCaste(Forecaste forecaste) {
		StringBuffer buffer = null;
		buffer = new StringBuffer();
		buffer.append("<forecaste><foreignHeat>").append(forecaste.getForeignHeat())
				.append("</foreignHeat><prediction>").append(forecaste.getPredictions())
				.append("</prediction></forecaste>");
		return buffer.toString();
	}

}
