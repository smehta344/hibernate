package com.wwa.resource;

import java.io.IOException;
import java.io.OutputStream;

import javax.ws.rs.GET;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.StreamingOutput;

import com.wwa.dto.Forecaste;

public abstract class AbstractWeatherForecastor {
	@GET
	@Produces({ MediaType.APPLICATION_XML, MediaType.APPLICATION_JSON })
	public StreamingOutput getWeatherPrediction(@QueryParam("zip") String zip) {
		Forecaste forecaste = null;
		String formattedForecaste = null;

		// business logic
		forecaste = new Forecaste(23.3, "Cloudy and partly raining");
		formattedForecaste = formatForeCaste(forecaste);
		return new ForecasteStreamingOutput(formattedForecaste);
	}

	private final class ForecasteStreamingOutput implements StreamingOutput {
		private String formattedForecaste;

		public ForecasteStreamingOutput(String formattedForecaste) {
			this.formattedForecaste = formattedForecaste;
		}

		@Override
		public void write(OutputStream os) throws IOException, WebApplicationException {
			os.write(formattedForecaste.getBytes());
			os.close();
		}

	}

	protected abstract String formatForeCaste(Forecaste forecaste);
}
