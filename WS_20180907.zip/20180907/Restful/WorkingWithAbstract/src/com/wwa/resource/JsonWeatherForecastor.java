package com.wwa.resource;

import javax.ws.rs.Path;

import com.wwa.dto.Forecaste;

@Path("/jsonForecastor")
public class JsonWeatherForecastor extends AbstractWeatherForecastor {

	@Override
	protected String formatForeCaste(Forecaste forecaste) {
		StringBuffer buffer = null;

		buffer = new StringBuffer();
		buffer.append("{'foreignHeat':").append(forecaste.getForeignHeat()).append(",'prediction':")
				.append(forecaste.getPredictions()).append("}");
		return buffer.toString();
	}

}
