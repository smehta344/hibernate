package com.rc.test;

import com.rc.provider.redbricks.service.invoker.AgentServiceInvoker;

public class AgentServiceInvokerTest {
	public static void main(String[] args) {
		AgentServiceInvoker agentServiceInvoker = null;

		try {
			agentServiceInvoker = new AgentServiceInvoker();
			String ack = agentServiceInvoker.addLand("ac390", "hyderabad", "madhapur", 938, "east", "s3904");
			System.out.println("ack : " + ack);
			
			String ack1 = agentServiceInvoker.addAgent("30930", "susan", "03004", "susan@gmail.com");
			System.out.println("ack1 : " + ack1);
		} finally {
			agentServiceInvoker.close();
		}
	}
}
