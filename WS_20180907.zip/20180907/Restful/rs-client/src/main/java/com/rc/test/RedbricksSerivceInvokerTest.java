package com.rc.test;

import com.rc.provider.redbricks.service.invoker.RedbricksServiceInvoker;

public class RedbricksSerivceInvokerTest {
	public static void main(String[] args) {
		RedbricksServiceInvoker redbricksServiceInvoker = null;

		try {
			redbricksServiceInvoker = new RedbricksServiceInvoker();
			String propertyInfo = redbricksServiceInvoker.searchPropertyType("hyderabad", "flat", "jubliee hills",
					2000);
			System.out.println(propertyInfo);
		} finally {
		}
	}
}
