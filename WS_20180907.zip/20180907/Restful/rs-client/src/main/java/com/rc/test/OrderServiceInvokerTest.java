package com.rc.test;

import com.rc.bch.provider.service.invoker.OrderServiceInvoker;

public class OrderServiceInvokerTest {
	public static void main(String[] args) {
		OrderServiceInvoker orderServiceInvoker = null;
		
		orderServiceInvoker = new OrderServiceInvoker();
		String orderInfo = orderServiceInvoker.createOrder("This is an order");
		System.out.println(orderInfo);
	}
}
