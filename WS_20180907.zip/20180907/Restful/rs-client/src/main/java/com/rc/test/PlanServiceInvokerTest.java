package com.rc.test;

import com.rc.ch.provider.service.dto.PlanInfo;
import com.rc.ch.provider.service.dto.Status;
import com.rc.ch.provider.service.invoker.PlanServiceInvoker;

public class PlanServiceInvokerTest {
	public static void main(String[] args) {
		PlanServiceInvoker planServiceInvoker = null;
		PlanInfo planInfo = null;
		Status status = null;
		
		try {
			planServiceInvoker = new PlanServiceInvoker();
			planInfo = new PlanInfo();
			planInfo.setPlanName("jeeval saral");
			planInfo.setPlanNo("93030");
			planInfo.setDescription("risk coverage plan");
			planInfo.setInsurrencePlanType("life insurance");
			planInfo.setMinTenure(36);
			planInfo.setMaxTenure(54);
			planInfo.setMinAge(18);
			planInfo.setMaxAge(60);
			planInfo.setMinInsurredAmount(100000);
			planInfo.setMaxInsurredAmount(9999999);
			status = planServiceInvoker.createPlan(planInfo);
			System.out.println(status.getPlanNo());
		}finally {
			planServiceInvoker.close();
		}
		
	}
}










