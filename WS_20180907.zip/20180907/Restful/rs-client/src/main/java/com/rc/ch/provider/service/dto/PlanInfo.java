package com.rc.ch.provider.service.dto;

public class PlanInfo {

	protected String planNo;
	protected String planName;
	protected String insurrencePlanType;
	protected String description;
	protected int minTenure;
	protected int maxTenure;
	protected int minAge;
	protected int maxAge;
	protected double minInsurredAmount;
	protected double maxInsurredAmount;

	public String getPlanNo() {
		return planNo;
	}

	public void setPlanNo(String planNo) {
		this.planNo = planNo;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getInsurrencePlanType() {
		return insurrencePlanType;
	}

	public void setInsurrencePlanType(String insurrencePlanType) {
		this.insurrencePlanType = insurrencePlanType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getMinTenure() {
		return minTenure;
	}

	public void setMinTenure(int minTenure) {
		this.minTenure = minTenure;
	}

	public int getMaxTenure() {
		return maxTenure;
	}

	public void setMaxTenure(int maxTenure) {
		this.maxTenure = maxTenure;
	}

	public int getMinAge() {
		return minAge;
	}

	public void setMinAge(int minAge) {
		this.minAge = minAge;
	}

	public int getMaxAge() {
		return maxAge;
	}

	public void setMaxAge(int maxAge) {
		this.maxAge = maxAge;
	}

	public double getMinInsurredAmount() {
		return minInsurredAmount;
	}

	public void setMinInsurredAmount(double minInsurredAmount) {
		this.minInsurredAmount = minInsurredAmount;
	}

	public double getMaxInsurredAmount() {
		return maxInsurredAmount;
	}

	public void setMaxInsurredAmount(double maxInsurredAmount) {
		this.maxInsurredAmount = maxInsurredAmount;
	}

}
