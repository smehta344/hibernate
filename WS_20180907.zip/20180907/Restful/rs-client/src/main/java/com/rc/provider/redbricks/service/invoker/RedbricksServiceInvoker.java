package com.rc.provider.redbricks.service.invoker;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

public class RedbricksServiceInvoker {
	protected Client client;
	protected final static String ROOT_WEB_TARGET_URI = "http://localhost:8081/JaxRsInjection/api/redbricks/{city}/";
	protected final static String SUB_RESOURCE_WEB_METHOD_SEARCH_PROPERTY_TYPE = "/search/{propertyType}";
	protected final static String SUB_RESOURCE_WEB_METHOD_SEARCH_PROPERTY_TYPE_AND_SQFT = "/search/{propertyType}/{sqft}";

	public RedbricksServiceInvoker() {
		client = ClientBuilder.newClient();
	}

	public String searchPropertyType(String city, String propertyType, String location, int size) {
		String propertyInfo = null;
		WebTarget webTarget = null;
		Invocation invocation = null;
		Response response = null;

		webTarget = client.target(ROOT_WEB_TARGET_URI).resolveTemplate("city", city);
		webTarget = webTarget.path(SUB_RESOURCE_WEB_METHOD_SEARCH_PROPERTY_TYPE).resolveTemplate("propertyType", propertyType)
				.matrixParam("size", size).queryParam("location", location);
		System.out.println(webTarget.getUri().toString());
		invocation = webTarget.request().buildGet();
		response = invocation.invoke();
		System.out.println(response.getStatus());
		if (response.getStatus() == 200) {
			propertyInfo = response.readEntity(String.class);
		}

		return propertyInfo;
	}

	public String searchPropertyTypeAndSqft(String city, String propertyType, int sqft, double minPrice,
			double maxPrice) {
		String propertyInfo = null;
		WebTarget webTarget = null;
		Invocation invocation = null;
		Response response = null;

		webTarget = client.target(ROOT_WEB_TARGET_URI).resolveTemplate("city", city)
				.path(SUB_RESOURCE_WEB_METHOD_SEARCH_PROPERTY_TYPE_AND_SQFT)
				.resolveTemplate("propertyType", propertyType).resolveTemplate("sqft", sqft)
				.queryParam("minPrice", minPrice).queryParam("maxPrice", maxPrice);
		invocation = webTarget.request().buildGet();
		response = invocation.invoke();
		if (response.getStatus() == 200) {
			propertyInfo = response.readEntity(String.class);
		}

		return propertyInfo;
	}
}
