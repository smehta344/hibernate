package com.rc.provider.redbricks.service.invoker;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.MultivaluedHashMap;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.Response;

public class AgentServiceInvoker {
	private Client client;
	private final static String ROOT_WEB_RESOURCE_URI = "http://localhost:8081/JaxRsInjection/api/agent/";
	private final static String SUB_RESOURCE_ADD_LAND_URI = "/land";

	public AgentServiceInvoker() {
		client = ClientBuilder.newClient();
	}

	public String addLand(String accessCode, String city, String area, int sqft, String facing, String surveyNo) {
		String ack = null;
		WebTarget webTarget = null;
		Response response = null;
		Invocation invocation = null;
		Invocation.Builder invocationBuilder = null;
		MultivaluedMap<String, String> formData = null;

		webTarget = client.target(ROOT_WEB_RESOURCE_URI).path(SUB_RESOURCE_ADD_LAND_URI);
		invocationBuilder = webTarget.request();
		invocationBuilder.header("accessCode", accessCode);

		formData = new MultivaluedHashMap<>();
		formData.add("city", city);
		formData.add("area", area);
		formData.add("sqft", String.valueOf(sqft));
		formData.add("facing", facing);
		formData.add("surveyNo", surveyNo);
		invocation = invocationBuilder.buildPost(Entity.form(formData));
		response = invocation.invoke();
		if (response.getStatus() == 200) {
			ack = response.readEntity(String.class);
		}

		return ack;
	}

	public String addAgent(String referralCode, String agentName, String mobileNo, String emailAddress) {
		String ack = null;
		Response response = null;
		WebTarget webTarget = null;
		Invocation invocation = null;
		Invocation.Builder invocationBuilder = null;
		MultivaluedMap<String, String> formData = null;

		webTarget = client.target(ROOT_WEB_RESOURCE_URI);
		invocationBuilder = webTarget.request();
		invocationBuilder.cookie("referralCode", referralCode);
		formData = new MultivaluedHashMap<>();
		formData.add("agentName", agentName);
		formData.add("mobileNo", mobileNo);
		formData.add("emailAddress", emailAddress);
		invocation = invocationBuilder.buildPost(Entity.form(formData));
		response = invocation.invoke();
		if (response.getStatus() == 200) {
			response.bufferEntity();
			ack = response.readEntity(String.class);
		}

		return ack;
	}

	public void close() {
		if (client != null) {
			client.close();
		}
	}

}
