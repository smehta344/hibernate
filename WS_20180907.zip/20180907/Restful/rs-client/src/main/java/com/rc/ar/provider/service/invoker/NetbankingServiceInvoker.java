package com.rc.ar.provider.service.invoker;

import java.util.Calendar;
import java.util.Date;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import javax.ws.rs.client.AsyncInvoker;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.InvocationCallback;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import com.ar.dto.Receipt;
import com.ar.dto.TransferRequest;

public class NetbankingServiceInvoker {
	private Client client;
	private final static String ROOT_WEB_RESOURCE_URI = "http://localhost:8081/async-rest/api/iservices/";
	private final static String SUB_RESOURCE_NEFT_URI = "/neft";

	public NetbankingServiceInvoker() {
		client = ClientBuilder.newClient();
	}

	public String neftTransfer(TransferRequest transferRequest) throws InterruptedException, ExecutionException {
		String receipt = null;
		Response response = null;
		WebTarget webTarget = null;
		AsyncInvoker asyncInvoker = null;
		Invocation.Builder invocationBuilder = null;

		webTarget = client.target(ROOT_WEB_RESOURCE_URI).path(SUB_RESOURCE_NEFT_URI);
		invocationBuilder = webTarget.request();
		/*asyncInvoker = invocationBuilder.async();

		Future<Response> future = asyncInvoker.post(Entity.json(transferRequest));
		System.out.println("am not blocked for response : " + new Date());

		response = future.get();
		if (response.getStatus() == 200) {
			receipt = response.readEntity(String.class);
		}*/
		
		asyncInvoker = invocationBuilder.async();
		asyncInvoker.post(Entity.json(transferRequest), new NeftResponseHandler());
		

		return receipt;
	}

	public void close() {
		if (client != null) {
			client.close();
		}
	}
	
	private final class NeftResponseHandler implements InvocationCallback<Response> {

		@Override
		public void completed(Response response) {
			String receipt = response.readEntity(String.class);
			System.out.println(receipt);
		}

		@Override
		public void failed(Throwable throwable) {
			
		}
		
	}
}












