package com.rc.ch.provider.service.invoker;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

import com.rc.ch.provider.service.dto.PlanInfo;
import com.rc.ch.provider.service.dto.Status;

public class PlanServiceInvoker {
	protected Client client;
	private final static String ROOT_WEB_RESOURCE_URI = "http://localhost:8081/custom-handlers/services/plan";

	public PlanServiceInvoker() {
		client = ClientBuilder.newClient();
	}

	public Status createPlan(PlanInfo planInfo) {
		Status status = null;
		WebTarget webTarget = null;
		Response response = null;
		Invocation invocation = null;
		Invocation.Builder iBuilder = null;

		webTarget = client.target(ROOT_WEB_RESOURCE_URI);
		iBuilder = webTarget.request();
		invocation = iBuilder.buildPost(Entity.json(planInfo));
		response = invocation.invoke();
		if (response.getStatus() == 200) {
			status = response.readEntity(Status.class);
		}

		return status;
	}

	public void close() {
		if (client != null) {
			client.close();
		}
	}

}
