package com.rc.test;

import java.util.concurrent.ExecutionException;

import com.ar.dto.Account;
import com.ar.dto.Receipt;
import com.ar.dto.TransferRequest;
import com.rc.ar.provider.service.invoker.NetbankingServiceInvoker;

public class NetbankingServiceInvokerTest {
	public static void main(String[] args) throws InterruptedException, ExecutionException {
		String receipt = null;
		TransferRequest transferRequest = null;
		NetbankingServiceInvoker netbankingServiceInvoker = null;

		transferRequest = new TransferRequest();
		Account fromAccount = new Account("0393", "savings", "ifc039");
		Account toAccount = new Account("0304", "savings", "if093");
		transferRequest.setFromAccount(fromAccount);
		transferRequest.setToAccount(toAccount);
		transferRequest.setAmount(3940);

		netbankingServiceInvoker = new NetbankingServiceInvoker();
		receipt = netbankingServiceInvoker.neftTransfer(transferRequest);
		System.out.println(receipt);

	}
}
