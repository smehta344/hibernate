package com.rc.test;

import com.rc.provider.paytm.service.invoker.WalletInvokerService;

public class WalletInvokerServiceTest {
	public static void main(String[] args) {
		WalletInvokerService walletInvokerService = null;

		try {
			walletInvokerService = new WalletInvokerService();
			double balance = walletInvokerService.getAccountBalance("9838903");
			System.out.println("balance : " + balance);
		} finally {
			walletInvokerService.close();
		}

	}
}
