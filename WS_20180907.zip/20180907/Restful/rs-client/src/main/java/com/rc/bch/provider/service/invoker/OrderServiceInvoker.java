package com.rc.bch.provider.service.invoker;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Entity;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

public class OrderServiceInvoker {
	private Client client;
	private final static String ROOT_WEB_RESOURCE_URI = "http://localhost:8081/basic-content-handler/services/order/";
	private final static String SUB_RESOURCE_CREATE_ORDER_URI = "/in";

	public OrderServiceInvoker() {
		client = ClientBuilder.newClient();
	}

	public String createOrder(String order) {
		String orderInfo = null;
		WebTarget webTarget = null;
		Response response = null;
		Invocation invocation = null;
		Invocation.Builder invocationBuilder = null;

		webTarget = client.target(ROOT_WEB_RESOURCE_URI).path(SUB_RESOURCE_CREATE_ORDER_URI);
		invocationBuilder = webTarget.request();
		invocation = invocationBuilder.buildPost(Entity.text(order));
		response = invocation.invoke();

		if (response.getStatus() == 200) {
			response.bufferEntity();
			orderInfo = response.readEntity(String.class);
		}

		return orderInfo;
	}

	public void close() {
		if (client != null) {
			client.close();
		}
	}
}
