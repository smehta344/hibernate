package com.rc.provider.paytm.service.invoker;

import javax.ws.rs.client.Client;
import javax.ws.rs.client.ClientBuilder;
import javax.ws.rs.client.Invocation;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.Response;

public class WalletInvokerService {
	protected Client client;
	protected final static String ROOT_WEB_RESOURCE_URI = "http://localhost:8081/PayTM/services/wallet";

	public WalletInvokerService() {
		ClientBuilder clientBuilder = null;

		clientBuilder = ClientBuilder.newBuilder();
		clientBuilder.property("connection.timeout", 10000);
		client = clientBuilder.build();
		clientBuilder = null;
	}

	public double getAccountBalance(String mobileNo) {
		double balance = 0.0;
		Response response = null;
		WebTarget getAccountBalanceTarget = null;
		Invocation getAccountBalanceInvocation = null;
		Invocation.Builder getAccountBalanceInvocationBuilder = null;

		getAccountBalanceTarget = client.target(ROOT_WEB_RESOURCE_URI);
		getAccountBalanceTarget.queryParam("mobileNo", mobileNo);

		getAccountBalanceInvocationBuilder = getAccountBalanceTarget.request();
		getAccountBalanceInvocation = getAccountBalanceInvocationBuilder.buildGet();
		response = getAccountBalanceInvocation.invoke();
		if (response.getStatus() == 200) {
			balance = response.readEntity(Double.class);
		}

		return balance;
	}

	public void close() {
		if (client != null) {
			client.close();
			client = null;
		}
	}
}
