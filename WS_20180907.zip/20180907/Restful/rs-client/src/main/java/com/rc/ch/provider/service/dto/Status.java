package com.rc.ch.provider.service.dto;

public class Status {
	protected int planNo;
	protected int effectiveInDays;
	protected String status;

	public int getPlanNo() {
		return planNo;
	}

	public void setPlanNo(int planNo) {
		this.planNo = planNo;
	}

	public int getEffectiveInDays() {
		return effectiveInDays;
	}

	public void setEffectiveInDays(int effectiveInDays) {
		this.effectiveInDays = effectiveInDays;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
