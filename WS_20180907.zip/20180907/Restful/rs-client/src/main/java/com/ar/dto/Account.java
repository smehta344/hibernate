package com.ar.dto;

public class Account {
	protected String accountNo;
	protected String accountType;
	protected String ifscCode;

	public Account(String accountNo, String accountType, String ifscCode) {
		super();
		this.accountNo = accountNo;
		this.accountType = accountType;
		this.ifscCode = ifscCode;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getIfscCode() {
		return ifscCode;
	}

	public void setIfscCode(String ifscCode) {
		this.ifscCode = ifscCode;
	}

}
