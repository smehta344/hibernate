package com.srl.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

public class PhilipsHomeApplianceCustomerCare {

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/warranty")
	public String getWarrantyInfo(@QueryParam("serialNo") String serialNo) {
		return "2020-Jan-31";
	}
}
