package com.srl.resource;

import javax.ws.rs.Path;
import javax.ws.rs.PathParam;

@Path("/philips")
public class PhilipsCare {

	/*
	 * @Path("/electronics") public PhilipsElectronicsCustomerCare electronicsCare()
	 * { return new PhilipsElectronicsCustomerCare(); }
	 * 
	 * @Path("/homeAppliances") public PhilipsHomeApplianceCustomerCare
	 * homeApplianceCare() { return new PhilipsHomeApplianceCustomerCare(); }
	 */

	@Path("/{productLine}")
	public Object productLineCustomerCare(@PathParam("productLine") String productLine) {
		if (productLine.equals("electronics")) {
			return new PhilipsElectronicsCustomerCare();
		} else if (productLine.equals("homeAppliances")) {
			return new PhilipsHomeApplianceCustomerCare();
		}
		return null;
	}

}
