package com.srl.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

public class PhilipsElectronicsCustomerCare {
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/serviceCenter")
	public String getServiceCenterNo(@QueryParam("zip") String zip) {
		return "909-933-3930";
	}
}
