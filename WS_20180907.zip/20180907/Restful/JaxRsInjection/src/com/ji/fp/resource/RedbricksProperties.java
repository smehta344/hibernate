package com.ji.fp.resource;

import java.util.List;
import java.util.Set;

import javax.ws.rs.Consumes;
import javax.ws.rs.FormParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

@Path("/properties")
public class RedbricksProperties {

	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public String addFlat(@FormParam("apartmentName") String apartmentName, @FormParam("floor") int floor,
			@FormParam("facing") String facing, @FormParam("sqft") int sqft, @FormParam("location") String location,
			@FormParam("saleType") String saleType) {
		return "apartmentName : " + apartmentName + " floor : " + floor + " facing :" + facing + " sqft : " + sqft
				+ " location : " + location + " saleType: " + saleType;
	}
	
	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/api")
	public String addFlat(MultivaluedMap<String, String> formData) {
		StringBuffer buffer = null;
		Set<String> keys = null;
		List<String> values = null;

		buffer = new StringBuffer();
		keys = formData.keySet();
		for (String key : keys) {// k1, k2, k3
			buffer.append(key).append(" : ");
			values = formData.get(key);
			for (int i = 0; i < values.size(); i++) {
				if (i == 0) {
					buffer.append(values.get(i));
					continue;
				}
				buffer.append(",").append(values.get(i));
			}
			buffer.append(";");
		}

		return buffer.toString();
	}

}

















