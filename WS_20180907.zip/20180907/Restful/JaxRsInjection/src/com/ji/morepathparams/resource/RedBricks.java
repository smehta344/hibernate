package com.ji.morepathparams.resource;

import java.util.List;

import javax.ws.rs.DefaultValue;
import javax.ws.rs.GET;
import javax.ws.rs.MatrixParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.PathSegment;

@Path("/redbricks/{city}")
public class RedBricks {

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/search/{propertyType}")
	public String search(@PathParam("propertyType") String propertyType, @QueryParam("location") String location,
			@PathParam("city") String city, @MatrixParam("size") String size) {
		return "propertyType: " + propertyType + " location : " + location + " city : " + city + " size :" + size;
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/search/{propertyType}/{sqft}")
	public String search(@PathParam("propertyType") String propertyType, @PathParam("city") String city,
			@QueryParam("minPrice") @DefaultValue("999999") double minPrice, @QueryParam("maxPrice") double maxPrice,
			@PathParam("sqft") int sqft) {
		return "propertyType : " + propertyType + " city : " + city + " minPrice: " + minPrice + " maxPrice :"
				+ maxPrice + " sqft : " + sqft;
	}

	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/builder/{builderName}/{city}")
	public String addBuilder(@PathParam("builderName") String builderName, @QueryParam("experience") int experience,
			@QueryParam("description") String description, @PathParam("city") String baseCity) {
		return "builderName : " + builderName + " experience :" + experience + " description: " + description
				+ " city : " + baseCity;
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/{propertyType}/{location}")
	public String search(@PathParam("propertyType") PathSegment propertyTypeSegment,
			@PathParam("location") PathSegment locationSegment, @PathParam("city") PathSegment citySegment) {
		StringBuffer buffer = new StringBuffer();

		buffer.append("propertyType : " + propertyTypeSegment.getPath()).append(" matrix params : ")
				.append(getMatrixParameters(propertyTypeSegment.getMatrixParameters())).append("location : ")
				.append(locationSegment.getPath()).append(" matrix Parameters : ")
				.append(getMatrixParameters(locationSegment.getMatrixParameters())).append(" city : ")
				.append(citySegment.getPath()).append(" matrix Parameters :")
				.append(getMatrixParameters(citySegment.getMatrixParameters()));
		return buffer.toString();
	}

	private String getMatrixParameters(MultivaluedMap<String, String> matrixParams) {
		StringBuffer buffer = new StringBuffer();

		for (String paramName : matrixParams.keySet()) {
			List<String> paramValues = matrixParams.get(paramName);
			buffer.append(paramName).append("=");
			for (String value : paramValues) {
				buffer.append(value).append(",");
			}
			buffer.append(";");
		}
		return buffer.toString();
	}
}
