package com.ji.hp.rsource;

import java.util.List;

import javax.ws.rs.Consumes;
import javax.ws.rs.CookieParam;
import javax.ws.rs.FormParam;
import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.core.PathSegment;
import javax.ws.rs.core.UriInfo;

@Path("/agent")
public class RedbricksAgent {
	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/land")
	public String addLand(@FormParam("city") String city, @FormParam("area") String area, @FormParam("sqft") int sqft,
			@FormParam("facing") String facing, @FormParam("surveyNo") String surveyNo,
			@HeaderParam("accessCode") String accessCode) {
		return "city : " + city + " area : " + area + " facing : " + facing + " sqft : " + sqft + " surveyNo : "
				+ surveyNo + " accessCode : " + accessCode;
	}

	@POST
	@Consumes(MediaType.APPLICATION_FORM_URLENCODED)
	@Produces(MediaType.TEXT_PLAIN)
	public String addAgent(@FormParam("agentName") String agentName, @FormParam("mobileNo") String mobileNo,
			@FormParam("emailAddress") String emailAddress, @CookieParam("referralCode") String referralCode) {
		return "agentName :" + agentName + " mobileNo : " + mobileNo + " email : " + emailAddress + " referralCode : "
				+ referralCode;
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/search/{agentName}/{mobileNo}")
	public String searchAgent(@Context UriInfo uriInfo) {
		StringBuffer buffer = null;
		List<PathSegment> pathSegments = null;
		MultivaluedMap<String, String> queryParams = null;

		buffer = new StringBuffer();
		pathSegments = uriInfo.getPathSegments();
		for (PathSegment pg : pathSegments) {
			buffer.append("ps : ").append(pg.getPath()).append(" matrix parameters")
					.append(getMatrixParameters(pg.getMatrixParameters())).append(" -- ");
		}
		queryParams = uriInfo.getQueryParameters();
		buffer.append("query Parameters : ").append(getMatrixParameters(queryParams));

		return buffer.toString();
	}

	private String getMatrixParameters(MultivaluedMap<String, String> matrixParams) {
		StringBuffer buffer = new StringBuffer();

		for (String paramName : matrixParams.keySet()) {
			List<String> paramValues = matrixParams.get(paramName);
			buffer.append(paramName).append("=");
			for (String value : paramValues) {
				buffer.append(value).append(",");
			}
			buffer.append(";");
		}
		return buffer.toString();
	}
}
