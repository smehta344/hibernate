package com.ji.phh.resource;

import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Cookie;
import javax.ws.rs.core.HttpHeaders;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;

@Path("/redbricks-admin")
public class Redbricks {

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/headers")
	public String getHeaders(@Context HttpHeaders httpHeaders) {
		MultivaluedMap<String, String> headerParams = null;
		Map<String, Cookie> cookies = null;
		StringBuffer buffer = null;
		Cookie cookie = null;

		buffer = new StringBuffer();
		headerParams = httpHeaders.getRequestHeaders();
		buffer.append("header params : ").append(getMutivaluedMap(headerParams));

		buffer.append("######## cookies : ");
		cookies = httpHeaders.getCookies();
		Set<String> keys = cookies.keySet();
		for (String key : keys) {
			cookie = cookies.get(key);
			buffer.append(cookie.getName() + " : " + cookie.getValue()).append(";");
		}

		return buffer.toString();
	}

	private String getMutivaluedMap(MultivaluedMap<String, String> in) {
		StringBuffer buffer = null;
		Set<String> keys = null;
		List<String> values = null;

		buffer = new StringBuffer();
		keys = in.keySet();
		for (String key : keys) {// k1, k2, k3
			buffer.append(key).append(" : ");
			values = in.get(key);
			for (int i = 0; i < values.size(); i++) {
				if (i == 0) {
					buffer.append(values.get(i));
					continue;
				}
				buffer.append(",").append(values.get(i));
			}
			buffer.append(";");
		}

		return buffer.toString();
	}
}
