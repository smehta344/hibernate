package com.ji.bp.resource;

import javax.ws.rs.BeanParam;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.ji.bp.dto.House;

@Path("/rprops")
public class RedbricksProperties {
	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/{buildingName}/{sqft}/{city}/{saleType}/{cost}")
	public String addHouse(@BeanParam House house) {
		return house.toString();
	}

}
