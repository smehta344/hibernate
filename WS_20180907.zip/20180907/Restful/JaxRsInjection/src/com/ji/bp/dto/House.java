package com.ji.bp.dto;

import javax.ws.rs.MatrixParam;
import javax.ws.rs.PathParam;
import javax.ws.rs.QueryParam;

public class House {
	@PathParam("buildingName")
	private String buildingName;
	@MatrixParam("location")
	private String location;
	@QueryParam("stairs")
	private int stairs;
	@PathParam("sqft")
	private int sqft;
	@PathParam("city")
	private String city;
	@MatrixParam("surveyNo")
	private String surveyNo;
	@QueryParam("facing")
	private String facing;
	@PathParam("saleType")
	private String saleType;
	@PathParam("cost")
	private double cost;

	public String getBuildingName() {
		return buildingName;
	}

	public void setBuildingName(String buildingName) {
		this.buildingName = buildingName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public int getStairs() {
		return stairs;
	}

	public void setStairs(int stairs) {
		this.stairs = stairs;
	}

	public int getSqft() {
		return sqft;
	}

	public void setSqft(int sqft) {
		this.sqft = sqft;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getSurveyNo() {
		return surveyNo;
	}

	public void setSurveyNo(String surveyNo) {
		this.surveyNo = surveyNo;
	}

	public String getFacing() {
		return facing;
	}

	public void setFacing(String facing) {
		this.facing = facing;
	}

	public String getSaleType() {
		return saleType;
	}

	public void setSaleType(String saleType) {
		this.saleType = saleType;
	}

	public double getCost() {
		return cost;
	}

	public void setCost(double cost) {
		this.cost = cost;
	}

	@Override
	public String toString() {
		return "House [buildingName=" + buildingName + ", location=" + location + ", stairs=" + stairs + ", sqft="
				+ sqft + ", city=" + city + ", surveyNo=" + surveyNo + ", facing=" + facing + ", saleType=" + saleType
				+ ", cost=" + cost + "]";
	}

}
