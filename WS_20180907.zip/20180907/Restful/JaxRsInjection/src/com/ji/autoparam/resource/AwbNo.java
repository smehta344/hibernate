package com.ji.autoparam.resource;

public class AwbNo {
	protected String branchCode;
	protected String uniqueNo;

	/*public AwbNo(String awbNo) {
		branchCode = awbNo.substring(0, 3);
		uniqueNo = awbNo.substring(4, awbNo.length());
	}*/

	public String getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}

	public String getUniqueNo() {
		return uniqueNo;
	}

	public void setUniqueNo(String uniqueNo) {
		this.uniqueNo = uniqueNo;
	}
	
	public static AwbNo valueOf(String awbNo) {
		AwbNo awb = null;
		
		awb = new AwbNo();
		awb.setBranchCode(awbNo.substring(0, 4));
		awb.setUniqueNo(awbNo.substring(4));
		
		return awb;
	}

	@Override
	public String toString() {
		return "AwbNo [branchCode=" + branchCode + ", uniqueNo=" + uniqueNo + "]";
	}

}

















