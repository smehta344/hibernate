package com.ji.autoparam.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/bluedart")
public class BluedartParcel {
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/track/{awbNo}")
	public String getParcelStatus(@PathParam("awbNo") AwbNo awbNo) {
		
		return awbNo.toString();
	}
}
