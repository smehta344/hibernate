package com.ji.pp.exp.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/geoServices")
public class GeoService {
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/location/{zip:\\d+}")
	public String getGeoLocation(@PathParam("zip") String zip) {
		return "(24,34.39)";
	}

}
