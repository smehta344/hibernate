package com.jobj.test;

import com.jobj.reader.PurchaseOrderReader;

public class ReaderTest {
	public static void main(String[] args) {
		PurchaseOrderReader reader = new PurchaseOrderReader();
		int total = reader.getTotalQuantity("po.json");
		System.out.println("total : " + total);
	}
}
