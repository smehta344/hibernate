package com.jobj.bean;

import java.util.Date;

public class Invoice {
	protected String invoiceNo;
	protected String distributeName;
	protected Date invoiceGeneratedDate;
	protected int days;
	protected double amount;

	public Invoice(String invoiceNo, String distributeName, Date invoiceGeneratedDate, int days, double amount) {
		this.invoiceNo = invoiceNo;
		this.distributeName = distributeName;
		this.invoiceGeneratedDate = invoiceGeneratedDate;
		this.days = days;
		this.amount = amount;
	}

	public String getInvoiceNo() {
		return invoiceNo;
	}

	public void setInvoiceNo(String invoiceNo) {
		this.invoiceNo = invoiceNo;
	}

	public String getDistributeName() {
		return distributeName;
	}

	public void setDistributeName(String distributeName) {
		this.distributeName = distributeName;
	}

	public Date getInvoiceGeneratedDate() {
		return invoiceGeneratedDate;
	}

	public void setInvoiceGeneratedDate(Date invoiceGeneratedDate) {
		this.invoiceGeneratedDate = invoiceGeneratedDate;
	}

	public int getDays() {
		return days;
	}

	public void setDays(int days) {
		this.days = days;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

}
