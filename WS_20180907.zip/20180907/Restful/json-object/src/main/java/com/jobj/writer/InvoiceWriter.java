package com.jobj.writer;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.text.SimpleDateFormat;

import javax.json.Json;
import javax.json.JsonObject;
import javax.json.JsonObjectBuilder;
import javax.json.JsonWriter;

import com.jobj.bean.Invoice;

public class InvoiceWriter {

	public void writeInvoiceToJson(Invoice invoice, String outFile) throws FileNotFoundException {
		OutputStream os = null;
		JsonWriter jsonWriter = null;
		JsonObject jsonObject = null;
		JsonObjectBuilder jsonObjectBuilder = null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd-MMM-yyyy");

		os = new FileOutputStream(new File(outFile));
		jsonWriter = Json.createWriter(os);

		jsonObjectBuilder = Json.createObjectBuilder();
		jsonObjectBuilder.add("invoice-no", invoice.getInvoiceNo());
		jsonObjectBuilder.add("distributor-name", invoice.getDistributeName());
		jsonObjectBuilder.add("invoice-generated-date", sdf.format(invoice.getInvoiceGeneratedDate()));
		jsonObjectBuilder.add("days", invoice.getDays());
		jsonObjectBuilder.add("amount", invoice.getAmount());
		jsonObject = jsonObjectBuilder.build();

		jsonWriter.write(jsonObject);
		jsonWriter.close();
	}
}









