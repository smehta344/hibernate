package com.jobj.reader;

import java.io.InputStream;

import javax.json.Json;
import javax.json.JsonArray;
import javax.json.JsonObject;
import javax.json.JsonReader;

public class PurchaseOrderReader {

	public int getTotalQuantity(String inFile) {
		int total = 0;
		InputStream in = null;
		JsonObject jsonObject = null;
		JsonReader jsonReader = null;
		JsonObject itemObject = null;
		JsonArray orderItemsArray = null;

		in = this.getClass().getClassLoader().getResourceAsStream(inFile);
		jsonReader = Json.createReader(in);

		jsonObject = jsonReader.readObject();
		orderItemsArray = jsonObject.getJsonArray("order-items");
		for (int i = 0; i < orderItemsArray.size(); i++) {
			itemObject = orderItemsArray.getJsonObject(i);
			total = total + itemObject.getInt("quantity");
		}

		return total;
	}

}
