package com.jobj.test;

import java.io.FileNotFoundException;
import java.util.Date;

import com.jobj.bean.Invoice;
import com.jobj.writer.InvoiceWriter;

public class WriterTest {
	public static void main(String[] args) throws FileNotFoundException {
		Invoice invoice = null;
		InvoiceWriter invoiceWriter = null;

		invoice = new Invoice("2ik3l9d8", "krishna enterprises", new Date(), 10, 92939.34);
		invoiceWriter = new InvoiceWriter();
		invoiceWriter.writeInvoiceToJson(invoice, "d:\\invoice.json");
	}
}













