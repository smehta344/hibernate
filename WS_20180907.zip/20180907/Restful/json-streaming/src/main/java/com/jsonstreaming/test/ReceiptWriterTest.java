package com.jsonstreaming.test;

import com.jsonstreaming.parser.ReceiptGenerator;

public class ReceiptWriterTest {
	public static void main(String[] args) {
		ReceiptGenerator receiptGenerator = new ReceiptGenerator();
		receiptGenerator.generateReceipt("r903", "document", 939, "accepted");
	}
}
