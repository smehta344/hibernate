package com.jsonstreaming.parser;

import javax.json.Json;
import javax.json.stream.JsonGenerator;

public class ReceiptGenerator {

	public void generateReceipt(String receiptNo, String description, double amount, String status) {
		JsonGenerator jsonGenerator = null;

		jsonGenerator = Json.createGenerator(System.out);
		jsonGenerator.writeStartObject();
		jsonGenerator.write("receiptNo", receiptNo);
		jsonGenerator.write("description", description);
		jsonGenerator.write("amount", amount);
		jsonGenerator.write("status", status);
		jsonGenerator.writeEnd();
		jsonGenerator.close();
	}
}
