package com.jsonstreaming.test;

import java.io.FileNotFoundException;

import com.jsonstreaming.parser.DeliveryStatusParser;

public class StreamingTest {
	public static void main(String[] args) throws FileNotFoundException {
		DeliveryStatusParser deliveryStatusParser = null;

		deliveryStatusParser = new DeliveryStatusParser();
		String deliveryStatus = deliveryStatusParser.getDeliveryStatus("a0235",
				"D:\\work\\master\\webservices\\20180907\\Restful\\json-streaming\\src\\main\\resources\\branch-deliveries.json");
		System.out.println(deliveryStatus);
	}
}
