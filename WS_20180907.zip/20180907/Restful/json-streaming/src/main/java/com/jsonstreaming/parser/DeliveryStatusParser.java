package com.jsonstreaming.parser;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javax.json.Json;
import javax.json.stream.JsonParser;
import javax.json.stream.JsonParser.Event;

public class DeliveryStatusParser {

	public String getDeliveryStatus(String awbNo, String inFile) throws FileNotFoundException {
		String deliveryStatus = null;
		JsonParser jsonParser = null;
		String key = null;
		String awbNoValue = null;
		Event event = null;
		boolean found = false;
		boolean awbNoKeyFound = false;
		boolean awbNoFound = false;
		boolean deliveryStatusKeyFound = false;

		jsonParser = Json.createParser(new FileInputStream(inFile));
		while (jsonParser.hasNext() && found == false) {
			event = jsonParser.next();
			switch (event) {
			case KEY_NAME:
				key = jsonParser.getString();
				if (key.equals("awbNo")) {
					awbNoKeyFound = true;
				}
				if (awbNoFound) {
					if (key.equals("deliveryStatus")) {
						deliveryStatusKeyFound = true;
					}
				}
				break;
			case VALUE_STRING:
				if (awbNoKeyFound) {
					awbNoValue = jsonParser.getString();
					if (awbNoValue.equals(awbNo)) {
						awbNoFound = true;
					}
				}
				if (awbNoFound && deliveryStatusKeyFound) {
					deliveryStatus = jsonParser.getString();
					found = true;
					awbNoFound = false;
					deliveryStatusKeyFound = false;
					break;
				}
				awbNoKeyFound = false;
				break;
			}

		}

		return deliveryStatus;
	}

}
