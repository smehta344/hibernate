package com.jsonb.test;

import com.jsonb.binding.Publisher;
import com.jsonb.unmarshaller.JsonMarshaller;

public class MarshallerTest {
	public static void main(String[] args) {
		JsonMarshaller jsonMarshaller = null;
		Publisher publisher = null;
		
		publisher = new Publisher();
		publisher.setPublisherName("Bpb publications");
		publisher.setEstDate("1980-2-2");
		jsonMarshaller = new JsonMarshaller();
		jsonMarshaller.toJson(publisher);
	}
}
