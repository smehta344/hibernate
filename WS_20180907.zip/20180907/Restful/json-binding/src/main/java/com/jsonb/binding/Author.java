package com.jsonb.binding;

import javax.json.bind.annotation.JsonbProperty;

public class Author {
	@JsonbProperty
	protected String authorName;
	@JsonbProperty
	protected String dob;

	public String getAuthorName() {
		return authorName;
	}

	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}

	public String getDob() {
		return dob;
	}

	public void setDob(String dob) {
		this.dob = dob;
	}

	@Override
	public String toString() {
		return "Author [authorName=" + authorName + ", dob=" + dob + "]";
	}

}
