package com.jsonb.binding;

import java.util.Arrays;

import javax.json.bind.annotation.JsonbProperty;

public class Book {
	@JsonbProperty
	protected String isbn;
	@JsonbProperty
	protected String title;
	@JsonbProperty
	protected Author[] authors;
	@JsonbProperty
	protected Publisher publisher;

	public String getIsbn() {
		return isbn;
	}

	public void setIsbn(String isbn) {
		this.isbn = isbn;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public Author[] getAuthors() {
		return authors;
	}

	public void setAuthors(Author[] authors) {
		this.authors = authors;
	}

	public Publisher getPublisher() {
		return publisher;
	}

	public void setPublisher(Publisher publisher) {
		this.publisher = publisher;
	}

	@Override
	public String toString() {
		return "Book [isbn=" + isbn + ", title=" + title + ", authors=" + Arrays.toString(authors) + ", publisher="
				+ publisher + "]";
	}

}
