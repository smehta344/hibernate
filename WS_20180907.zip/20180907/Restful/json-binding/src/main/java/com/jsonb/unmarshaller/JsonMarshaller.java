package com.jsonb.unmarshaller;

import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;

public class JsonMarshaller {

	public void toJson(Object obj) {
		Jsonb jsonb = null;

		jsonb = JsonbBuilder.create();
		jsonb.toJson(obj, System.out);
	}

}
