package com.jsonb.unmarshaller;

import java.io.FileInputStream;
import java.io.FileNotFoundException;

import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;
import javax.json.bind.JsonbException;

public class JsonUnMarshaller {

	public Object fromJson(String inJsonFile, Class<?> classType) throws JsonbException, FileNotFoundException {
		Jsonb jsonb = null;
		Object obj = null;

		jsonb = JsonbBuilder.create();
		obj = jsonb.fromJson(new FileInputStream(inJsonFile), classType);

		return obj;
	}
}
