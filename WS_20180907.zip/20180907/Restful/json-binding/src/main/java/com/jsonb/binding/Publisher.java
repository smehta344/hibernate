package com.jsonb.binding;

import javax.json.bind.annotation.JsonbProperty;

public class Publisher {
	@JsonbProperty
	protected String publisherName;
	@JsonbProperty
	protected String estDate;

	public String getPublisherName() {
		return publisherName;
	}

	public void setPublisherName(String publisherName) {
		this.publisherName = publisherName;
	}

	public String getEstDate() {
		return estDate;
	}

	public void setEstDate(String estDate) {
		this.estDate = estDate;
	}

	@Override
	public String toString() {
		return "Publisher [publisherName=" + publisherName + ", estDate=" + estDate + "]";
	}

}
