package com.jsonb.test;

import java.io.FileNotFoundException;

import javax.json.bind.JsonbException;

import com.jsonb.binding.Book;
import com.jsonb.unmarshaller.JsonUnMarshaller;

public class UnMarshallerTest {
	public static void main(String[] args) throws JsonbException, FileNotFoundException {
		JsonUnMarshaller jsonUnMarshaller = new JsonUnMarshaller();
		Object obj = jsonUnMarshaller.fromJson(
				"D:\\work\\master\\webservices\\20180907\\Restful\\json-binding\\src\\main\\resources\\book.json",
				Book.class);
		System.out.println(obj);
	}
}
