package com.swgintg.resource;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.Produces;
import javax.ws.rs.Path;

import com.swgintg.dto.JourneyPlan;
import com.swgintg.dto.Ticket;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.parameters.RequestBody;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

@Path("/trainService")
public class TrainService {
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/bookTicket")
	@Operation(summary = "reservation service", description = "book ticket service", requestBody = @RequestBody(content = @Content(schema = @Schema(implementation = JourneyPlan.class))), responses = {
			@ApiResponse(content = @Content(schema = @Schema(implementation = Ticket.class))) })
	public Ticket bookTicket(JourneyPlan journeyPlan) {
		Ticket ticket = null;

		ticket = new Ticket();
		ticket.setPnrNo("p3k3044");
		ticket.setBerths(new int[] { 29, 35, 46 });
		ticket.setCoach("s12");
		ticket.setStatus("CNF");
		return ticket;
	}

}
