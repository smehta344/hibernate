package com.swgintg.dto;

import java.util.Date;

import javax.json.bind.annotation.JsonbDateFormat;
import javax.json.bind.annotation.JsonbProperty;

public class JourneyPlan {
	protected String source;
	protected String destination;
	@JsonbProperty
	@JsonbDateFormat("dd-mm-yyyy")
	protected Date journeyDate;
	protected int trainNo;
	protected String reservationClass;
	protected int tickets;

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Date getJourneyDate() {
		return journeyDate;
	}

	public void setJourneyDate(Date journeyDate) {
		this.journeyDate = journeyDate;
	}

	public int getTrainNo() {
		return trainNo;
	}

	public void setTrainNo(int trainNo) {
		this.trainNo = trainNo;
	}

	public String getReservationClass() {
		return reservationClass;
	}

	public void setReservationClass(String reservationClass) {
		this.reservationClass = reservationClass;
	}

	public int getTickets() {
		return tickets;
	}

	public void setTickets(int tickets) {
		this.tickets = tickets;
	}

}
