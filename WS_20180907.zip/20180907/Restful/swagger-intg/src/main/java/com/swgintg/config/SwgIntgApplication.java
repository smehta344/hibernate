package com.swgintg.config;

import java.util.Set;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.swgintg.resource.TrainService;

import io.swagger.v3.jaxrs2.integration.resources.OpenApiResource;

@ApplicationPath("/services")
public class SwgIntgApplication extends Application {

	@Override
	public Set<Class<?>> getClasses() {
		return Stream.of(new Class<?>[] { OpenApiResource.class, TrainService.class }).collect(Collectors.toSet());
	}

}
