package com.swgintg.dto;

public class Ticket {
	protected String pnrNo;
	protected int[] berths;
	protected String coach;
	protected String status;

	public String getPnrNo() {
		return pnrNo;
	}

	public void setPnrNo(String pnrNo) {
		this.pnrNo = pnrNo;
	}

	public int[] getBerths() {
		return berths;
	}

	public void setBerths(int[] berths) {
		this.berths = berths;
	}

	public String getCoach() {
		return coach;
	}

	public void setCoach(String coach) {
		this.coach = coach;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
