package com.asyncservlet.servlet;

import java.io.IOException;

import javax.servlet.AsyncContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class LongRunningServlet extends HttpServlet {
	@Override
	protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			final AsyncContext asyncContext = req.startAsync();
			Runnable t = () -> {
				try {
					Thread.sleep(6000L);
					System.out.println("long running job finished");
					HttpServletResponse response = (HttpServletResponse) asyncContext.getResponse();
					response.getWriter().println("finished");
					asyncContext.complete();
				} catch (InterruptedException | IOException e) {
					e.printStackTrace();
				}

			};
			new Thread(t).start();

		} catch (Exception e) {
			throw new ServletException(e);
		}
	}

}
