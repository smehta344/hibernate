package com.pc.dto;

import java.io.Serializable;

public class AccountNo implements Serializable {
	protected int branchCode;
	protected int accountType;
	protected long accountNo;

	public int getBranchCode() {
		return branchCode;
	}

	public void setBranchCode(int branchCode) {
		this.branchCode = branchCode;
	}

	public int getAccountType() {
		return accountType;
	}

	public void setAccountType(int accountType) {
		this.accountType = accountType;
	}

	public long getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(long accountNo) {
		this.accountNo = accountNo;
	}

	@Override
	public String toString() {
		return "AccountNo [branchCode=" + branchCode + ", accountType=" + accountType + ", accountNo=" + accountNo
				+ "]";
	}

}
