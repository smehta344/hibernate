package com.pc.converter;

import javax.ws.rs.ext.ParamConverter;

import com.pc.dto.AccountNo;

public class AccountNoParamConverter implements ParamConverter<AccountNo> {

	@Override
	public AccountNo fromString(String value) {
		AccountNo accountNo = null;

		accountNo = new AccountNo();
		accountNo.setBranchCode(Integer.parseInt(value.substring(0, 5)));
		accountNo.setAccountType(Integer.parseInt(value.substring(5, 7)));
		accountNo.setAccountNo(Long.parseLong(value.substring(7, value.length())));

		return accountNo;
	}

	@Override
	public String toString(AccountNo accountNo) {
		return accountNo.getBranchCode() + "" + accountNo.getAccountType() + "" + accountNo.getAccountNo();
	}

}












