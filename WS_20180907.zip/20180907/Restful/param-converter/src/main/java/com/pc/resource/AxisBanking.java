package com.pc.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.pc.dto.AccountNo;

@Path("/axis-banking")
public class AxisBanking {
	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/balance/{accountNo}")
	public double getAccountBalance(@PathParam("accountNo") AccountNo accountNo) {
		System.out.println(accountNo);
		return accountNo.getAccountNo();
	}
}
