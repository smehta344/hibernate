package com.pc.providers;

import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import javax.ws.rs.ext.ParamConverter;
import javax.ws.rs.ext.ParamConverterProvider;
import javax.ws.rs.ext.Provider;

import com.pc.converter.AccountNoParamConverter;
import com.pc.dto.AccountNo;

@Provider
public class AxisParamConverterProvider implements ParamConverterProvider {

	@Override
	public <Object> ParamConverter<Object> getConverter(Class<Object> rawType, Type genericType,
			Annotation[] annotations) {
		if (rawType.isAssignableFrom(AccountNo.class)) {
			return (ParamConverter<Object>) new AccountNoParamConverter();
		}
		return null;
	}

}
