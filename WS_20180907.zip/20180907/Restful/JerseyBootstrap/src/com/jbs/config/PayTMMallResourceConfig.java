package com.jbs.config;

import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.server.ResourceConfig;

import com.jbs.resource.PayTMMall;

@ApplicationPath("/services")
public class PayTMMallResourceConfig extends ResourceConfig {

	public PayTMMallResourceConfig() {
		super.register(new PayTMMall());
	}

}
