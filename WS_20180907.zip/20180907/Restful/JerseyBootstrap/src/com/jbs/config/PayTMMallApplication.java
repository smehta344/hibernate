package com.jbs.config;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.jbs.resource.PayTMMall;

/*@ApplicationPath("/services")*/
public class PayTMMallApplication extends Application {
	private Set<Object> singletons;
	private Set<Class<?>> classes;

	public PayTMMallApplication() {
		singletons = new HashSet<>();
		classes = new HashSet<>();

		singletons.add(new PayTMMall());
		System.out.println("PayTMMallApplication() created...");
	}

	@Override
	public Set<Class<?>> getClasses() {
		System.out.println("getClasses()");
		return classes;
	}

	@Override
	public Set<Object> getSingletons() {
		System.out.println("getSingletons()");
		return singletons;
	}

}














