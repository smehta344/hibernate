package com.pp.dto;

public class Policy {
	protected String policyNo;
	protected String planName;
	protected String policyHolderName;
	protected double insurredAmount;

	public Policy(String policyNo, String planName, String policyHolderName, double insurredAmount) {
		super();
		this.policyNo = policyNo;
		this.planName = planName;
		this.policyHolderName = policyHolderName;
		this.insurredAmount = insurredAmount;
	}

	public String getPolicyNo() {
		return policyNo;
	}

	public void setPolicyNo(String policyNo) {
		this.policyNo = policyNo;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getPolicyHolderName() {
		return policyHolderName;
	}

	public void setPolicyHolderName(String policyHolderName) {
		this.policyHolderName = policyHolderName;
	}

	public double getInsurredAmount() {
		return insurredAmount;
	}

	public void setInsurredAmount(double insurredAmount) {
		this.insurredAmount = insurredAmount;
	}

}
