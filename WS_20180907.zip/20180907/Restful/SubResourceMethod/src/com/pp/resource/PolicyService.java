package com.pp.resource;

import java.io.IOException;
import java.io.OutputStream;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.StreamingOutput;

import com.pp.dto.Policy;

@Path("/policy")
public class PolicyService {

	@GET
	@Produces(MediaType.APPLICATION_XML)
	@Path("/{policyNo}/detail")
	public StreamingOutput getPolicy(@PathParam("policyNo") String policyNo) {
		Policy policy = null;

		policy = new Policy(policyNo, "Jeevan Abhay", "Mathew", 939493);
		return new PolicyStreamingOutput(policy);
	}

	private final class PolicyStreamingOutput implements StreamingOutput {
		private Policy policy;

		public PolicyStreamingOutput(Policy policy) {
			this.policy = policy;
		}

		@Override
		public void write(OutputStream os) throws IOException, WebApplicationException {
			StringBuffer buffer = null;

			buffer = new StringBuffer();
			buffer.append("<policy><policyNo>").append(policy.getPolicyNo()).append("</policyNo><planName>")
					.append(policy.getPlanName()).append("</planName><policyHolderName>")
					.append(policy.getPolicyHolderName()).append("</policyHolderName><insurredAmount>")
					.append(policy.getInsurredAmount()).append("</insurredAmount></policy>");
			os.write(buffer.toString().getBytes());
			os.close();
		}

	}
}
