package com.srm.resource;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;

@Path("/rbi")
public class RbiBank {

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/ifscCode")
	public String getIfscCode(@QueryParam("bankName") String bankName, @QueryParam("city") String city,
			@QueryParam("area") String area) {
		return "icic0030398";
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/atmLocation")
	public String getAtmLocation(@QueryParam("bankName") String bankName, @QueryParam("city") String city) {
		return "jubliee hills, madhapur, kondapur";
	}
}
