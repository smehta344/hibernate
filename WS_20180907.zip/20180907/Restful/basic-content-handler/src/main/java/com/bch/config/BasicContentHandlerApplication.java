package com.bch.config;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

import com.bch.resource.OrderService;

@ApplicationPath("/services/*")
public class BasicContentHandlerApplication extends Application {
	private Set<Object> singletons;
	private Set<Class<?>> classes;

	public BasicContentHandlerApplication() {
		singletons = new HashSet<>();
		classes = new HashSet<>();

		classes.add(OrderService.class);
	}

	@Override
	public Set<Class<?>> getClasses() {
		return classes;
	}

	@Override
	public Set<Object> getSingletons() {
		return singletons;
	}

}
