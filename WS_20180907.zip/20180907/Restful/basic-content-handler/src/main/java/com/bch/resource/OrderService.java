package com.bch.resource;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Reader;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.StreamingOutput;

@Path("/order")
public class OrderService {

	@POST
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/in")
	public String createOrder(InputStream in) throws IOException {
		StringBuffer buffer = null;
		int c = 0;

		buffer = new StringBuffer();
		while ((c = in.read()) != -1) {
			buffer.append((char) c);
		}
		return buffer.toString();
	}

	@POST
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/reader")
	public String createOrder(Reader reader) throws IOException {
		StringBuffer buffer = null;
		char[] buf = null;

		buffer = new StringBuffer();
		buf = new char[256];
		while ((reader.read(buf)) != -1) {
			buffer.append(buf);
		}

		return buffer.toString();
	}

	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.TEXT_PLAIN)
	@Path("/byte")
	public byte[] createOrder(byte[] body) {
		return body;
	}

	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.TEXT_PLAIN)
	@Path("/string")
	public StreamingOutput createOrder(final String order) {
		StreamingOutput output = (OutputStream os) -> {
			os.write(order.getBytes());
			os.close();
		};
		return output;
	}

	@POST
	@Produces(MediaType.MULTIPART_FORM_DATA)
	@Consumes(MediaType.MULTIPART_FORM_DATA)
	@Path("/file")
	public File createOrder(File orderFile) {
		return orderFile;
	}
}
