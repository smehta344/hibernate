package com.eh.dto;

import javax.json.bind.annotation.JsonbAnnotation;

@JsonbAnnotation
public class PayRequest {
	protected String mobileNo;
	protected String merchantNo;
	protected double amount;

	public String getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}

	public String getMerchantNo() {
		return merchantNo;
	}

	public void setMerchantNo(String merchantNo) {
		this.merchantNo = merchantNo;
	}

	public double getAmount() {
		return amount;
	}

	public void setAmount(double amount) {
		this.amount = amount;
	}

}
