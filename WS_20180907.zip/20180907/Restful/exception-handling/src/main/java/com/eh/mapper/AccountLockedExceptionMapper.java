package com.eh.mapper;

import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;
import javax.ws.rs.ext.ExceptionMapper;
import javax.ws.rs.ext.Provider;

import com.eh.dto.Error;
import com.eh.exception.AccountLockedException;

@Provider
public class AccountLockedExceptionMapper implements ExceptionMapper<AccountLockedException> {

	@Override
	public Response toResponse(AccountLockedException exception) {
		Error error = new Error();
		error.setErrorCode("004");
		error.setDescription("account locked");
		return Response.status(Status.PRECONDITION_FAILED).entity(error).build();
	}

}
