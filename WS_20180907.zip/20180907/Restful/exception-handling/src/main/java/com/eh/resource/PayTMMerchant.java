package com.eh.resource;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.NotFoundException;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import com.eh.dto.Error;
import com.eh.dto.PayRequest;
import com.eh.dto.PayStatus;
import com.eh.exception.AccountNotFoundException;
import com.eh.exception.BankAccountNotFoundException;
import com.eh.service.MerchantService;

@Path("/merchant")
public class PayTMMerchant {
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/pay")
	public PayStatus pay(PayRequest payRequest) {
		PayStatus payStatus = null;
		String accountNo = null;
		MerchantService merchantService = null;

		merchantService = new MerchantService();
		accountNo = merchantService.getAccountNo(payRequest.getMobileNo());

		return payStatus;
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	@Path("/upi")
	public Response upiPay(PayRequest payRequest) {
		MerchantService merchantService = null;
		String bankAccountNo = null;
		Response response = null;

		try {
			merchantService = new MerchantService();
			bankAccountNo = merchantService.getBankAccountNo(payRequest.getMobileNo());
		} catch (BankAccountNotFoundException e) {
			Error error = new Error();
			error.setErrorCode("001");
			error.setDescription("upino not found");
			response = Response.status(Status.BAD_REQUEST).entity(error).build();
			return response;
		}
		response = Response.ok().build();
		return response;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/balance/{mobileNo}")
	public double getAccountBalance(@PathParam("mobileNo") String mobileNo) {
		MerchantService merchantService = null;
		String accountNo = null;

		try {
			merchantService = new MerchantService();
			accountNo = merchantService.getAccountNo(mobileNo);
		} catch (AccountNotFoundException e) {
			Error error = new Error();
			error.setErrorCode("002");
			error.setDescription("account no is not available");
			Response response = Response.status(Status.NOT_FOUND).entity(error).build();
			NotFoundException notFoundException = new NotFoundException(response);
			throw notFoundException;
		}
		return 35;
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/accountHolderName/{mobileNo}")
	public String getAccountHolderName(@PathParam("mobileNo") String mobileNo) {
		MerchantService merchantService = null;

		merchantService = new MerchantService();
		merchantService.getAccountName(mobileNo);

		return "susan";
	}
}
