package com.eh.service;

import com.eh.exception.AccountLockedException;
import com.eh.exception.AccountNotFoundException;
import com.eh.exception.BankAccountNotFoundException;

public class MerchantService {

	public String getAccountNo(String mobileNo) {
		throw new AccountNotFoundException("account not found exception");
	}

	public String getBankAccountNo(String mobileNo) {
		throw new BankAccountNotFoundException("no upi account found with mobileNo");
	}

	public String getAccountName(String mobileNo) {
		throw new AccountLockedException("account locked");
	}
}
