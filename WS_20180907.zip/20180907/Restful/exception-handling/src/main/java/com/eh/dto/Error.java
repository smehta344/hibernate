package com.eh.dto;

import javax.json.bind.annotation.JsonbAnnotation;

@JsonbAnnotation
public class Error {
	protected String errorCode;
	protected String description;

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

}
