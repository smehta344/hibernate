package com.netbanking.resource;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.QueryParam;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.StreamingOutput;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

import com.netbanking.dto.Account;
import com.netbanking.dto.CloseAccount;
import com.netbanking.dto.DepositeFunds;
import com.netbanking.dto.OpenAccount;

@Path("/netbanking")
public class Netbanking {
	private static Map<String, Account> accounts = new HashMap<>();

	@POST
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.TEXT_PLAIN)
	public String openAccount(InputStream in) throws ParserConfigurationException, SAXException, IOException {
		String accountNo = null;
		Account account = null;
		OpenAccount openAccount = null;

		openAccount = buildOpenAccount(in);
		accountNo = UUID.randomUUID().toString();
		account = new Account();
		account.setAccountNo(accountNo);
		account.setAccountHolderName(openAccount.getAccountHolderName());
		account.setAccountType(openAccount.getAccountType());
		account.setBalance(500);
		account.setEmailAddress(openAccount.getEmailAddress());
		account.setMobileNo(openAccount.getMobileNo());
		account.setIfscCode(openAccount.getIfscCode());

		accounts.put(accountNo, account);

		return accountNo;
	}

	@PUT
	@Consumes(MediaType.APPLICATION_XML)
	@Produces(MediaType.TEXT_PLAIN)
	public String depositeFunds(InputStream in) throws ParserConfigurationException, SAXException, IOException {
		String refNo = null;
		Account account = null;
		DepositeFunds depositeFunds = null;

		depositeFunds = buildDepositeFunds(in);
		if (accounts.containsKey(depositeFunds.getAccountNo()) == false) {
			throw new RuntimeException("Account not found");
		}
		account = accounts.get(depositeFunds.getAccountNo());
		account.setBalance(account.getBalance() + depositeFunds.getAmount());
		refNo = UUID.randomUUID().toString();

		return refNo;
	}

	@GET
	@Produces(MediaType.APPLICATION_XML)
	public StreamingOutput getAccount(@QueryParam("accountNo") String accountNo) {
		Account account = null;
		AccountStreamingOuput accountStreamingOuput = null;

		if (accounts.containsKey(accountNo) == false) {
			throw new RuntimeException("account not found");
		}
		account = accounts.get(accountNo);
		accountStreamingOuput = new AccountStreamingOuput(account);

		return accountStreamingOuput;
	}

	@DELETE
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.APPLICATION_XML)
	public String closeAccount(InputStream in) throws ParserConfigurationException, SAXException, IOException {
		CloseAccount closeAccount = null;
		Account account = null;

		closeAccount = buildCloseAccount(in);
		if (accounts.containsKey(closeAccount.getAccountNo()) == false) {
			throw new RuntimeException("account not found to close");
		}
		account = accounts.get(closeAccount.getAccountNo());
		accounts.remove(account);
		return "account removed";
	}

	private OpenAccount buildOpenAccount(InputStream in)
			throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = null;
		DocumentBuilder builder = null;
		OpenAccount openAccount = null;
		NodeList children = null;
		Node rootNode = null;
		Document doc = null;
		Node child = null;
		String nName = null;
		String nValue = null;

		factory = DocumentBuilderFactory.newInstance();
		builder = factory.newDocumentBuilder();
		doc = builder.parse(in);
		rootNode = doc.getFirstChild();
		children = rootNode.getChildNodes();

		openAccount = new OpenAccount();

		for (int i = 0; i < children.getLength(); i++) {
			child = children.item(i);

			if (child.getNodeType() == Node.ELEMENT_NODE) {
				nName = child.getNodeName();
				nValue = child.getFirstChild().getNodeValue();

				if (nName.equals("account-holder-name")) {
					openAccount.setAccountHolderName(nValue);
				} else if (nName.equals("account-type")) {
					openAccount.setAccountType(nValue);
				} else if (nName.equals("ifsc-code")) {
					openAccount.setIfscCode(nValue);
				} else if (nName.equals("mobile-no")) {
					openAccount.setMobileNo(nValue);
				} else if (nName.equals("email-address")) {
					openAccount.setEmailAddress(nValue);
				}
			}
		}
		return openAccount;

	}

	private DepositeFunds buildDepositeFunds(InputStream in)
			throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = null;
		DepositeFunds depositeFunds = null;
		DocumentBuilder builder = null;
		NodeList children = null;
		Node rootNode = null;
		Document doc = null;
		Node child = null;
		String nName = null;
		String nValue = null;

		factory = DocumentBuilderFactory.newInstance();
		builder = factory.newDocumentBuilder();
		doc = builder.parse(in);
		rootNode = doc.getFirstChild();
		children = rootNode.getChildNodes();

		depositeFunds = new DepositeFunds();

		for (int i = 0; i < children.getLength(); i++) {
			child = children.item(i);

			if (child.getNodeType() == Node.ELEMENT_NODE) {
				nName = child.getNodeName();
				nValue = child.getFirstChild().getNodeValue();

				if (nName.equals("account-holder-name")) {
					depositeFunds.setAccountHolderName(nValue);
				} else if (nName.equals("account-no")) {
					depositeFunds.setAccountNo(nValue);
				} else if (nName.equals("amount")) {
					depositeFunds.setAmount(Float.parseFloat(nValue));
				}
			}
		}
		return depositeFunds;
	}

	private final class AccountStreamingOuput implements StreamingOutput {
		private Account account;

		public AccountStreamingOuput(Account account) {
			this.account = account;
		}

		@Override
		public void write(OutputStream os) throws IOException, WebApplicationException {
			StringBuffer buffer = null;

			buffer = new StringBuffer();
			buffer.append("<account><account-no>").append(account.getAccountNo())
					.append("</account-no><account-holder-name>").append(account.getAccountHolderName())
					.append("</account-holder-name><balance>").append(account.getBalance())
					.append("</balance></account>");
			os.write(buffer.toString().getBytes());
			os.close();
		}

	}

	private CloseAccount buildCloseAccount(InputStream in)
			throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = null;
		CloseAccount closeAccount = null;
		DocumentBuilder builder = null;
		NodeList children = null;
		Node rootNode = null;
		Document doc = null;
		Node child = null;
		String nName = null;
		String nValue = null;

		factory = DocumentBuilderFactory.newInstance();
		builder = factory.newDocumentBuilder();
		doc = builder.parse(in);
		rootNode = doc.getFirstChild();
		children = rootNode.getChildNodes();

		closeAccount = new CloseAccount();

		for (int i = 0; i < children.getLength(); i++) {
			child = children.item(i);

			if (child.getNodeType() == Node.ELEMENT_NODE) {
				nName = child.getNodeName();
				nValue = child.getFirstChild().getNodeValue();

				if (nName.equals("account-holder-name")) {
					closeAccount.setAccountHolderName(nValue);
				} else if (nName.equals("account-no")) {
					closeAccount.setAccountNo(nValue);
				} else if (nName.equals("reason")) {
					closeAccount.setReason(nValue);
				}
			}
		}
		return closeAccount;

	}
}
