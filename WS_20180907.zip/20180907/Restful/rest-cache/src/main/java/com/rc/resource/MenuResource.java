package com.rc.resource;

import java.util.Date;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.CacheControl;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import com.rc.dto.Food;

@Path("/menu")
public class MenuResource {
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/food/{restaurantNo}/{foodNo}")
	public Response getFoodInfo(@PathParam("restaurantNo") String restaurantNo, @PathParam("foodNo") int foodNo) {
		Food food = null;
		Response response = null;

		System.out.println("request for food :" + foodNo);

		food = new Food();
		food.setFoodNo(foodNo);
		food.setDishName("Chicken Biryani");
		food.setDescription("Authentic Dish");
		food.setQuantity("500 gm");
		food.setPrice(235);

		response = Response.ok().entity(Entity.json(food)).expires(new Date(2019, 02, 18, 00, 00)).build();

		return response;
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/food/{restaurantNo}/{foodNo}/availability")
	public Response getFoodAvailability(@PathParam("restaurantNo") String restaurantNo,
			@PathParam("foodNo") int foodNo) {
		Response response = null;
		CacheControl cc = null;

		System.out.println("getFoodAvailability()");
		cc = new CacheControl();
		cc.setPrivate(true);
		cc.setMaxAge(1000 * 60);
		response = Response.ok(23).cacheControl(cc).build();

		return response;
	}
}
