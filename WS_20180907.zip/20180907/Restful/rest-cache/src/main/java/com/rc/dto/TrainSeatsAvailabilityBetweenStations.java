package com.rc.dto;

import java.util.List;

public class TrainSeatsAvailabilityBetweenStations {
	protected String source;
	protected String destination;
	protected String journeyDate;
	protected List<TrainSeatsAvailablityStatus> trainSeatsAvailablityStatus;

	public TrainSeatsAvailabilityBetweenStations(String source, String destination, String journeyDate,
			List<TrainSeatsAvailablityStatus> trainSeatsAvailablityStatus) {
		super();
		this.source = source;
		this.destination = destination;
		this.journeyDate = journeyDate;
		this.trainSeatsAvailablityStatus = trainSeatsAvailablityStatus;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getJourneyDate() {
		return journeyDate;
	}

	public void setJourneyDate(String journeyDate) {
		this.journeyDate = journeyDate;
	}

	public List<TrainSeatsAvailablityStatus> getTrainSeatsAvailablityStatus() {
		return trainSeatsAvailablityStatus;
	}

	public void setTrainSeatsAvailablityStatus(List<TrainSeatsAvailablityStatus> trainSeatsAvailablityStatus) {
		this.trainSeatsAvailablityStatus = trainSeatsAvailablityStatus;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((destination == null) ? 0 : destination.hashCode());
		result = prime * result + ((journeyDate == null) ? 0 : journeyDate.hashCode());
		result = prime * result + ((source == null) ? 0 : source.hashCode());
		result = prime * result + ((trainSeatsAvailablityStatus == null) ? 0 : trainSeatsAvailablityStatus.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TrainSeatsAvailabilityBetweenStations other = (TrainSeatsAvailabilityBetweenStations) obj;
		if (destination == null) {
			if (other.destination != null)
				return false;
		} else if (!destination.equals(other.destination))
			return false;
		if (journeyDate == null) {
			if (other.journeyDate != null)
				return false;
		} else if (!journeyDate.equals(other.journeyDate))
			return false;
		if (source == null) {
			if (other.source != null)
				return false;
		} else if (!source.equals(other.source))
			return false;
		if (trainSeatsAvailablityStatus == null) {
			if (other.trainSeatsAvailablityStatus != null)
				return false;
		} else if (!trainSeatsAvailablityStatus.equals(other.trainSeatsAvailablityStatus))
			return false;
		return true;
	}

}
