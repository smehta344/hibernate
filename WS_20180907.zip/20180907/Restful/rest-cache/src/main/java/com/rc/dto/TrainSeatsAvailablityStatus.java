package com.rc.dto;

public class TrainSeatsAvailablityStatus {
	protected int trainNo;
	protected String trainName;
	protected String source;
	protected String destination;
	protected String availablityDate;
	protected int sleeperAvailablity;
	protected int thirdAcAvailablity;
	protected int secondAcAvailability;
	protected int firstAcAvailability;

	public TrainSeatsAvailablityStatus() {
	}

	public TrainSeatsAvailablityStatus(int trainNo, String trainName, String source, String destination,
			String availablityDate, int sleeperAvailablity, int thirdAcAvailablity, int secondAcAvailability,
			int firstAcAvailability) {
		this.trainNo = trainNo;
		this.trainName = trainName;
		this.source = source;
		this.destination = destination;
		this.availablityDate = availablityDate;
		this.sleeperAvailablity = sleeperAvailablity;
		this.thirdAcAvailablity = thirdAcAvailablity;
		this.secondAcAvailability = secondAcAvailability;
		this.firstAcAvailability = firstAcAvailability;
	}

	public int getTrainNo() {
		return trainNo;
	}

	public void setTrainNo(int trainNo) {
		this.trainNo = trainNo;
	}

	public String getTrainName() {
		return trainName;
	}

	public void setTrainName(String trainName) {
		this.trainName = trainName;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public String getAvailablityDate() {
		return availablityDate;
	}

	public void setAvailablityDate(String availablityDate) {
		this.availablityDate = availablityDate;
	}

	public int getSleeperAvailablity() {
		return sleeperAvailablity;
	}

	public void setSleeperAvailablity(int sleeperAvailablity) {
		this.sleeperAvailablity = sleeperAvailablity;
	}

	public int getThirdAcAvailablity() {
		return thirdAcAvailablity;
	}

	public void setThirdAcAvailablity(int thirdAcAvailablity) {
		this.thirdAcAvailablity = thirdAcAvailablity;
	}

	public int getSecondAcAvailability() {
		return secondAcAvailability;
	}

	public void setSecondAcAvailability(int secondAcAvailability) {
		this.secondAcAvailability = secondAcAvailability;
	}

	public int getFirstAcAvailability() {
		return firstAcAvailability;
	}

	public void setFirstAcAvailability(int firstAcAvailability) {
		this.firstAcAvailability = firstAcAvailability;
	}

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((availablityDate == null) ? 0 : availablityDate.hashCode());
		result = prime * result + ((destination == null) ? 0 : destination.hashCode());
		result = prime * result + firstAcAvailability;
		result = prime * result + secondAcAvailability;
		result = prime * result + sleeperAvailablity;
		result = prime * result + ((source == null) ? 0 : source.hashCode());
		result = prime * result + thirdAcAvailablity;
		result = prime * result + ((trainName == null) ? 0 : trainName.hashCode());
		result = prime * result + trainNo;
		return result;
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		TrainSeatsAvailablityStatus other = (TrainSeatsAvailablityStatus) obj;
		if (availablityDate == null) {
			if (other.availablityDate != null)
				return false;
		} else if (!availablityDate.equals(other.availablityDate))
			return false;
		if (destination == null) {
			if (other.destination != null)
				return false;
		} else if (!destination.equals(other.destination))
			return false;
		if (firstAcAvailability != other.firstAcAvailability)
			return false;
		if (secondAcAvailability != other.secondAcAvailability)
			return false;
		if (sleeperAvailablity != other.sleeperAvailablity)
			return false;
		if (source == null) {
			if (other.source != null)
				return false;
		} else if (!source.equals(other.source))
			return false;
		if (thirdAcAvailablity != other.thirdAcAvailablity)
			return false;
		if (trainName == null) {
			if (other.trainName != null)
				return false;
		} else if (!trainName.equals(other.trainName))
			return false;
		if (trainNo != other.trainNo)
			return false;
		return true;
	}

}
