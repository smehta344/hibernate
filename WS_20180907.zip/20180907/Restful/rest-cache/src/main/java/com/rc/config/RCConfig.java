package com.rc.config;

import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.server.ResourceConfig;

import com.rc.resource.MenuResource;
import com.rc.resource.TrainSeatAvailablityService;

@ApplicationPath("/services")
public class RCConfig extends ResourceConfig {

	public RCConfig() {
		super.register(MenuResource.class);
		super.register(new TrainSeatAvailablityService());
	}

}
