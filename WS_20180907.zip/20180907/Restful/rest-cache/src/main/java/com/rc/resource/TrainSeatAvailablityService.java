package com.rc.resource;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ws.rs.GET;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.CacheControl;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.EntityTag;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Request;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;
import javax.ws.rs.core.Response.Status;

import com.rc.dto.TrainSeatsAvailabilityBetweenStations;
import com.rc.dto.TrainSeatsAvailablityStatus;

@Path("/seatService")
public class TrainSeatAvailablityService {
	private Map<Integer, TrainSeatsAvailablityStatus> trainSeatAvailabilityStatusMap;

	public TrainSeatAvailablityService() {
		TrainSeatsAvailablityStatus trainSeatsAvailablityStatus = null;

		trainSeatAvailabilityStatusMap = new HashMap<>();
		trainSeatsAvailablityStatus = new TrainSeatsAvailablityStatus(12, "sethapdi", "hyderabad", "chennai",
				"17-03-2019", 200, 30, 15, 10);
		trainSeatAvailabilityStatusMap.put(12, trainSeatsAvailablityStatus);

		trainSeatsAvailablityStatus = new TrainSeatsAvailablityStatus(11, "visaka express", "hyderabad", "vizag",
				"17-03-2019", 210, 31, 25, 11);
		trainSeatAvailabilityStatusMap.put(11, trainSeatsAvailablityStatus);

		trainSeatsAvailablityStatus = new TrainSeatsAvailablityStatus(10, "chennai express", "hyderabad", "chennai",
				"17-03-2019", 190, 35, 15, 15);
		trainSeatAvailabilityStatusMap.put(10, trainSeatsAvailablityStatus);

		trainSeatsAvailablityStatus = new TrainSeatsAvailablityStatus(13, "trivandram express", "hyderabad", "chennai",
				"17-03-2019", 110, 11, 15, 2);
		trainSeatAvailabilityStatusMap.put(13, trainSeatsAvailablityStatus);
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/between/{source}/{destination}/{journeyDate}/availability")
	public Response getTrainAvailabilityBetweenStations(@PathParam("source") String source,
			@PathParam("destination") String destination, @PathParam("journeyDate") String journeyDate,
			@Context Request request) {
		ResponseBuilder builder = null;
		Response response = null;
		CacheControl cc = null;
		String eTag = null;
		List<TrainSeatsAvailablityStatus> trainSeatsAvailablityStatus = null;
		TrainSeatsAvailabilityBetweenStations trainSeatsAvailabilityBetweenStations = null;

		trainSeatsAvailablityStatus = new ArrayList<>();
		for (TrainSeatsAvailablityStatus tas : trainSeatAvailabilityStatusMap.values()) {
			if (tas.getSource().equals(source) && tas.getDestination().equals(destination)
					&& tas.getAvailablityDate().equals(journeyDate)) {
				trainSeatsAvailablityStatus.add(tas);
			}
		}
		trainSeatsAvailabilityBetweenStations = new TrainSeatsAvailabilityBetweenStations(source, destination,
				journeyDate, trainSeatsAvailablityStatus);
		eTag = String.valueOf(trainSeatsAvailabilityBetweenStations.hashCode());

		builder = request.evaluatePreconditions(new EntityTag(eTag));
		if (builder != null) {
			return builder.build();
		}

		cc = new CacheControl();
		cc.setPrivate(true);
		cc.setMaxAge(1000 * 60 * 2);
		cc.setMustRevalidate(true);

		response = Response.ok(trainSeatsAvailabilityBetweenStations).cacheControl(cc).tag(new EntityTag(eTag)).build();

		return response;
	}

	@PUT
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/updateAvailability")
	public Response updateTrainSeatAvailability(TrainSeatsAvailablityStatus trainSeatsAvailablityStatus) {
		Response response;

		if (trainSeatAvailabilityStatusMap.containsKey(trainSeatsAvailablityStatus.getTrainNo()) == false) {
			trainSeatAvailabilityStatusMap.put(trainSeatsAvailablityStatus.getTrainNo(), trainSeatsAvailablityStatus);
			response = Response.status(201).build();
			return response;
		}
		trainSeatAvailabilityStatusMap.put(trainSeatsAvailablityStatus.getTrainNo(), trainSeatsAvailablityStatus);
		response = Response.status(Status.ACCEPTED).build();
		return response;
	}

}
