package com.ch.writers;

import java.io.IOException;
import java.io.OutputStream;
import java.lang.annotation.Annotation;
import java.lang.reflect.Type;

import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.MultivaluedMap;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.MessageBodyWriter;
import javax.ws.rs.ext.Provider;
import javax.ws.rs.ext.Providers;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.annotation.XmlRootElement;

@Provider
@Produces(MediaType.APPLICATION_XML)
public class JaxbMessageBodyWriter implements MessageBodyWriter<Object> {
	@Context
	private Providers providers;

	@Override
	public boolean isWriteable(Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType) {
		if (mediaType.isCompatible(MediaType.APPLICATION_XML_TYPE) && type.isAnnotationPresent(XmlRootElement.class)) {
			return true;
		}
		return false;
	}

	@Override
	public void writeTo(Object object, Class<?> type, Type genericType, Annotation[] annotations, MediaType mediaType,
			MultivaluedMap<String, Object> httpHeaders, OutputStream entityStream)
			throws IOException, WebApplicationException {
		JAXBContext jContext = null;
		Marshaller marshaller = null;
		ContextResolver<JAXBContext> contextResolver = null;

		try {
			contextResolver = providers.getContextResolver(JAXBContext.class, MediaType.APPLICATION_XML_TYPE);
			jContext = contextResolver.getContext(type);
			
			marshaller = jContext.createMarshaller();
			marshaller.marshal(object, entityStream);
			entityStream.close();
		} catch (JAXBException e) {
			throw new WebApplicationException(e);
		}

	}

}













