package com.ch.resolvers;

import javax.ws.rs.Produces;
import javax.ws.rs.WebApplicationException;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.ext.ContextResolver;
import javax.ws.rs.ext.Provider;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;

import com.ch.dto.Plan;
import com.ch.dto.PlanStatus;

@Provider
@Produces(MediaType.APPLICATION_XML)
public class JaxbContextResolver implements ContextResolver<JAXBContext> {
	private JAXBContext jaxbContext;

	public JaxbContextResolver() {
		try {
			jaxbContext = JAXBContext.newInstance(Plan.class, PlanStatus.class);
		} catch (JAXBException e) {
			throw new WebApplicationException(e);
		}
	}

	@Override
	public JAXBContext getContext(Class<?> type) {
		System.out.println("ClassType : " + type.getName());
		return jaxbContext;
	}

}
