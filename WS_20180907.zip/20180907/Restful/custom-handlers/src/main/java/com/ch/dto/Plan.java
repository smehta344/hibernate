package com.ch.dto;

import javax.json.bind.annotation.JsonbAnnotation;
import javax.json.bind.annotation.JsonbProperty;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

@XmlType(name = "plan")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "plan")
@JsonbAnnotation
public class Plan {
	@JsonbProperty
	protected int planNo;
	@JsonbProperty
	protected String planName;
	@JsonbProperty
	protected String insurrencePlanType;
	@JsonbProperty
	protected String description;
	@JsonbProperty
	protected int minTenure;
	@JsonbProperty
	protected int maxTenure;
	@JsonbProperty
	protected int minAge;
	@JsonbProperty
	protected int maxAge;
	@JsonbProperty
	protected double minInsurredAmount;
	@JsonbProperty
	protected double maxInsurredAmount;

	public int getPlanNo() {
		return planNo;
	}

	public void setPlanNo(int planNo) {
		this.planNo = planNo;
	}

	public String getPlanName() {
		return planName;
	}

	public void setPlanName(String planName) {
		this.planName = planName;
	}

	public String getInsurrencePlanType() {
		return insurrencePlanType;
	}

	public void setInsurrencePlanType(String insurrencePlanType) {
		this.insurrencePlanType = insurrencePlanType;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getMinTenure() {
		return minTenure;
	}

	public void setMinTenure(int minTenure) {
		this.minTenure = minTenure;
	}

	public int getMaxTenure() {
		return maxTenure;
	}

	public void setMaxTenure(int maxTenure) {
		this.maxTenure = maxTenure;
	}

	public int getMinAge() {
		return minAge;
	}

	public void setMinAge(int minAge) {
		this.minAge = minAge;
	}

	public int getMaxAge() {
		return maxAge;
	}

	public void setMaxAge(int maxAge) {
		this.maxAge = maxAge;
	}

	public double getMinInsurredAmount() {
		return minInsurredAmount;
	}

	public void setMinInsurredAmount(double minInsurredAmount) {
		this.minInsurredAmount = minInsurredAmount;
	}

	public double getMaxInsurredAmount() {
		return maxInsurredAmount;
	}

	public void setMaxInsurredAmount(double maxInsurredAmount) {
		this.maxInsurredAmount = maxInsurredAmount;
	}

}
