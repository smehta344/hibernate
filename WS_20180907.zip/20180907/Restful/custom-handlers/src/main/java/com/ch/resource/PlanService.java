package com.ch.resource;

import javax.ws.rs.Consumes;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import com.ch.dto.Plan;
import com.ch.dto.PlanStatus;

@Path("/plan")
public class PlanService {
	@POST
	@Produces({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	@Consumes({ MediaType.APPLICATION_JSON, MediaType.APPLICATION_XML })
	public PlanStatus createPlan(Plan plan) {
		PlanStatus planStatus = null;

		planStatus = new PlanStatus();
		planStatus.setPlanNo(plan.getPlanNo());
		planStatus.setEffectiveInDays(10);
		planStatus.setStatus("Accepted");

		return planStatus;
	}
}
