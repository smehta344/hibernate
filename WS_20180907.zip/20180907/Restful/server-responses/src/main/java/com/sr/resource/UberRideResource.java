package com.sr.resource;

import java.util.Date;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.client.Entity;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.NewCookie;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.ResponseBuilder;

import com.sr.dto.CabRequest;
import com.sr.dto.RideInfo;

@Path("/uberRide")
public class UberRideResource {

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/fare/{source}/{destination}")
	public Response getEstimatedRideFare(@PathParam("source") String source,
			@PathParam("destination") String destination) {
		Response response = null;
		ResponseBuilder builder = null;

		builder = Response.status(202);
		builder.entity(324);
		response = builder.build();

		return response;
	}

	@GET
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/time/{source}/{destination}")
	public Response getEstimatedTravelTime(@PathParam("source") String source,
			@PathParam("destination") String destination) {
		Response response = null;
		ResponseBuilder builder = null;

		builder = Response.ok();
		builder.entity("Estimated Travel Time : 1 hours 15 mins");
		builder.header("rideType", "suv");

		response = builder.build();

		return response;
	}

	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public Response bookRide(CabRequest cabRequest) {
		Response response = null;
		RideInfo rideInfo = null;
		ResponseBuilder builder = null;

		rideInfo = new RideInfo();
		rideInfo.setRideNo("JAO3984");
		rideInfo.setDriverName("Mathew");
		rideInfo.setContactNo("0380439084");
		rideInfo.setEstimatedAmount(340);
		rideInfo.setEstimatedReachTime(new Date());

		/*
		 * builder = Response.ok(); builder.entity(Entity.json(rideInfo));
		 * builder.header("promotion", "p303"); builder.cookie(new
		 * NewCookie("otp","9303")); response = builder.build();
		 */

		return Response.ok().entity(rideInfo).header("promotion", "p303")
				.cookie(new NewCookie("otp", "0394")).build();
	}

}












