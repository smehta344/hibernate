package com.sr.dto;

import java.util.Date;

import javax.json.bind.annotation.JsonbAnnotation;

@JsonbAnnotation
public class RideInfo {
	protected String rideNo;
	protected Date estimatedReachTime;
	protected String driverName;
	protected String contactNo;
	protected double estimatedAmount;

	public String getRideNo() {
		return rideNo;
	}

	public void setRideNo(String rideNo) {
		this.rideNo = rideNo;
	}

	public Date getEstimatedReachTime() {
		return estimatedReachTime;
	}

	public void setEstimatedReachTime(Date estimatedReachTime) {
		this.estimatedReachTime = estimatedReachTime;
	}

	public String getDriverName() {
		return driverName;
	}

	public void setDriverName(String driverName) {
		this.driverName = driverName;
	}

	public String getContactNo() {
		return contactNo;
	}

	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}

	public double getEstimatedAmount() {
		return estimatedAmount;
	}

	public void setEstimatedAmount(double estimatedAmount) {
		this.estimatedAmount = estimatedAmount;
	}

}
