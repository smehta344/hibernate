package com.sr.config;

import javax.ws.rs.ApplicationPath;

import org.glassfish.jersey.server.ResourceConfig;

import com.sr.resource.UberRideResource;

@ApplicationPath("/services")
public class UberApplication extends ResourceConfig {
	public UberApplication() {
		System.out.println("UberApplication");
		super.register(UberRideResource.class);
	}

}
