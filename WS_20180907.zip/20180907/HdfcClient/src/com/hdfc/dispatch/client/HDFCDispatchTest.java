package com.hdfc.dispatch.client;

import java.io.IOException;

import javax.xml.namespace.QName;
import javax.xml.soap.MessageFactory;
import javax.xml.soap.SOAPBody;
import javax.xml.soap.SOAPElement;
import javax.xml.soap.SOAPException;
import javax.xml.soap.SOAPMessage;
import javax.xml.ws.Dispatch;
import javax.xml.ws.Service;
import javax.xml.ws.Service.Mode;
import javax.xml.ws.soap.SOAPBinding;

public class HDFCDispatchTest {
	private final static String ENDPOINT_URL = "http://localhost:8080/HdfcBroker/hub";
	private final static String SERVICE_NM = "BankHubImplService";
	private final static String PORT_NM = "BankHubImplPort";
	private final static String TRGT_NMSPC = "http://www.hdfc.com/bank/service";
	private final static String TYP_NMSPC = "http://www.hdfc.com/bank/types";
	private final static String SOAP_ACTION = "http://www.hdfc.com/bank/service:transfer";

	public static void main(String[] args) throws SOAPException, IOException {
		Service bankHubService = Service.create(new QName(TRGT_NMSPC,
				SERVICE_NM));
		bankHubService.addPort(new QName(TRGT_NMSPC, PORT_NM),
				SOAPBinding.SOAP11HTTP_BINDING, ENDPOINT_URL);

		Dispatch<SOAPMessage> transferDispatch = bankHubService
				.createDispatch(new QName(TRGT_NMSPC, PORT_NM),
						SOAPMessage.class, Mode.MESSAGE);

		MessageFactory messageFactory = MessageFactory.newInstance();
		SOAPMessage request = messageFactory.createMessage();
		SOAPBody body = request.getSOAPBody();
		SOAPElement transferElem = body.addChildElement(new QName(TYP_NMSPC,
				"transfer"));

		SOAPElement fromAcElem = transferElem.addChildElement("fromAccount");
		SOAPElement fromAcNoElem = fromAcElem.addChildElement("account-no");
		fromAcNoElem.addTextNode("3939");
		SOAPElement fromBankNameElem = fromAcElem.addChildElement("bank-name");
		fromBankNameElem.addTextNode("icici");
		SOAPElement fromAcIfscCodeElem = fromAcElem
				.addChildElement("ifsc-code");
		fromAcIfscCodeElem.addTextNode("9383");
		SOAPElement fromAcchldNmElem = fromAcElem
				.addChildElement("account-holder-name");
		fromAcchldNmElem.addTextNode("adrew");

		SOAPElement toAcElem = transferElem.addChildElement("toAccount");
		SOAPElement toAcNoElem = toAcElem.addChildElement("account-no");
		toAcNoElem.addTextNode("9084");
		SOAPElement toBankNameElem = toAcElem.addChildElement("bank-name");
		toBankNameElem.addTextNode("hdfc");
		SOAPElement toAcIfscCodeElem = toAcElem.addChildElement("ifsc-code");
		toAcIfscCodeElem.addTextNode("hdfc0394");
		SOAPElement toAcchldNmElem = toAcElem
				.addChildElement("account-holder-name");
		toAcchldNmElem.addTextNode("smith");

		SOAPElement amountElem = transferElem.addChildElement("amount");
		amountElem.addTextNode("983");

		SOAPMessage response = transferDispatch.invoke(request);
		response.writeTo(System.out);
	}
}

















