package com.hdfc.client;

import com.hdfc.bank.service.BankHub;
import com.hdfc.bank.service.BankHubImplService;
import com.hdfc.bank.types.Account;
import com.hdfc.bank.types.Receipt;

public class HdfcClient {
	public static void main(String[] args) {
		BankHubImplService service = new BankHubImplService();
		BankHub port = service.getBankHubImplPort();
		Account fromAc = new Account();
		fromAc.setAccountNo("9393");
		fromAc.setAccountHolderName("susn");
		fromAc.setBankName("hdfc");
		fromAc.setIfscCode("93i393");
		
		Account toAc = new Account();
		toAc.setAccountNo("93939");
		toAc.setAccountHolderName("susn");
		toAc.setBankName("icici");
		toAc.setIfscCode("9339938");
		
		Receipt receipt = port.transfer(fromAc, toAc, 3930.3f);
		System.out.println("tx ref : " +receipt.getTxRefNo());
		
		
	}
}







