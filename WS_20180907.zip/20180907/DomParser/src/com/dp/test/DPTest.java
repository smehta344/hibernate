package com.dp.test;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class DPTest {
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder
				.parse(new File("D:\\work\\master\\webservices\\20180907\\DomParser\\resources\\po1.xml"));

		NodeList nl = doc.getElementsByTagName("item-code");
		for (int i = 0; i < nl.getLength(); i++) {
			Node n = nl.item(i);
			Node cn = n.getFirstChild();
			System.out.println(cn.getNodeValue());
		}

	}
}



