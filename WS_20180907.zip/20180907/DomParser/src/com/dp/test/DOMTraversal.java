package com.dp.test;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.SAXException;

public class DOMTraversal {
	public static void printNode(Node node) {
		if (node.getNodeType() == Node.DOCUMENT_NODE) {
			printNode(node.getFirstChild());
		} else if (node.getNodeType() == Node.ELEMENT_NODE) {
			System.out.print("<" + node.getNodeName() + ">");
			NodeList children = node.getChildNodes();
			// iterate over children
			for (int i = 0; i < children.getLength(); i++) {
				printNode(children.item(i));
			}
			System.out.println("</" + node.getNodeName() + ">");
		} else if (node.getNodeType() == Node.TEXT_NODE) {
			System.out.print(node.getNodeValue());
		}

	}

	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
		DocumentBuilder builder = factory.newDocumentBuilder();
		Document doc = builder
				.parse(new File("D:\\work\\master\\webservices\\20180907\\DomParser\\resources\\po1.xml"));
		printNode(doc);
	}
}
