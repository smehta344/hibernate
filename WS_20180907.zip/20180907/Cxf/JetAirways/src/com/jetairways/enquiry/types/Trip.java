
package com.jetairways.enquiry.types;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="source" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="destination" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="journey_date" type="{http://www.w3.org/2001/XMLSchema}date"/>
 *         &lt;element name="halts" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="travelClass" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="travelBy" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "source",
    "destination",
    "journeyDate",
    "halts",
    "travelClass",
    "travelBy"
})
@XmlRootElement(name = "trip")
public class Trip {

    @XmlElement(required = true)
    protected String source;
    @XmlElement(required = true)
    protected String destination;
    @XmlElement(name = "journey_date", required = true)
    @XmlSchemaType(name = "date")
    protected Date journeyDate;
    protected int halts;
    @XmlElement(required = true)
    protected String travelClass;
    @XmlElement(required = true)
    protected String travelBy;

    /**
     * Gets the value of the source property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getSource() {
        return source;
    }

    /**
     * Sets the value of the source property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setSource(String value) {
        this.source = value;
    }

    /**
     * Gets the value of the destination property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getDestination() {
        return destination;
    }

    /**
     * Sets the value of the destination property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setDestination(String value) {
        this.destination = value;
    }

    /**
     * Gets the value of the journeyDate property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public Date getJourneyDate() {
        return journeyDate;
    }

    /**
     * Sets the value of the journeyDate property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setJourneyDate(Date value) {
        this.journeyDate = value;
    }

    /**
     * Gets the value of the halts property.
     * 
     */
    public int getHalts() {
        return halts;
    }

    /**
     * Sets the value of the halts property.
     * 
     */
    public void setHalts(int value) {
        this.halts = value;
    }

    /**
     * Gets the value of the travelClass property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTravelClass() {
        return travelClass;
    }

    /**
     * Sets the value of the travelClass property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTravelClass(String value) {
        this.travelClass = value;
    }

    /**
     * Gets the value of the travelBy property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getTravelBy() {
        return travelBy;
    }

    /**
     * Sets the value of the travelBy property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setTravelBy(String value) {
        this.travelBy = value;
    }

}
