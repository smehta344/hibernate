
package com.jetairways.enquiry.types;

import java.util.Date;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlSchemaType;
import javax.xml.bind.annotation.XmlType;
import javax.xml.datatype.XMLGregorianCalendar;


/**
 * <p>Java class for anonymous complex type.
 * 
 * <p>The following schema fragment specifies the expected content contained within this class.
 * 
 * <pre>
 * &lt;complexType>
 *   &lt;complexContent>
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType">
 *       &lt;sequence>
 *         &lt;element name="flight_no" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="flight_name" type="{http://www.w3.org/2001/XMLSchema}string"/>
 *         &lt;element name="departure_time" type="{http://www.w3.org/2001/XMLSchema}dateTime"/>
 *         &lt;element name="available_seats" type="{http://www.w3.org/2001/XMLSchema}int"/>
 *         &lt;element name="fare" type="{http://www.w3.org/2001/XMLSchema}float"/>
 *       &lt;/sequence>
 *     &lt;/restriction>
 *   &lt;/complexContent>
 * &lt;/complexType>
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "flightNo",
    "flightName",
    "departureTime",
    "availableSeats",
    "fare"
})
@XmlRootElement(name = "flight_status")
public class FlightStatus {

    @XmlElement(name = "flight_no", required = true)
    protected String flightNo;
    @XmlElement(name = "flight_name", required = true)
    protected String flightName;
    @XmlElement(name = "departure_time", required = true)
    @XmlSchemaType(name = "dateTime")
    protected Date departureTime;
    @XmlElement(name = "available_seats")
    protected int availableSeats;
    protected float fare;

    /**
     * Gets the value of the flightNo property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlightNo() {
        return flightNo;
    }

    /**
     * Sets the value of the flightNo property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlightNo(String value) {
        this.flightNo = value;
    }

    /**
     * Gets the value of the flightName property.
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getFlightName() {
        return flightName;
    }

    /**
     * Sets the value of the flightName property.
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setFlightName(String value) {
        this.flightName = value;
    }

    /**
     * Gets the value of the departureTime property.
     * 
     * @return
     *     possible object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public Date getDepartureTime() {
        return departureTime;
    }

    /**
     * Sets the value of the departureTime property.
     * 
     * @param value
     *     allowed object is
     *     {@link XMLGregorianCalendar }
     *     
     */
    public void setDepartureTime(Date value) {
        this.departureTime = value;
    }

    /**
     * Gets the value of the availableSeats property.
     * 
     */
    public int getAvailableSeats() {
        return availableSeats;
    }

    /**
     * Sets the value of the availableSeats property.
     * 
     */
    public void setAvailableSeats(int value) {
        this.availableSeats = value;
    }

    /**
     * Gets the value of the fare property.
     * 
     */
    public float getFare() {
        return fare;
    }

    /**
     * Sets the value of the fare property.
     * 
     */
    public void setFare(float value) {
        this.fare = value;
    }

}
