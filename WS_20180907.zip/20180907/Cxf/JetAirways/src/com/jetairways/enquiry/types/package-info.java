@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.jetairways.com/enquiry/types")
package com.jetairways.enquiry.types;
