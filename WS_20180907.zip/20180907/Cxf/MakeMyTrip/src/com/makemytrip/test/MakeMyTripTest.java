package com.makemytrip.test;

import java.util.Date;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.makemytrip.bo.EnquiryBo;
import com.makemytrip.bo.FlightStatus;
import com.makemytrip.enquiry.endpoints.JetAirwaysEnquiryServiceEndpoint;

public class MakeMyTripTest {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext(
				"com/makemytrip/common/application-context.xml");

		JetAirwaysEnquiryServiceEndpoint jetAirwaysEnquiryServiceEndpoint = context.getBean("jetAirwaysServiceEndpoint",
				JetAirwaysEnquiryServiceEndpoint.class);
		EnquiryBo enquiryBo = new EnquiryBo("hyderabad", "banglore", new Date(), "economy", 1, "n/a");
		List<FlightStatus> flightStatus = jetAirwaysEnquiryServiceEndpoint.enquire(enquiryBo);

		for (FlightStatus fs : flightStatus) {
			System.out.println(fs.getFlightName());
		}
	}
}
