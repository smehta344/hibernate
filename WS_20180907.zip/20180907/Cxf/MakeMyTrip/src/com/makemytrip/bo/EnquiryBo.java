package com.makemytrip.bo;

import java.util.Date;

public class EnquiryBo {
	protected String source;
	protected String destination;
	protected Date journeyDate;
	protected String reservationClass;
	protected int halts;
	protected String routePath;

	public EnquiryBo(String source, String destination, Date journeyDate, String reservationClass, int halts,
			String routePath) {
		super();
		this.source = source;
		this.destination = destination;
		this.journeyDate = journeyDate;
		this.reservationClass = reservationClass;
		this.halts = halts;
		this.routePath = routePath;
	}

	public String getSource() {
		return source;
	}

	public void setSource(String source) {
		this.source = source;
	}

	public String getDestination() {
		return destination;
	}

	public void setDestination(String destination) {
		this.destination = destination;
	}

	public Date getJourneyDate() {
		return journeyDate;
	}

	public void setJourneyDate(Date journeyDate) {
		this.journeyDate = journeyDate;
	}

	public String getReservationClass() {
		return reservationClass;
	}

	public void setReservationClass(String reservationClass) {
		this.reservationClass = reservationClass;
	}

	public int getHalts() {
		return halts;
	}

	public void setHalts(int halts) {
		this.halts = halts;
	}

	public String getRoutePath() {
		return routePath;
	}

	public void setRoutePath(String routePath) {
		this.routePath = routePath;
	}

}
