package com.makemytrip.bo;

import java.util.Date;

public class FlightStatus {
	protected String flightNo;
	protected String flightName;
	protected Date departureTime;
	protected int availableSeats;
	protected double price;

	public FlightStatus(String flightNo, String flightName, Date departureTime, int availableSeats, double price) {
		super();
		this.flightNo = flightNo;
		this.flightName = flightName;
		this.departureTime = departureTime;
		this.availableSeats = availableSeats;
		this.price = price;
	}

	public String getFlightNo() {
		return flightNo;
	}

	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}

	public String getFlightName() {
		return flightName;
	}

	public void setFlightName(String flightName) {
		this.flightName = flightName;
	}

	public Date getDepartureTime() {
		return departureTime;
	}

	public void setDepartureTime(Date departureTime) {
		this.departureTime = departureTime;
	}

	public int getAvailableSeats() {
		return availableSeats;
	}

	public void setAvailableSeats(int availableSeats) {
		this.availableSeats = availableSeats;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

}
