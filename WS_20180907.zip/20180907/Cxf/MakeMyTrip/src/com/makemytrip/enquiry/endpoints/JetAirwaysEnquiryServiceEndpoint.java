package com.makemytrip.enquiry.endpoints;

import java.util.ArrayList;
import java.util.List;

import com.jetairways.enquiry.service.JetAirwaysEnquiryEndpoint;
import com.jetairways.enquiry.types.AvailabilityStatus;
import com.jetairways.enquiry.types.Trip;
import com.makemytrip.bo.EnquiryBo;
import com.makemytrip.bo.FlightStatus;

public class JetAirwaysEnquiryServiceEndpoint {
	private JetAirwaysEnquiryEndpoint jetAirwaysEnquiryEndpoint;

	public List<FlightStatus> enquire(EnquiryBo enquiryBo) {
		AvailabilityStatus availabilityStatus = null;
		List<FlightStatus> flightStatus = null;
		Trip trip = null;

		trip = new Trip();
		trip.setSource(enquiryBo.getSource());
		trip.setDestination(enquiryBo.getDestination());
		trip.setJourneyDate(null);
		trip.setHalts(enquiryBo.getHalts());
		trip.setTravelClass(enquiryBo.getReservationClass());
		trip.setTravelBy(enquiryBo.getRoutePath());

		availabilityStatus = jetAirwaysEnquiryEndpoint.enquireFlights(trip);
		flightStatus = new ArrayList<>();
		for (com.jetairways.enquiry.types.FlightStatus fs : availabilityStatus.getFlightStatus()) {
			flightStatus.add(
					new FlightStatus(fs.getFlightNo(), fs.getFlightName(), null, fs.getAvailableSeats(), fs.getFare()));
		}

		return flightStatus;
	}

	public void setJetAirwaysEnquiryEndpoint(JetAirwaysEnquiryEndpoint jetAirwaysEnquiryEndpoint) {
		this.jetAirwaysEnquiryEndpoint = jetAirwaysEnquiryEndpoint;
	}

}
