package io.swagger.api;

import io.swagger.model.*;
import io.swagger.api.BookticketApiService;
import io.swagger.api.factories.BookticketApiServiceFactory;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.media.ArraySchema;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;

import io.swagger.model.JourneyPlan;
import io.swagger.model.Ticket;

import java.util.Map;
import java.util.List;
import io.swagger.api.NotFoundException;

import java.io.InputStream;

import org.glassfish.jersey.media.multipart.FormDataContentDisposition;
import org.glassfish.jersey.media.multipart.FormDataParam;

import javax.servlet.ServletConfig;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.SecurityContext;
import javax.ws.rs.*;
import javax.validation.constraints.*;

@Path("/bookticket")

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJerseyServerCodegen", date = "2019-03-17T15:51:04.634Z[GMT]")
public class BookticketApi {
	private final BookticketApiService delegate;

	public BookticketApi(@Context ServletConfig servletContext) {
		BookticketApiService delegate = null;

		if (servletContext != null) {
			String implClass = servletContext.getInitParameter("BookticketApi.implementation");
			if (implClass != null && !"".equals(implClass.trim())) {
				try {
					delegate = (BookticketApiService) Class.forName(implClass).newInstance();
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
			}
		}

		if (delegate == null) {
			delegate = BookticketApiServiceFactory.getBookticketApi();
		}

		this.delegate = delegate;
	}

	@POST

	@Consumes({ "application/json" })
	@Produces({ "application/json" })
	@Operation(summary = "", description = "", tags = {})
	@ApiResponses(value = {
			@ApiResponse(responseCode = "200", description = "ticket information", content = @Content(schema = @Schema(implementation = Ticket.class))) })
	public Response bookticketPost(@Parameter(description = "") JourneyPlan body

			,
			@Parameter(description = "partner platform token should be passed") @HeaderParam("platform") String platform

			, @Context SecurityContext securityContext) throws NotFoundException {
		return delegate.bookticketPost(body, platform, securityContext);
	}
}











