package io.swagger.api.factories;

import io.swagger.api.BookticketApiService;
import io.swagger.api.impl.BookticketApiServiceImpl;

@javax.annotation.Generated(value = "io.swagger.codegen.v3.generators.java.JavaJerseyServerCodegen", date = "2019-03-17T15:51:04.634Z[GMT]")public class BookticketApiServiceFactory {
    private final static BookticketApiService service = new BookticketApiServiceImpl();

    public static BookticketApiService getBookticketApi() {
        return service;
    }
}
