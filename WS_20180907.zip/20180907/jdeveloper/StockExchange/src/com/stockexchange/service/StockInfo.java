package com.stockexchange.service;

import javax.jws.WebService;

import javax.xml.ws.BindingType;
import javax.xml.ws.soap.SOAPBinding;

@WebService(endpointInterface = "com.stockexchange.service.StockInfoPortType")
@BindingType(SOAPBinding.SOAP12HTTP_BINDING)
public class StockInfo {
    public float getStockPrice(String stockName) {
        return 393.34f;
    }
}
