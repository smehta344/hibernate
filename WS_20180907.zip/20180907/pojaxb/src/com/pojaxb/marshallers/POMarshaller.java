package com.pojaxb.marshallers;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;

import in.ebay.sales.types.ItemType;
import in.ebay.sales.types.OrderItemsType;
import in.ebay.sales.types.PurchaseOrderType;
import in.ebay.sales.types.ShippingAddressType;

public class POMarshaller {
	public static void main(String[] args) throws JAXBException {
		ItemType it = new ItemType();
		it.setItemCode("oc30");
		it.setQuantity(35);

		ShippingAddressType sat = new ShippingAddressType();
		sat.setAddressLine1("Racecourse Street");
		sat.setAddressLine2("Near Community Park");
		sat.setCity("Banglore");
		sat.setState("KN");
		sat.setZip(30346);
		sat.setCountry("India");

		OrderItemsType oi = new OrderItemsType();
		oi.getItem().add(it);

		PurchaseOrderType pot = new PurchaseOrderType();
		pot.setOrderItems(oi);
		pot.setShippingAddress(sat);

		JAXBContext jContext = JAXBContext.newInstance("in.ebay.sales.types");
		Marshaller marshaller = jContext.createMarshaller();
		marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
		marshaller.marshal(pot, System.out);
	}
}










