package com.pojaxb.unmarshallers;

import in.ebay.sales.types.PurchaseOrderType;

import java.io.File;

import javax.xml.XMLConstants;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBElement;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Unmarshaller;
import javax.xml.validation.Schema;
import javax.xml.validation.SchemaFactory;

import org.xml.sax.SAXException;

public class POUnMarshaller {
	public static void main(String[] args) throws JAXBException, SAXException {
		SchemaFactory sFactory = SchemaFactory
				.newInstance(XMLConstants.W3C_XML_SCHEMA_NS_URI);
		Schema poSchema = sFactory.newSchema(new File(
				"C:\\work\\20180907\\pojaxb\\resources\\po.xsd"));

		JAXBContext jContext = JAXBContext.newInstance("in.ebay.sales.types");
		Unmarshaller unMarshaller = jContext.createUnmarshaller();
		unMarshaller.setSchema(poSchema);
		
		JAXBElement<PurchaseOrderType> jElement = (JAXBElement<PurchaseOrderType>) unMarshaller
				.unmarshal(new File(
						"C:\\work\\20180907\\pojaxb\\resources\\po.xml"));
		PurchaseOrderType pot = jElement.getValue();
		System.out.println(pot.getOrderItems().getItem().get(0).getItemCode());
	}
}









