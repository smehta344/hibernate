package com.kindle.dp.store;

import java.net.MalformedURLException;
import java.net.URL;
import java.rmi.RemoteException;

import javax.xml.namespace.QName;
import javax.xml.rpc.Service;
import javax.xml.rpc.ServiceException;
import javax.xml.rpc.ServiceFactory;

import com.kindle.wrox.service.bindings.BookInfo;

public class StoreTest {
	private static final String WSDL_URL = "http://localhost:8080/WroxConnect/bookPrice?WSDL";
	private static final String TARGET_NMSPC = "http://www.wrox.com/publisher/service";
	private static final String SERVICE_NM = "BookInfoService";
	private static final String PORT_NM = "BookInfoPort";

	public static void main(String[] args) throws ServiceException,
			MalformedURLException, RemoteException {
		ServiceFactory serviceFactory = ServiceFactory.newInstance();
		Service bookInfoService = serviceFactory.createService(
				new URL(WSDL_URL), new QName(TARGET_NMSPC, SERVICE_NM));

		BookInfo port = (BookInfo) bookInfoService.getPort(new QName(
				TARGET_NMSPC, PORT_NM), BookInfo.class);
		float price = port.getBookPrice("isbn1001");
		System.out.println("price : " + price);
	}
}

















