package com.kindle.store;

import java.rmi.RemoteException;

import javax.xml.rpc.ServiceException;

import com.kindle.wrox.service.bindings.BookInfo;
import com.kindle.wrox.service.bindings.BookInfoService;
import com.kindle.wrox.service.bindings.BookInfoService_Impl;

public class StoreTest {
	public static void main(String[] args) throws ServiceException, RemoteException {
		BookInfoService bookInfoService = new BookInfoService_Impl();
		BookInfo port = bookInfoService.getBookInfoPort();
		float price = port.getBookPrice("isbn1001");
		System.out.println("price: " + price);
	}
}













