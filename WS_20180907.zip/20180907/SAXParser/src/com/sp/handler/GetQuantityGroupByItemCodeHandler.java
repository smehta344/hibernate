package com.sp.handler;

import java.util.HashMap;
import java.util.Map;

import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

public class GetQuantityGroupByItemCodeHandler extends DefaultHandler {
	private Map<String, Integer> itemCodeQuantityMap;
	private String elementName;
	private String itemCode;

	@Override
	public void startDocument() throws SAXException {
		itemCodeQuantityMap = new HashMap<String, Integer>();
	}

	@Override
	public void startElement(String uri, String localName, String qName, Attributes attributes) throws SAXException {
		elementName = qName;
	}

	@Override
	public void endElement(String uri, String localName, String qName) throws SAXException {
		elementName = null;
	}

	@Override
	public void characters(char[] ch, int start, int length) throws SAXException {
		String data = null;

		if (elementName != null) {
			if (elementName.equals("item-code")) {
				data = new String(ch, start, length);
				itemCode = data;
			} else if (elementName.equals("quantity")) {
				int quantity = 0;

				data = new String(ch, start, length);
				quantity = Integer.parseInt(data);
				if (itemCodeQuantityMap.containsKey(itemCode)) {
					quantity = quantity + itemCodeQuantityMap.get(itemCode);
					itemCodeQuantityMap.put(itemCode, quantity);
				} else {
					itemCodeQuantityMap.put(itemCode, quantity);
				}

			}
		}
	}

	public final Map<String, Integer> getItemCodeQuantityMap() {
		return itemCodeQuantityMap;
	}

}
