package com.sp.test;

import java.io.File;
import java.io.IOException;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

import com.sp.handler.PurchaseOrderTotalQuantityHandler;

public class TotalQuantityTest {
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		SAXParserFactory sFactory = SAXParserFactory.newInstance();
		SAXParser parser = sFactory.newSAXParser();
		PurchaseOrderTotalQuantityHandler handler = new PurchaseOrderTotalQuantityHandler();

		parser.parse(new File("D:\\work\\master\\webservices\\20180907\\SAXParser\\resources\\po1.xml"), handler);
		System.out.println("total quantity : " + handler.getTotalQuanity());

		parser.parse(new File("D:\\work\\master\\webservices\\20180907\\SAXParser\\resources\\po2.xml"), handler);
		System.out.println("total quantity : " + handler.getTotalQuanity());
	}
}
