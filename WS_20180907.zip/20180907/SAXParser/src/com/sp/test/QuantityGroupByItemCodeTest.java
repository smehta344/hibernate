package com.sp.test;

import java.io.File;
import java.io.IOException;
import java.util.Map;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.xml.sax.SAXException;

import com.sp.handler.GetQuantityGroupByItemCodeHandler;

public class QuantityGroupByItemCodeTest {
	public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException {
		SAXParserFactory sFactory = SAXParserFactory.newInstance();
		SAXParser parser = sFactory.newSAXParser();
		GetQuantityGroupByItemCodeHandler handler = new GetQuantityGroupByItemCodeHandler();
		parser.parse(new File("D:\\\\work\\\\master\\\\webservices\\\\20180907\\\\SAXParser\\\\resources\\\\po1.xml"),
				handler);

		Map<String, Integer> itemCodeQuantityMap = handler.getItemCodeQuantityMap();
		int totalQuantity = 0;
		for (String itemCode : itemCodeQuantityMap.keySet()) {
			System.out.println(itemCode + " : " + itemCodeQuantityMap.get(itemCode));
			totalQuantity = totalQuantity + itemCodeQuantityMap.get(itemCode);
		}
		System.out.println("Total Quantiy : " + totalQuantity);
	}
}
