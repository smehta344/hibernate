@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.hdfc.com/bank/types")
package com.hdfc.bank.types;
