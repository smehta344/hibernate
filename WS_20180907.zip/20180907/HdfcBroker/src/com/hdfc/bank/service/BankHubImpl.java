package com.hdfc.bank.service;

import java.util.Date;
import java.util.UUID;

import javax.jws.WebService;

import com.hdfc.bank.types.Account;
import com.hdfc.bank.types.Receipt;

@WebService(endpointInterface = "com.hdfc.bank.service.BankHub")
public class BankHubImpl {

	public Receipt transfer(Account fromAccount, Account toAccount, float amount) {
		Receipt receipt = null;

		receipt = new Receipt();
		receipt.setTxRefNo(UUID.randomUUID().toString());
		receipt.setTxDate(new Date());
		receipt.setStatus("success");
		return receipt;
	}

}
