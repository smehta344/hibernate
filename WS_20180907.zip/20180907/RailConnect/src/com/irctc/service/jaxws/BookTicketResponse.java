
package com.irctc.service.jaxws;

import javax.xml.bind.annotation.AccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.irctc.service.jaxws.BookTicketResponse;

@XmlRootElement(name = "bookTicketResponse", namespace = "http://www.irctc.co.in/rail/service")
@XmlAccessorType(AccessType.FIELD)
@XmlType(name = "bookTicketResponse", namespace = "http://www.irctc.co.in/rail/service")
public class BookTicketResponse {

    @XmlElement(name = "ticket", namespace = "http://www.irctc.co.in/rail/types")
    private com.irctc.dto.Ticket _return;

    /**
     * 
     * @return
     *     returns Ticket
     */
    public com.irctc.dto.Ticket get_return() {
        return this._return;
    }

    /**
     * 
     * @param _return
     *     the value for the _return property
     */
    public void set_return(com.irctc.dto.Ticket _return) {
        this._return = _return;
    }

}
