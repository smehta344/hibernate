
package com.irctc.service.jaxws;

import javax.xml.bind.annotation.AccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;
import com.irctc.service.jaxws.BookTicket;

@XmlRootElement(name = "bookTicket", namespace = "http://www.irctc.co.in/rail/service")
@XmlAccessorType(AccessType.FIELD)
@XmlType(name = "bookTicket", namespace = "http://www.irctc.co.in/rail/service", propOrder = {
    "journeyInfo",
    "passengerInfo"
})
public class BookTicket {

    @XmlElement(name = "journeyInfo", namespace = "http://www.irctc.co.in/rail/types")
    private com.irctc.dto.JourneyInfo journeyInfo;
    @XmlElement(name = "passengerInfo", namespace = "http://www.irctc.co.in/rail/types")
    private com.irctc.dto.PassengerInfo passengerInfo;

    /**
     * 
     * @return
     *     returns JourneyInfo
     */
    public com.irctc.dto.JourneyInfo getJourneyInfo() {
        return this.journeyInfo;
    }

    /**
     * 
     * @param journeyInfo
     *     the value for the journeyInfo property
     */
    public void setJourneyInfo(com.irctc.dto.JourneyInfo journeyInfo) {
        this.journeyInfo = journeyInfo;
    }

    /**
     * 
     * @return
     *     returns PassengerInfo
     */
    public com.irctc.dto.PassengerInfo getPassengerInfo() {
        return this.passengerInfo;
    }

    /**
     * 
     * @param passengerInfo
     *     the value for the passengerInfo property
     */
    public void setPassengerInfo(com.irctc.dto.PassengerInfo passengerInfo) {
        this.passengerInfo = passengerInfo;
    }

}
