package com.irctc.service;

import javax.jws.WebService;

import com.irctc.dto.JourneyInfo;
import com.irctc.dto.PassengerInfo;
import com.irctc.dto.Ticket;

@WebService(endpointInterface = "com.irctc.service.RailConnect", serviceName = "RailConnectService", portName = "RailConnectSOAPPort")
public class RailConnectImpl {

	public Ticket bookTicket(JourneyInfo journeyInfo,
			PassengerInfo passengerInfo) {
		
		Ticket ticket = null;
		ticket = new Ticket();
		ticket.setPnrNo("39830");
		ticket.setBerth(passengerInfo.getAge());
		ticket.setCoach("s1");
		ticket.setStatus("CNF");

		return ticket;
	}

}
