package com.irctc.service;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebResult;
import javax.jws.WebService;

import com.irctc.dto.JourneyInfo;
import com.irctc.dto.PassengerInfo;
import com.irctc.dto.Ticket;

@WebService(targetNamespace = "http://www.irctc.co.in/rail/service")
public interface RailConnect {
	@WebResult(name = "ticket", targetNamespace = "http://www.irctc.co.in/rail/types")
	@WebMethod(action = "http://www.irctc.co.in/rail/services:bookTicket")
	Ticket bookTicket(
			@WebParam(name = "journeyInfo", targetNamespace = "http://www.irctc.co.in/rail/types") JourneyInfo journeyInfo,
			@WebParam(name = "passengerInfo", targetNamespace = "http://www.irctc.co.in/rail/types") PassengerInfo passengerInfo);
}
