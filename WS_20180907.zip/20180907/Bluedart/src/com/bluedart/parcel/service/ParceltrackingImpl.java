package com.bluedart.parcel.service;

import javax.jws.WebService;

import com.bluedart.parcel.types.Cause;
import com.bluedart.parcel.types.ParcelInfo;
import com.bluedart.parcel.types.Status;

@WebService(endpointInterface = "com.bluedart.parcel.service.Parceltracking")
public class ParceltrackingImpl {

	public Status track(ParcelInfo in) throws NoParcelFoundFaultMessage {
		Status status = null;
		Cause cause = null;
		NoParcelFoundFaultMessage noParcelFoundFaultMessage = null;

		if (in.getTrackingNo() == null
				|| in.getTrackingNo().trim().length() < 16) {
			cause = new Cause();
			cause.setCode("100");
			cause.setDescription("tracking no must be 16 characters");
			noParcelFoundFaultMessage = new NoParcelFoundFaultMessage(
					"tracking failure", cause);
			throw noParcelFoundFaultMessage;
		}

		status = new Status();
		status.setTrackingNo(in.getTrackingNo());
		status.setDescription("in-transit");
		status.setDeliveryStatus("Out for delivery");

		return status;
	}

}
