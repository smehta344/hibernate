@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.bluedart.com/parcel/types")
package com.bluedart.parcel.types;
