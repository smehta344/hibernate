package com.wrox.endpoint;

import java.rmi.RemoteException;

public class BookInfoImpl implements BookInfo {
	public float getBookPrice(String isbn) throws RemoteException {
		float price = 0.0f;

		if (isbn == null || isbn.trim().length() == 0) {
			throw new RemoteException("isbn is not valid");
		}
		if (isbn.equals("isbn1001")) {
			price = 989.3f;
		} else if (isbn.equals("isbn2001")) {
			price = 768.34f;
		} else {
			price = 304.45f;
		}
		return price;
	}

}
