package com.el.test;

import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.el.bo.Product;
import com.el.dao.ProductDao;

public class ELTest {
	public static void main(String[] args) {
		ApplicationContext context = new ClassPathXmlApplicationContext("com/el/common/application-context.xml");
		ProductDao productDao = context.getBean("productDao", ProductDao.class);
		List<Product> products = productDao.getProducts();
		for (Product product : products) {
			System.out.println(product);
		}
	}
}
