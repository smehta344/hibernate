package com.el.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.el.bo.Product;

public class ProductDao {
	private final String SQL_GET_PRODUCTS = "select product_no, product_nm from product";
	private JdbcTemplate jdbcTemplate;

	public ProductDao(JdbcTemplate jdbcTemplate) {
		this.jdbcTemplate = jdbcTemplate;
	}

	public List<Product> getProducts() {
		return jdbcTemplate.query(SQL_GET_PRODUCTS, new RowMapper<Product>() {
			@Override
			public Product mapRow(ResultSet rs, int rowNum) throws SQLException {
				return new Product(rs.getInt(1), rs.getString(2));
			}

		});
	}

}
