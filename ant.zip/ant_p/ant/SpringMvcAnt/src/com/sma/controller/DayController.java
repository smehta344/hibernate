package com.sma.controller;

import java.util.Calendar;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

public class DayController extends AbstractController {
	@Override
	protected ModelAndView handleRequestInternal(HttpServletRequest req, HttpServletResponse resp) throws Exception {
		ModelAndView mav = null;
		Calendar calendar = null;
		String day = null;

		calendar = Calendar.getInstance();
		day = calendar.getDisplayName(Calendar.DAY_OF_WEEK, Calendar.LONG_FORMAT, Locale.getDefault());

		mav = new ModelAndView();
		mav.addObject("day", day);
		mav.setViewName("spring-ant");

		return mav;
	}

}
