package com.uv.test;

import com.uv.helper.MatrixGenerator;

public class SudokuTest {
	public static void main(String[] args) {
		int rows = 3;
		int cols = 3;
		int[][] matrix = null;
		MatrixGenerator matrixGenerator = null;

		matrixGenerator = new MatrixGenerator();
		matrix = matrixGenerator.generate(rows, cols);
		for (int i = 0; i < rows; i++) {
			for (int j = 0; j < cols; j++) {
				System.out.print(normalize(matrix[i][j]));
			}
			System.out.println("");
		}
	}

	private static String normalize(int value) {
		StringBuffer sb = null;

		sb = new StringBuffer();
		if (value <= 9) {
			sb.append(value).append("    ");
		} else if (value <= 99) {
			sb.append(value).append("   ");
		} else {
			sb.append(value).append("  ");
		}
		return sb.toString();
	}
}
