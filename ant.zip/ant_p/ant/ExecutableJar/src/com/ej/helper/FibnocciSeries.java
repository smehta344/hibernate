package com.ej.helper;

public class FibnocciSeries {
	public int[] series(int n) {
		int[] in = null;

		in = new int[n];
		in[0] = 0;
		in[1] = 1;
		for (int i = 2; i < n; i++) {
			in[i] = in[i - 1] + in[i - 2];
		}

		return in;
	}
}
