package com.ct.test;

import com.dt.helper.StringUtils;

public class CTTest {
	public static void main(String[] args) {
		StringUtils stringUtils = null;

		stringUtils = new StringUtils();
		boolean flag = stringUtils.isPalindrome("madam");
		System.out.println("is palindrom : " + flag);
	}
}
