package com.dj.test;

import com.dj.util.Arrays;

public class DJTest {
	public static void main(String[] args) {
		Arrays arrays = null;
		int[] in = {10, 1, 5, 12, 9, 45, 2};
		int[] sort = null;
		
		arrays = new Arrays();
		sort = arrays.sort(in);
		System.out.println("original array");
		for(int i=0;i<in.length;i++) {
			System.out.print(in[i]+" ");
		}
		System.out.println("");
		System.out.println("sorted array");
		for(int i=0;i<in.length;i++) {
			System.out.print(sort[i]+ " ");
		}
	}
}
