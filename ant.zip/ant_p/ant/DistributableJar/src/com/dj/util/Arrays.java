package com.dj.util;

public class Arrays {

	public int[] sort(int[] in) {
		int[] sort = null;

		sort = new int[in.length];
		for (int i = 0; i < in.length; i++) {
			sort[i] = in[i];
		}

		for (int i = 0; i < sort.length; i++) {
			for (int j = 0; j < sort.length - 1 - i; j++) {
				if (sort[j] > sort[j + 1]) {
					int t = sort[j];
					sort[j] = sort[j + 1];
					sort[j + 1] = t;
				}
			}
		}

		return sort;
	}

}
