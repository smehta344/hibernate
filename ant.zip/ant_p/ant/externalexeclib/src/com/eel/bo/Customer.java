package com.eel.bo;

public class Customer {
	protected int customerNo;
	protected String customerName;

	public Customer(int customerNo, String customerName) {
		this.customerNo = customerNo;
		this.customerName = customerName;
	}

	public int getCustomerNo() {
		return customerNo;
	}

	public void setCustomerNo(int customerNo) {
		this.customerNo = customerNo;
	}

	public String getCustomerName() {
		return customerName;
	}

	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}

	@Override
	public String toString() {
		return "Customer [customerNo=" + customerNo + ", customerName=" + customerName + "]";
	}

}
