package com.bj.helper;

public class ArrayHelper {
	public int findElementPos(int[] inArray, int element) {
		int pos = -1;

		for (int i = 0; i < inArray.length; i++) {
			if (inArray[i] == element) {
				pos = i;
				break;
			}
		}

		return pos;
	}
}
